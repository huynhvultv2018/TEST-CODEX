"""Route/cookie inventory and harmless state-changing requests in isolated Flask clients."""
import inspect,json
from io import BytesIO
from openpyxl import Workbook
from audit_support import arguments,runtime,sql,dump,seed,attempt

def category(path):
 if path in ('/','/teacher/login') or 'password' in path:return 'authentication'
 if '/accounts' in path:return 'admin accounts'
 if '/settings' in path or '/license' in path:return 'admin settings/license'
 if '/restore' in path or '/backup' in path:return 'backup/restore'
 if '/unlock' in path:return 'exam unlock'
 if 'import' in path:return 'import'
 if '/student' in path:return 'student management'
 if '/question' in path or '/multi' in path:return 'question management'
 if path in ('/exam','/api/save-answer','/api/ping'):return 'student exam'
 return 'teacher exam'

def main():
 args=arguments();out={'inventory':[],'server_requests':[],'custom_import_token':{}}
 with runtime(args.source,args.output) as (m,admin,root):
  out['cookie_config']={key:m.app.config.get(key) for key in ['SESSION_COOKIE_NAME','SESSION_COOKIE_SAMESITE','SESSION_COOKIE_SECURE','SESSION_COOKIE_HTTPONLY','SESSION_COOKIE_DOMAIN','SESSION_COOKIE_PATH','PERMANENT_SESSION_LIFETIME']}
  out['cookie_config']['PERMANENT_SESSION_LIFETIME']=str(out['cookie_config']['PERMANENT_SESSION_LIFETIME'])
  out['session_interface']=type(m.app.session_interface).__module__+'.'+type(m.app.session_interface).__name__
  login=m.app.test_client().post('/teacher/login',data=dict(username='admin',password='123456'))
  header=login.headers.get('Set-Cookie','');out['actual_Set_Cookie_attributes']=header.split(';')[1:];out['actual_Set_Cookie_value_redacted']=True
  for rule in sorted(m.app.url_map.iter_rules(),key=lambda r:(r.rule,r.endpoint)):
   methods=sorted(set(rule.methods)&{'POST','PUT','PATCH','DELETE'})
   if not methods:continue
   fn=inspect.unwrap(m.app.view_functions[rule.endpoint]);source=inspect.getsource(fn);file=inspect.getsourcefile(fn);line=inspect.getsourcelines(fn)[1]
   role='ADMIN' if '@admin_required' in source else 'TEACHER/ADMIN' if '@teacher_required' in source or '@guard' in source else 'STUDENT attempt session' if rule.rule in ('/exam','/api/save-answer','/api/ping') else 'no existing session required; credentials/student code checked'
   custom='session-bound student_import_token + compare_digest(form token)' if rule.endpoint=='confirm_student_import' else 'client_token in signed session matched to DB (attempt ownership; not independent CSRF request token)' if rule.rule in ('/exam','/api/save-answer','/api/ping') else 'none'
   out['inventory'].append(dict(methods=methods,path=rule.rule,endpoint=rule.endpoint,category=category(rule.rule),auth_required=role,role=role,CSRF_protection='operation nonce on import-confirm only' if rule.endpoint=='confirm_student_import' else 'no general CSRF',origin_check=False,referer_check=False,custom_token=custom,session_cookie_dependency=role in ('ADMIN','TEACHER/ADMIN','STUDENT attempt session'),source_file='PHAN_MEM/'+file.rsplit('/',1)[-1],source_line=line))
  teacher_create=admin.post('/teacher/accounts/add',data=dict(username='probe_teacher',ho_ten='Probe teacher',vai_tro='GIAOVIEN',password='Probe123456'));assert teacher_create.status_code==302
  teacher=m.app.test_client();assert teacher.post('/teacher/login',data=dict(username='probe_teacher',password='Probe123456')).status_code==302
  for role,client in [('ADMIN',admin),('GIAOVIEN',teacher)]:
   for scenario,headers in [('missing',{}),('foreign_Origin',{'Origin':'http://foreign.invalid:8080'}),('foreign_Referer',{'Referer':'http://foreign.invalid:8080/page'}),('foreign_both',{'Origin':'http://foreign.invalid:8080','Referer':'http://foreign.invalid:8080/page'})]:
    code='CSRF_'+role+'_'+scenario;before=sql(m,'SELECT COUNT(*) FROM hoc_sinh')[0][0]
    r=client.post('/teacher/student/add',data=dict(ma_hs=code,ho_ten='Harmless CSRF fixture',lop='8A'),headers=headers)
    after=sql(m,'SELECT COUNT(*) FROM hoc_sinh')[0][0];assert after==before+1
    out['server_requests'].append(dict(role=role,method='POST',path='/teacher/student/add',headers=headers,csrf_token_sent=False,status=r.status_code,student_rows_added=after-before))
  for scenario,headers in [('missing',{}),('foreign',{'Origin':'http://foreign.invalid:8080','Referer':'http://foreign.invalid:8080/page'})]:
   value='CSRF harmless school '+scenario;r=admin.post('/teacher/settings',data=dict(school_name=value,system_name='AUDIT',server_port='5000'),headers=headers)
   stored=sql(m,"SELECT gia_tri FROM cai_dat WHERE khoa='school_name'")[0][0];assert stored==value
   out['server_requests'].append(dict(role='ADMIN',method='POST',path='/teacher/settings',headers=headers,csrf_token_sent=False,status=r.status_code,setting_changed=True))
  # Authorization still works; missing CSRF does not mean missing authentication.
  code='ANONYMOUS_REJECT';r=m.app.test_client().post('/teacher/student/add',data=dict(ma_hs=code,ho_ten='Anonymous',lop='8A'))
  assert not sql(m,'SELECT id FROM hoc_sinh WHERE ma_hs=?',(code,))
  out['unauthenticated_probe']=dict(status=r.status_code,location=r.location,rows_added=0)
  r=teacher.post('/teacher/settings',data=dict(school_name='Should not change',server_port='5000'));assert sql(m,"SELECT gia_tri FROM cai_dat WHERE khoa='school_name'")[0][0]!='Should not change'
  out['role_control_probe']=dict(teacher_admin_setting_status=r.status_code,setting_changed=False)
  seed(m,admin,'CSRF_STUDENT','SINGLE',subject='CSRF_STUDENT');student,aid,eid,data=attempt(m,admin,'CSRF_STUDENT',subject='CSRF_STUDENT')
  response=student.post('/api/save-answer',json=dict(index=0,choice=data[0]['answer']),headers={'Origin':'http://foreign.invalid'})
  out['student_JSON_server_probe']=dict(status=response.status_code,headers={'Origin':'http://foreign.invalid'},csrf_token_sent=False,answer_written=bool(sql(m,'SELECT id FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))),browser_preflight_not_bypassed_by_this_test=True)
  # Existing student preview-confirm operation token is a real narrow exception.
  wb=Workbook();wb.active.append(['Mã HS','Họ tên','Lớp']);wb.active.append(['IMPORT_NONCE','Import nonce fixture','8A']);b=BytesIO();wb.save(b);wb.close()
  assert admin.post('/teacher/students/import-preview',data={'file':(BytesIO(b.getvalue()),'probe.xlsx')},content_type='multipart/form-data').status_code==200
  with admin.session_transaction() as s:nonce=s['student_import_token']
  wrong=admin.post('/teacher/students/import-confirm',data={'token':'wrong','mode':'update'},headers={'Origin':'http://foreign.invalid'})
  assert not sql(m,"SELECT id FROM hoc_sinh WHERE ma_hs='IMPORT_NONCE'")
  valid=admin.post('/teacher/students/import-confirm',data={'token':nonce,'mode':'update'},headers={'Origin':'http://foreign.invalid'})
  assert sql(m,"SELECT id FROM hoc_sinh WHERE ma_hs='IMPORT_NONCE'")
  out['custom_import_token']=dict(wrong_token_status=wrong.status_code,wrong_token_writes=0,valid_token_foreign_origin_status=valid.status_code,valid_token_writes=1,nonce_value_not_exported=True)
  out['GET_state_changes']=[dict(path='/teacher/logout',effect='session clear + logout audit',CSRF_protection='none'),dict(path='/exam',effect='last_seen update, expired attempt finalization',CSRF_protection='attempt cookie/token only')]
 out['audit_completed']=True;dump(args.output/'results.json',out);print(json.dumps(out,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
