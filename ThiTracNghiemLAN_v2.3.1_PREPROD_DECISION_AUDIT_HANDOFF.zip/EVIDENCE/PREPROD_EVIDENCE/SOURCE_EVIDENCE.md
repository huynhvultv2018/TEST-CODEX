# Numbered source evidence from the SHA-256 locked R3 candidate

Read-only excerpts; not a patched source or candidate.

### PHAN_MEM/app.py:271 — init_db

```python
271: def init_db():
272:     c=db()
273:     c.executescript("""
274:     CREATE TABLE IF NOT EXISTS tai_khoan_gv(
275:       id INTEGER PRIMARY KEY AUTOINCREMENT,
276:       username TEXT UNIQUE NOT NULL,
277:       password_salt TEXT NOT NULL,
278:       password_hash TEXT NOT NULL,
279:       ho_ten TEXT,
280:       vai_tro TEXT NOT NULL DEFAULT 'GIAOVIEN',
281:       active INTEGER NOT NULL DEFAULT 1,
282:       failed_attempts INTEGER NOT NULL DEFAULT 0,
283:       locked_until TEXT,
284:       last_login TEXT,
285:       created_at TEXT
286:     );
287:     CREATE TABLE IF NOT EXISTS nhat_ky(
288:       id INTEGER PRIMARY KEY AUTOINCREMENT,
289:       thoi_gian TEXT NOT NULL,
290:       username TEXT,
291:       hanh_dong TEXT NOT NULL,
292:       chi_tiet TEXT,
293:       ip TEXT
294:     );
295:     CREATE TABLE IF NOT EXISTS cai_dat(
296:       khoa TEXT PRIMARY KEY,
297:       gia_tri TEXT
298:     );
299:     CREATE TABLE IF NOT EXISTS hoc_sinh(
300:       id INTEGER PRIMARY KEY AUTOINCREMENT,
301:       ma_hs TEXT UNIQUE NOT NULL,
302:       ho_ten TEXT NOT NULL,
303:       lop TEXT NOT NULL
304:     );
305:     CREATE TABLE IF NOT EXISTS cau_hoi(
306:       id INTEGER PRIMARY KEY AUTOINCREMENT,
307:       ma_cau TEXT,
308:       mon TEXT,
309:       chu_de TEXT,
310:       muc_do TEXT,
311:       noi_dung TEXT NOT NULL,
312:       a TEXT NOT NULL,b TEXT NOT NULL,c TEXT NOT NULL,d TEXT NOT NULL,
313:       dap_an_dung TEXT NOT NULL,
314:       hinh_anh TEXT
315:     );
316:     CREATE TABLE IF NOT EXISTS ky_thi(
317:       id INTEGER PRIMARY KEY AUTOINCREMENT,
318:       ten TEXT NOT NULL,
319:       lop TEXT,
320:       mon TEXT,
321:       so_cau INTEGER NOT NULL,
322:       thoi_gian_phut INTEGER NOT NULL,
323:       chu_de TEXT,
324:       muc_do TEXT,
325:       nb_count INTEGER NOT NULL DEFAULT 0,
326:       th_count INTEGER NOT NULL DEFAULT 0,
327:       vd_count INTEGER NOT NULL DEFAULT 0,
328:       vdc_count INTEGER NOT NULL DEFAULT 0,
329:       hien_diem INTEGER NOT NULL DEFAULT 1,
330:       trang_thai TEXT NOT NULL DEFAULT 'MO',
331:       created_at TEXT NOT NULL
332:     );
333:     CREATE TABLE IF NOT EXISTS bai_thi(
334:       id INTEGER PRIMARY KEY AUTOINCREMENT,
335:       ky_thi_id INTEGER NOT NULL,
336:       ma_hs TEXT NOT NULL,
337:       ho_ten TEXT NOT NULL,
338:       lop TEXT NOT NULL,
339:       started_at TEXT NOT NULL,
340:       deadline_at TEXT NOT NULL,
341:       submitted_at TEXT,
342:       de_json TEXT NOT NULL,
343:       so_cau_dung INTEGER,
344:       tong_so_cau INTEGER,
345:       diem REAL,
346:       last_seen_at TEXT,
347:       client_token TEXT,
348:       force_relogin INTEGER NOT NULL DEFAULT 0,
349:       UNIQUE(ky_thi_id,ma_hs)
350:     );
351:     CREATE TABLE IF NOT EXISTS cau_tra_loi(
352:       id INTEGER PRIMARY KEY AUTOINCREMENT,
353:       bai_thi_id INTEGER NOT NULL,
354:       vi_tri_cau INTEGER NOT NULL,
355:       cau_hoi_id INTEGER NOT NULL,
356:       lua_chon INTEGER,
357:       dung INTEGER NOT NULL DEFAULT 0,
358:       saved_at TEXT NOT NULL,
359:       UNIQUE(bai_thi_id,vi_tri_cau)
360:     );
361:     """)
362:     cols=[r["name"] for r in c.execute("PRAGMA table_info(cau_hoi)").fetchall()]
363:     if "hinh_anh" not in cols:
364:         c.execute("ALTER TABLE cau_hoi ADD COLUMN hinh_anh TEXT")
365:     cols=[r["name"] for r in c.execute("PRAGMA table_info(bai_thi)").fetchall()]
366:     if "last_seen_at" not in cols:
367:         c.execute("ALTER TABLE bai_thi ADD COLUMN last_seen_at TEXT")
368:     if "client_token" not in cols:
369:         c.execute("ALTER TABLE bai_thi ADD COLUMN client_token TEXT")
370:     if "force_relogin" not in cols:
371:         c.execute("ALTER TABLE bai_thi ADD COLUMN force_relogin INTEGER NOT NULL DEFAULT 0")
372:     acc_cols=[r["name"] for r in c.execute("PRAGMA table_info(tai_khoan_gv)").fetchall()]
373:     if "ho_ten" not in acc_cols:
374:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN ho_ten TEXT")
375:     if "vai_tro" not in acc_cols:
376:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN vai_tro TEXT NOT NULL DEFAULT 'GIAOVIEN'")
377:     if "active" not in acc_cols:
378:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
379:     if "failed_attempts" not in acc_cols:
380:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN failed_attempts INTEGER NOT NULL DEFAULT 0")
381:     if "locked_until" not in acc_cols:
382:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN locked_until TEXT")
383:     if "last_login" not in acc_cols:
384:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN last_login TEXT")
385:     if "created_at" not in acc_cols:
386:         c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN created_at TEXT")
387:     # v2.2.1: indexes keep search/filter responsive with large school rosters.
388:     c.execute("CREATE INDEX IF NOT EXISTS idx_hoc_sinh_lop_hoten ON hoc_sinh(lop,ho_ten)")
389:     c.execute("CREATE INDEX IF NOT EXISTS idx_hoc_sinh_hoten ON hoc_sinh(ho_ten)")
390:     exam_cols=[r["name"] for r in c.execute("PRAGMA table_info(ky_thi)").fetchall()]
391:     if "nb_count" not in exam_cols:
392:         c.execute("ALTER TABLE ky_thi ADD COLUMN nb_count INTEGER NOT NULL DEFAULT 0")
393:     if "th_count" not in exam_cols:
394:         c.execute("ALTER TABLE ky_thi ADD COLUMN th_count INTEGER NOT NULL DEFAULT 0")
395:     if "vd_count" not in exam_cols:
396:         c.execute("ALTER TABLE ky_thi ADD COLUMN vd_count INTEGER NOT NULL DEFAULT 0")
397:     if "vdc_count" not in exam_cols:
398:         c.execute("ALTER TABLE ky_thi ADD COLUMN vdc_count INTEGER NOT NULL DEFAULT 0")
399:     if not c.execute("SELECT 1 FROM tai_khoan_gv WHERE username='admin'").fetchone():
400:         salt,digest=hash_password("123456")
401:         c.execute("""INSERT INTO tai_khoan_gv(
402:                      username,password_salt,password_hash,ho_ten,vai_tro,active,
403:                      failed_attempts,created_at)
404:                      VALUES(?,?,?,?, 'ADMIN',1,0,?)""",
405:                   ("admin",salt,digest,"Quản trị viên",datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
406:     else:
407:         c.execute("UPDATE tai_khoan_gv SET vai_tro='ADMIN',active=1 WHERE username='admin'")
408: 
409:     defaults={
410:         "school_name":"TRƯỜNG THCS",
411:         "system_name":"THI TRẮC NGHIỆM LAN",
412:         "support_text":"",
413:         "logo_file":"",
414:         "license_name":"",
415:         "license_code":"",
416:         "server_port":"5000"
417:     }
418:     for k,v in defaults.items():
419:         c.execute("INSERT OR IGNORE INTO cai_dat(khoa,gia_tri) VALUES(?,?)",(k,v))
420:     c.commit(); c.close()
```

### PHAN_MEM/app.py:81 — teacher_required

```python
81: def teacher_required(f):
82:     @wraps(f)
83:     def wrapped(*args,**kwargs):
84:         if not session.get("teacher_logged_in"):
85:             return redirect(url_for("teacher_login"))
86:         return f(*args,**kwargs)
87:     return wrapped
```

### PHAN_MEM/app.py:90 — admin_required

```python
90: def admin_required(f):
91:     @wraps(f)
92:     def wrapped(*args,**kwargs):
93:         if not session.get("teacher_logged_in"):
94:             return redirect(url_for("teacher_login"))
95:         if session.get("teacher_role")!="ADMIN":
96:             flash("Chức năng này chỉ dành cho quản trị viên.")
97:             return redirect(url_for("teacher"))
98:         return f(*args,**kwargs)
99:     return wrapped
```

### PHAN_MEM/app.py:422 — norm_answer

```python
422: def norm_answer(x):
423:     s="" if x is None else str(x).strip().upper()
424:     return s if s in ("A","B","C","D") else ""
```

### PHAN_MEM/app.py:494 — build_exam

```python
494: def build_exam(kt):
495:     topics=exam_topics(kt["chu_de"])
496:     sql,args=_question_filters(kt["mon"] or "",topics)
497:     c=db()
498:     rows=list(c.execute(sql,args).fetchall())
499:     c.close()
500: 
501:     quotas={
502:         "NB": int(kt["nb_count"] or 0),
503:         "TH": int(kt["th_count"] or 0),
504:         "VD": int(kt["vd_count"] or 0),
505:         "VDC": int(kt["vdc_count"] or 0),
506:     }
507: 
508:     selected=[]
509:     if sum(quotas.values())>0:
510:         # Exact number of questions from each cognitive level.
511:         by_level={"NB":[],"TH":[],"VD":[],"VDC":[]}
512:         for r in rows:
513:             lv=(r["muc_do"] or "").strip().upper()
514:             if lv in by_level:
515:                 by_level[lv].append(r)
516: 
517:         for lv,needed in quotas.items():
518:             random.shuffle(by_level[lv])
519:             selected.extend(by_level[lv][:needed])
520:     else:
521:         # Compatibility with older exams: filter selected levels if present.
522:         allowed=[x.strip().upper() for x in (kt["muc_do"] or "").split(",") if x.strip()]
523:         if allowed:
524:             rows=[r for r in rows if (r["muc_do"] or "").strip().upper() in allowed]
525:         random.shuffle(rows)
526:         selected=rows[:min(int(kt["so_cau"]),len(rows))]
527: 
528:     random.shuffle(selected)
529:     out=[snapshot(dict(r,question_type=question_classification(r)[1])) for r in selected]
530:     return out
```

### PHAN_MEM/app.py:547 — enforce_commercial_license

```python
547: def enforce_commercial_license():
548:     if is_access_allowed():
549:         return None
550: 
551:     allowed={
552:         "teacher_login",
553:         "teacher_logout",
554:         "license_page",
555:         "health",
556:         "about_page",
557:         "static",
558:     }
559:     if request.endpoint in allowed:
560:         return None
561: 
562:     if request.path.startswith("/teacher"):
563:         if session.get("teacher_logged_in") and session.get("teacher_role")=="ADMIN":
564:             return redirect(url_for("license_page"))
565:         return redirect(url_for("teacher_login"))
566: 
567:     if request.path.startswith("/api/"):
568:         return jsonify(ok=False,reason="license_required"),403
569: 
570:     return render_template("license_required.html",machine_id=machine_id()),403
```

### PHAN_MEM/app.py:573 — _daily_maintenance

```python
573: def _daily_maintenance():
574:     # Lightweight check; actual copy occurs only once per day.
575:     if request.path.startswith("/teacher"):
576:         auto_backup_daily()
```

### PHAN_MEM/app.py:580 — teacher_login

```python
580: def teacher_login():
581:     if request.method=="POST":
582:         u=request.form.get("username","").strip()
583:         p=request.form.get("password","")
584:         c=db()
585:         row=c.execute("SELECT * FROM tai_khoan_gv WHERE username=?",(u,)).fetchone()
586: 
587:         if row and int(row["active"] or 0)==0:
588:             c.close()
589:             flash("Tài khoản đã bị vô hiệu hóa.")
590:             return render_template("teacher_login.html")
591: 
592:         if row and is_locked(row):
593:             until=row["locked_until"]
594:             c.close()
595:             flash(f"Tài khoản đang tạm khóa do đăng nhập sai nhiều lần. Thử lại sau {until}.")
596:             return render_template("teacher_login.html")
597: 
598:         if row and verify_password(p,row["password_salt"],row["password_hash"]):
599:             now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
600:             c.execute("""UPDATE tai_khoan_gv
601:                          SET failed_attempts=0,locked_until=NULL,last_login=?
602:                          WHERE id=?""",(now,row["id"]))
603:             c.commit()
604:             c.close()
605: 
606:             session.clear()
607:             session["teacher_logged_in"]=True
608:             session["teacher_username"]=u
609:             session["teacher_name"]=row["ho_ten"] or u
610:             session["teacher_role"]=row["vai_tro"] or "GIAOVIEN"
611:             audit("ĐĂNG NHẬP","Đăng nhập thành công")
612:             app.logger.info("Teacher login: %s", u)
613:             if not is_access_allowed():
614:                 if session.get("teacher_role")=="ADMIN":
615:                     flash("Hãy kích hoạt bản quyền để sử dụng phần mềm.")
616:                     return redirect(url_for("license_page"))
617:                 session.clear()
618:                 flash("Phần mềm chưa kích hoạt. Vui lòng liên hệ quản trị viên.")
619:                 return redirect(url_for("teacher_login"))
620:             return redirect(url_for("teacher"))
621: 
622:         if row:
623:             attempts=int(row["failed_attempts"] or 0)+1
624:             locked_until=None
625:             if attempts>=5:
626:                 locked_until=(datetime.now()+timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S")
627:                 attempts=0
628:             c.execute("UPDATE tai_khoan_gv SET failed_attempts=?,locked_until=? WHERE id=?",
629:                       (attempts,locked_until,row["id"]))
630:             c.commit()
631:         c.close()
632:         flash("Sai tài khoản hoặc mật khẩu.")
633:     return render_template("teacher_login.html")
```

### PHAN_MEM/app.py:636 — teacher_logout

```python
636: def teacher_logout():
637:     if session.get("teacher_logged_in"):
638:         audit("ĐĂNG XUẤT","Đăng xuất hệ thống")
639:     session.clear()
640:     return redirect(url_for("teacher_login"))
```

### PHAN_MEM/app.py:1012 — add_question

```python
1012: def add_question():
1013:     f=request.files.get("image"); img=""
1014:     if f and f.filename:
1015:         fn=secure_filename(f.filename)
1016:         f.save(UPLOAD_DIR/fn)
1017:         img=fn
1018:     vals=[
1019:         request.form.get("ma_cau","").strip(),
1020:         request.form.get("mon","").strip(),
1021:         request.form.get("chu_de","").strip(),
1022:         request.form.get("muc_do","").strip(),
1023:         request.form.get("noi_dung","").strip(),
1024:         request.form.get("a","").strip(),
1025:         request.form.get("b","").strip(),
1026:         request.form.get("c","").strip(),
1027:         request.form.get("d","").strip(),
1028:         norm_answer(request.form.get("dap_an_dung","")),
1029:         img
1030:     ]
1031:     if vals[4] and all(vals[5:9]) and vals[9]:
1032:         c=db()
1033:         c.execute("""INSERT INTO cau_hoi(ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,hinh_anh)
1034:                      VALUES(?,?,?,?,?,?,?,?,?,?,?)""",vals)
1035:         c.commit(); c.close()
1036:     return redirect(url_for("teacher"))
```

### PHAN_MEM/app.py:1040 — edit_question

```python
1040: def edit_question(qid):
1041:     c=db(); row=c.execute("SELECT * FROM cau_hoi WHERE id=?",(qid,)).fetchone()
1042:     if not row:
1043:         c.close(); return "Không tìm thấy",404
1044:     if row["payload"]:
1045:         c.close()
1046:         return redirect(url_for("multi_editor",qid=qid))
1047:     if request.method=="POST":
1048:         answer=norm_answer(request.form.get("dap_an_dung",""))
1049:         if not answer:
1050:             c.close()
1051:             return "Đáp án đúng phải là A, B, C hoặc D.",400
1052:         c.execute("""UPDATE cau_hoi SET ma_cau=?,mon=?,chu_de=?,muc_do=?,noi_dung=?,a=?,b=?,c=?,d=?,dap_an_dung=? WHERE id=?""",
1053:                   (request.form.get("ma_cau",""),request.form.get("mon",""),request.form.get("chu_de",""),
1054:                    request.form.get("muc_do",""),request.form.get("noi_dung",""),
1055:                    request.form.get("a",""),request.form.get("b",""),request.form.get("c",""),
1056:                    request.form.get("d",""),answer,qid))
1057:         c.commit(); c.close()
1058:         return redirect(url_for("question_bank"))
1059:     c.close()
1060:     return render_template("edit_question.html",q=row)
```

### PHAN_MEM/app.py:1127 — clone_question

```python
1127: def clone_question(qid):
1128:     c=db()
1129:     q=c.execute("SELECT * FROM cau_hoi WHERE id=?",(qid,)).fetchone()
1130:     if not q:
1131:         c.close()
1132:         flash("Không tìm thấy câu hỏi.")
1133:         return redirect(url_for("question_bank"))
1134: 
1135:     base=(q["ma_cau"] or "").strip()
1136:     new_code=(base + "_COPY") if base else ""
1137:     c.execute("""INSERT INTO cau_hoi(
1138:                  ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,hinh_anh,question_type,payload,khoi_lop)
1139:                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
1140:               (new_code,q["mon"],q["chu_de"],q["muc_do"],q["noi_dung"],
1141:                q["a"],q["b"],q["c"],q["d"],q["dap_an_dung"],q["hinh_anh"],q["question_type"],q["payload"],q["khoi_lop"]))
1142:     c.commit()
1143:     c.close()
1144:     flash("Đã nhân bản câu hỏi.")
1145:     return redirect(request.referrer or url_for("question_bank"))
```

### PHAN_MEM/app.py:1345 — import_questions

```python
1345: def import_questions():
1346:     f=request.files.get("file")
1347:     if not f or not f.filename.lower().endswith(".xlsx"):
1348:         flash("Chọn file .xlsx")
1349:         return redirect(request.referrer or url_for("teacher"))
1350: 
1351:     path=IMPORT_DIR/secure_filename(f.filename)
1352:     f.save(path)
1353: 
1354:     try:
1355:         ws=load_workbook(path,data_only=True).active
1356:     except Exception:
1357:         flash("Không đọc được file Excel.")
1358:         return redirect(request.referrer or url_for("teacher"))
1359: 
1360:     prepared=[]
1361:     errors=[]
1362: 
1363:     for excel_row,row in enumerate(ws.iter_rows(min_row=2,values_only=True),start=2):
1364:         vals=list(row)+[None]*10
1365:         ma,mon,topic,level,q,a,b,cc,d,ans=vals[:10]
1366: 
1367:         # Skip completely empty rows.
1368:         if not any(v is not None and str(v).strip() for v in vals[:10]):
1369:             continue
1370: 
1371:         ma=str(ma or "").strip()
1372:         mon=str(mon or "").strip()
1373:         topic=str(topic or "").strip()
1374:         level=str(level or "").strip().upper()
1375:         q=str(q or "").strip()
1376:         a=str(a or "").strip()
1377:         b=str(b or "").strip()
1378:         cc=str(cc or "").strip()
1379:         d=str(d or "").strip()
1380:         ans=norm_answer(ans)
1381: 
1382:         row_errors=[]
1383:         if not q:
1384:             row_errors.append("thiếu nội dung")
1385:         if not all([a,b,cc,d]):
1386:             row_errors.append("thiếu phương án A/B/C/D")
1387:         if not ans:
1388:             row_errors.append("đáp án đúng phải là A/B/C/D")
1389:         if level not in ("NB","TH","VD","VDC"):
1390:             row_errors.append("mức độ phải là NB/TH/VD/VDC")
1391: 
1392:         if row_errors:
1393:             errors.append(f"Dòng {excel_row}: " + ", ".join(row_errors))
1394:         else:
1395:             prepared.append((ma,mon,topic,level,q,a,b,cc,d,ans))
1396: 
1397:     if errors:
1398:         preview=" | ".join(errors[:8])
1399:         extra="" if len(errors)<=8 else f" | ... còn {len(errors)-8} lỗi khác"
1400:         flash(f"KHÔNG nhập dữ liệu vì file có {len(errors)} dòng lỗi. {preview}{extra}")
1401:         return redirect(request.referrer or url_for("teacher"))
1402: 
1403:     if not prepared:
1404:         flash("File không có câu hỏi hợp lệ để nhập.")
1405:         return redirect(request.referrer or url_for("teacher"))
1406: 
1407:     c=db()
1408:     for vals in prepared:
1409:         c.execute("""INSERT INTO cau_hoi(
1410:                      ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung)
1411:                      VALUES(?,?,?,?,?,?,?,?,?,?)""",vals)
1412:     c.commit()
1413:     c.close()
1414:     flash(f"Đã kiểm tra file và nhập thành công {len(prepared)} câu hỏi. Không có dòng lỗi.")
1415:     return redirect(request.referrer or url_for("question_bank"))
```

### PHAN_MEM/app.py:1287 — confirm_student_import

```python
1287: def confirm_student_import():
1288:     token=request.form.get("token","")
1289:     if not secrets.compare_digest(token,session.get("student_import_token","")):
1290:         flash("Phiên xem trước đã hết hạn. Vui lòng chọn lại file.")
1291:         return redirect(url_for("students_page"))
1292:     path=IMPORT_DIR/f"students_preview_{token}.xlsx"
1293:     if not path.exists():
1294:         flash("Không tìm thấy file xem trước.")
1295:         return redirect(url_for("students_page"))
1296:     mode=request.form.get("mode","update")
1297:     if mode not in ("update","skip"): mode="update"
1298:     c=None
1299:     try:
1300:         rows,invalid,duplicate_rows=read_student_excel(path)
1301:         c=db(); existing={r[0] for r in c.execute("SELECT ma_hs FROM hoc_sinh").fetchall()}
1302:         created=updated=skipped=0
1303:         for ma,hoten,lop in rows:
1304:             if ma in existing:
1305:                 if mode=="skip": skipped+=1; continue
1306:                 c.execute("UPDATE hoc_sinh SET ho_ten=?,lop=? WHERE ma_hs=?",(hoten,lop,ma)); updated+=1
1307:             else:
1308:                 c.execute("INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES(?,?,?)",(ma,hoten,lop)); created+=1
1309:         c.commit(); c.close(); c=None
1310:         audit("NHẬP HỌC SINH",f"thêm {created}, cập nhật {updated}, bỏ qua {skipped}, lỗi {invalid}")
1311:         flash(f"Nhập xong: thêm {created}, cập nhật {updated}, bỏ qua {skipped}, dòng thiếu dữ liệu {invalid}.")
1312:     except Exception:
1313:         if c is not None:
1314:             c.rollback(); c.close()
1315:         app.logger.exception("Student import confirmation failed")
1316:         flash("Nhập danh sách không thành công; dữ liệu hiện có không bị thay đổi.")
1317:     finally:
1318:         remove_import_file(path)
1319:         session.pop("student_import_token",None)
1320:     return redirect(url_for("students_page"))
```

### PHAN_MEM/app.py:1442 — create_exam

```python
1442: def create_exam():
1443:     ten=request.form.get("ten","").strip()
1444:     lop=request.form.get("lop","").strip()
1445:     mon=request.form.get("mon","").strip()
1446:     topics=request.form.getlist("chu_de")
1447: 
1448:     # v2.3.1: chọn chính xác số câu theo 5 loại trắc nghiệm x 4 mức độ.
1449:     levels=("NB","TH","VD","VDC")
1450:     has_type_fields=any(f"{k}_{lv}" in request.form for k in TYPES for lv in levels)
1451:     try:
1452:         tg=exam_integer(request.form,"thoi_gian",15,1,180)
1453:         quotas={k:{lv:exam_integer(request.form,f"{k}_{lv}",0) for lv in levels} for k in TYPES}
1454:         # Tương thích biểu mẫu cũ nếu cần.
1455:         if not has_type_fields:
1456:             old_counts={lv:exam_integer(request.form,lv.lower()+"_count",0) for lv in levels}
1457:             quotas={k:{lv:0 for lv in levels} for k in TYPES}
1458:             for lv,n in old_counts.items():
1459:                 quotas["SINGLE"][lv]=n
1460:     except ValueError as error:
1461:         flash(str(error))
1462:         return redirect(url_for("teacher"))
1463: 
1464:     level_totals={lv:sum(quotas[k][lv] for k in TYPES) for lv in levels}
1465:     total=sum(level_totals.values())
1466: 
1467:     if not ten:
1468:         flash("Cần nhập tên kỳ thi.")
1469:         return redirect(url_for("teacher"))
1470:     if total<=0:
1471:         flash("Hãy chọn ít nhất 1 câu trong bảng Loại câu hỏi × Mức độ.")
1472:         return redirect(url_for("teacher"))
1473: 
1474:     available,by_type=question_availability(mon,topics)
1475:     missing=[]
1476:     for kind,label in TYPES.items():
1477:         for lv in levels:
1478:             n=quotas[kind][lv]
1479:             have=by_type.get(kind,{}).get(lv,0)
1480:             if n>have:
1481:                 missing.append(f"{label} / {lv}: cần {n}, hiện có {have}")
1482:     if missing:
1483:         flash("Không thể tạo kỳ thi vì ngân hàng chưa đủ câu. " + " | ".join(missing[:10]))
1484:         return redirect(url_for("teacher"))
1485: 
1486:     show=1 if request.form.get("hien_diem")=="on" else 0
1487:     topic_value=",".join(topics)
1488:     if any("," in x for x in topics):
1489:         topic_value=json.dumps(topics,ensure_ascii=False)
1490:         quotas["_topics_format"]={"version":1}
1491:     c=db()
1492:     c.execute("""INSERT INTO ky_thi(
1493:                  ten,lop,mon,so_cau,thoi_gian_phut,chu_de,muc_do,
1494:                  nb_count,th_count,vd_count,vdc_count,
1495:                  hien_diem,trang_thai,created_at,type_quotas)
1496:                  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
1497:               (ten,lop,mon,total,tg,topic_value,"NB,TH,VD,VDC",
1498:                level_totals["NB"],level_totals["TH"],level_totals["VD"],level_totals["VDC"],
1499:                show,"MO",now_text(),json.dumps(quotas,ensure_ascii=False)))
1500:     c.commit()
1501:     c.close()
1502:     parts=[f"{lv} {level_totals[lv]}" for lv in levels if level_totals[lv]]
1503:     flash(f"Đã tạo kỳ thi '{ten}' với {total} câu (" + ", ".join(parts) + ").")
1504:     return redirect(url_for("teacher"))
```

### PHAN_MEM/app.py:1553 — report

```python
1553: def report(eid):
1554:     c=db()
1555:     exam=c.execute("SELECT * FROM ky_thi WHERE id=?",(eid,)).fetchone()
1556:     if not exam:
1557:         c.close()
1558:         return "Không tìm thấy kỳ thi.",404
1559: 
1560:     rows=c.execute("""
1561:         SELECT * FROM bai_thi
1562:         WHERE ky_thi_id=?
1563:         ORDER BY CASE WHEN diem IS NULL THEN 1 ELSE 0 END, diem DESC, ho_ten
1564:     """,(eid,)).fetchall()
1565: 
1566:     stats=c.execute("""
1567:       SELECT ctl.cau_hoi_id,cq.ma_cau,cq.noi_dung,cq.muc_do,
1568:              COUNT(*) AS so_luot,
1569:              SUM(CASE WHEN ctl.dung=1 THEN 1 ELSE 0 END) AS so_dung
1570:       FROM cau_tra_loi ctl
1571:       JOIN bai_thi bt ON bt.id=ctl.bai_thi_id
1572:       JOIN cau_hoi cq ON cq.id=ctl.cau_hoi_id
1573:       WHERE bt.ky_thi_id=? AND bt.submitted_at IS NOT NULL
1574:       GROUP BY ctl.cau_hoi_id,cq.ma_cau,cq.noi_dung,cq.muc_do
1575:       ORDER BY ctl.cau_hoi_id
1576:     """,(eid,)).fetchall()
1577: 
1578:     level_stats=c.execute("""
1579:       SELECT UPPER(cq.muc_do) AS muc_do,
1580:              COUNT(*) AS so_luot,
1581:              SUM(CASE WHEN ctl.dung=1 THEN 1 ELSE 0 END) AS so_dung
1582:       FROM cau_tra_loi ctl
1583:       JOIN bai_thi bt ON bt.id=ctl.bai_thi_id
1584:       JOIN cau_hoi cq ON cq.id=ctl.cau_hoi_id
1585:       WHERE bt.ky_thi_id=? AND bt.submitted_at IS NOT NULL
1586:       GROUP BY UPPER(cq.muc_do)
1587:     """,(eid,)).fetchall()
1588:     c.close()
1589: 
1590:     submitted=[r for r in rows if r["submitted_at"] is not None and r["diem"] is not None]
1591:     scores=[float(r["diem"]) for r in submitted]
1592: 
1593:     total_students=len(rows)
1594:     submitted_count=len(submitted)
1595:     avg=round(sum(scores)/len(scores),2) if scores else 0
1596:     highest=round(max(scores),2) if scores else 0
1597:     lowest=round(min(scores),2) if scores else 0
1598: 
1599:     pass_count=sum(1 for s in scores if s>=5)
1600:     good_count=sum(1 for s in scores if s>=8)
1601:     below5_count=sum(1 for s in scores if s<5)
1602:     pass_rate=round(pass_count/len(scores)*100,1) if scores else 0
1603:     good_rate=round(good_count/len(scores)*100,1) if scores else 0
1604: 
1605:     bands=[
1606:         {"label":"0–<2","min":0,"max":2,"count":0},
1607:         {"label":"2–<5","min":2,"max":5,"count":0},
1608:         {"label":"5–<6.5","min":5,"max":6.5,"count":0},
1609:         {"label":"6.5–<8","min":6.5,"max":8,"count":0},
1610:         {"label":"8–10","min":8,"max":10.0001,"count":0},
1611:     ]
1612:     for s in scores:
1613:         for b in bands:
1614:             if b["min"] <= s < b["max"]:
1615:                 b["count"]+=1
1616:                 break
1617:     max_band=max([b["count"] for b in bands] or [1])
1618:     for b in bands:
1619:         b["pct"]=round(b["count"]/len(scores)*100,1) if scores else 0
1620:         b["bar"]=round(b["count"]/max_band*100,1) if max_band else 0
1621: 
1622:     qstats=[]
1623:     for s in stats:
1624:         rate=round(s["so_dung"]/s["so_luot"]*100,1) if s["so_luot"] else 0
1625:         difficulty="Khó" if rate<40 else ("Trung bình" if rate<75 else "Dễ")
1626:         qstats.append({
1627:             "id":s["cau_hoi_id"],
1628:             "code":s["ma_cau"] or "",
1629:             "text":s["noi_dung"],
1630:             "cognitive":(s["muc_do"] or "").upper(),
1631:             "attempts":s["so_luot"],
1632:             "correct":s["so_dung"],
1633:             "rate":rate,
1634:             "level":difficulty
1635:         })
1636: 
1637:     levels={lv:{"attempts":0,"correct":0,"rate":0} for lv in ("NB","TH","VD","VDC")}
1638:     for s in level_stats:
1639:         lv=(s["muc_do"] or "").upper()
1640:         if lv not in levels:
1641:             continue
1642:         attempts=int(s["so_luot"] or 0)
1643:         correct=int(s["so_dung"] or 0)
1644:         levels[lv]={
1645:             "attempts":attempts,
1646:             "correct":correct,
1647:             "rate":round(correct/attempts*100,1) if attempts else 0
1648:         }
1649: 
1650:     top_students=[{
1651:         "ma_hs":r["ma_hs"],
1652:         "ho_ten":r["ho_ten"],
1653:         "lop":r["lop"],
1654:         "diem":r["diem"]
1655:     } for r in submitted[:10]]
1656: 
1657:     return render_template(
1658:         "report.html",
1659:         exam=exam,
1660:         rows=rows,
1661:         qstats=qstats,
1662:         avg=avg,
1663:         highest=highest,
1664:         lowest=lowest,
1665:         submitted_count=submitted_count,
1666:         total_students=total_students,
1667:         pass_count=pass_count,
1668:         pass_rate=pass_rate,
1669:         good_count=good_count,
1670:         good_rate=good_rate,
1671:         below5_count=below5_count,
1672:         bands=bands,
1673:         levels=levels,
1674:         top_students=top_students
1675:     )
```

### PHAN_MEM/app.py:1679 — export_exam_report

```python
1679: def export_exam_report(eid):
1680:     c=db()
1681:     exam=c.execute("SELECT * FROM ky_thi WHERE id=?",(eid,)).fetchone()
1682:     if not exam:
1683:         c.close()
1684:         return "Không tìm thấy kỳ thi.",404
1685: 
1686:     students=c.execute("""
1687:         SELECT ma_hs,ho_ten,lop,started_at,submitted_at,so_cau_dung,tong_so_cau,diem
1688:         FROM bai_thi
1689:         WHERE ky_thi_id=?
1690:         ORDER BY lop,ho_ten
1691:     """,(eid,)).fetchall()
1692: 
1693:     qstats=c.execute("""
1694:       SELECT cq.ma_cau,cq.mon,cq.chu_de,cq.muc_do,cq.noi_dung,
1695:              COUNT(*) AS so_luot,
1696:              SUM(CASE WHEN ctl.dung=1 THEN 1 ELSE 0 END) AS so_dung
1697:       FROM cau_tra_loi ctl
1698:       JOIN bai_thi bt ON bt.id=ctl.bai_thi_id
1699:       JOIN cau_hoi cq ON cq.id=ctl.cau_hoi_id
1700:       WHERE bt.ky_thi_id=? AND bt.submitted_at IS NOT NULL
1701:       GROUP BY ctl.cau_hoi_id,cq.ma_cau,cq.mon,cq.chu_de,cq.muc_do,cq.noi_dung
1702:       ORDER BY ctl.cau_hoi_id
1703:     """,(eid,)).fetchall()
1704: 
1705:     level_stats=c.execute("""
1706:       SELECT UPPER(cq.muc_do) AS muc_do,
1707:              COUNT(*) AS so_luot,
1708:              SUM(CASE WHEN ctl.dung=1 THEN 1 ELSE 0 END) AS so_dung
1709:       FROM cau_tra_loi ctl
1710:       JOIN bai_thi bt ON bt.id=ctl.bai_thi_id
1711:       JOIN cau_hoi cq ON cq.id=ctl.cau_hoi_id
1712:       WHERE bt.ky_thi_id=? AND bt.submitted_at IS NOT NULL
1713:       GROUP BY UPPER(cq.muc_do)
1714:     """,(eid,)).fetchall()
1715:     c.close()
1716: 
1717:     wb=Workbook()
1718: 
1719:     # Sheet 1: Summary
1720:     ws=wb.active
1721:     ws.title="TongQuan"
1722:     ws["A1"]="BÁO CÁO KỲ THI"
1723:     ws["A1"].font=Font(bold=True,size=16)
1724:     ws.merge_cells("A1:D1")
1725:     ws["A2"]="Tên kỳ thi"; ws["B2"]=exam["ten"]
1726:     ws["A3"]="Lớp"; ws["B3"]=exam["lop"] or "Tất cả lớp"
1727:     ws["A4"]="Môn"; ws["B4"]=exam["mon"] or "Tất cả môn"
1728:     ws["A5"]="Số câu"; ws["B5"]=exam["so_cau"]
1729:     ws["A6"]="Thời gian"; ws["B6"]=f'{exam["thoi_gian_phut"]} phút'
1730: 
1731:     scores=[float(r["diem"]) for r in students if r["submitted_at"] and r["diem"] is not None]
1732:     submitted=len(scores)
1733:     avg=round(sum(scores)/submitted,2) if submitted else 0
1734:     high=round(max(scores),2) if scores else 0
1735:     low=round(min(scores),2) if scores else 0
1736:     passed=sum(1 for x in scores if x>=5)
1737:     good=sum(1 for x in scores if x>=8)
1738: 
1739:     summary_rows=[
1740:         ("Số bài đã nộp",submitted),
1741:         ("Điểm trung bình",avg),
1742:         ("Điểm cao nhất",high),
1743:         ("Điểm thấp nhất",low),
1744:         ("Số bài >= 5",passed),
1745:         ("Tỷ lệ >= 5",round(passed/submitted*100,1) if submitted else 0),
1746:         ("Số bài >= 8",good),
1747:         ("Tỷ lệ >= 8",round(good/submitted*100,1) if submitted else 0),
1748:     ]
1749:     row=8
1750:     for name,val in summary_rows:
1751:         ws.cell(row=row,column=1,value=name)
1752:         ws.cell(row=row,column=2,value=val)
1753:         row+=1
1754: 
1755:     # Sheet 2: Students
1756:     ws2=wb.create_sheet("KetQuaHocSinh")
1757:     headers=["Mã HS","Họ tên","Lớp","Bắt đầu","Nộp bài","Số câu đúng","Tổng số câu","Điểm"]
1758:     ws2.append(headers)
1759:     for cell in ws2[1]:
1760:         cell.font=Font(bold=True)
1761:         cell.alignment=Alignment(horizontal="center")
1762:     for r in students:
1763:         ws2.append([r["ma_hs"],r["ho_ten"],r["lop"],r["started_at"],r["submitted_at"],
1764:                     r["so_cau_dung"],r["tong_so_cau"],r["diem"]])
1765: 
1766:     # Sheet 3: Question analysis
1767:     ws3=wb.create_sheet("PhanTichCauHoi")
1768:     headers3=["Mã câu","Môn","Chủ đề","Mức độ","Nội dung","Số lượt","Số đúng","Tỷ lệ đúng (%)","Độ khó"]
1769:     ws3.append(headers3)
1770:     for cell in ws3[1]:
1771:         cell.font=Font(bold=True)
1772:         cell.alignment=Alignment(horizontal="center")
1773:     for r in qstats:
1774:         attempts=int(r["so_luot"] or 0)
1775:         correct=int(r["so_dung"] or 0)
1776:         rate=round(correct/attempts*100,1) if attempts else 0
1777:         difficulty="Khó" if rate<40 else ("Trung bình" if rate<75 else "Dễ")
1778:         ws3.append([r["ma_cau"],r["mon"],r["chu_de"],r["muc_do"],r["noi_dung"],
1779:                     attempts,correct,rate,difficulty])
1780: 
1781:     # Sheet 4: Level analysis
1782:     ws4=wb.create_sheet("TheoMucDo")
1783:     ws4.append(["Mức độ","Số lượt trả lời","Số đúng","Tỷ lệ đúng (%)"])
1784:     for cell in ws4[1]:
1785:         cell.font=Font(bold=True)
1786:         cell.alignment=Alignment(horizontal="center")
1787:     level_map={r["muc_do"]:r for r in level_stats}
1788:     for lv in ("NB","TH","VD","VDC"):
1789:         r=level_map.get(lv)
1790:         attempts=int(r["so_luot"] or 0) if r else 0
1791:         correct=int(r["so_dung"] or 0) if r else 0
1792:         rate=round(correct/attempts*100,1) if attempts else 0
1793:         ws4.append([lv,attempts,correct,rate])
1794: 
1795:     # Adjust widths
1796:     for sheet in wb.worksheets:
1797:         for col in range(1, sheet.max_column+1):
1798:             width=10
1799:             for cell in sheet[get_column_letter(col)]:
1800:                 if cell.value is not None:
1801:                     width=max(width,min(45,len(str(cell.value))+2))
1802:             sheet.column_dimensions[get_column_letter(col)].width=width
1803: 
1804:     excel_text_cells(ws[cell] for cell in ("B2","B3","B4"))
1805:     for sheet,columns in ((ws2,5),(ws3,5)):
1806:         excel_text_cells(cell for row in sheet.iter_rows(min_row=2,max_col=columns) for cell in row)
1807: 
1808:     fn=EXPORT_DIR/f"BaoCao_{secure_filename(str(exam['ten']))}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
1809:     wb.save(fn)
1810:     return send_file(fn,as_attachment=True,download_name=fn.name)
```

### PHAN_MEM/app.py:1816 — analytics_dashboard

```python
1816: def analytics_dashboard():
1817:     c=db()
1818:     exams=c.execute("""
1819:         SELECT kt.*,
1820:                COUNT(bt.id) AS so_bai,
1821:                SUM(CASE WHEN bt.submitted_at IS NOT NULL THEN 1 ELSE 0 END) AS da_nop,
1822:                ROUND(AVG(CASE WHEN bt.submitted_at IS NOT NULL THEN bt.diem END),2) AS diem_tb,
1823:                MAX(CASE WHEN bt.submitted_at IS NOT NULL THEN bt.diem END) AS diem_cao,
1824:                MIN(CASE WHEN bt.submitted_at IS NOT NULL THEN bt.diem END) AS diem_thap
1825:         FROM ky_thi kt
1826:         LEFT JOIN bai_thi bt ON bt.ky_thi_id=kt.id
1827:         GROUP BY kt.id
1828:         ORDER BY kt.id DESC
1829:     """).fetchall()
1830: 
1831:     totals={
1832:         "students":c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0],
1833:         "questions":c.execute("SELECT COUNT(*) FROM cau_hoi").fetchone()[0],
1834:         "exams":c.execute("SELECT COUNT(*) FROM ky_thi").fetchone()[0],
1835:         "submitted":c.execute("SELECT COUNT(*) FROM bai_thi WHERE submitted_at IS NOT NULL").fetchone()[0],
1836:     }
1837: 
1838:     overall=c.execute("""
1839:         SELECT ROUND(AVG(diem),2) AS avg_score,
1840:                MAX(diem) AS max_score,
1841:                MIN(diem) AS min_score,
1842:                SUM(CASE WHEN diem>=5 THEN 1 ELSE 0 END) AS pass_count,
1843:                COUNT(*) AS total
1844:         FROM bai_thi
1845:         WHERE submitted_at IS NOT NULL AND diem IS NOT NULL
1846:     """).fetchone()
1847:     c.close()
1848: 
1849:     overall_dict={
1850:         "avg":overall["avg_score"] or 0,
1851:         "max":overall["max_score"] or 0,
1852:         "min":overall["min_score"] or 0,
1853:         "pass_rate":round((overall["pass_count"] or 0)/(overall["total"] or 1)*100,1) if overall["total"] else 0
1854:     }
1855: 
1856:     return render_template("analytics.html",exams=exams,totals=totals,overall=overall_dict)
```

### PHAN_MEM/app.py:2095 — export_results

```python
2095: def export_results():
2096:     c=db()
2097:     rows=c.execute("""SELECT bt.*,kt.ten AS ten_ky_thi FROM bai_thi bt
2098:                       JOIN ky_thi kt ON kt.id=bt.ky_thi_id
2099:                       WHERE bt.submitted_at IS NOT NULL
2100:                       ORDER BY kt.id,bt.lop,bt.ho_ten""").fetchall()
2101:     c.close()
2102:     wb=Workbook(); ws=wb.active; ws.title="Bang diem"
2103:     ws.append(["STT","Kỳ thi","Mã HS","Họ tên","Lớp","Đúng","Tổng câu","Điểm","Bắt đầu","Nộp bài"])
2104:     for i,r in enumerate(rows,1):
2105:         ws.append([i,r["ten_ky_thi"],r["ma_hs"],r["ho_ten"],r["lop"],r["so_cau_dung"],
2106:                    r["tong_so_cau"],r["diem"],r["started_at"],r["submitted_at"]])
2107:     excel_text_cells(row[i-1] for row in ws.iter_rows(min_row=2) for i in (2,3,4,5,9,10))
2108:     fn=f"BangDiem_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
2109:     path=EXPORT_DIR/fn; wb.save(path)
2110:     return send_file(path,as_attachment=True,download_name=fn)
```

### PHAN_MEM/app.py:2008 — restore_database_from_path

```python
2008: def restore_database_from_path(source_path):
2009:     # Validate DB first.
2010:     test = sqlite3.connect(source_path)
2011:     try:
2012:         tables = {r[0] for r in test.execute(
2013:             "SELECT name FROM sqlite_master WHERE type='table'"
2014:         ).fetchall()}
2015:         required = {"hoc_sinh", "cau_hoi", "ky_thi", "bai_thi"}
2016:         if not required.issubset(tables):
2017:             raise ValueError("Không đúng cơ sở dữ liệu của ThiTracNghiemLAN")
2018:     finally:
2019:         test.close()
2020: 
2021:     # Preserve the current DB before replacing it.
2022:     if DB_PATH.exists():
2023:         before = BACKUP_DIR / f"before_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
2024:         src = sqlite3.connect(DB_PATH)
2025:         dst = sqlite3.connect(before)
2026:         try:
2027:             src.backup(dst)
2028:         finally:
2029:             dst.close()
2030:             src.close()
2031: 
2032:     # Restore safely through SQLite backup API.
2033:     source = sqlite3.connect(source_path)
2034:     destination = sqlite3.connect(DB_PATH)
2035:     try:
2036:         source.backup(destination)
2037:     finally:
2038:         destination.close()
2039:         source.close()
2040:     init_db()
```

### PHAN_MEM/app.py:2044 — restore

```python
2044: def restore():
2045:     f = request.files.get("file")
2046:     if not f or not f.filename.lower().endswith(".db"):
2047:         flash("Vui lòng chọn file sao lưu .db.")
2048:         return redirect(url_for("backup_manager"))
2049: 
2050:     temp = BACKUP_DIR / ("uploaded_restore_" + secure_filename(f.filename))
2051:     f.save(temp)
2052:     try:
2053:         restore_database_from_path(temp)
2054:         audit("KHÔI PHỤC DỮ LIỆU",f"Từ file tải lên: {f.filename}")
2055:         app.logger.info("Restored uploaded backup: %s", f.filename)
2056:         flash("Đã khôi phục dữ liệu từ file đã chọn. Hãy kiểm tra lại học sinh, câu hỏi và kỳ thi.")
2057:     except Exception:
2058:         app.logger.exception("Restore failed")
2059:         flash("Khôi phục thất bại: file không hợp lệ hoặc không đúng dữ liệu của phần mềm.")
2060:     finally:
2061:         try:
2062:             temp.unlink()
2063:         except:
2064:             pass
2065:     return redirect(url_for("backup_manager"))
```

### PHAN_MEM/app.py:2069 — restore_saved_backup

```python
2069: def restore_saved_backup(name):
2070:     safe = secure_filename(name)
2071:     path = BACKUP_DIR / safe
2072:     if not path.exists() or path.suffix.lower() != ".db":
2073:         flash("Không tìm thấy bản sao lưu.")
2074:         return redirect(url_for("backup_manager"))
2075: 
2076:     try:
2077:         restore_database_from_path(path)
2078:         audit("KHÔI PHỤC DỮ LIỆU",f"Từ backup: {safe}")
2079:         app.logger.info("Restored saved backup: %s", safe)
2080:         flash(f"Đã khôi phục từ: {safe}")
2081:     except Exception:
2082:         app.logger.exception("Restore saved backup failed")
2083:         flash("Khôi phục thất bại. Hãy kiểm tra file sao lưu.")
2084:     return redirect(url_for("backup_manager"))
```

### PHAN_MEM/app.py:2115 — student_login

```python
2115: def student_login():
2116:     c=db()
2117:     exams=c.execute("SELECT * FROM ky_thi WHERE trang_thai='MO' ORDER BY id DESC").fetchall()
2118:     if request.method=="POST":
2119:         ma=request.form.get("ma_hs","").strip()
2120:         kid=request.form.get("ky_thi_id","")
2121:         hs=c.execute("SELECT * FROM hoc_sinh WHERE ma_hs=?",(ma,)).fetchone()
2122:         kt=c.execute("SELECT * FROM ky_thi WHERE id=? AND trang_thai='MO'",(int(kid),)).fetchone() if kid.isdigit() else None
2123: 
2124:         if not hs or not kt:
2125:             c.close()
2126:             return render_template("login.html",exams=exams,error="Sai mã HS hoặc kỳ thi.")
2127: 
2128:         if kt["lop"] and hs["lop"]!=kt["lop"]:
2129:             c.close()
2130:             return render_template("login.html",exams=exams,error="Kỳ thi không dành cho lớp của em.")
2131: 
2132:         ex=c.execute("SELECT * FROM bai_thi WHERE ky_thi_id=? AND ma_hs=?",(kt["id"],ma)).fetchone()
2133: 
2134:         if ex:
2135:             # Submitted attempts are only viewable unless teacher explicitly grants retake.
2136:             if ex["submitted_at"] and not ex["force_relogin"]:
2137:                 session["attempt_id"]=ex["id"]
2138:                 session["client_token"]=ex["client_token"] or ""
2139:                 c.close()
2140:                 return redirect(url_for("result"))
2141: 
2142:             # Teacher-granted retake: clear old answers and rebuild a fresh exam.
2143:             if ex["submitted_at"] and ex["force_relogin"]:
2144:                 de=build_exam(kt)
2145:                 if len(de)<kt["so_cau"]:
2146:                     c.close()
2147:                     return render_template("login.html",exams=exams,error="Ngân hàng câu hỏi chưa đủ để cho thi lại.")
2148:                 c.execute("DELETE FROM cau_tra_loi WHERE bai_thi_id=?",(ex["id"],))
2149:                 token=secrets.token_urlsafe(24)
2150:                 now=datetime.now()
2151:                 deadline=now+timedelta(minutes=kt["thoi_gian_phut"])
2152:                 c.execute("""UPDATE bai_thi
2153:                              SET started_at=?,deadline_at=?,submitted_at=NULL,de_json=?,
2154:                                  so_cau_dung=NULL,tong_so_cau=NULL,diem=NULL,last_seen_at=?,
2155:                                  client_token=?,force_relogin=0
2156:                              WHERE id=?""",
2157:                           (now_text(),deadline.strftime("%Y-%m-%d %H:%M:%S"),
2158:                            json.dumps(de,ensure_ascii=False),now_text(),token,ex["id"]))
2159:                 c.commit()
2160:                 session["attempt_id"]=ex["id"]
2161:                 session["client_token"]=token
2162:                 c.close()
2163:                 return redirect(url_for("exam"))
2164: 
2165:             # In-progress attempt: block a second machine while the first one is still alive.
2166:             if not ex["force_relogin"] and ex["client_token"] and seconds_since(ex["last_seen_at"]) <= 20:
2167:                 c.close()
2168:                 return render_template(
2169:                     "login.html",exams=exams,
2170:                     error="Mã học sinh này đang làm bài trên một máy khác. Nếu máy cũ bị lỗi, báo giáo viên bấm Mở khóa."
2171:                 )
2172: 
2173:             # Stale/disconnected or teacher-unlocked attempt: allow reconnect with a new token.
2174:             token=secrets.token_urlsafe(24)
2175:             c.execute("UPDATE bai_thi SET client_token=?,force_relogin=0,last_seen_at=? WHERE id=?",
2176:                       (token,now_text(),ex["id"]))
2177:             c.commit()
2178:             session["attempt_id"]=ex["id"]
2179:             session["client_token"]=token
2180:             c.close()
2181:             return redirect(url_for("exam"))
2182: 
2183:         de=build_exam(kt)
2184:         if len(de)<kt["so_cau"]:
2185:             c.close()
2186:             return render_template("login.html",exams=exams,error="Kỳ thi chưa đủ câu phù hợp trong ngân hàng. Giáo viên cần kiểm tra cơ cấu NB–TH–VD–VDC.")
2187: 
2188:         token=secrets.token_urlsafe(24)
2189:         now=datetime.now()
2190:         deadline=now+timedelta(minutes=kt["thoi_gian_phut"])
2191:         cur=c.execute("""INSERT INTO bai_thi(
2192:                          ky_thi_id,ma_hs,ho_ten,lop,started_at,deadline_at,de_json,
2193:                          last_seen_at,client_token,force_relogin)
2194:                          VALUES(?,?,?,?,?,?,?,?,?,0)""",
2195:                       (kt["id"],hs["ma_hs"],hs["ho_ten"],hs["lop"],
2196:                        now_text(),deadline.strftime("%Y-%m-%d %H:%M:%S"),
2197:                        json.dumps(de,ensure_ascii=False),now_text(),token))
2198:         c.commit()
2199:         session["attempt_id"]=cur.lastrowid
2200:         session["client_token"]=token
2201:         c.close()
2202:         return redirect(url_for("exam"))
2203: 
2204:     c.close()
2205:     return render_template("login.html",exams=exams)
```

### PHAN_MEM/app.py:2208 — exam

```python
2208: def exam():
2209:     aid=session.get("attempt_id")
2210:     if not aid:
2211:         return redirect(url_for("student_login"))
2212: 
2213:     c=db()
2214:     bt=validate_attempt_session(c,aid)
2215:     if not bt:
2216:         c.close()
2217:         session.pop("attempt_id",None)
2218:         session.pop("client_token",None)
2219:         return render_template("session_conflict.html")
2220: 
2221:     kt=c.execute("SELECT ten,hien_diem FROM ky_thi WHERE id=?",(bt["ky_thi_id"],)).fetchone()
2222:     if bt["submitted_at"]:
2223:         c.close()
2224:         return redirect(url_for("result"))
2225: 
2226:     data=json.loads(bt["de_json"])
2227:     saved={r["vi_tri_cau"]:decode(r["lua_chon"]) for r in c.execute(
2228:         "SELECT vi_tri_cau,lua_chon FROM cau_tra_loi WHERE bai_thi_id=?",(aid,))}
2229:     deadline=datetime.strptime(bt["deadline_at"],"%Y-%m-%d %H:%M:%S")
2230:     remaining=(deadline-datetime.now()).total_seconds()
2231:     sec=max(0,int(remaining))
2232: 
2233:     if request.method=="POST" or remaining<=0:
2234:         # Fast path only; the authoritative check is inside the write transaction.
2235:         fresh=c.execute("SELECT submitted_at FROM bai_thi WHERE id=?",(aid,)).fetchone()
2236:         if fresh and fresh["submitted_at"]:
2237:             c.close()
2238:             return redirect(url_for("result"))
2239: 
2240:         try:
2241:             # F002: serialize submit/autosave before reading the state to commit.
2242:             c.execute("BEGIN IMMEDIATE")
2243:             bt=validate_attempt_session(c,aid)
2244:             if not bt:
2245:                 session.pop("attempt_id",None)
2246:                 session.pop("client_token",None)
2247:                 return render_template("session_conflict.html")
2248:             if bt["submitted_at"]:
2249:                 return redirect(url_for("result"))
2250:             data=json.loads(bt["de_json"])
2251:             saved={r["vi_tri_cau"]:decode(r["lua_chon"]) for r in c.execute(
2252:                 "SELECT vi_tri_cau,lua_chon FROM cau_tra_loi WHERE bai_thi_id=?",(aid,))}
2253:             deadline=datetime.strptime(bt["deadline_at"],"%Y-%m-%d %H:%M:%S")
2254:             # F001: a request that waited for a writer must recheck the deadline.
2255:             use_post=request.method=="POST" and datetime.now()<deadline
2256:             correct=0
2257:             grading_choices={}
2258:             for i,item in enumerate(data):
2259:                 choice=from_form(request.form,i,item) if use_post else saved.get(i)
2260:                 grading_choices[i]=choice
2261:                 is_ok=int(answer_correct(item,choice))
2262:                 ch=json.dumps(choice,ensure_ascii=False)
2263:                 correct+=is_ok
2264:                 c.execute("""INSERT INTO cau_tra_loi(
2265:                          bai_thi_id,vi_tri_cau,cau_hoi_id,lua_chon,dung,saved_at)
2266:                          VALUES(?,?,?,?,?,?)
2267:                          ON CONFLICT(bai_thi_id,vi_tri_cau)
2268:                          DO UPDATE SET lua_chon=excluded.lua_chon,
2269:                                        dung=excluded.dung,
2270:                                        saved_at=excluded.saved_at""",
2271:                           (aid,i,item["id"],ch,is_ok,now_text()))
2272: 
2273:             score=total_score(data,grading_choices)
2274:             sub=now_text()
2275:             changed=c.execute("""UPDATE bai_thi
2276:                      SET submitted_at=?,so_cau_dung=?,tong_so_cau=?,diem=?,last_seen_at=?
2277:                      WHERE id=? AND submitted_at IS NULL""",
2278:                       (sub,correct,len(data),score,sub,aid)).rowcount
2279:             if changed==1:
2280:                 c.commit()
2281:             else:
2282:                 c.rollback()
2283:             return redirect(url_for("result"))
2284:         finally:
2285:             # Closing also rolls back an incomplete transaction on any exception.
2286:             c.close()
2287: 
2288:     c.execute("UPDATE bai_thi SET last_seen_at=? WHERE id=?",(now_text(),aid))
2289:     c.commit()
2290:     bt_view=dict(bt)
2291:     bt_view["ten"]=kt["ten"] if kt else ""
2292:     bt_view["hien_diem"]=kt["hien_diem"] if kt else 1
2293:     c.close()
2294:     return render_template("exam.html",bt=bt_view,questions=data,saved=saved,seconds_left=sec)
```

### PHAN_MEM/app.py:2297 — save_answer

```python
2297: def save_answer():
2298:     aid=session.get("attempt_id")
2299:     p=request.get_json(silent=True) or {}
2300:     i=p.get("index"); ch=p.get("choice")
2301:     if aid is None or not isinstance(i,int) :
2302:         return jsonify(ok=False,reason="bad_request"),400
2303: 
2304:     c=db()
2305:     try:
2306:         # F002: checks and the answer write share the submit write lock.
2307:         c.execute("BEGIN IMMEDIATE")
2308:         bt=validate_attempt_session(c,aid)
2309:         if not bt:
2310:             return jsonify(ok=False,reason="session_conflict"),409
2311:         if bt["submitted_at"]:
2312:             return jsonify(ok=False,reason="submitted"),409
2313: 
2314:         if datetime.now()>=datetime.strptime(bt["deadline_at"],"%Y-%m-%d %H:%M:%S"):
2315:             return jsonify(ok=False,reason="expired"),409
2316:         data=json.loads(bt["de_json"])
2317:         if i<0 or i>=len(data):
2318:             return jsonify(ok=False,reason="bad_index"),400
2319: 
2320:         item=data[i]
2321:         is_ok=int(answer_correct(item,ch))
2322:         ch=json.dumps(ch,ensure_ascii=False)
2323:         now=now_text()
2324:         c.execute("""INSERT INTO cau_tra_loi(
2325:                  bai_thi_id,vi_tri_cau,cau_hoi_id,lua_chon,dung,saved_at)
2326:                  VALUES(?,?,?,?,?,?)
2327:                  ON CONFLICT(bai_thi_id,vi_tri_cau)
2328:                  DO UPDATE SET lua_chon=excluded.lua_chon,
2329:                                dung=excluded.dung,
2330:                                saved_at=excluded.saved_at""",
2331:                   (aid,i,item["id"],ch,is_ok,now))
2332:         c.execute("UPDATE bai_thi SET last_seen_at=? WHERE id=?",(now,aid))
2333:         c.commit()
2334:         return jsonify(ok=True)
2335:     finally:
2336:         c.close()
```

### PHAN_MEM/app.py:2339 — ping

```python
2339: def ping():
2340:     aid=session.get("attempt_id")
2341:     if not aid:
2342:         return jsonify(ok=False),401
2343:     c=db()
2344:     bt=validate_attempt_session(c,aid)
2345:     if not bt:
2346:         c.close()
2347:         return jsonify(ok=False,reason="session_conflict"),409
2348:     if bt["submitted_at"]:
2349:         c.close()
2350:         return jsonify(ok=False,reason="submitted"),409
2351:     c.execute("UPDATE bai_thi SET last_seen_at=? WHERE id=?",(now_text(),aid))
2352:     c.commit()
2353:     c.close()
2354:     return jsonify(ok=True)
```

### PHAN_MEM/app.py:439 — validate_attempt_session

```python
439: def validate_attempt_session(c, aid):
440:     token=session.get("client_token")
441:     row=c.execute("SELECT * FROM bai_thi WHERE id=?",(aid,)).fetchone()
442:     if not row:
443:         return None
444:     # F017: NULL is compatible with legacy attempts only when not revoked.
445:     if row["force_relogin"]:
446:         return None
447:     if row["client_token"] and token != row["client_token"]:
448:         return None
449:     return row
```

### PHAN_MEM/multi_routes.py:31 — init_db

```python
31:     def init_db():
32:         # Back up the original schema before the first v2.2 migration.
33:         path=g['DB_PATH']
34:         if path.exists():
35:             c=db(); exists=c.execute("SELECT 1 FROM sqlite_master WHERE name='cau_hoi'").fetchone()
36:             columns={r[1] for r in c.execute('PRAGMA table_info(cau_hoi)')}; c.close()
37:             if exists and 'question_type' not in columns:
38:                 g['create_sqlite_backup'](g['BACKUP_DIR']/('before_v22_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.db'))
39:             elif exists and 'khoi_lop' not in columns:
40:                 g['create_sqlite_backup'](g['BACKUP_DIR']/('before_v222_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.db'))
41:         old_init()
42:         c=db()
43:         for table,name,definition in [('cau_hoi','question_type',"TEXT NOT NULL DEFAULT 'SINGLE'"),('cau_hoi','payload',"TEXT NOT NULL DEFAULT ''"),('cau_hoi','khoi_lop',"TEXT NOT NULL DEFAULT ''"),('ky_thi','type_quotas',"TEXT NOT NULL DEFAULT ''")]:
44:             if name not in {r[1] for r in c.execute('PRAGMA table_info('+table+')')}:
45:                 c.execute(f'ALTER TABLE {table} ADD COLUMN {name} {definition}')
46:         # v2.2.2: classify old questions when grade can be inferred safely.
47:         for row in c.execute("SELECT id,ma_cau,mon,chu_de FROM cau_hoi WHERE TRIM(COALESCE(khoi_lop,''))='' ").fetchall():
48:             grade=infer_grade(row['ma_cau'],row['mon'],row['chu_de'])
49:             if grade: c.execute('UPDATE cau_hoi SET khoi_lop=? WHERE id=?',(grade,row['id']))
50:         c.execute('CREATE INDEX IF NOT EXISTS idx_cau_hoi_khoi_mon ON cau_hoi(khoi_lop,mon)')
51:         c.execute('CREATE INDEX IF NOT EXISTS idx_cau_hoi_folder_filter ON cau_hoi(khoi_lop,mon,question_type,muc_do)')
52:         c.commit(); c.close()
```

### PHAN_MEM/multi_routes.py:75 — values

```python
75:     def values(f):
76:         level=str(f.get('muc_do','NB')).strip().upper(); kind=str(f.get('question_type','SINGLE')).strip().upper()
77:         if level not in ('NB','TH','VD','VDC'): raise ValueError('Mức độ không hợp lệ.')
78:         question=str(f.get('noi_dung','')).strip()
79:         if not question: raise ValueError('Cần nhập nội dung câu hỏi.')
80:         spec=parse_spec(kind,str(f.get('items','')),str(f.get('answers','')))
81:         spec['scoring']=config(f,kind,len(spec['options']))
82:         code=str(f.get('ma_cau','')).strip(); subject=str(f.get('mon','')).strip(); topic=str(f.get('chu_de','')).strip()
83:         grade=normalize_grade(f.get('khoi_lop','')) or infer_grade(code,subject,topic)
84:         return (code,grade,subject,topic,level,question,kind,json.dumps(spec,ensure_ascii=False))
```

### PHAN_MEM/multi_routes.py:85 — insert

```python
85:     def insert(c,v):
86:         c.execute("INSERT INTO cau_hoi(ma_cau,khoi_lop,mon,chu_de,muc_do,noi_dung,question_type,payload,a,b,c,d,dap_an_dung,hinh_anh) VALUES(?,?,?,?,?,?,?,?,'','','','','A','')",v)
```

### PHAN_MEM/multi_routes.py:139 — multi_editor

```python
139:     def multi_editor(qid):
140:         f={}
141:         if qid:
142:             c=db(); row=c.execute('SELECT * FROM cau_hoi WHERE id=?',(qid,)).fetchone(); c.close()
143:             if not row: return 'Không tìm thấy câu hỏi',404
144:             f=dict(row)
145:             if not f['payload']:
146:                 f['payload']=json.dumps({'options':[f[x] for x in ('a','b','c','d')],'answer':'ABCD'.index(f['dap_an_dung'].strip().upper())})
147:             spec=json.loads(f['payload']); kind=f['question_type']
148:             rule=spec.get('scoring',{})
149:             f.update(points=rule.get('points',1),scoring_mode=rule.get('mode','all'),weights=','.join(str(x) for x in rule.get('weights',[])))
150:             f['items']='\n'.join(spec['options'])
151:             f['answers']=str(spec['answer']+1) if kind=='SINGLE' else ','.join(str(i+1) for i in spec['answer']) if kind=='MULTI' else '\n'.join(spec['answer']) if kind=='TF' else '\n'.join(spec['right']) if kind=='MATCH' else '\n'.join('|'.join(x) for x in spec['answer'])
152:         if request.method=='POST':
153:             f=request.form.to_dict()
154:             try:
155:                 v=values(f); c=db()
156:                 if qid: c.execute('UPDATE cau_hoi SET ma_cau=?,khoi_lop=?,mon=?,chu_de=?,muc_do=?,noi_dung=?,question_type=?,payload=? WHERE id=?',v+(qid,))
157:                 else: insert(c,v)
158:                 c.commit(); c.close(); flash('Đã lưu câu hỏi.')
159:                 return redirect(url_for('multi_bank',khoi=v[1],mon=v[2]))
160:             except ValueError as e: flash(str(e))
161:         return render_template('multi_editor.html',f=f,types=TYPES,grades=GRADE_OPTIONS)
```

### PHAN_MEM/multi_routes.py:199 — multi_import

```python
199:     def multi_import():
200:         try:
201:             upload=request.files.get('file')
202:             if not upload: raise ValueError('Chọn tệp Excel.')
203:             folder_grade=normalize_grade(request.form.get('khoi_lop',''))
204:             folder_subject=request.form.get('mon_folder','').strip()
205:             with BytesIO(upload.read()) as stream:
206:                 wb=load_workbook(stream,data_only=True)
207:             ws=wb.active; prepared=[]
208:             headers=[str(x or '').strip().lower() for x in next(ws.iter_rows(min_row=1,max_row=1,values_only=True))]
209:             has_grade_column=len(headers)>=9 and ('khối' in headers[1] or 'khoi' in headers[1])
210:             for i,row in enumerate(ws.iter_rows(min_row=2,values_only=True),2):
211:                 if not any(v is not None for v in row): continue
212:                 vals=list(row)+['']*9
213:                 names=['ma_cau','khoi_lop','mon','chu_de','muc_do','question_type','noi_dung','items','answers'] if has_grade_column else ['ma_cau','mon','chu_de','muc_do','question_type','noi_dung','items','answers']
214:                 names+=['points','scoring_mode','weights']
215:                 f=dict(zip(names,['' if x is None else str(x) for x in vals[:len(names)]]))
216:                 if folder_grade: f['khoi_lop']=folder_grade
217:                 if folder_subject: f['mon']=folder_subject
218:                 try: prepared.append(values(f))
219:                 except ValueError as e: raise ValueError(f'Dòng {i}: {e}')
220:             if not prepared: raise ValueError('Tệp không có câu hỏi hợp lệ.')
221:             c=db()
222:             with c:
223:                 for v in prepared: insert(c,v)
224:             c.close(); actual_grade=folder_grade or prepared[0][1]; actual_subject=folder_subject or prepared[0][2]
225:             flash(f'Đã nhập {len(prepared)} câu hỏi vào Khối {actual_grade or "chưa phân loại"} → {actual_subject or "chưa xác định môn"}.')
226:         except Exception as e:
227:             flash('Không nhập dữ liệu: '+str(e))
228:             return redirect(url_for('multi_bank'))
229:         return redirect(url_for('multi_bank',khoi=actual_grade or 'none',mon=actual_subject))
```

### PHAN_MEM/multi_routes.py:232 — build_exam

```python
232:     def build_exam(kt):
233:         if not dict(kt).get('type_quotas'): return old_build(kt)
234:         from question_types import snapshot
235:         import random
236:         quotas=json.loads(kt['type_quotas']); c=db(); selected=[]
237:         topics=g['exam_topics'](kt['chu_de'],quotas)
238:         for kind,levels in quotas.items():
239:             if kind=='_topics_format': continue
240:             for level,n in levels.items():
241:                 n=int(n or 0)
242:                 if n<=0: continue
243:                 sql='SELECT * FROM cau_hoi WHERE (?="" OR mon=?)'
244:                 args=[kt['mon'],kt['mon']]
245:                 if topics:
246:                     sql+=' AND chu_de IN (%s)' % ','.join('?'*len(topics))
247:                     args+=topics
248:                 rows=c.execute(sql,args).fetchall()
249:                 rows=[r for r in rows if g['question_classification'](r)==(level,kind)]
250:                 if len(rows)<n: c.close(); return []
251:                 selected.extend(random.sample(rows,n))
252:         c.close(); random.shuffle(selected); return [snapshot(dict(r,question_type=g['question_classification'](r)[1])) for r in selected]
```

### PHAN_MEM/multi_routes.py:57 — export_question_points

```python
57:     def export_question_points(eid):
58:         c=db(); attempts=c.execute('SELECT * FROM bai_thi WHERE ky_thi_id=? AND submitted_at IS NOT NULL',(eid,)).fetchall()
59:         wb=Workbook(); ws=wb.active; ws.title='DiemTungCau'
60:         ws.append(['Mã HS','Họ tên','Câu','Loại','Điểm đạt','Điểm tối đa','Điểm quy đổi /10'])
61:         for bt in attempts:
62:             items=json.loads(bt['de_json'])
63:             choices={r['vi_tri_cau']:r['lua_chon'] for r in c.execute('SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(bt['id'],))}
64:             scored=[grade(item,choices.get(i)) for i,item in enumerate(items)]
65:             maximum=sum(b for a,b in scored)
66:             for i,(a,b) in enumerate(scored):
67:                 ws.append([bt['ma_hs'],bt['ho_ten'],i+1,items[i].get('type','SINGLE'),a,b,a/maximum*10 if maximum else 0])
68:         c.close()
69:         for row in ws:
70:             for cell in row:
71:                 if isinstance(cell.value,str) and cell.value.startswith('='): cell.data_type='s'
72:         out=BytesIO(); wb.save(out); out.seek(0)
73:         return send_file(out,as_attachment=True,download_name='DiemTungCau.xlsx')
```

### PHAN_MEM/multi_routes.py:257 — mixed_exam

```python
257:     def mixed_exam():
258:         if request.method=='POST':
259:             try:
260:                 f=request.form; title=f.get('ten','').strip(); mon=f.get('mon','').strip(); minutes=g['exam_integer'](f,'minutes',15,1,180)
261:                 if not title or not 1<=minutes<=180: raise ValueError('Nhập tên kỳ thi và thời gian 1–180 phút.')
262:                 quotas={k:{lv:g['exam_integer'](f,k+'_'+lv,0) for lv in ('NB','TH','VD','VDC')} for k in TYPES}
263:                 if any(n<0 for q in quotas.values() for n in q.values()): raise ValueError('Số câu không được âm.')
264:                 total=sum(n for q in quotas.values() for n in q.values())
265:                 if not total: raise ValueError('Chọn ít nhất một câu.')
266:                 _,available=g['question_availability'](mon)
267:                 c=db()
268:                 for k,q in quotas.items():
269:                     for lv,n in q.items():
270:                         count=available[k][lv]
271:                         if n>count: c.close(); raise ValueError(f'{TYPES[k]} / {lv}: yêu cầu {n}, hiện có {count}.')
272:                 c.execute('INSERT INTO ky_thi(ten,lop,mon,so_cau,thoi_gian_phut,chu_de,muc_do,nb_count,th_count,vd_count,vdc_count,hien_diem,trang_thai,created_at,type_quotas) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(title,f.get('lop','').strip(),mon,total,minutes,'','NB,TH,VD,VDC',*(sum(q[lv] for q in quotas.values()) for lv in ('NB','TH','VD','VDC')),1 if f.get('hien_diem') else 0,'MO',g['now_text'](),json.dumps(quotas)))
273:                 c.commit();c.close();flash('Đã tạo kỳ thi nhiều dạng.');return redirect(url_for('teacher'))
274:             except ValueError as e: flash(str(e))
275:         c=db(); counts=c.execute('SELECT mon,question_type,muc_do,COUNT(*) AS n FROM cau_hoi GROUP BY mon,question_type,muc_do').fetchall(); c.close()
276:         return render_template('mixed_exam.html',types=TYPES,counts=counts)
```

### PHAN_MEM/question_types.py:10 — parse_spec

```python
10: def parse_spec(kind, text, answers):
11:     kind=kind.upper()
12:     if kind not in TYPES: raise ValueError('Loại câu hỏi không hợp lệ.')
13:     lines=[s.strip() for s in text.splitlines() if s.strip()]
14:     ans=[s.strip() for s in answers.splitlines() if s.strip()]
15:     if kind in ('SINGLE','MULTI'):
16:         if not 2<=len(lines)<=20: raise ValueError('Cần 2 đến 20 phương án, mỗi phương án một dòng.')
17:         try: keys=sorted(set(int(x.strip())-1 for x in answers.split(',')))
18:         except ValueError: raise ValueError('Đáp án dùng số thứ tự, ví dụ 1 hoặc 1,3.')
19:         if not keys or min(keys)<0 or max(keys)>=len(lines) or (kind=='SINGLE' and len(keys)!=1): raise ValueError('Số thứ tự đáp án không hợp lệ.')
20:         return {'options':lines,'answer':keys[0] if kind=='SINGLE' else keys}
21:     if not lines or len(lines)>30 or len(lines)!=len(ans): raise ValueError('Cần 1–30 dòng nội dung và số dòng đáp án phải bằng số dòng nội dung.')
22:     if kind=='TF':
23:         if any(a.upper() not in ('D','S') for a in ans): raise ValueError('Mỗi dòng đáp án đúng–sai là D hoặc S.')
24:         return {'options':lines,'answer':[a.upper() for a in ans]}
25:     if kind=='MATCH':
26:         if len(set(ans))!=len(ans): raise ValueError('Các mục ở cột phải phải khác nhau.')
27:         return {'options':lines,'right':ans,'answer':list(range(len(lines)))}
28:     accepted=[[a.strip() for a in x.split('|') if a.strip()] for x in ans]
29:     if any(not a for a in accepted): raise ValueError('Mỗi ô cần ít nhất một đáp án.')
30:     return {'options':lines,'answer':accepted}
```

### PHAN_MEM/question_types.py:32 — snapshot

```python
32: def snapshot(row):
33:     row=dict(row); kind=row.get('question_type','SINGLE')
34:     if row.get('payload'):
35:         item=json.loads(row['payload'])
36:     else:
37:         item={'options':[row[x] for x in ('a','b','c','d')], 'answer':'ABCD'.index(row['dap_an_dung'].strip().upper())}
38:     if kind in ('SINGLE','MULTI'):
39:         order=list(range(len(item['options']))); random.shuffle(order)
40:         item['options']=[item['options'][i] for i in order]
41:         item['answer']=order.index(item['answer']) if kind=='SINGLE' else sorted(order.index(i) for i in item['answer'])
42:     elif kind=='MATCH':
43:         order=list(range(len(item['right']))); random.shuffle(order)
44:         item['right']=[item['right'][i] for i in order]
45:         item['answer']=[order.index(i) for i in item['answer']]
46:     item.update(id=row['id'],q=row['noi_dung'],image=row['hinh_anh'] or '',type=kind)
47:     return item
```

### PHAN_MEM/question_types.py:55 — correct

```python
55: def correct(item, value):
56:     value=decode(value); kind=item.get('type','SINGLE'); ans=item['answer']
57:     if kind=='SINGLE': return type(value) is int and value==ans
58:     if not isinstance(value,list): return False
59:     if kind=='MULTI': return all(type(x) is int for x in value) and sorted(set(value))==sorted(ans)
60:     if len(value)!=len(ans): return False
61:     if kind=='FILL': return all(isinstance(v,str) and normalize(v) in [normalize(a) for a in opts] for v,opts in zip(value,ans))
62:     if kind=='MATCH': return all(type(v) is int for v in value) and value==ans
63:     return value==ans
```

### PHAN_MEM/question_types.py:65 — from_form

```python
65: def from_form(form,index,item):
66:     key=f'q_{index}'; kind=item.get('type','SINGLE')
67:     if kind=='SINGLE':
68:         v=form.get(key,''); return int(v) if v.isdigit() else None
69:     if kind=='MULTI': return [int(v) for v in form.getlist(key) if v.isdigit()]
70:     values=[form.get(f'{key}_{j}','') for j in range(len(item['options']))]
71:     if kind=='MATCH': return [int(v) if v.isdigit() else None for v in values]
72:     return values
```

### PHAN_MEM/scoring.py:6 — config

```python
6: def config(form, kind, count):
7:     try:
8:         points=float(form.get('points',1) or 1)
9:         weights=[float(x.strip()) for x in str(form.get('weights','')).split(',') if x.strip()]
10:     except ValueError:
11:         raise ValueError('Điểm và trọng số phải là số.')
12:     mode=form.get('scoring_mode','all') or 'all'
13:     if mode not in ('all','partial'): raise ValueError('Cách chấm không hợp lệ.')
14:     if not math.isfinite(points) or not 0<points<=1000: raise ValueError('Điểm câu phải lớn hơn 0 và không quá 1000.')
15:     if weights and (kind not in ('TF','MATCH','FILL') or len(weights)!=count or any(not math.isfinite(x) or x<=0 or x>1000 for x in weights)):
16:         raise ValueError('Trọng số: một số dương cho mỗi ý, chỉ dùng cho đúng–sai, ghép nối, điền khuyết.')
17:     return dict(version=1,points=points,mode=mode,weights=weights)
```

### PHAN_MEM/scoring.py:19 — grade

```python
19: def grade(item, value):
20:     rule=item.get('scoring',{}); maximum=rule.get('points',1)
21:     if rule.get('mode','all')=='all' or item.get('type','SINGLE')=='SINGLE':
22:         return maximum*int(correct(item,value)),maximum
23:     value=decode(value); ans=item['answer']; kind=item['type']
24:     if not isinstance(value,list): return 0,maximum
25:     if kind=='MULTI':
26:         if any(type(v) is not int or v<0 or v>=len(item['options']) for v in value): return 0,maximum
27:         chosen=set(value); right=set(ans)
28:         fraction=max(0,(len(chosen & right)-len(chosen-right))/len(right))
29:     else:
30:         if len(value)!=len(ans): return 0,maximum
31:         weights=rule.get('weights') or [1]*len(ans)
32:         hits=[]
33:         for v,a in zip(value,ans):
34:             if kind=='FILL': hit=isinstance(v,str) and normalize(v) in [normalize(x) for x in a]
35:             elif kind=='MATCH': hit=type(v) is int and v==a
36:             else: hit=isinstance(v,str) and v==a
37:             hits.append(int(hit))
38:         fraction=sum(w*h for w,h in zip(weights,hits))/sum(weights)
39:     return maximum*fraction,maximum
```

### PHAN_MEM/scoring.py:41 — total_score

```python
41: def total_score(items, choices):
42:     scored=[grade(item,choices.get(i)) for i,item in enumerate(items)]
43:     maximum=sum(b for a,b in scored)
44:     raw=sum(a for a,b in scored)/maximum*10 if maximum else 0
45:     return float(Decimal(str(raw)).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
```

### PHAN_MEM/app.py:1

```text
1: from scoring import total_score
2: 
3: from flask import Flask, render_template, request, redirect, url_for, session, send_file, flash, jsonify
4: import sqlite3, random, json, os, shutil, hashlib, secrets, socket, logging, sys, time, platform, uuid
5: from logging.handlers import RotatingFileHandler
6: from datetime import datetime, timedelta
7: from pathlib import Path
8: from werkzeug.utils import secure_filename
9: from openpyxl import load_workbook, Workbook
10: from openpyxl.styles import Font, Alignment
11: from openpyxl.utils import get_column_letter
12: from functools import wraps
13: from question_types import TYPES, snapshot, correct as answer_correct, decode, from_form, completed
14: from license_core import format_license_code, verify_license_code, license_details, trial_status
15: 
16: # PyInstaller-safe paths:
17: # RESOURCE_DIR: bundled read-only resources such as templates.
18: # DATA_DIR: persistent writable data beside the EXE.
19: if getattr(sys, "frozen", False):
20:     RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
21:     DATA_DIR = Path(sys.executable).resolve().parent
22: else:
23:     RESOURCE_DIR = Path(__file__).resolve().parent
24:     DATA_DIR = RESOURCE_DIR
25: 
26: # Prefer the editable templates folder beside the EXE. Fall back to the copy
27: # bundled by PyInstaller when the external folder is unavailable.
28: EXTERNAL_TEMPLATE_DIR = DATA_DIR / "templates"
29: TEMPLATE_DIR = EXTERNAL_TEMPLATE_DIR if EXTERNAL_TEMPLATE_DIR.exists() else RESOURCE_DIR / "templates"
30: EXTERNAL_STATIC_DIR = DATA_DIR / "static"
31: STATIC_DIR = EXTERNAL_STATIC_DIR if EXTERNAL_STATIC_DIR.exists() else RESOURCE_DIR / "static"
32: app = Flask(__name__, template_folder=str(TEMPLATE_DIR),
33:             static_folder=str(STATIC_DIR), static_url_path="/static")
34: 
35: BASE_DIR = DATA_DIR
36: SECRET_FILE = DATA_DIR / ".session_secret"
37: try:
38:     if SECRET_FILE.exists():
39:         app.secret_key = SECRET_FILE.read_text(encoding="utf-8").strip()
40:     else:
41:         _secret = secrets.token_hex(32)
42:         SECRET_FILE.write_text(_secret, encoding="utf-8")
43:         app.secret_key = _secret
44: except Exception:
45:     app.secret_key = secrets.token_hex(32)
46: 
47: DB_PATH = DATA_DIR / "thi_trac_nghiem.db"
48: UPLOAD_DIR = DATA_DIR / "uploads"
49: IMPORT_DIR = DATA_DIR / "imports"
50: EXPORT_DIR = DATA_DIR / "exports"
51: BACKUP_DIR = DATA_DIR / "backups"
52: LOG_DIR = DATA_DIR / "logs"
53: for p in [UPLOAD_DIR, IMPORT_DIR, EXPORT_DIR, BACKUP_DIR, LOG_DIR]:
54:     p.mkdir(parents=True, exist_ok=True)
55: 
56: # ---------- Logging ----------
57: handler = RotatingFileHandler(LOG_DIR / "app.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")
58: handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
59: handler.setLevel(logging.INFO)
60: app.logger.addHandler(handler)
61: app.logger.setLevel(logging.INFO)
62: 
63: # ---------- DB helpers ----------
64: def db():
65:     conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
66:     conn.row_factory = sqlite3.Row
67:     conn.execute("PRAGMA journal_mode=WAL")
68:     conn.execute("PRAGMA synchronous=NORMAL")
69:     conn.execute("PRAGMA busy_timeout=30000")
70:     return conn
71: 
72: def hash_password(password, salt=None):
73:     salt=salt or secrets.token_hex(16)
74:     digest=hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120000).hex()
75:     return salt,digest
76: 
77: def verify_password(password,salt,digest):
78:     _,check=hash_password(password,salt)
79:     return secrets.compare_digest(check,digest)
80: 
81: def teacher_required(f):
82:     @wraps(f)
83:     def wrapped(*args,**kwargs):
84:         if not session.get("teacher_logged_in"):
85:             return redirect(url_for("teacher_login"))
86:         return f(*args,**kwargs)
87:     return wrapped
88: 
89: 
90: def admin_required(f):
91:     @wraps(f)
92:     def wrapped(*args,**kwargs):
93:         if not session.get("teacher_logged_in"):
94:             return redirect(url_for("teacher_login"))
95:         if session.get("teacher_role")!="ADMIN":
96:             flash("Chức năng này chỉ dành cho quản trị viên.")
97:             return redirect(url_for("teacher"))
```

### PHAN_MEM/app.py:2391

```text
2391: if __name__=="__main__":
2392:     init_db()
2393:     get_license_status()
2394:     auto_backup_daily()
2395:     port=get_server_port()
2396:     ips=get_lan_ips()
2397: 
2398:     print("="*72)
2399:     print("THI TRAC NGHIEM LAN v2.3 THUONG MAI")
2400:     for ip in ips:
2401:         print(f"Hoc sinh:  http://{ip}:{port}")
2402:     print(f"Giao vien: http://127.0.0.1:{port}/teacher/login")
2403:     print(f"Kiem tra:  http://127.0.0.1:{port}/health")
2404:     print("Tai khoan khoi tao: admin / 123456")
2405:     print("Khuyen nghi doi mat khau admin sau lan dang nhap dau tien.")
2406:     print("="*72)
2407: 
2408:     try:
2409:         from waitress import serve
2410:         print("May chu: Waitress production WSGI")
2411:         serve(app, host="0.0.0.0", port=port, threads=12,
2412:               connection_limit=200, channel_timeout=120)
2413:     except ImportError:
2414:         print("CANH BAO: Chua co Waitress, tam chay Flask server.")
2415:         app.run(host="0.0.0.0",port=port,debug=False,threaded=True)
```

### PHAN_MEM/README_v2.3.txt:1

```text
1: THI TRẮC NGHIỆM LAN v2.3 — CHẤM ĐIỂM LINH HOẠT
2: Nâng cấp từ đúng bộ nguồn v2.2.2 Khối/Môn đã gửi.
3: 
4: 1. CÁCH DÙNG
5: Vào Ngân hàng câu hỏi → Sửa → Chấm điểm v2.3.
6: - Điểm tối đa câu: số dương, tối đa 1000. Mặc định 1.
7: - Chấm toàn bộ: đúng hết câu mới nhận điểm.
8: - Chấm từng phần: áp dụng cho MULTI, TF, MATCH, FILL.
9: - Trọng số ý: tùy chọn cho TF, MATCH, FILL; mỗi ý một số dương
10:   không quá 1000, phân cách dấu phẩy. Ví dụ 1,3: ý thứ hai chiếm 3/4 điểm.
11:   Để trống thì các ý bằng điểm nhau. Dùng dấu chấm cho số thập phân.
12: - SINGLE luôn chấm đúng/sai toàn câu, nhưng có thể đổi điểm tối đa.
13: 
14: 2. CÔNG THỨC
15: SINGLE: đúng được toàn bộ điểm, sai/bỏ trống được 0.
16: MULTI ở chế độ từng phần:
17:   Điểm câu = điểm tối đa × max(0, (số lựa chọn đúng - số lựa chọn sai)
18:                                      / tổng số đáp án đúng).
19:   Ví dụ đúng A,C và câu 2 điểm: chọn A được 1; chọn A,B,C được 1;
20:   chọn A,C được 2. Chọn lặp không được cộng thêm điểm.
21: TF/MATCH/FILL ở chế độ từng phần:
22:   Điểm câu = điểm tối đa × tổng trọng số ý đúng / tổng trọng số các ý.
23:   Bỏ trống ý được 0 điểm ý đó. Không trừ điểm các ý đúng khác.
24: FILL: vẫn nhận các đáp án tương đương ngăn bằng |, không phân biệt
25:   hoa/thường, chuẩn hóa khoảng trắng, vẫn phân biệt dấu tiếng Việt.
26: Điểm bài = tổng điểm đạt / tổng điểm tối đa × 10; làm tròn 2 chữ số
27:   theo quy tắc 5 làm tròn lên. Điểm từng câu không làm tròn trước khi cộng.
28: Màn hình học sinh hiển thị điểm quy đổi và cách chấm từng câu.
29: 
30: 3. EXCEL VÀ BÁO CÁO
31: Tải Excel mẫu trong ngân hàng: 12 cột, thêm 3 cột cuối:
32:   Điểm câu | Cách chấm (all/partial) | Trọng số ý.
33: Ví dụ: 2 | partial | 1,3.
34: Vẫn nhập được mẫu 8 cột v2.2.1 và 9 cột v2.2.2.
35: Mẫu cũ mặc định 1 điểm/câu, chấm toàn bộ.
36: Trong Báo cáo kỳ thi → Xuất điểm từng câu (Excel).
37: Số câu đúng và thống kê đúng/sai vẫn đếm câu đúng toàn bộ;
38:   điểm tổng có thể bao gồm điểm từng phần.
39: 
40: 4. GIỮ DỮ LIỆU VÀ NÂNG CẤP
41: Chỉ nâng cấp khi không có học sinh đang thi. Dừng máy chủ và sao lưu
42:   toàn bộ thư mục đang sử dụng trước khi thay chương trình.
43: Nếu chạy Python: chép các file .py, templates, static và các file .bat
44:   của PHAN_MEM mới vào thư mục chương trình cũ.
45: Giữ nguyên cơ sở dữ liệu, uploads, backups và tất cả tệp giấy phép,
46:   trạng thái dùng thử, cấu hình/bí mật phiên có sẵn.
47: Nếu chạy EXE: đóng gói trong thư mục mới bằng build_exe.bat; sau khi
48:   thành công, chép EXE mới cùng templates và static sang thư mục chạy cũ.
49: Không chép cơ sở dữ liệu hoặc trạng thái dùng thử sinh ra từ chạy thử
50:   vào thư mục dùng thật. Không xóa dữ liệu/giấy phép cũ.
51: Cách chấm được chốt lúc học sinh bắt đầu bài. Đổi cấu hình trong ngân hàng
52:   chỉ áp dụng cho bài bắt đầu sau đó. Không tự tính lại bài đã nộp.
53: Giữ nguyên MathJax ngoại tuyến, phân loại Khối/Môn và quản lý học sinh.
54: 
55: 5. ĐÓNG GÓI VÀ KIỂM THỬ
56: Đây là bộ nguồn và công cụ đóng gói, chưa phải EXE Windows đã tạo sẵn.
57: Chạy PHAN_MEM/build_exe.bat trên Windows có Python và kết nối mạng để
58:   cài các phụ thuộc nếu còn thiếu. Các kiểm tra dùng dữ liệu tạm.
59: Sau khi thành công, EXE ở PHAN_MEM/dist/ThiTracNghiemLAN.exe.
60: Máy chạy EXE không cần cài Python; thư mục chương trình cần quyền ghi dữ liệu.
61: Đã kiểm tra tại môi trường phát triển: 5 dạng, điểm từng phần, trọng số,
62:   bài cũ, nhập/xuất cấu hình, lưu đáp án, nộp bài, hết giờ, chốt cách chấm,
63:   báo cáo, 1000 học sinh, Khối/Môn, tích hợp tài nguyên MathJax và giấy phép.
64: Chưa xác minh chạy EXE và giao diện thực tế trên Windows.
```

### PHAN_MEM/HUONG_DAN_V22.txt:29

```text
29: 4. TẠO VÀ THI
30: Bấm Tạo đề nhiều dạng, chọn môn/lớp và số câu theo mỗi loại × NB/TH/VD/VDC. Môn hoặc lớp trống nghĩa là tất cả.
31: Đề nhiều dạng hiện lọc theo môn, chưa có bộ lọc chủ đề ở trang này. Trang tạo đề cũ vẫn có bộ lọc chủ đề và chọn số câu theo mức độ.
32: Học sinh chọn/nhập đáp án. Hệ thống tự lưu, giữ đáp án khi tải lại và chấm khi nộp.
33: Điểm = số câu đúng toàn bộ / tổng câu × 10. Không chia điểm từng ý/cặp/ô trong phiên bản này.
34: Nhiều đáp án phải chọn đúng đủ, không chọn thừa. Ghép nối và đúng-sai phải đúng tất cả mục. Điền khuyết phải đúng tất cả ô, bỏ qua hoa/thường và khoảng trắng thừa, có phân biệt dấu tiếng Việt.
35: Giám sát Đã làm đếm câu trả lời đầy đủ; với nhiều đáp án, đếm câu đã có ít nhất một lựa chọn.
36: Báo cáo và Excel điểm vẫn theo số câu đúng toàn bộ.
37: 
38: 5. PHẠM VI KIỂM TRA
```

### PHAN_MEM/templates/report.html:1

```text
1: {% extends "base.html" %}{% block body %}<div class="wrap"><a href="/teacher/report/{{exam.id}}/points">Xuất điểm từng câu (Excel)</a><p>Số câu đúng là số câu đúng toàn bộ; điểm có thể bao gồm điểm từng phần.</p></div>
2: <div class="wrap">
3:   <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
4:     <div>
5:       <h1>Báo cáo kỳ thi</h1>
6:       <p><b>{{ exam.ten }}</b> — {{ exam.lop or 'Tất cả lớp' }} — {{ exam.mon or 'Tất cả môn' }}</p>
7:     </div>
8:     <div>
9:       <a class="btn" href="/teacher/report/{{ exam.id }}/export">Xuất báo cáo Excel</a>
10:       <a class="btn" href="/teacher">← Trang giáo viên</a>
11:     </div>
12:   </div>
13: 
14:   <div class="grid">
15:     <div class="card"><h3>{{ submitted_count }}</h3><p>Bài đã nộp</p></div>
16:     <div class="card"><h3>{{ avg }}</h3><p>Điểm trung bình</p></div>
17:     <div class="card"><h3>{{ highest }}</h3><p>Điểm cao nhất</p></div>
18:     <div class="card"><h3>{{ lowest }}</h3><p>Điểm thấp nhất</p></div>
19:     <div class="card"><h3>{{ pass_rate }}%</h3><p>Tỷ lệ từ 5 điểm</p></div>
20:     <div class="card"><h3>{{ good_rate }}%</h3><p>Tỷ lệ từ 8 điểm</p></div>
21:   </div>
22: 
23:   <div class="card">
24:     <h3>Phân bố điểm</h3>
25:     {% for b in bands %}
26:       <div style="margin:10px 0">
27:         <div style="display:flex;justify-content:space-between">
28:           <span>{{ b.label }}</span>
29:           <b>{{ b.count }} bài ({{ b.pct }}%)</b>
30:         </div>
31:         <div style="background:#eee;border-radius:6px;height:18px;overflow:hidden">
32:           <div style="height:18px;width:{{ b.bar }}%;background:#4b8ad6"></div>
33:         </div>
34:       </div>
35:     {% endfor %}
36:   </div>
37: 
38:   <div class="card">
39:     <h3>Kết quả theo mức độ nhận thức</h3>
40:     <table>
41:       <tr><th>Mức độ</th><th>Lượt trả lời</th><th>Số đúng</th><th>Tỷ lệ đúng</th></tr>
42:       {% for lv in ["NB","TH","VD","VDC"] %}
43:       <tr>
44:         <td><b>{{ lv }}</b></td>
45:         <td>{{ levels[lv].attempts }}</td>
46:         <td>{{ levels[lv].correct }}</td>
47:         <td>{{ levels[lv].rate }}%</td>
48:       </tr>
49:       {% endfor %}
50:     </table>
51:   </div>
52: 
53:   <div class="card">
54:     <h3>Top điểm</h3>
55:     <table>
56:       <tr><th>STT</th><th>Mã HS</th><th>Họ tên</th><th>Lớp</th><th>Điểm</th></tr>
57:       {% for s in top_students %}
58:       <tr><td>{{ loop.index }}</td><td>{{ s.ma_hs }}</td><td>{{ s.ho_ten }}</td><td>{{ s.lop }}</td><td><b>{{ s.diem }}</b></td></tr>
59:       {% else %}
60:       <tr><td colspan="5">Chưa có bài nộp.</td></tr>
61:       {% endfor %}
62:     </table>
63:   </div>
64: 
65:   <div class="card">
66:     <h3>Phân tích câu hỏi</h3>
67:     <table>
68:       <tr>
69:         <th>Mã câu</th><th>Mức</th><th>Nội dung</th><th>Lượt</th><th>Đúng</th><th>Tỷ lệ đúng</th><th>Độ khó</th>
70:       </tr>
71:       {% for q in qstats %}
72:       <tr>
73:         <td>{{ q.code }}</td>
74:         <td><b>{{ q.cognitive }}</b></td>
75:         <td style="max-width:520px">{{ q.text }}</td>
76:         <td>{{ q.attempts }}</td>
77:         <td>{{ q.correct }}</td>
78:         <td>{{ q.rate }}%</td>
79:         <td><b>{{ q.level }}</b></td>
80:       </tr>
81:       {% else %}
82:       <tr><td colspan="7">Chưa đủ dữ liệu phân tích.</td></tr>
83:       {% endfor %}
84:     </table>
85:   </div>
86: 
87:   <div class="card">
88:     <h3>Kết quả học sinh</h3>
89:     <table>
90:       <tr><th>STT</th><th>Mã HS</th><th>Họ tên</th><th>Lớp</th><th>Đúng/Tổng</th><th>Điểm</th><th>Trạng thái</th></tr>
91:       {% for r in rows %}
92:       <tr>
93:         <td>{{ loop.index }}</td>
94:         <td>{{ r.ma_hs }}</td>
95:         <td>{{ r.ho_ten }}</td>
96:         <td>{{ r.lop }}</td>
97:         <td>{{ r.so_cau_dung if r.so_cau_dung is not none else '' }}/{{ r.tong_so_cau if r.tong_so_cau is not none else '' }}</td>
98:         <td><b>{{ r.diem if r.diem is not none else '' }}</b></td>
99:         <td>{{ 'Đã nộp' if r.submitted_at else 'Chưa nộp' }}</td>
100:       </tr>
101:       {% else %}
102:       <tr><td colspan="7">Chưa có học sinh tham gia.</td></tr>
103:       {% endfor %}
104:     </table>
105:   </div>
106: </div>
107: {% endblock %}
```

### PHAN_MEM/templates/exam.html:1

```text
1: {% extends 'base.html' %}{% block body %}<div class="wrap"><div class="card"><h2>{{bt.ten}}</h2><p>{{bt.ho_ten}} — {{bt.lop}}</p><p>Điểm và cách chấm được ghi ở từng câu. Tổng điểm quy đổi về thang 10, làm tròn 2 chữ số. Điền khuyết không phân biệt hoa/thường, vẫn phân biệt dấu tiếng Việt.</p><div id="timer"></div></div>
2: {% set totals=namespace(points=0) %}{% for q in questions %}{% set totals.points=totals.points+q.get('scoring',{}).get('points',1) %}{% endfor %}
3: <form id="form" method="post" onsubmit="return ask()">{% for q in questions %}{% set qi=loop.index0 %}{% set kind=q.get('type','SINGLE') %}{% set val=saved.get(qi) %}
4: <div class="card question math-content" data-index="{{qi}}" data-kind="{{kind}}"><b>Câu {{loop.index}}.</b> {{q.q}}{% if q.image %}<img class="qimg" src="/uploads/{{q.image}}">{% endif %}
5: {% set rule=q.get('scoring',{}) %}<p><small>Điểm tối đa: {{ ('%.3f' % (rule.get('points',1)/totals.points*10)) if totals.points else '0' }} / 10.
6: {% if rule.get('mode','all')=='partial' and kind!='SINGLE' %}
7: {% if kind=='MULTI' %}Chấm từng phần: số lựa chọn đúng trừ số lựa chọn sai, chia số đáp án đúng; thấp nhất 0 điểm.
8: {% else %}Chấm từng ý. {% if rule.get('weights') %}Trọng số các ý theo thứ tự: {{rule.weights|join(', ')}}.{% else %}Các ý chia đều điểm.{% endif %}{% endif %}
9: {% else %}Đúng toàn bộ câu mới được điểm.{% endif %}</small></p>
10: {% for op in q.options %}{% set j=loop.index0 %}
11: {% if kind in ['SINGLE','MULTI'] %}<label style="display:block;padding:8px"><input type="{{'radio' if kind=='SINGLE' else 'checkbox'}}" name="q_{{qi}}" value="{{j}}" {% if (kind=='SINGLE' and val==j) or (kind=='MULTI' and val and j in val) %}checked{% endif %}> {{op}}</label>
12: {% elif kind=='TF' %}<p>{{op}} <select name="q_{{qi}}_{{j}}"><option value="">Chưa chọn</option>{% for v,label in [('D','Đúng'),('S','Sai')] %}<option value="{{v}}" {% if val and val[j]==v %}selected{% endif %}>{{label}}</option>{% endfor %}</select></p>
13: {% elif kind=='MATCH' %}<p>{{op}} <select name="q_{{qi}}_{{j}}"><option value="">Chọn mục tương ứng</option>{% for right in q.right %}<option value="{{loop.index0}}" {% if val and val[j]==loop.index0 %}selected{% endif %}>{{right}}</option>{% endfor %}</select></p>
14: {% else %}<label style="display:block;padding:8px">{{op}} <input autocomplete="off" name="q_{{qi}}_{{j}}" value="{{val[j] if val else ''}}"></label>{% endif %}
15: {% endfor %}<small id="s{{qi}}">{% if qi in saved %}Đã lưu{% endif %}</small></div>{% endfor %}<button>Nộp bài</button></form></div>
16: <script>
17: let left={{seconds_left}},submitted=false;
18: const queues={};
19: function choice(el){let kind=el.dataset.kind;
20:  if(kind==='SINGLE'){let x=el.querySelector('input:checked');return x?Number(x.value):null;}
21:  if(kind==='MULTI')return Array.from(el.querySelectorAll('input:checked'),x=>Number(x.value));
22:  return Array.from(el.querySelectorAll('select,input'),x=>kind==='MATCH'?(x.value===''?null:Number(x.value)):x.value);
23: }
24: function save(el){let i=el.dataset.index,v=choice(el),s=document.getElementById('s'+i);s.textContent='Đang lưu…';
25:  queues[i]=(queues[i]||Promise.resolve()).catch(()=>{}).then(async()=>{
26:  try{let r=await fetch('/api/save-answer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:Number(i),choice:v})});
27:  if(r.status===409){location.href='/exam';return;} s.textContent=r.ok?'Đã lưu':'Chưa lưu được';}catch(e){s.textContent='Mất kết nối — giữ nguyên cửa sổ';}
28:  });
29: }
30: document.querySelectorAll('.question').forEach(el=>{el.addEventListener('change',()=>save(el));el.querySelectorAll('input:not([type])').forEach(x=>x.addEventListener('input',()=>save(el)));});
31: function tick(){document.getElementById('timer').textContent='Thời gian còn lại: '+Math.floor(left/60)+':'+String(left%60).padStart(2,'0');if(left<=0&&!submitted){submitted=true;document.getElementById('form').submit();return;}left--;setTimeout(tick,1000);}
32: async function ping(){try{let r=await fetch('/api/ping',{method:'POST'});if(r.status===409)location.href='/exam';}catch(e){}setTimeout(ping,5000);}
33: function ask(){if(submitted)return true;if(confirm('Nộp bài?')){submitted=true;return true;}return false;}
34: tick();ping();
35: </script>{% endblock %}
```

### PHAN_MEM/templates/multi_editor.html:1

```text
1: {% extends 'base.html' %}{% block body %}<div class="wrap"><h1>Soạn câu hỏi nhiều dạng</h1><a href="/teacher/multi">Quay lại ngân hàng</a>{% for m in get_flashed_messages() %}<p class="warn">{{m}}</p>{% endfor %}
2: <form method="post" class="card" data-live-math-form><label>Loại câu <select name="question_type">{% for k,v in types.items() %}<option value="{{k}}" {% if f.get('question_type')==k %}selected{% endif %}>{{v}}</option>{% endfor %}</select></label>
3: <label>Khối <select name="khoi_lop"><option value="">Chưa phân loại</option>{% for g in grades %}<option value="{{g}}" {% if f.get('khoi_lop')==g %}selected{% endif %}>Khối {{g}}</option>{% endfor %}</select></label>
4: {% for name,label in [('ma_cau','Mã câu'),('mon','Môn'),('chu_de','Chủ đề')] %}<label>{{label}} <input name="{{name}}" value="{{f.get(name,'')}}"></label>{% endfor %}
5: <select name="muc_do">{% for k in ['NB','TH','VD','VDC'] %}<option {% if f.get('muc_do')==k %}selected{% endif %}>{{k}}</option>{% endfor %}</select>
6: <p>Nội dung câu hỏi</p><textarea name="noi_dung" rows="3" style="width:95%" required>{{f.get('noi_dung','')}}</textarea>
7: <p>Các mục: mỗi phương án / ý / mục cột trái / nhãn ô trống trên một dòng.</p><textarea name="items" rows="6" style="width:95%" required>{{f.get('items','')}}</textarea>
8: <p>Đáp án: một đáp án ghi số thứ tự (1); nhiều đáp án ghi 1,3. Đúng–sai ghi D hoặc S mỗi dòng. Ghép nối ghi mục cột phải tương ứng mỗi dòng. Điền khuyết ghi đáp án cho từng ô mỗi dòng, dùng | để ngăn đáp án tương đương.</p><textarea name="answers" rows="6" style="width:95%" required>{{f.get('answers','')}}</textarea><div class="math-preview-title">Xem trước nội dung và các mục</div><div class="math-preview math-content" data-math-preview></div><fieldset><legend>Chấm điểm v2.3</legend>
9: <label>Điểm tối đa câu <input name="points" type="number" min="0.001" max="1000" step="any" value="{{f.get('points',1)}}" required></label>
10: <label>Cách chấm <select name="scoring_mode"><option value="all" {% if f.get('scoring_mode','all')=='all' %}selected{% endif %}>Đúng toàn bộ</option><option value="partial" {% if f.get('scoring_mode')=='partial' %}selected{% endif %}>Chấm một phần</option></select></label>
11: <p>Nhiều đáp án: mỗi lựa chọn đúng được 1 phần, mỗi lựa chọn sai trừ 1 phần; điểm câu không âm. Một đáp án: đúng được toàn bộ điểm.</p>
12: <label>Trọng số từng ý (đúng–sai, ghép nối, điền khuyết) <input name="weights" value="{{f.get('weights','')}}" placeholder="Ví dụ: 1,1,2,2"></label>
13: <p>Để trống để chia đều. Tổng điểm toàn bài quy đổi về thang 10, làm tròn 2 chữ số.</p></fieldset><button>Lưu câu hỏi</button></form></div>{% endblock %}
```

### PHAN_MEM/HUONG_DAN_SU_DUNG.txt:1

```text
1: HƯỚNG DẪN NHANH
2: 
3: I. ĐÓNG GÓI EXE TRÊN MÁY CÓ PYTHON
4: 1. Giải nén toàn bộ gói phần mềm.
5: 2. Nhấp đúp build_exe.bat.
6: 3. Chờ thông báo THÀNH CÔNG.
7: 4. Bộ chạy hoàn chỉnh được tạo trong thư mục dist.
8: 
9: II. CHẠY MÁY CHỦ
10: 1. Mở thư mục dist.
11: 2. Lần đầu, nhấp phải CAU_HINH_FIREWALL.bat và chọn Run as administrator.
12: 3. Nhấp đúp CHAY_MAY_CHU.bat.
13: 4. Giữ cửa sổ máy chủ mở trong suốt buổi thi.
14: 5. Giáo viên mở: http://127.0.0.1:5000/teacher/login
15: 6. Đăng nhập admin / 123456 và đổi mật khẩu.
16: 
17: II.1. KÍCH HOẠT BẢN QUYỀN
18: 1. Sau khi đăng nhập quản trị lần đầu, phần mềm chuyển đến trang kích hoạt.
19: 2. Gửi Machine ID và tên đơn vị cho chủ sở hữu phần mềm.
20: 3. Nhập đúng tên đơn vị đã đăng ký và mã bản quyền được cấp.
21: 4. Bấm Kích hoạt. Mã mới có hiệu lực 1 năm theo ngày bắt đầu ghi trong mã. Dùng thử miễn phí 7 ngày trước khi kích hoạt.
22: 5. Khi chưa kích hoạt, chức năng tổ chức thi và quản trị bị khóa.
23: 
24: III. MÁY HỌC SINH
25: 1. Kết nối cùng mạng LAN/Wi-Fi với máy chủ.
26: 2. Nhập địa chỉ được cửa sổ máy chủ hiển thị, ví dụ:
27:    http://192.168.1.29:5000
28: 3. Học sinh không cần cài Python.
29: 
30: IV. GIÁM SÁT PHÒNG THI
31: 1. Giáo viên tạo kỳ thi và mở kỳ thi.
32: 2. Trong Danh sách kỳ thi, bấm Giám sát.
```
