"""Real Chromium cookie/origin behavior against two loopback-only HTTP servers."""
import html,json,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from playwright.sync_api import sync_playwright
from waitress import create_server
from audit_support import arguments,runtime,sql,dump,seed,attempt

def main():
 args=arguments();out={'browser_cases':[],'external_requests':[]}
 with runtime(args.source,args.output) as (m,teacher,root):
  victim=create_server(m.app,host='127.0.0.1',port=0,threads=8);vt=threading.Thread(target=victim.run,daemon=True);vt.start();vurl=f'http://127.0.0.1:{victim.effective_port}'
  class Attacker(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):
    name=self.path.strip('/') or 'same_site'
    if name=='fetch':
     body=f'''<button id="send">Send harmless JSON probe</button><p id="done"></p><script>document.querySelector('#send').onclick=async()=>{{try{{let r=await fetch('{vurl}/api/save-answer',{{method:'POST',credentials:'include',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{index:0,choice:0}})}});document.querySelector('#done').textContent='response '+r.status}}catch(e){{document.querySelector('#done').textContent=String(e)}}}}</script>'''
    elif name=='logout':body=f'<form method="get" action="{vurl}/teacher/logout"><button>Harmless logout probe</button></form>'
    else:
     body=f'<form method="post" action="{vurl}/teacher/student/add"><input name="ma_hs" value="BROWSER_{html.escape(name)}"><input name="ho_ten" value="Harmless browser fixture"><input name="lop" value="8A"><button>Send harmless form probe</button></form>'
    b=body.encode();self.send_response(200);self.send_header('Content-Type','text/html;charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
  attacker=ThreadingHTTPServer(('127.0.0.1',0),Attacker);at=threading.Thread(target=attacker.serve_forever,daemon=True);at.start();port=attacker.server_address[1]
  same=f'http://127.0.0.1:{port}';cross=f'http://localhost:{port}'
  try:
   with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);out['chromium_version']=browser.version
    def restrict(route):
     if any(route.request.url.startswith(url+'/') for url in [vurl,same,cross]):route.continue_()
     else:out['external_requests'].append(route.request.url);route.abort()
    for case,origin in [('same_site_cross_origin',same),('cross_site_fresh_cookie',cross),('logout',cross)]:
     context=browser.new_context();context.route('**/*',restrict);page=context.new_page()
     page.goto(vurl+'/teacher/login');page.fill('[name=username]','admin');page.fill('[name=password]','123456');page.click('button');page.wait_for_url(vurl+'/teacher');started=time.monotonic()
     cookies=[{k:v for k,v in c.items() if k!='value'} for c in context.cookies()]
     page.goto(origin+'/'+case)
     method='GET' if case=='logout' else 'POST';path='/teacher/logout' if case=='logout' else '/teacher/student/add'
     with page.expect_request(lambda r:r.url==vurl+path and r.method==method) as request_info:
      with page.expect_response(lambda r:r.url==vurl+path) as response_info:page.click('button')
     request=request_info.value;response=response_info.value;headers=request.all_headers();page.wait_for_load_state('networkidle')
     row=bool(sql(m,'SELECT id FROM hoc_sinh WHERE ma_hs=?',('BROWSER_'+case,))) if case!='logout' else None
     record=dict(case=case,victim_origin=vurl,request_origin=origin,cookie_metadata=cookies,seconds_since_login=round(time.monotonic()-started,3),method=method,Origin=headers.get('origin'),Referer=headers.get('referer'),Sec_Fetch_Site=headers.get('sec-fetch-site'),Cookie_attached=bool(headers.get('cookie')),CSRF_token_sent=False,response_status=response.status,fixture_student_created=row,final_url=page.url)
     if case=='logout':
      page.goto(vurl+'/teacher');record['authenticated_teacher_page_after_logout']=page.url==vurl+'/teacher'
     page.screenshot(path=str(args.output/(case+'.png')),full_page=True);out['browser_cases'].append(record);context.close()
    # Application JSON autosave is not a simple cross-origin form; verify preflight behavior.
    seed(m,teacher,'BROWSER_JSON','SINGLE',subject='BROWSER_JSON');_,aid,eid,_=attempt(m,teacher,'BROWSER_JSON',subject='BROWSER_JSON')
    sql(m,'UPDATE bai_thi SET last_seen_at=NULL WHERE id=?',(aid,))
    context=browser.new_context();context.route('**/*',restrict);page=context.new_page();page.goto(vurl);page.fill('[name=ma_hs]','BROWSER_JSON');page.select_option('[name=ky_thi_id]',str(eid));page.click('button');page.wait_for_url(vurl+'/exam')
    observed=[];page.on('request',lambda req:observed.append(dict(method=req.method,url=req.url)) if '/api/save-answer' in req.url else None)
    page.goto(same+'/fetch');page.click('#send');page.wait_for_function("document.getElementById('done').textContent.length>0")
    out['student_JSON_browser']=dict(attacker_origin=same,victim_origin=vurl,result=page.locator('#done').inner_text(),observed_requests=observed,answers_written=len(sql(m,'SELECT id FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))),OPTIONS_same_origin_test_headers=dict(m.app.test_client().options('/api/save-answer',headers={'Origin':same,'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type'}).headers))
    context.close();browser.close()
  finally:
   attacker.shutdown();attacker.server_close();victim.close();victim.task_dispatcher.shutdown()
 out['audit_completed']=True;dump(args.output/'results.json',out);print(json.dumps(out,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
