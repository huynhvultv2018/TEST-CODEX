"""Isolated runtime support; the locked source tree is never imported in place."""
import argparse,contextlib,hashlib,json,logging,os,shutil,sys,tempfile
from pathlib import Path

def arguments():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=Path('/workspace/preprod-r3-baseline/PHAN_MEM'));p.add_argument('--output',type=Path,required=True)
 a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);return a

@contextlib.contextmanager
def runtime(source,output):
 with tempfile.TemporaryDirectory(prefix='tnlan_preprod_') as tmp:
  root=Path(tmp);shutil.copytree(source,root/'app',ignore=shutil.ignore_patterns('__pycache__'))
  sys.dont_write_bytecode=True;os.environ['LOCALAPPDATA']=str(root/'localappdata');sys.path.insert(0,str(root/'app'))
  import app as m
  m.init_db();teacher=m.app.test_client();assert teacher.post('/teacher/login',data={'username':'admin','password':'123456'}).status_code==302
  try:yield m,teacher,root
  finally:
   logging.shutdown();shutil.copyfile(root/'app/logs/app.log',output/'runtime.log')

def sql(m,query,params=()):
 c=m.db()
 try:rows=c.execute(query,params).fetchall();c.commit();return rows
 finally:c.close()

def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def seed(m,teacher,code,kind='SINGLE',subject='AUDIT',level='NB',text='Câu audit',points='4',mode='partial',weights=''):
 specs={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
 items,answers=specs[kind]
 form=dict(ma_cau=code,khoi_lop='8',mon=subject,chu_de='Audit',muc_do=level,question_type=kind,noi_dung=text,items=items,answers=answers,points=points,scoring_mode=mode,weights=weights)
 assert teacher.post('/teacher/multi/new',data=form).status_code==302
 return dict(sql(m,'SELECT * FROM cau_hoi WHERE ma_cau=?',(code,))[0]),form

def attempt(m,teacher,name,subject='AUDIT',kind='SINGLE',level='NB'):
 f=dict(ten='Audit '+name,mon=subject,thoi_gian='15',hien_diem='on',**{kind+'_'+level:'1'})
 assert teacher.post('/teacher/create-exam',data=f).status_code==302
 eid=sql(m,'SELECT MAX(id) FROM ky_thi')[0][0]
 assert teacher.post('/teacher/student/add',data=dict(ma_hs=name,ho_ten='Học sinh '+name,lop='8A')).status_code==302
 student=m.app.test_client();r=student.post('/',data=dict(ma_hs=name,ky_thi_id=eid));assert r.location.endswith('/exam')
 with student.session_transaction() as s:aid=s['attempt_id']
 data=json.loads(sql(m,'SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0]);return student,aid,eid,data

def form_answers(data,choices):
 f={}
 for i,q in enumerate(data):
  v=choices[i]
  if q['type']=='SINGLE':f['q_'+str(i)]=str(v)
  elif q['type']=='MULTI':f['q_'+str(i)]=[str(x) for x in v]
  else:
   for j,x in enumerate(v):f[f'q_{i}_{j}']='' if x is None else str(x)
 return f
