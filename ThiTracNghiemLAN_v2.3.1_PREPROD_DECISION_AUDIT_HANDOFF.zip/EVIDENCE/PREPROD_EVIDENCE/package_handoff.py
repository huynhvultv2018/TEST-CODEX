"""Package existing decision reports/evidence; never write application files or candidate."""
import hashlib,json,shutil,zipfile
from pathlib import Path

REPO=Path(__file__).resolve().parents[1]
EV=REPO/'PREPROD_EVIDENCE'
REPORTS=['PREPROD_DECISION_AUDIT.md','F010_SCORING_AUDIT.md','F011_CSRF_AUDIT.md','F012_HISTORY_REPORT_AUDIT.md','PREPROD_RUNTIME_REPORT.md','PREPROD_ROUTE_INVENTORY.md','PREPROD_DECISION_MATRIX.md']
EXPECTED='f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    baseline=REPO/'ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip'
    assert sha(baseline)==EXPECTED
    root_manifest=REPO/'CHECKSUMS.sha256';old_manifest_hash=sha(root_manifest)
    staging=REPO/'PREPROD_HANDOFF_CONTENTS'
    output=REPO/'ThiTracNghiemLAN_v2.3.1_PREPROD_DECISION_AUDIT_HANDOFF.zip'
    assert not staging.exists() and not output.exists()
    (staging/'REPORTS').mkdir(parents=True)
    for name in REPORTS:shutil.copyfile(REPO/name,staging/'REPORTS'/name)
    evidence=staging/'EVIDENCE/PREPROD_EVIDENCE'
    shutil.copytree(EV,evidence,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
    files=sorted(p for p in staging.rglob('*') if p.is_file())
    entries={p.relative_to(staging).as_posix():sha(p) for p in files}
    manifest=staging/'CHECKSUMS.sha256'
    manifest.write_text(''.join(f'{digest}  {name}\n' for name,digest in entries.items()))
    with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(p for p in staging.rglob('*') if p.is_file()):z.write(p,p.relative_to(staging).as_posix())
    assert output.stat().st_size>0
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        names=z.namelist();assert len(names)==len(set(names))
        assert sorted(n for n in names if n.startswith('REPORTS/'))==sorted('REPORTS/'+x for x in REPORTS)
        assert set(names)==set(entries)|{'CHECKSUMS.sha256'}
        for name,digest in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
        assert z.read('CHECKSUMS.sha256')==manifest.read_bytes()
        assert not any(n.endswith('.zip') or '/__pycache__/' in n or n.endswith(('.pyc','.pyo')) or n.startswith(('/', '../','CANDIDATE/')) for n in names)
    assert sha(baseline)==EXPECTED and sha(root_manifest)==old_manifest_hash
    result=dict(HANDOFF_PATH=str(output),HANDOFF_SHA256=sha(output),HANDOFF_BYTES=output.stat().st_size,HANDOFF_FILES=len(names),REPORTS_COUNT=len(REPORTS),EVIDENCE_FILES=len(entries)-len(REPORTS),ZIP_CRC='PASS',MEMBER_CHECKSUMS='PASS',BASELINE_SHA256=sha(baseline),ROOT_R1_CHECKSUMS_UNCHANGED=True,ROOT_R1_CHECKSUMS_SHA256=old_manifest_hash,CHECKSUMS_PATH=str(manifest),CANDIDATE_INCLUDED=False,SOURCE_PATCHED=False)
    (REPO/'PREPROD_PACKAGE_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
