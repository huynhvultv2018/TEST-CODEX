"""F012 legitimate teacher-edit workflow; before/after reports and stored snapshots."""
import json
from io import BytesIO
from flask import template_rendered
from openpyxl import load_workbook
from audit_support import arguments,runtime,sql,dump,seed,attempt,form_answers

def main():
 args=arguments();out={}
 with runtime(args.source,args.output) as (m,teacher,root):
  q,form=seed(m,teacher,'HISTORY','SINGLE',subject='HISTORY',text='SOURCE_BEFORE_NB',points='4',mode='all')
  student,aid,eid,data=attempt(m,teacher,'HISTORY_STUDENT',subject='HISTORY');answer=data[0]['answer']
  assert student.post('/api/save-answer',json=dict(index=0,choice=answer)).status_code==200
  assert student.post('/exam',data=form_answers(data,{0:answer})).status_code==302
  def capture(label):
   bt=dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0]);context={}
   def receiver(sender,template,context:dict,**kwargs):
    if template.name=='report.html':captured.update(context)
   captured={};template_rendered.connect(receiver,m.app)
   try:report=teacher.get('/teacher/report/'+str(eid))
   finally:template_rendered.disconnect(receiver,m.app)
   assert report.status_code==200 and captured
   (args.output/(label+'_report.html')).write_bytes(report.data)
   exported=teacher.get('/teacher/report/'+str(eid)+'/export');assert exported.status_code==200
   (args.output/(label+'_exam_report.xlsx')).write_bytes(exported.data)
   wb=load_workbook(BytesIO(exported.data),data_only=False)
   sheets={ws.title:[list(row) for row in ws.iter_rows(values_only=True)] for ws in wb};wb.close()
   other={}
   for name,url,client in [('result','/result',student),('analytics','/teacher/analytics',teacher),('monitor','/teacher/api/monitor/'+str(eid),teacher),('points','/teacher/report/'+str(eid)+'/points',teacher),('results','/teacher/export-results',teacher)]:
    r=client.get(url);assert r.status_code==200;ext='xlsx' if name in ('points','results') else 'json' if name=='monitor' else 'html';(args.output/(label+'_'+name+'.'+ext)).write_bytes(r.data)
    if ext=='xlsx':
     wb=load_workbook(BytesIO(r.data),data_only=False);other[name]=[list(row) for row in wb.active.iter_rows(values_only=True)];wb.close()
    elif ext=='json':other[name]=r.get_json()
    else:other[name+'_contains_score10']='10.0/10' in r.get_data(as_text=True)
   return dict(question_row=dict(sql(m,'SELECT * FROM cau_hoi WHERE id=?',(q['id'],))[0]),stored_attempt=bt,stored_answers=[dict(r) for r in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))],report_qstats=captured['qstats'],report_levels=captured['levels'],report_average=captured['avg'],xlsx_sheets=sheets,related=other)
  before=capture('before')
  edit={**form,'muc_do':'VD','noi_dung':'SOURCE_AFTER_VD','points':'9'}
  response=teacher.post('/teacher/multi/edit/'+str(q['id']),data=edit);assert response.status_code==302
  after=capture('after')
  assert before['stored_attempt']==after['stored_attempt'] and before['stored_answers']==after['stored_answers']
  assert before['stored_attempt']['diem']==after['stored_attempt']['diem']==10
  assert before['report_qstats'][0]['cognitive']=='NB' and after['report_qstats'][0]['cognitive']=='VD'
  assert before['report_qstats'][0]['text']=='SOURCE_BEFORE_NB' and after['report_qstats'][0]['text']=='SOURCE_AFTER_VD'
  assert before['report_levels']['NB']['attempts']==1 and after['report_levels']['NB']['attempts']==0 and after['report_levels']['VD']['attempts']==1
  assert before['xlsx_sheets']['KetQuaHocSinh']==after['xlsx_sheets']['KetQuaHocSinh']
  assert before['xlsx_sheets']['PhanTichCauHoi']!=after['xlsx_sheets']['PhanTichCauHoi'] and before['xlsx_sheets']['TheoMucDo']!=after['xlsx_sheets']['TheoMucDo']
  assert before['related']['points']==after['related']['points'] and before['related']['results']==after['related']['results']
  snapshot=json.loads(after['stored_attempt']['de_json'])[0];assert snapshot['q']=='SOURCE_BEFORE_NB' and snapshot['scoring']['points']==4
  out=dict(audit_completed=True,workflow='valid UI create/build/login/autosave/submit → teacher edit NB to VD/content/points → report again',before=before,after=after,comparison=dict(stored_score_unchanged=10,stored_snapshot_unchanged=True,stored_answers_unchanged=True,report_text_changed=True,report_level_changed=True,Excel_question_and_level_sheets_changed=True,Excel_student_sheet_unchanged=True,points_export_unchanged=True,results_export_unchanged=True,snapshot_has_cognitive_metadata='muc_do' in snapshot or 'cognitive' in snapshot,snapshot_fields=sorted(snapshot)))
 dump(args.output/'results.json',out);print(json.dumps(out['comparison'],ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
