"""Generate decision-audit documents from preserved evidence, without importing the app."""
import json
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
EV = REPO / 'PREPROD_EVIDENCE'
BASELINE = 'f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a'

def write(name, body):
    p = REPO / name
    assert not p.exists(), f'Report already exists: {p}'
    p.write_text(body.strip() + '\n', encoding='utf-8')

matrix = '''| Finding | Runtime evidence | Reachability | Impact | Decision |
|---|---|---|---|---|
| F010 | Snapshot fixture: chia 0/HTTP 500; điểm lưu 20, -10; NaN/Infinity → submitted với điểm NULL. Restore `.db` có SQLite integrity `ok`, nhận weights `[0,0]`, bài mới submit 500. | Form/Excel hiện tại chặn cấu hình hỏng. Nguồn gây hỏng là `ONLY_CORRUPTED/EXTERNAL_DATA`; đường tiếp nhận đã chứng minh là `REACHABLE_FROM_IMPORT` qua restore `.db`. Legacy thiếu rule hợp lệ chấm đúng 1/all. | Không thể chốt hoặc chốt kết quả sai khi đọc dữ liệu hỏng đã được tiếp nhận. | `F010_PREPROD = REQUIRED` |
| F011 | Server nhận POST thiếu token, thiếu/khác Origin/Referer. Chromium thực: form origin khác gửi cookie và thêm học sinh; cross-site cookie mới cũng thành công. Form `/exam` origin khác chốt bài test 0 điểm. | Phiên giáo viên/admin/học sinh hợp lệ và trang origin khác; không cần đọc cookie HttpOnly. JSON autosave khác origin bị preflight chặn trong probe tự nhiên. | Thao tác dưới quyền phiên nạn nhân, kể cả chốt bài học sinh; cùng cơ chế guard áp dụng các route quản trị trong inventory. | `F011_PREPROD = REQUIRED` |
| F012 | UI tạo NB → nộp 10 → UI sửa VD/nội dung/points. Report và Excel phân tích đổi NB→VD/nội dung mới; snapshot, đáp án, điểm, Excel kết quả/điểm từng câu giữ nguyên. | `REACHABLE_FROM_VALID_UI` | Phân loại/nội dung lịch sử thay đổi theo ngân hàng hiện tại. Contract cho metadata báo cáo chưa được định nghĩa rõ. | `F012_PREPROD = PRODUCT_DECISION_REQUIRED`; `CONTRACT = UNDEFINED` |'''

write('PREPROD_DECISION_AUDIT.md', f'''# PRE-PRODUCTION DECISION AUDIT — ThiTracNghiemLAN v2.3.1

Ngày kiểm tra: 2026-10-02 UTC. Phạm vi duy nhất: F010/F011/F012 trên candidate R3 đã khóa.

`PREPROD_GATE = READY_FOR_PATCH_DECISION`

{matrix}

Đây là kết luận đủ bằng chứng để người dùng quyết định patch/phạm vi nghiệp vụ. Không có kết luận PRODUCTION READY. F010/F011 chưa được sửa trong vòng này; F012 chưa được chọn hành vi nghiệp vụ.

## Baseline và điều kiện vào audit

- Baseline duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip`.
- SHA-256 trước kiểm tra: `{BASELINE}`; khớp chính xác yêu cầu.
- Candidate: 863.183 byte, 62 file; ZIP đọc được. Source giải nén mới: `/workspace/preprod-r3-baseline`.
- Smoke trước decision audit: 83 nhóm/script/scenario PASS, 0 FAIL. Các finding F001/F002/F003/F004/F005/F006/F007/F008/F009/F017 đều PASS; `R3_BASELINE_REGRESSION = NOT_DETECTED`.
- Bằng chứng khóa và smoke: `baseline-lock.json`, `smoke-summary.json`, các thư mục `smoke-*`. Bằng chứng kiểm tra hash cuối: `source-lock-final.json`.

## Cơ sở quyết định

F010: native form, edit và Excel dùng cùng validation. Không chứng minh được chúng tạo cấu hình bất thường từ input hợp lệ. Tuy nhiên, chức năng restore có thật nhận `.db` hợp lệ về cấu trúc SQLite nhưng sai ngữ nghĩa scoring; bài thi mới được tạo qua UI sau restore gặp HTTP 500. Các snapshot fixture còn chứng minh khả năng lưu điểm ngoài miền hoặc NULL khi đã submitted. Yêu cầu tối thiểu là kiểm tra ngữ nghĩa lúc đọc, không tự chữa dữ liệu hay đổi công thức v2.3. Chi tiết write-path, từng probe và đề xuất regression nằm trong `F010_SCORING_AUDIT.md`.

F011: 34 route state-changing POST đã được inventory, không có PUT/PATCH/DELETE. Có một nonce riêng cho student-import-confirm nhưng không có cơ chế CSRF chung hay kiểm Origin/Referer. Cookie thực không phát SameSite/Secure, có HttpOnly và được ký. Trình duyệt thực xác nhận attack surface form POST; Signed session và token sở hữu attempt không thay thế CSRF token gửi riêng trong request. Phạm vi teacher/admin có thể bảo vệ riêng về kỹ thuật, nhưng probe `/exam` cho thấy không thể coi đó là bảo vệ toàn ứng dụng. Chi tiết cookie, CORS, giới hạn trình duyệt và phạm vi đề xuất nằm trong `F011_CSRF_AUDIT.md`.

F012: report JOIN ngân hàng hiện tại trong khi điểm lấy từ attempt/snapshot. Sửa câu hỏi qua UI làm đổi phân tích NB/VD và nội dung trong report/Excel. Tài liệu chỉ cam kết chốt cách chấm lúc bắt đầu bài, không xác định contract cho metadata báo cáo lịch sử. Hai hành vi để lựa chọn nằm trong `F012_HISTORY_REPORT_AUDIT.md`; audit không chọn thay người dùng.

## Khóa phạm vi và bàn giao

Không sửa source, schema/database thật, template/JavaScript, test gốc hay candidate; không tạo R4/version/candidate mới. Các ứng dụng test chạy trên bản sao tạm và database/LOCALAPPDATA tạm. Chỉ tạo harness ngoài baseline, fixture, báo cáo và evidence. Các lần lỗi cơ khí của harness mới được giữ nguyên và phân biệt với lỗi sản phẩm; không skip/XFAIL hay sửa test gốc để PASS.

HANDOFF chứa `REPORTS/` (7 báo cáo), `EVIDENCE/PREPROD_EVIDENCE/` và `CHECKSUMS.sha256`. Manifest mới dùng đường dẫn trong handoff và không ghi đè manifest R1 hiện có ở repository root. SHA-256 của handoff được ghi ngoài ZIP trong chứng cứ bàn giao, vì một ZIP không thể tự chứa hash của chính nó.

Chỉ HANDOFF ZIP được commit với message `Add v2.3.1 pre-production decision audit handoff` trên branch hiện tại. Handoff không chứa source/candidate ZIP mới. Sau bàn giao, dừng để người dùng quyết định; không patch F010/F011/F012 hoặc đưa lên Production.
''')

write('F010_SCORING_AUDIT.md', '''# F010 — Snapshot/scoring defensive validation

`F010_PREPROD = REQUIRED`

Form và Excel hiện tại kiểm tra đủ các cấu hình bất thường được probe; dữ liệu scoring hỏng không được tạo bởi những input đó. Quyết định REQUIRED dựa trên đường restore `.db` đã chứng minh tiếp nhận dữ liệu sai ngữ nghĩa rồi tạo bài mới gặp lỗi, cùng hậu quả chốt điểm sai từ snapshot hỏng. Đây là yêu cầu phòng vệ tại ranh giới đọc dữ liệu, không phải thay đổi scoring v2.3.

## Representation thực tế

`cau_hoi.payload` là JSON options/answer/right/scoring. `scoring` gồm `version`, `points`, `mode`, `weights`. `bai_thi.de_json` lưu toàn bộ snapshot từng câu lúc bắt đầu/retake. Không có input/column scoring tên literal `max_score`: maximum từng câu là `scoring.points` (`scoring.py:20`), maximum bài là tổng các points (`scoring.py:43`). Alias `max_score` ở analytics là MAX của điểm đã lưu, không phải writer cấu hình. Probe max_score âm/NaN/Infinity sử dụng đúng representation `points`, không thêm field mà scorer bỏ qua.

Python `json.loads` chấp nhận các literal mở rộng NaN/Infinity; `json.dumps` mặc định cũng phát chúng. Native config ngăn chúng bằng `math.isfinite`, nhưng reader snapshot/scorer không ngăn. Kết quả evidence JSON dùng object `{non_finite: ...}` và giữ chuỗi snapshot representation nguyên bản để không biến evidence thành JSON sai chuẩn.

## Toàn bộ write-path liên quan

Các line dưới đây thuộc đúng source R3, được giữ dưới dạng excerpt có số dòng trong `SOURCE_EVIDENCE.md`; inventory SQL trong `source-write-map.json`. Search tất cả Python runtime trong baseline không tìm writer scoring/snapshot khác ngoài các đường sau. Các script `kiem_tra_*` là test, không phải production writer.

| Entry/path | Validation → DB | Snapshot → reader/scoring | Reachability |
|---|---|---|---|
| POST `/teacher/multi/new`, `/teacher/multi/edit/<qid>` | `multi_routes.py:74` values → `question_types.py:10` parse_spec → `scoring.py:6` config → JSON dumps; INSERT tại multi_routes:85/156 hoặc UPDATE:156. Không dùng raw request payload. | build_exam → snapshot → login de_json → submit total_score | `REACHABLE_FROM_VALID_UI`; cấu hình bất thường được probe bị từ chối trước write. Edit dùng cùng values. |
| POST `/teacher/multi/import` | multi_routes:197–226 đọc 8/9/11/12 cột tương thích, chuyển từng row qua cùng values; prepare cả file trước INSERT transaction. | Như trên | `REACHABLE_FROM_IMPORT` (Excel); 7 invalid file bị reject, không có row mới. |
| POST `/teacher/question/add` | app:1010–1036 yêu cầu nội dung/4 options/ABCD; INSERT legacy, không ghi payload/scoring. | snapshot legacy dựng options/answer; scorer mặc định 1/all | `REACHABLE_FROM_VALID_UI`, không tạo weights/points bất thường. |
| POST `/teacher/question/edit/<qid>` | app:1038–1060 payload khác rỗng redirect multi_editor; legacy norm_answer/ABCD reject trước UPDATE. Không ghi scoring. | Snapshot đã bắt đầu không bị update | `REACHABLE_FROM_VALID_UI`; không có writer arbitrary payload. |
| POST `/teacher/import-questions` | app:1343–1417 kiểm toàn file options/ABCD/level rồi INSERT legacy, không payload/rule | Default 1/all | `REACHABLE_FROM_IMPORT` (legacy Excel), không tạo scoring bất thường. |
| POST `/teacher/question/clone/<qid>` | app:1125–1144 copy question_type/payload/khoi_lop nguyên trạng; không revalidate payload | Snapshot copy dữ liệu row đã chọn | `REACHABLE_FROM_VALID_UI` chỉ khuếch đại row đã hỏng; không phát sinh rule hỏng từ row hợp lệ. R3 clone payload byte-identical smoke PASS. |
| POST `/teacher/create-exam`, `/teacher/mixed-exam` | app:1440; multi_routes:255 lưu quota/type/topic/time vào ky_thi, không scoring/payload/de_json | app:494 build_exam hoặc quota sampler multi_routes:231–252 chọn row → question_types:32 snapshot | `REACHABLE_FROM_VALID_UI`; không tạo rule mới hoặc đọc raw scoring từ exam form. |
| POST `/` — bắt đầu bài mới | app:2114–2205 build_exam → json.dumps(data) INSERT bai_thi.de_json:2191 | Reader tại exam:2226/2250, autosave:2316, monitor:1901, points export multi_routes:62 | `REACHABLE_FROM_VALID_UI`; kế thừa rule DB, không semantic validation lại. |
| POST `/` — retake sau unlock | app:2142–2163 rebuild → UPDATE de_json:2152; resume chỉ đổi token/last_seen:2175 | Như trên | Snapshot retake mới; snapshot resume cũ không sửa. |
| init_db legacy/migration | app:271, multi_routes:31 thêm cột/defaults và suy luận khối; không ghi/chữa scoring hiện có | Row legacy payload rỗng hoặc payload v2.2 thiếu scoring được đọc bằng default | `REACHABLE_FROM_LEGACY_DATA` cho thiếu rule hợp lệ. Không có evidence writer legacy bình thường sinh zero/negative weights. |
| POST `/teacher/restore`, `/teacher/backup/restore/<name>` | app:2007–2084 chỉ kiểm có 4 table yêu cầu → SQLite backup copy toàn DB → init_db; không semantic validation payload/de_json/rule | Row/snapshot đã restore đi thẳng tới các reader trên | `REACHABLE_FROM_IMPORT` qua restore; origin dữ liệu sai là `ONLY_CORRUPTED/EXTERNAL_DATA`. Hai endpoint gọi cùng helper; uploaded restore đã probe runtime. |
| POST `/api/save-answer`, `/exam` và GET timeout `/exam` | app:2296/2207 ghi choices/dung vào cau_tra_loi; không ghi config hay de_json. Submit tính total_score rồi chốt diem | `correct` tin cấu trúc answer; `grade` tin points/weights, `total_score` không kiểm finite/bounds | Không cho student request trực tiếp viết config. POST muộn/đồng thời vẫn tuân thủ R1; snapshot fixture hỏng là trường hợp khác. |

## Validation trên đường native

`parse_spec` đòi SINGLE/MULTI có 2–20 options, answer đúng chỉ số và MULTI không rỗng; TF/MATCH/FILL có 1–30 mục, shape/đáp án hợp lệ. `config` chỉ nhận all/partial; points hữu hạn trong (0,1000]; explicit weights chỉ TF/MATCH/FILL, đúng số mục, từng weight hữu hạn trong (0,1000]. Weights rỗng là trường hợp hợp lệ dùng trọng số đều, khác với danh sách `[0,0]`.

Runtime POST tạo câu hỏi: MULTI answer rỗng, weights zero/negative, points negative/NaN/Infinity, mode lạ đều trả 200 với cảnh báo và delta DB = 0. Cùng 7 file Excel trả 302, delta DB = 0. Field form `payload="{malformed JSON"` bị bỏ qua: payload vẫn được dựng từ fields đã validate, rule valid points=4/partial/weights=[1,3]. Không gọi đây là đường arbitrary payload.

Evidence: `F010-final/results.json` → UI_write_probes/Excel_import_probes; các HTML và XLSX đầu vào nằm cùng thư mục. Không suy ra rằng HTTP 200/302 một mình có nghĩa validation PASS: chính delta DB và payload quyết định.

## Probe đọc/scoring và classification từng trường hợp

| Probe | Kết quả pure scorer và HTTP runtime | Classification |
|---|---|---|
| MULTI answer=[] + PARTIAL | grade/total ZeroDivisionError; exam GET 200, autosave 200, submit 500, chưa submitted | `ONLY_CORRUPTED/EXTERNAL_DATA` ở snapshot fixture; UI/Excel reject |
| TF weights=[0,0] | ZeroDivisionError; GET/save 200, submit 500 | `ONLY_CORRUPTED/EXTERNAL_DATA` ở snapshot fixture; bổ sung restore ingress đã chứng minh riêng bên dưới |
| TF weights=[-1,2], chỉ ý weight 2 đúng | earned 2 > maximum 1; total/stored score 20; submit 302, đã submitted | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| TF weights=[-1,2], chỉ ý weight -1 đúng | earned -1, total/stored score -10; submit 302 | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| points=-1, SINGLE đúng | earned/max=-1; quy đổi/stored score 10 dù maximum âm | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject. Không khẳng định riêng points âm luôn cho total âm. |
| points=NaN | pure earned/max/total NaN; HTTP submit 302, submitted_at có giá trị, SQLite diem=NULL | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| points=Infinity | pure earned/max Infinity, total NaN; HTTP submit 302, submitted_at có giá trị, SQLite diem=NULL | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| Snapshot thiếu answer | KeyError; GET 200, autosave/submit 500, chưa submitted | `ONLY_CORRUPTED/EXTERNAL_DATA` |
| Item snapshot là string, không mapping | Pure grade/total AttributeError; không gán kết quả HTTP cho probe này | `ONLY_CORRUPTED/EXTERNAL_DATA` |
| de_json không parse được | GET/submit 500; không chốt | `ONLY_CORRUPTED/EXTERNAL_DATA` |
| MULTI hợp lệ nhưng thiếu toàn bộ scoring | Mặc định maximum=1/all; full answer chấm 10 | `REACHABLE_FROM_LEGACY_DATA`: representation v2.2 được hỗ trợ theo source/docs, fixture row v2.2 qua init_db/snapshot giữ thiếu scoring, chấm 10 |
| PARTIAL thiếu points/weights | Fallback maximum=1, weights đều; chấm 10 cho full answer | `ONLY_CORRUPTED/EXTERNAL_DATA` cho partial rule không đầy đủ: không tìm thấy writer legacy hợp lệ phát shape này. Chỉ probe tính tương thích reader, không coi là lỗi bắt buộc. |
| Legacy SINGLE thiếu type/scoring | Pure grade default SINGLE/1/all chấm 10 | `REACHABLE_FROM_LEGACY_DATA`; không buộc thêm scoring vào dữ liệu cũ |

Snapshot HTTP được thay bằng SQL chỉ trong database fixture tạm. Không có người dùng production hay student UI nào được gán quyền ghi de_json. Runtime lỗi này giữ nguyên trace/500 trong evidence, không sửa source để chạy qua.

### Restore ingress thực

Fixture `.db` tạo từ backup của app test, sửa duy nhất TF payload thành weights=[0,0] ngoài workflow; SQLite `PRAGMA integrity_check = ok`. Giáo viên POST `/teacher/restore`: 302; đọc DB xác nhận rule hỏng vẫn còn. Sau đó giáo viên tạo kỳ thi và học sinh login qua UI hợp lệ: snapshot chứa rule đó, autosave 200, submit 500. Evidence `F010-final/results.json:restore_ingress` và runtime.log.

Nguồn tạo sai = `ONLY_CORRUPTED/EXTERNAL_DATA`. Đường đưa sai vào app = `REACHABLE_FROM_IMPORT` (restore `.db`, không phải Excel). Integrity SQLite chỉ chứng minh file/structure, không chứng minh scoring semantics. Clone/restore không tạo sai từ dữ liệu tốt nhưng bảo toàn sai đã có. Không phát hiện đường legacy bình thường sinh điểm âm/zero weights; không coi thiếu rule legacy hợp lệ là hỏng.

## Đề xuất patch tối thiểu để duyệt, CHƯA áp dụng

1. Một validator dữ liệu đọc cho cấu trúc item/answer theo 5 types và scoring: nonempty answer đúng shape/range; explicit points/weights phải đúng miền hữu hạn như config hiện tại; weights explicit đúng chiều/sum dương; mode đúng. Giữ các default legacy 1/all và weights rỗng hợp lệ; không yêu cầu dữ liệu cũ có version/type/fields mới khi fallback hiện tại có nghĩa hợp lệ.
2. Dùng validator ở payload→snapshot và khi đọc de_json trước autosave/submit/points export; kiểm earned/maximum/total hữu hạn và trong miền hợp lệ trước commit. Không clamp điểm, không thay trọng số/đáp án/công thức làm tròn, không tự sửa DB.
3. Bắt lỗi validation cụ thể tại caller, thông báo dữ liệu không hợp lệ và rollback trước khi chốt; giữ nguyên R1 BEGIN IMMEDIATE, deadline recheck, submitted_at condition, atomic answer+score và R2 token/unlock. Với snapshot không parse được cần cùng đường lỗi có kiểm soát. Cấu hình đã valid phải cho kết quả byte/numeric-equivalent với scorer v2.3.
4. Reuse semantic validation cho restore preflight trước thay DB là lớp phòng vệ tiếp nhận đáng cân nhắc; kiểm toàn payload và attempt snapshot, không migration sửa dữ liệu. Nếu chỉ chấp nhận bản backup tin cậy, phải định nghĩa và kiểm tra điều kiện đó; hiện chưa có assurance như vậy. Không đổi đường native UI/Excel đã validate chỉ để làm lại validation form.

Regression đề xuất: toàn bộ các probe lỗi ở bảng trên với không write/chốt khi invalid; restore file integrity-ok nhưng zero/negative/nonfinite rule; legacy payload rỗng/v2.2 không scoring; all/partial × 5 types, weights hợp lệ/rỗng và max points; round-half-up/aggregate; stored answers re-grade = stored score; deadline/autosave/submit/race/unlock/result; clone/matrix/comma topics; export điểm từng câu. Không có regression mới được viết vào candidate trong vòng audit này.

Giới hạn: không có bằng chứng DB người dùng thực tế đã hỏng hay lỗi từ file Excel hợp lệ; REQUIRED là quyết định bảo vệ ranh giới đọc/restore đã được chứng minh, không nâng/hạ severity finding để đạt một nhãn PASS.
''')

write('F011_CSRF_AUDIT.md', '''# F011 — CSRF security decision audit

`F011_PREPROD = REQUIRED`

Các thao tác dùng phiên đăng nhập nhận form POST origin khác khi browser gắn cookie; không cần đọc cookie hay biết session secret. Probe thực hiện hoàn toàn trên 2 HTTP server loopback và DB test tạm. Không có tấn công hệ thống thật.

## Inventory và cơ chế hiện tại

Runtime Flask url_map đã liệt kê 34 route POST có khả năng đổi trạng thái; không có PUT/PATCH/DELETE. Xem toàn bộ từng route, role/auth/token/cookie/Origin/Referer trong `PREPROD_ROUTE_INVENTORY.md` và `F011-server/results.json`. Source `app.py:81/90` kiểm phiên/role; multi_routes dùng cùng teacher_required. Hai before_request (`app.py:546/572`) chỉ kiểm giấy phép và maintenance, không kiểm CSRF.

Không route nào kiểm Origin/Referer trước business write. Việc dùng request.referrer làm URL redirect trong import không phải Referer validation. Tất cả teacher/admin POST dựa vào signed session, ngoại trừ login dùng credential. `/teacher/students/import-confirm` là ngoại lệ nonce riêng: so sánh `student_import_token` trong session với token của form bằng compare_digest (`app.py:1285`); nonce không được export. Không thể suy từ ngoại lệ này ra cơ chế CSRF toàn app.

Student client_token nằm trong cookie session, so khớp DB bởi validate_attempt_session. Đây là bảo vệ sở hữu attempt/revocation, không phải request nonce mà trang origin khác không tự gửi được. Browser tự gửi cùng cookie hợp lệ trong form CSRF; R1/R2 không ngăn loại request origin khác này.

Old password ở change-password và signed license key ở activation là điều kiện nghiệp vụ riêng; chúng hạn chế input/thao tác tương ứng, không thay cơ chế CSRF chung cho add/delete/restore/unlock/settings.

## Cookie/session thực tế

| Thuộc tính | Cấu hình/Set-Cookie quan sát |
|---|---|
| Name/domain/path | session; host-only (Domain không đặt); Path=/ |
| SameSite | Flask SESSION_COOKIE_SAMESITE = Python None; **attribute bị bỏ khỏi Set-Cookie**, khác với explicit `SameSite=None` |
| Secure | False; Set-Cookie không có Secure |
| HttpOnly | True; Set-Cookie có HttpOnly |
| Lifetime | Session cookie, không expires trong probe; PERMANENT_SESSION_LIFETIME mặc định 31 ngày không được dùng làm chứng minh thời gian sống permanent |
| Implementation | flask.sessions.SecureCookieSessionInterface: cookie phía client được ký, không có server-side session store; ký không ngăn browser tự gửi cookie |
| Browser interpretation | Chromium 151.0.7922.173 hiển thị SameSite=Lax hiệu lực cho cookie thiếu attribute |
| Transport hợp tài liệu/source | Waitress host 0.0.0.0 không TLS (`app.py:2411`); hướng dẫn dùng http://127.0.0.1 và http://192.168.1.29:5000. Không có HTTPS/reverse-proxy được cấu hình/test ở vòng này |

Evidence `F011-server/results.json` giữ attributes Set-Cookie và config thực, đã redact value; browser giữ cookie metadata không giữ giá trị. Không giả định rằng nhãn Lax hiệu lực sẽ chặn mọi POST. Probe cross-site mới đăng nhập (<1 giây) thành công như bảng dưới; không kéo dài/giả định kết quả cho cookie cũ hơn hoặc browser khác.

## Runtime server-side

| Fixture/request | Origin/Referer/token | Kết quả |
|---|---|---|
| ADMIN và GIAOVIEN POST student/add, mỗi role 4 trường hợp | Thiếu cả hai; Origin khác; Referer khác; cả hai khác; không CSRF nonce | 8/8 nhận 302, mỗi request thêm đúng 1 row test |
| ADMIN POST settings | Thiếu cả hai hoặc cả hai khác; không nonce | 2/2 nhận 302, school_name fixture được đổi |
| Anonymous POST student/add | Không phiên | 302 login, 0 row; authentication vẫn hoạt động |
| GIAOVIEN POST admin settings | Phiên teacher | Không đổi setting; admin role guard vẫn hoạt động |
| Student POST JSON autosave trong Flask client | Cookie/attempt token hợp lệ, Origin khác, không request nonce | 200, answer được lưu; đây là server acceptance, **không phải browser bypass CORS** |
| Import-confirm | Nonce sai | 302, 0 row |
| Import-confirm | Nonce session hợp lệ + Origin khác | 302, 1 row; confirms nonce thực, server không check Origin |

Evidence `F011-server/results.json` và runtime.log. Probes dùng account/student/settings/Excel mới vô hại trong DB tạm; không restore/delete dữ liệu thật để chứng minh CSRF.

## Chromium tự nhiên — không route/intercept request

Nguồn kết luận: `F011-browser-complete/results.json` + ảnh + WSGI wire observer. Observer chỉ ghi header metadata rồi gọi app nguyên trạng; không override headers/cookie/security flags. Đã có một run dùng Playwright routing làm sai phép đo CORS; run đó bị loại khỏi kết luận, xem `HARNESS_OBSERVATION_NOTES.md`. Bản kết luận không có route interception.

| Scenario | Browser/WSGI evidence | Trạng thái DB test |
|---|---|---|
| Teacher form POST từ cùng host nhưng port khác | Origin khác; Sec-Fetch-Site=same-site; Cookie attached; không token; 302 | Tạo học sinh fixture thành công |
| Teacher form POST từ localhost tới 127.0.0.1 sau login mới | Sec-Fetch-Site=cross-site; Cookie attached; không token; 302 | Tạo học sinh fixture thành công. Chỉ khẳng định cookie mới trong probe, không mọi tuổi cookie |
| Cross-site GET teacher/logout | Cookie attached; không token; 302 | Phiên test bị clear, mở teacher phải login |
| Student fetch JSON application/json từ cùng-site origin khác | Browser Failed to fetch; wire chỉ OPTIONS, không POST; server không phát Allow-Origin | 0 answer row. Playwright phát sự kiện request-intent POST không có nghĩa POST đã tới server |
| Student top-level HTML form POST `/exam` từ cùng-site origin khác | Cookie attached; không nonce; wire POST tới app | submitted_at từ NULL thành có giá trị; score từ NULL thành 0, redirect result |

JSON non-simple request bị preflight chặn trong trình duyệt này, nhưng CORS không chặn top-level form POST và không thay CSRF policy server. Browser probe chưa đo older-cookie >2 phút, Firefox/WebKit, origin Internet/public→private theo chính sách private-network của từng browser, hay mạng LAN/HTTPS vật lý. Các giới hạn đó không phủ định form origin khác đã thành công; không hạ rủi ro chỉ vì LAN.

## Attack surface/impact có chứng cứ

Phiên ADMIN có thể thực hiện route admin và teacher; phiên GIAOVIEN có các route teacher. Form POST kiểu x-www-form-urlencoded tới add/clone/create-exam/toggle/delete/unlock/settings được browser phép gửi mà không cần đọc response. Destructive route được xác định bằng source/guard inventory, không bị khai thác trong runtime. Restore/import yêu cầu file: form trang khác không tự chọn local file của nạn nhân; payload upload khả thi còn phụ thuộc browser/CORS/nguồn file, **không coi mọi route upload đã được khai thác**. Import-confirm nonce riêng hiện hạn chế request không biết nonce. Change-password còn yêu cầu old password; license còn yêu cầu key hợp lệ.

Login không đòi phiên cũ: source không CSRF nonce, login CSRF là bề mặt cần bảo vệ khi biết credential tài khoản của bên gửi; không claim lấy được mật khẩu nạn nhân. `/exam` đã probe chốt sớm khi chưa hết hạn; token ownership và R1 deadline/atomicity vẫn đúng vì request dùng chính phiên valid. Đây không phải regression của F001/F002, mà thiếu kiểm nguồn/nonce request (F011).

## Tác động của CSRF và phạm vi patch để duyệt

| Workflow | Thay đổi cần thiết nếu bảo vệ | Điều phải giữ |
|---|---|---|
| HTML teacher/admin forms | Hidden request nonce, check trước write cho cả direct/nested multi routes | Role/auth guard và validation nghiệp vụ hiện có |
| Teacher AJAX/fetch | Header nonce khi có mutation; GET availability/monitor không cần mutation nonce | Không làm hỏng 20-cell matrix/topics |
| Login teacher | Nonce gắn pre-auth session, rotate sau successful login | Failed-password/lockout và giấy phép; không chặn chỉ vì chưa có phiên authenticated |
| Import multipart/preview/confirm | Nonce chung cho preview/upload/confirm; giữ riêng operation nonce hiện có | Không ghi/save upload trước validation; không thay input Excel |
| Unlock/retake | Nonce trước unlock write | F017 revoke token, legacy semantics và retake snapshot |
| Logout | Mutation POST + nonce hoặc giải pháp kiểm nonce phù hợp; điều chỉnh link/form tương ứng | Không để GET có thể clear session ngoài ý muốn |
| Student login/submit | Nonce riêng cho form và check trước business mutation nếu phạm vi bao phủ student | Snapshot/scoring/deadline/atomicity/token ownership; không nhận late answers |
| Student autosave/ping | Nếu global guard thì JS gửi nonce header; giữ API JSON và không mở CORS bừa | Autosave deadline/status, submitted rejection, token refresh/unlock; token đủ sống cho kỳ thi tới 180 phút |

**Có thể bảo vệ riêng TEACHER/ADMIN về kỹ thuật**, dùng guard theo endpoint/namespace, bao gồm pre-auth teacher login và logout. Không bắt buộc refactor student/scorer/schema để đóng bề mặt teacher/admin. Scope này phải ghi rõ chỉ đóng F011 teacher/admin; `/exam` HTML attack vừa chứng minh vẫn còn, nên không thể gọi app đã có CSRF protection đầy đủ.

Phạm vi nhỏ nhất để đóng các **đường tấn công đã chứng minh trong audit**: teacher/admin mutation routes + login/logout và student HTML login/submit có request nonce gắn session/rotate khi đổi phiên. Giữ operation nonce import. Với JSON autosave/ping hiện preflight chặn browser cross-origin, có thể tách giai đoạn khỏi guard teacher; nếu chọn global CSRF guard thì phải cập nhật đồng bộ 2 API JS, không thêm guard làm student workflow lỗi. Trước bất kỳ kết luận pre-production tổng thể cần người dùng xác nhận phạm vi student còn mở hoặc chọn bảo vệ thống nhất. Không chỉ thêm SameSite hoặc kiểm cookie token rồi tuyên bố đã xử lý CSRF.

Đề xuất security policy: nonce session khó đoán, kiểm request form/header trước thay trạng thái, missing/wrong nonce trả lỗi kiểm soát; xử lý Origin/Referer theo origin app thực làm lớp bổ sung với policy rõ cho header thiếu. Cookie SameSite explicit có thể là lớp phụ; Secure=True cần HTTPS deployment và không được bật trên LAN HTTP rồi làm mất cookie. Đây là đề xuất, không cấu hình/patch nào đã áp dụng.

Regression cần có khi patch được duyệt: missing/wrong/valid nonce trên đủ 34 route, role/anonymous controls, pre-auth login/session rotation, origin/cross-site browser form cases, GET logout, multipart imports và nonce preview-confirm, unlock/relogin, student submit/expiry/race, autosave/ping JS, stale tabs/token lifetime/180 phút, result/scoring/snapshot và HTTPS/HTTP policy đã chọn. Không đổi test gốc hoặc cấu hình môi trường trong audit này.
''')

write('F012_HISTORY_REPORT_AUDIT.md', '''# F012 — Historical report integrity

`F012_PREPROD = PRODUCT_DECISION_REQUIRED`

`CONTRACT = UNDEFINED` đối với metadata/nội dung/phân loại trong báo cáo lịch sử. Contract **scoring** đã xác định: chốt khi bắt đầu bài. Hai contract phải được phân biệt.

## Runtime workflow hoàn toàn qua UI endpoints hợp lệ

1. Teacher tạo SINGLE level NB, text SOURCE_BEFORE_NB, points=4/all qua `/teacher/multi/new`.
2. Teacher tạo kỳ thi, thêm học sinh; student login nhận snapshot, autosave đúng, submit → điểm 10.
3. Capture report HTML/context, exam-report Excel, result, analytics, monitor, điểm từng câu Excel, kết quả Excel; đọc attempt/answers từ DB fixture.
4. Teacher sửa chính câu qua `/teacher/multi/edit/<qid>`: NB→VD, text SOURCE_AFTER_VD, points=9.
5. Capture lại cùng các endpoints; không re-submit/re-grade/update attempt/answers, không SQL sửa câu trực tiếp.

Evidence `F012/results.json`, các file before_*/after_*, `probe_history.py`, `F012/history-secondary-comparison.json`. Tất cả response dùng trong so sánh HTTP 200; create/edit/submit trả 302 như flow hiện tại.

| Giá trị/view | BEFORE | AFTER |
|---|---|---|
| Bank row level/text/points | NB / SOURCE_BEFORE_NB / 4 | VD / SOURCE_AFTER_VD / 9 |
| Stored attempt score | 10 | 10 |
| Stored de_json question text/points | SOURCE_BEFORE_NB / 4 | Giữ nguyên byte string |
| Stored answer rows và toàn bộ attempt row | Captured | Hoàn toàn bằng BEFORE |
| Report qstats text/cognitive | SOURCE_BEFORE_NB / NB | SOURCE_AFTER_VD / VD |
| Report levels số lượt NB/VD | 1 / 0 | 0 / 1 |
| Report average, student result, monitor score | 10 | 10 |
| Excel PhanTichCauHoi | NB / text cũ | VD / text mới |
| Excel TheoMucDo lượt NB/VD | 1 / 0 | 0 / 1 |
| Excel KetQuaHocSinh/TongQuan | Score/summary 10 | Rows giữ nguyên |
| Excel DiemTungCau | earned/max=4/4, quy đổi 10 | Rows giữ nguyên dù bank points=9 |
| Excel BangDiem | 10 | Rows giữ nguyên |
| Analytics HTML | Điểm TB 10.0 và row 10.0 | Bodies bằng nhau, số vẫn 10.0 |
| Student result HTML | 10.0/10 | Bodies bằng nhau |

`analytics_contains_score10=false` trong raw results là phép tìm literal `10.0/10` không phù hợp markup analytics; không phải điểm analytics bị mất/sai. Saved HTML có `<h3>10.0</h3><p>Điểm TB toàn hệ thống`; kiểm tra offline bổ sung nằm trong history-secondary-comparison.json. Raw probe được giữ nguyên, không sửa assertion/source để PASS.

`REACHABLE_FROM_VALID_UI`: trạng thái thay đổi do teacher edit hợp lệ, không cần DB hỏng/restore/legacy manipulation.

## Source và UI/docs contract

- `app.py:1553` report: qstats/level_stats JOIN `cau_tra_loi → bai_thi → cau_hoi`; lấy ma_cau/noi_dung/muc_do từ bảng bank hiện tại. Count/dung lấy answers đã lưu. Các điểm/average lấy bai_thi.diem, không re-grade theo ngân hàng.
- `app.py:1675` exam-report Excel: JOIN tương tự, thêm mon/chu_de hiện tại; PhanTichCauHoi và TheoMucDo kế thừa dữ liệu này. KetQuaHocSinh/TongQuan dùng attempt score.
- `multi_routes.py:55` points export đọc de_json rồi grade với choices đã lưu; đã chứng minh không đổi khi bank points bị sửa. `app.py:2093` export-results dùng attempt score.
- `app.py:1816` analytics và `/teacher/api/monitor/<eid>` tổng hợp attempt/score; `/result` (`app.py:2356`) hiển thị stored score. Những view này không đổi trong scenario.
- `question_types.py:32` snapshot giữ q/image/type/options/answer/right/scoring/id, nhưng **không lưu cognitive/muc_do, mon, chu_de, ma_cau**. Fixture xác nhận fields thực: answer,id,image,options,q,scoring,type.
- `README_v2.3.txt:51–53`: “Cách chấm được chốt lúc học sinh bắt đầu bài. Đổi cấu hình trong ngân hàng chỉ ảnh hưởng các bài bắt đầu sau đó. Không tự tính lại bài đã nộp.” Cam kết này nói cách chấm, không nói đóng băng mọi metadata report.
- `templates/report.html` chỉ ghi “Báo cáo kỳ thi”, “Mức độ”, nội dung/thống kê; không ghi “tại thời điểm thi” hay “theo ngân hàng hiện tại”. Docs báo cáo/Excel hiện có không xác định rõ thời điểm metadata. Full text search source/docs/UI và numbered excerpts nằm trong SOURCE_EVIDENCE.md và contract-search.txt.

Source hiện thực dynamic bank view; đây là quan sát behavior, **không phải bằng chứng người dùng đã chọn contract B**. Cam kết snapshot scoring không đủ để tự chọn A cho toàn bộ report. Vì chưa có contract nghiệp vụ rõ nên cần quyết định, không tự patch/đổi severity để đạt PASS.

## Hai hành vi chính xác để người dùng quyết định

| Lựa chọn | Hành vi report/Excel | Dữ liệu cũ và hệ quả |
|---|---|---|
| A — SNAPSHOT TẠI THỜI ĐIỂM THI | Đóng băng ma_cau/mon/chu_de/muc_do và nội dung theo từng attempt lúc bắt đầu. Sửa bank NB→VD không đổi phân tích lịch sử; points/answers/score vẫn dùng snapshot. | Bổ sung metadata vào snapshot mới, lấy report từ per-attempt snapshot. Bài cũ có q nhưng không có level/topic/code; không thể khôi phục chính xác metadata lịch sử nếu không có backup đáng tin. Phải định nghĩa nhãn unknown/legacy hoặc chỉ backfill từ evidence xác thực; không dùng current bank rồi gọi là snapshot lịch sử. Khi cùng ID được sửa giữa các lần bắt đầu, grouping phải tôn trọng snapshot/version, không ghép sai cohort. |
| B — VIEW THEO NGÂN HÀNG HIỆN TẠI | Giữ JOIN hiện tại cho code/subject/topic/level/content; đổi NB→VD sẽ chuyển các lượt lịch sử sang VD và hiển thị text mới. Điểm/answers/snapshot bài thi giữ nguyên. | Cần ghi rõ nhãn/contract rằng phân tích dùng bank hiện tại; tránh trình bày metadata mới như câu học sinh thực sự đã thi. Ngữ nghĩa points export vẫn là scoring snapshot. |

Audit không chọn A hoặc B. Nếu người dùng chọn A, patch tối thiểu phải xử lý metadata snapshot và readers report/export nhất quán, regression NB→VD/text/code/topic/subject + nhiều snapshot cùng ID + legacy missing metadata, tuyệt đối không tự re-grade bài đã nộp. Nếu chọn B, cần xác nhận dynamic behavior và tài liệu/nhãn nhất quán; vẫn giữ regression score/snapshot/answers/Excel điểm không đổi. Không áp dụng lựa chọn nào trong vòng này.

Giới hạn: scenario một câu/attempt đã đủ chứng minh report drift; chưa kiểm nhiều đời snapshot/grouping vì đó thuộc lựa chọn/patch tương lai. Không có evidence contract lịch sử riêng ngoài bộ source/docs/UI baseline R3 được cung cấp.
''')

write('PREPROD_RUNTIME_REPORT.md', f'''# PREPROD runtime report

`R3_BASELINE_REGRESSION = NOT_DETECTED`

`PREPROD_GATE = READY_FOR_PATCH_DECISION`

## Isolation và môi trường

SHA-256 baseline trước mọi smoke: `{BASELINE}`. Python 3.12.14; Flask 3.1.3; Waitress 3.0.2; openpyxl 3.1.5; Chromium 151.0.7922.173. Harness mới ở PREPROD_EVIDENCE, không đưa vào baseline/candidate. `audit_support.py` copy PHAN_MEM vào TemporaryDirectory, riêng LOCALAPPDATA/SQLite/file output; không import locked source in place, không viết pycache mới vào baseline. Smoke runner tương tự dùng stage tạm và giữ tên thư mục cũ chỉ để harness nguyên gốc resolve paths; **nội dung stage là R3, không chạy lại baseline cũ**.

Browser Waitress và attacker server bind 127.0.0.1 trên port tạm; không công khai server, không tới mạng ngoài trong browser probe. Không test Windows EXE hay LAN vật lý/production; không cấu hình TLS/cookie môi trường thật. Những giới hạn này không thay bằng suy đoán browser.

## Smoke/regression trước decision probes

| Suite | PASS | FAIL | Evidence |
|---|---:|---:|---|
| R1 regression F001/F002/F003 và scoring × 5 types | 18 | 0 | smoke-r1/results.json |
| R2 regression F004/F007/F009/F017 | 15 | 0 | smoke-r2/results.json |
| R3 regression F005/F006/F008 | 15 | 0 | smoke-r3/results.json |
| 6 test gốc: v23, v23_integration, v22, v221, v222, mathjax | 6 | 0 | smoke-original/runner-results.json và từng log |
| Audit harness gốc | 21 | 0 | smoke-original/audit-checks.json |
| Legacy harness gốc | 6 | 0 | smoke-original/legacy-checks.json |
| Race probe gốc | 1 | 0 | smoke-original/race-probe.json |
| Browser scenario gốc: mathjax, 20-cell matrix, five types | 1 | 0 | smoke-original/browser-checks.json và 3 ảnh |
| Tổng nhóm/script/scenario (không gọi là số assertion) | 83 | 0 | smoke-summary.json |

| Finding đã PASS | Smoke tái xác nhận |
|---|---|
| F001 | Expired POST/GET, exact deadline, wait-lock recheck, saved ALL/PARTIAL/weights, đủ 5 types |
| F002 | 8 parallel submit, duplicate/autosave sau submitted, queued autosave, atomic rollback/retry, race re-grade khớp stored score |
| F003 | Comma-topic 20-cell round-trip và 14 legacy cases, persisted row/schema tương thích |
| F004 | 20-cell type×level canonical/lowercase/space/Unicode, create/mixed/fallback sampler, score10 |
| F005 | Clone 4 grades × 5 types × 2 modes; legacy metadata/payload giữ nguyên |
| F006 | Invalid time/quota ở cả 2 flows, đúng notice/DB unchanged; valid boundary/defaults |
| F007 | Result valid/invalid/current/legacy tokens |
| F008 | Teacher Excel text literal exports, numeric cells giữ numeric, 5 types/points outputs |
| F009 | Invalid legacy ABCD edit reject before write; valid normalized answers score10 |
| F017 | Unlock revoke old save/submit/result; NULL legacy token; relogin/retake; queued writers |

Source SHA của 6 test gốc được ghi trong runner-results; 4 harness audit gốc là unchanged/byte-identical. Harness R3 smoke dùng đúng ui_observer đã PASS R3, không sửa nó trong vòng này. Không skip/XFAIL và không edit test gốc. Trace rollback injection trong smoke là assertion kiểm transaction, không được đếm thành regression chỉ vì log có ERROR.

## Decision runtime probes

| Run | Hoàn tất | Nội dung/bằng chứng |
|---|---|---|
| F010 final | Exit 0 | 12 pure scorer probes, 7 invalid UI rejects + raw payload ignored, 7 invalid Excel rejects, 9 HTTP corrupted snapshot scenarios, v2.2 legacy fixture, restore ingress. F010-final/results.json |
| F011 server | Exit 0 | 34-route inventory, cookie config/Set-Cookie, 8 teacher/admin add requests, 2 settings, auth/role controls, import nonce, student server JSON. F011-server/results.json |
| F011 browser complete — passive | Exit 0 | Same-site/cross-site fresh teacher POST, logout, student JSON OPTIONS-only, student HTML early submit. F011-browser-complete/results.json và 3 PNG |
| F012 legitimate history | Exit 0 | Create NB → submit10 → edit VD/text/points → before/after 7 views/exports; unchanged snapshot/answers/score; report/Excel metadata drift. F012/results.json và before_*/after_* |

Exit 0 ở decision harness có nghĩa **đã hoàn tất phép đo**, không có nghĩa F010/F011/F012 đã được sửa hoặc PASS. Những HTTP 500, score -10/20/NULL là finding evidence được tái hiện chủ động trên DB fixture, không phải regression các finding đã hotfix. JSON schema output giữ nonfinite dưới representation rõ, không che NaN.

Lệnh thực thi (cwd repository, output không trùng lần trước):

```sh
/workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source /workspace/preprod-r3-baseline/PHAN_MEM --output PREPROD_EVIDENCE/smoke-r1
/workspace/tnlan-audit-venv/bin/python HOTFIX_R2_EVIDENCE/r2_regression.py --source /workspace/preprod-r3-baseline/PHAN_MEM --output PREPROD_EVIDENCE/smoke-r2
/workspace/tnlan-audit-venv/bin/python HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py --source /workspace/preprod-r3-baseline/PHAN_MEM --output PREPROD_EVIDENCE/smoke-r3
/workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/run_original_checks.py --source /workspace/preprod-r3-baseline --output PREPROD_EVIDENCE/smoke-original
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_scoring.py --output PREPROD_EVIDENCE/F010-final
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_csrf_server.py --output PREPROD_EVIDENCE/F011-server
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_csrf_browser_complete.py --output PREPROD_EVIDENCE/F011-browser-complete
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_history.py --output PREPROD_EVIDENCE/F012
```

Các smoke harness phụ thuộc bố cục repository gốc; copies/hash chỉ là provenance nguyên trạng, không giả định handoff tự chứa application để chạy độc lập. Để tái lập cần lấy đúng candidate R3 có SHA trên và dependencies; handoff intentionally không chứa source/candidate mới.

## Raw run thất bại và phép đo bị loại

`HARNESS_OBSERVATION_NOTES.md` giải thích đầy đủ. F010 initial: fixture legacy thiếu 4 NOT NULL option columns, runner preparation IntegrityError; bổ sung fields của **fixture mới**, final đầy đủ. F011 initial: exact response URL observer timeout tại GET logout; observer mới đối chiếu URL bỏ query suffix và quan sát navigation/response thực. Nguyên nhân ở observer không được suy thành lỗi ứng dụng. Run browser có network routing cho kết quả POST JSON tới app không phù hợp phép đo CORS tự nhiên, bị loại. Hai run passive sau đó xác nhận wire chỉ OPTIONS/0 writes cho JSON và complete thêm student HTML submit; kết luận dựa trên complete passive. Raw logs và partial outputs các run ban đầu giữ nguyên; các bản browser harness được giữ riêng, chỉ sửa cách dựng fixture mới F010. Không sửa source/test assertion gốc để làm PASS.

## Bằng chứng cuối và giới hạn

62/62 source files đã giải nén được hash so lại, file set không đổi; candidate SHA và size vẫn khớp. Manifest/checksum/package được kiểm tra read/CRC và từng member; chỉ handoff ZIP commit. Xem source-lock-final.json và package validation ngoài ZIP. Không có patch, candidate mới, migration DB thật, hotfix R4, bump version hoặc production.
''')

write('PREPROD_DECISION_MATRIX.md', f'''# PREPROD decision matrix

{matrix}

`PREPROD_GATE = READY_FOR_PATCH_DECISION`

Đủ runtime/source evidence cho ba quyết định; không dùng điểm số rủi ro tổng hợp. Không kết luận PRODUCTION READY. R3 smoke PASS chỉ xác nhận các finding đã sửa, không đóng F010/F011/F012.

| Finding | Evidence chính | Quyết định tiếp theo cần duyệt |
|---|---|---|
| F010 | F010-final/results.json, runtime.log; SOURCE_EVIDENCE.md: config/grade/total_score/snapshot/restore; source-write-map.json | Validator đọc snapshot/scoring + controlled errors/rollback, giữ legacy/defaults và toàn bộ scoring v2.3; cân nhắc restore preflight. Xem F010_SCORING_AUDIT.md. |
| F011 | F011-server/results.json; F011-browser-complete/results.json, wire headers/PNG; 34-route inventory | Nonce cho teacher/admin/login/logout; xác nhận scope student HTML đã chứng minh có thể bị chốt sớm. Nếu global guard, cập nhật autosave/ping JS đồng bộ. Xem F011_CSRF_AUDIT.md. |
| F012 | F012/results.json và before/after HTML/XLSX; README_v2.3:51; report/export JOIN và snapshot fields | Chọn A: metadata tại thời điểm thi, policy legacy không có metadata; hoặc B: bank hiện tại với nhãn/contract rõ. Audit không tự chọn. |

Các đề xuất chỉ để review; chưa áp dụng thay đổi nào. Dừng sau Git handoff và chờ người dùng quyết định.
''')

inventory = json.loads((EV / 'F011-server/results.json').read_text())
lines = ['| METHOD | PATH | AUTH REQUIRED? | ROLE | CATEGORY | CURRENT CSRF | ORIGIN CHECK? | REFERER CHECK? | CUSTOM TOKEN? | SESSION COOKIE DEPENDENCY? | SOURCE |',
         '|---|---|---|---|---|---|---|---|---|---|---|']
for r in inventory['inventory']:
    student = r['path'] in ('/exam', '/api/save-answer', '/api/ping')
    public = r['path'] in ('/', '/teacher/login')
    role = 'STUDENT attempt' if student else 'Login credential/code' if public else r['role']
    auth = 'No pre-auth; validates code/credential' if public else 'Yes'
    custom = 'import-confirm operation nonce' if 'import-confirm' in r['path'] else 'attempt client_token in session (not request CSRF nonce)' if student else 'none for CSRF; business inputs separately validated'
    csrf = 'session-bound form nonce' if 'import-confirm' in r['path'] else 'none general'
    dep = 'Not needed beforehand; issues cookie on login' if public else 'Yes'
    lines.append('| ' + ' | '.join([','.join(r['methods']), '`'+r['path']+'`', auth, role, r['category'], csrf, 'No', 'No', custom, dep, f"{r['source_file']}:{r['source_line']}"]) + ' |')

write('PREPROD_ROUTE_INVENTORY.md', '''# PREPROD route inventory — F011

Inventory lấy từ runtime `app.url_map` của đúng R3 trong source copy/DB tạm, sau install_multi_routes. 34 route state-changing **POST**; không có PUT/PATCH/DELETE. HEAD/OPTIONS tự sinh không được tính thành business mutation. Role đọc decorator của view unwrapped và được kiểm source/negative auth controls, không giả định mọi `/teacher` đều admin. Toàn bộ route cũng đi qua license gate hiện có.

Teacher/ADMIN nghĩa GIAOVIEN hoặc ADMIN có teacher session; ADMIN nghĩa admin_required. STUDENT attempt nghĩa aid/client_token hợp lệ theo DB; token không là CSRF nonce độc lập. AUTH No pre-auth chỉ áp dụng login; không có nghĩa bypass credential/student code.

''' + '\n'.join(lines) + '''

## Route family / state effect

| Family | State-changing effect |
|---|---|
| Authentication | Teacher login reset/update failed attempts/lockout/last login hoặc tạo session; student login tạo/resume/retake attempt; change/reset password |
| Admin accounts | Add account, toggle active, reset password; admin guard |
| Settings/license | Đổi branding/port/settings, nhận signed license activation; admin guard |
| Questions | Add/edit/clone/delete/bulk-delete; multi editor và Excel import ghi validated payload |
| Exam management | Create/mixed-exam ghi kỳ thi, toggle active, delete kỳ thi/answers/attempts |
| Student management | Add/delete/import/bulk update/xóa học sinh theo logic route |
| Restore/backup | Tạo backup, upload/saved restore thay DB; file và table-name validation có thật nhưng không CSRF chung |
| Unlock | force_relogin/client_token và quyền relogin/retake attempt |
| Student exam | Autosave answers/last_seen; ping last_seen; submit answers+score một transaction |

## GET side effects ngoài tập 34 mutation routes

`GET /teacher/logout` clear session và ghi logout audit; browser cross-site đã tái hiện. `GET /exam` cập nhật last_seen, hoặc finalize attempt khi deadline hết hạn theo chính sách hiện tại. Đây là các effect nghiệp vụ cần tính khi chọn policy, không được giả định GET hoàn toàn read-only.

Export GET có thể ghi file export/audit; trước request teacher có daily backup một lần/ngày. Các effect file/log này được ghi nhận, không xếp thành proof khai thác destructive mutation và không sửa maintenance trong audit. Guard CSRF chỉ chặn POST không tự loại tất cả side effects GET; cần review logout riêng.

Source tham chiếu trong SOURCE_EVIDENCE.md; machine inventory ở F011-server/results.json. Request.referrer redirect không phải kiểm Referer; signed license/old password là business credential, không custom CSRF nonce. Nonce import-confirm là ngoại lệ hẹp duy nhất; không đóng toàn bộ import preview/teacher workflow.
''')

notes = '''# Harness observation notes — preserve raw outcomes

No application source, candidate, original test or prior hotfix harness was changed.

1. F010 initial (`F010.log`, `F010/`): preparation failed at synthetic legacy INSERT because option columns a/b/c/d are NOT NULL. Final `probe_scoring.py` fixture INSERT supplies four empty strings and answer A, consistent with the v2.2 payload row format. This corrects new fixture construction, not scoring assertions. Completed output uses fresh `F010-final/` and `F010-final.log`. Initial partial files/log remain; no exception is treated as product PASS.
2. F011 initial (`probe_csrf_browser.py`, `F011-browser.log`, `F011-browser/`): exact-URL response observer timed out at GET logout. A form GET may append a query suffix. New observer matches URL before query suffix and records actual response/wire events. No app/source change; initial incomplete run is retained and excluded from conclusions.
3. Routing observer (`probe_csrf_browser_observer.py`, `F011-browser-final/`): network interception was enabled as a loopback allow-list. JSON fetch showed app-side POST despite CORS failure and no natural OPTIONS preflight, so this run is unsuitable evidence for natural CORS/browser behavior. Do not infer JSON autosave browser exploitation from its answers_written=1. Raw data is retained, explicitly superseded for browser conclusions.
4. Passive observer (`probe_csrf_browser_passive.py`, `F011-browser-passive/`): replaces request routing with passive request event observation. No Chromium security flags except sandbox adaptation --no-sandbox, no altered headers/cookies, no external requests. WSGI sees OPTIONS only; zero JSON answer writes. Teacher same-site and cross-site fresh-cookie form POST and logout still succeed.
5. Completed passive observer (`probe_csrf_browser_complete.py`, `F011-browser-complete/`): same passive setup adds student HTML blank submit scenario. This is the authoritative browser evidence: teacher mutation, student HTML forced early submission; JSON CORS preflight blocked. Playwright request-intent event is distinguished from actual WSGI request. No assertions weakened to hide errors.
6. F012 raw analytics_contains_score10 tests literal 10.0/10, which belongs to result markup, not analytics. Preserved before/after analytics HTML instead shows average 10.0 and bodies unchanged; secondary offline parsing is saved separately. Raw result field is not rewritten.

All actual R3 smoke results are complete PASS. New instrumentation preparation/observer failures above are not baseline regression; actual abnormal scoring runtime failures remain findings evidence, not fixed. No original test, skip or XFAIL added/modified.
'''
(EV / 'HARNESS_OBSERVATION_NOTES.md').write_text(notes, encoding='utf-8')
print('Created 7 decision reports and harness observation notes.')
