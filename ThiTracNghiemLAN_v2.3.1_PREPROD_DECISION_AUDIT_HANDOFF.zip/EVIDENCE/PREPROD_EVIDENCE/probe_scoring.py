"""F010 reachability and failure observations; no defensive patch."""
import copy,json,math,sqlite3,traceback
from io import BytesIO
from pathlib import Path
from openpyxl import Workbook
from audit_support import arguments,runtime,sql,dump,seed,attempt,form_answers

def numeric(value):
 if isinstance(value,float) and not math.isfinite(value):return {'non_finite':repr(value)}
 return value

def main():
 args=arguments();out={'pure_probes':[],'UI_write_probes':[],'Excel_import_probes':[],'runtime_corrupted_snapshots':[],'legacy':[]}
 with runtime(args.source,args.output) as (m,teacher,root):
  from scoring import grade,total_score
  base=dict(type='TF',options=['Ý 1','Ý 2'],answer=['D','S'],scoring=dict(version=1,points=1,mode='partial',weights=[1,1]))
  cases=[]
  def add(name,item,value,reach='ONLY_CORRUPTED/EXTERNAL_DATA'):cases.append((name,item,value,reach))
  add('MULTI_answer_empty',dict(type='MULTI',options=['A','B'],answer=[],scoring=dict(version=1,points=1,mode='partial',weights=[])),[])
  for name,weights,value in [('weights_all_zero',[0,0],['D','S']),('negative_weight_over_max',[-1,2],['','S']),('negative_weight_negative_score',[-1,2],['D',''])]:
   item=copy.deepcopy(base);item['scoring']['weights']=weights;add(name,item,value)
  for name,points in [('max_score_negative',-1),('max_score_NaN',float('nan')),('max_score_Infinity',float('inf'))]:
   add(name,dict(type='SINGLE',options=['A','B'],answer=0,scoring=dict(version=1,points=points,mode='all',weights=[])),0)
  add('malformed_missing_answer',dict(type='SINGLE',options=['A','B'],scoring=dict(points=1)),0)
  add('malformed_snapshot_non_mapping','not a mapping',0)
  add('missing_scoring_legacy',dict(type='MULTI',options=['A','B'],answer=[0]),[0],'REACHABLE_FROM_LEGACY_DATA')
  item=copy.deepcopy(base);item['scoring']={'mode':'partial'};add('missing_points_weights_fallback',item,['D','S'])
  item=dict(type='SINGLE',options=['A','B'],answer=0);add('legacy_SINGLE_without_type_scoring',dict(options=item['options'],answer=0),0,'REACHABLE_FROM_LEGACY_DATA')
  for name,item,value,reach in cases:
   record=dict(name=name,reachability=reach,snapshot_representation=json.dumps(item,ensure_ascii=False,allow_nan=True),value=value)
   try:
    earned,maximum=grade(item,value);record.update(grade={'earned':numeric(earned),'maximum':numeric(maximum),'finite':math.isfinite(earned) and math.isfinite(maximum),'bounded':0<=earned<=maximum})
   except Exception as exc:record['grade_exception']=dict(type=type(exc).__name__,message=str(exc))
   try:score=total_score([item],{0:value});record.update(total_score=numeric(score),total_finite=math.isfinite(score))
   except Exception as exc:record['total_exception']=dict(type=type(exc).__name__,message=str(exc))
   out['pure_probes'].append(record)
  # Normal UI writes: config/answer validation, not raw JSON persistence.
  _,valid=seed(m,teacher,'VALID_UI','TF',subject='F010_UI',points='4',weights='1,3')
  invalid=[('MULTI_empty_answers',dict(question_type='MULTI',items='A\nB',answers='')),('zero_weights',dict(weights='0,0')),('negative_weights',dict(weights='-1,2')),('negative_points',dict(points='-1')),('NaN_points',dict(points='NaN')),('Infinity_points',dict(points='Infinity')),('unknown_mode',dict(scoring_mode='unknown'))]
  for i,(name,change) in enumerate(invalid):
   f={**valid,**change,'ma_cau':'REJECT_'+str(i)};before=sql(m,'SELECT COUNT(*) FROM cau_hoi')[0][0];response=teacher.post('/teacher/multi/new',data=f)
   after=sql(m,'SELECT COUNT(*) FROM cau_hoi')[0][0];assert after==before
   (args.output/('UI_'+name+'.html')).write_bytes(response.data)
   out['UI_write_probes'].append(dict(name=name,status=response.status_code,row_delta=after-before,invalid_rule_persisted=False,reachability='ONLY_CORRUPTED/EXTERNAL_DATA',input_path='UI rejected'))
  f={**valid,'ma_cau':'IGNORE_RAW_PAYLOAD','payload':'{malformed JSON'}
  assert teacher.post('/teacher/multi/new',data=f).status_code==302
  row=sql(m,"SELECT payload FROM cau_hoi WHERE ma_cau='IGNORE_RAW_PAYLOAD'")[0][0];decoded=json.loads(row);assert decoded['scoring']['points']==4 and decoded['answer']==['D','S']
  out['UI_write_probes'].append(dict(name='raw_payload_not_a_write_input',raw_input='{malformed JSON',stored_rule=decoded['scoring'],payload_built_from_validated_fields=True))
  # Same invalid definitions through the supported spreadsheet importer.
  from multi_routes import HEADERS
  for i,(name,change) in enumerate(invalid):
   f={**valid,**change,'ma_cau':'IMPORT_REJECT_'+str(i)};wb=Workbook();ws=wb.active;ws.append(HEADERS)
   ws.append([f['ma_cau'],'8',f['mon'],f['chu_de'],'NB',f['question_type'],f['noi_dung'],f['items'],f['answers'],f['points'],f['scoring_mode'],f['weights']]);b=BytesIO();wb.save(b);wb.close()
   (args.output/('import_'+name+'.xlsx')).write_bytes(b.getvalue())
   before=sql(m,'SELECT COUNT(*) FROM cau_hoi')[0][0];response=teacher.post('/teacher/multi/import',data={'file':(BytesIO(b.getvalue()),name+'.xlsx')},content_type='multipart/form-data')
   after=sql(m,'SELECT COUNT(*) FROM cau_hoi')[0][0];assert after==before
   out['Excel_import_probes'].append(dict(name=name,status=response.status_code,row_delta=after-before,invalid_rule_persisted=False,reachability='ONLY_CORRUPTED/EXTERNAL_DATA',input_path='Excel importer rejected'))
  # Real legacy shape: payload with answer/options but no scoring, preserved by init_db.
  payload={'options':['A','B'],'answer':[0]}
  sql(m,"INSERT INTO cau_hoi(ma_cau,khoi_lop,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,question_type,payload) VALUES('LEGACY_NO_RULE','8','F010_LEGACY','Audit','NB','Legacy','','','','','A','MULTI',?)",(json.dumps(payload),))
  m.init_db();row=dict(sql(m,"SELECT * FROM cau_hoi WHERE ma_cau='LEGACY_NO_RULE'")[0]);from question_types import snapshot
  item=snapshot(row);score=total_score([item],{0:item['answer']});assert 'scoring' not in item and score==10
  out['legacy'].append(dict(name='v22_style_no_rule',reachability='REACHABLE_FROM_LEGACY_DATA',scoring_field_present=False,full_correct_total=score,grade_maximum=grade(item,item['answer'])[1]))
  # HTTP integration after an explicit fixture-only external alteration of attempt de_json.
  seed(m,teacher,'CORRUPTION_CONTROL','SINGLE',subject='F010_RUNTIME')
  for i,(name,item,value,reach) in enumerate(cases[:8]):
   student,aid,eid,data=attempt(m,teacher,'CORRUPT_'+str(i),subject='F010_RUNTIME')
   poisoned=copy.deepcopy(item);poisoned.update(id=data[0]['id'],q='Corrupted fixture '+name,image='')
   sql(m,'UPDATE bai_thi SET de_json=? WHERE id=?',(json.dumps([poisoned],allow_nan=True),aid))
   get=student.get('/exam');save=student.post('/api/save-answer',json=dict(index=0,choice=value))
   f=form_answers([poisoned],{0:value});response=student.post('/exam',data=f)
   bt=dict(sql(m,'SELECT submitted_at,diem,tong_so_cau FROM bai_thi WHERE id=?',(aid,))[0])
   out['runtime_corrupted_snapshots'].append(dict(name=name,reachability=reach,mutation='temporary fixture SQL only',exam_GET=get.status_code,autosave=save.status_code,submit=response.status_code,stored=bt))
  # Malformed JSON is also read directly; legitimate writer never emits this.
  student,aid,eid,data=attempt(m,teacher,'MALFORMED_JSON',subject='F010_RUNTIME');sql(m,"UPDATE bai_thi SET de_json='{broken' WHERE id=?",(aid,))
  out['runtime_corrupted_snapshots'].append(dict(name='malformed_de_json',reachability='ONLY_CORRUPTED/EXTERNAL_DATA',exam_GET=student.get('/exam').status_code,submit=student.post('/exam').status_code))
  # Restore is a supported ingress that does not validate JSON semantics.
  row,_=seed(m,teacher,'RESTORE_BAD','TF',subject='F010_RESTORE',points='1',weights='1,1')
  backup=root/'synthetic_restore.db';m.create_sqlite_backup(backup)
  c=sqlite3.connect(backup);spec=json.loads(row['payload']);spec['scoring']['weights']=[0,0]
  c.execute('UPDATE cau_hoi SET payload=? WHERE id=?',(json.dumps(spec),row['id']));c.commit();integrity=c.execute('PRAGMA integrity_check').fetchone()[0];c.close();assert integrity=='ok'
  response=teacher.post('/teacher/restore',data={'file':(BytesIO(backup.read_bytes()),'synthetic_restore.db')},content_type='multipart/form-data')
  restored=json.loads(sql(m,'SELECT payload FROM cau_hoi WHERE id=?',(row['id'],))[0][0]);assert restored['scoring']['weights']==[0,0]
  student,aid,eid,data=attempt(m,teacher,'RESTORE_INGRESS',subject='F010_RESTORE',kind='TF');save=student.post('/api/save-answer',json=dict(index=0,choice=['D','S']));submit=student.post('/exam',data=form_answers(data,{0:['D','S']}))
  out['restore_ingress']=dict(reachability='REACHABLE_FROM_IMPORT',import_type='teacher .db restore',origin_of_bad_rule='ONLY_CORRUPTED/EXTERNAL_DATA',SQLite_integrity=integrity,restore_status=response.status_code,malformed_semantics_preserved=True,autosave_status=save.status_code,submit_status=submit.status_code,rule=restored['scoring'])
 out['audit_completed']=True;dump(args.output/'results.json',out);print(json.dumps(out,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
