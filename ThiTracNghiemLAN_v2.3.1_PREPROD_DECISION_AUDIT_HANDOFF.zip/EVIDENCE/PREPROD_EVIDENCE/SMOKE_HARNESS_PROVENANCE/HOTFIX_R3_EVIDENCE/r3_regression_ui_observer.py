"""Same R3 assertions on verified R2 and candidate R3; application state is temporary."""
import argparse,hashlib,json,logging,os,shutil,sys,tempfile,traceback,zipfile
from datetime import datetime
from io import BytesIO
from pathlib import Path
from openpyxl import Workbook,load_workbook

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True);results=[]
    def check(name,fn):
        try:results.append(dict(name=name,status='PASS',detail=fn()))
        except Exception:results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()))
        print(name,results[-1]['status'],flush=True)
    with tempfile.TemporaryDirectory(prefix='tnlan_r3_') as tmp:
        root=Path(tmp);shutil.copytree(args.source,root/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(root/'localappdata');sys.path.insert(0,str(root/'app'))
        import app as m
        from question_types import snapshot,correct
        from scoring import total_score
        m.init_db();teacher=m.app.test_client()
        assert teacher.post('/teacher/login',data=dict(username='admin',password='123456')).status_code==302
        def sql(q,a=()):
            c=m.db()
            try:r=c.execute(q,a).fetchall();c.commit();return r
            finally:c.close()
        definitions={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
        levels=('NB','TH','VD','VDC');markers=['=1+1','+test','-test','@test','Tên bình thường']
        def new_question(code,kind,grade='8',level='NB',subject='R3',mode='partial'):
            items,answers=definitions[kind]
            assert teacher.post('/teacher/multi/new',data=dict(ma_cau=code,khoi_lop=grade,mon=subject,chu_de='Safe',muc_do=level,question_type=kind,noi_dung='Câu '+kind,items=items,answers=answers,points='4',scoring_mode=mode,weights='1,3' if kind in ('TF','MATCH','FILL') else '')).status_code==302
            return dict(sql('SELECT * FROM cau_hoi WHERE ma_cau=?',(code,))[0])
        def clone_matrix():
            cases=[]
            for grade in ['6','7','8','9']:
                for kind in definitions:
                    for mode in ['all','partial']:
                        source=new_question('R3CLONE_'+grade+kind+mode,kind,grade=grade,mode=mode)
                        before=sql('SELECT COUNT(*) FROM cau_hoi')[0][0]
                        assert teacher.post('/teacher/question/clone/'+str(source['id'])).status_code==302
                        copy=dict(sql('SELECT * FROM cau_hoi ORDER BY id DESC')[0])
                        assert sql('SELECT COUNT(*) FROM cau_hoi')[0][0]==before+1
                        assert copy['khoi_lop']==grade and copy['ma_cau']==source['ma_cau']+'_COPY'
                        assert {k:v for k,v in copy.items() if k not in ('id','ma_cau')}=={k:v for k,v in source.items() if k not in ('id','ma_cau')}
                        assert dict(sql('SELECT * FROM cau_hoi WHERE id=?',(source['id'],))[0])==source
                        item=snapshot(copy);answer=item['answer'] if kind!='FILL' else [a[0] for a in item['answer']]
                        assert correct(item,answer) and total_score([item],{0:answer})==10
                        cases.append(dict(grade=grade,kind=kind,mode=mode,payload_byte_identical=True))
            return cases
        check('F005_clone_4_grades_5_types_2_scoring_modes',clone_matrix)
        def clone_legacy():
            cases=[]
            for grade in ['6','7','8','9','',' 8 ']:
                sql("INSERT INTO cau_hoi(ma_cau,khoi_lop,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung) VALUES('','LegacyGrade','Legacy','A','NB','Cũ','Hai','Ba','Bốn','Năm','D')")
                qid=sql('SELECT MAX(id) FROM cau_hoi')[0][0];sql('UPDATE cau_hoi SET khoi_lop=? WHERE id=?',(grade,qid))
                before=dict(sql('SELECT * FROM cau_hoi WHERE id=?',(qid,))[0])
                assert teacher.post('/teacher/question/clone/'+str(qid)).status_code==302
                clone=dict(sql('SELECT * FROM cau_hoi ORDER BY id DESC')[0]);assert clone['khoi_lop']==grade and clone['ma_cau']==''
                assert {k:v for k,v in clone.items() if k!='id'}=={k:v for k,v in before.items() if k!='id'}
                assert dict(sql('SELECT * FROM cau_hoi WHERE id=?',(qid,))[0])==before
                cases.append(dict(input_grade=grade,clone_grade=clone['khoi_lop']))
            return cases
        check('F005_clone_legacy_exact_metadata_no_init_db',clone_legacy)
        # Canonical quota fixtures with 2 questions/cell; never modify persisted source/DB.
        for k in definitions:
            for lv in levels:
                for i in range(2):new_question('R3BANK_'+k+lv+str(i),k,level=lv,subject='R3BANK')
        def exam_state():return [dict(r) for r in sql('SELECT * FROM ky_thi ORDER BY id')]
        def clear_flashes():
            with teacher.session_transaction() as s:s.pop('_flashes',None)
        def fields(endpoint):
            f=dict(ten='R3 Validation',mon='R3BANK',lop='8A',hien_diem='on')
            f['thoi_gian' if endpoint=='/teacher/create-exam' else 'minutes']='15'
            f.update({k+'_'+lv:'1' for k in definitions for lv in levels});return f
        def invalid_request(endpoint,f,field):
            before=exam_state();clear_flashes();r=teacher.post(endpoint,data=f)
            assert r.status_code in (200,302,400) and r.status_code!=500
            assert exam_state()==before,'Invalid request created/changed exam rows'
            # New harness correction: render consumes flashes; observe the actual visible notice.
            if r.status_code==302:
                with teacher.session_transaction() as s:messages=[v for _,v in s.get('_flashes',[])]
            else:
                import re,html
                messages=[html.unescape(v) for v in re.findall(r'<p class="warn">(.*?)</p>',r.get_data(as_text=True),re.S)]
            assert messages and any(field in text for text in messages),(field,messages)
            return r.status_code
        def invalid_time(endpoint):
            field='thoi_gian' if endpoint=='/teacher/create-exam' else 'minutes';out=[]
            for value in ['abc','',' ','0','-1','181','1.5','1e2','1_0','NaN','9'*5000]:
                f=fields(endpoint);f[field]=value
                status=invalid_request(endpoint,f,field)
                out.append(dict(value=value if len(value)<50 else '5000 decimal digits',status=status,no_exam_created=True))
            return out
        for ep in ['/teacher/create-exam','/teacher/mixed-exam']:
            check('F006_invalid_time_'+ep.rsplit('/',1)[1],lambda ep=ep:invalid_time(ep))
        def invalid_counts(endpoint):
            cases=[]
            for kind in definitions:
                for lv in levels:
                    field=kind+'_'+lv
                    for value in ['abc','-1','1.5','1e2','1_0','','1 2']:
                        f=fields(endpoint);f[field]=value;status=invalid_request(endpoint,f,field)
                        cases.append(dict(field=field,value=value,status=status,no_exam_created=True))
            return cases
        for ep in ['/teacher/create-exam','/teacher/mixed-exam']:
            check('F006_invalid_counts_all_20_cells_'+ep.rsplit('/',1)[1],lambda ep=ep:invalid_counts(ep))
        def invalid_legacy():
            out=[]
            for field in ['nb_count','th_count','vd_count','vdc_count']:
                for value in ['abc','-1','1.5','1_0','']:
                    f=dict(ten='R3 Legacy',mon='R3BANK',thoi_gian='15',nb_count='1',th_count='1',vd_count='1',vdc_count='1');f[field]=value
                    out.append(dict(field=field,value=value,status=invalid_request('/teacher/create-exam',f,field)))
            return out
        check('F006_invalid_legacy_counts',invalid_legacy)
        def valid_validation():
            details=[]
            for ep in ['/teacher/create-exam','/teacher/mixed-exam']:
                tf='thoi_gian' if ep=='/teacher/create-exam' else 'minutes'
                for time in ['1','180','15',' +015 ',None]:
                    f=fields(ep)
                    if time is None:f.pop(tf)
                    else:f[tf]=time
                    # Exact non-negative integer counts; zeros do not change total policy.
                    f['SINGLE_NB']=' +1 ';f['MULTI_TH']='00';f['TF_VD']='-0'
                    before=len(exam_state());assert teacher.post(ep,data=f).status_code==302
                    assert len(exam_state())==before+1
                    row=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0];quotas=json.loads(row['type_quotas'])
                    assert row['thoi_gian_phut']==(15 if time is None else int(time)) and row['so_cau']==18
                    assert quotas['SINGLE']['NB']==1 and quotas['MULTI']['TH']==0 and quotas['TF']['VD']==0
                    assert len(m.build_exam(row))==18
                    details.append(dict(route=ep,time=time,actual_minutes=row['thoi_gian_phut'],questions=18))
                # Omitted counts stay 0 and omitted duration stays 15.
                f=dict(ten='R3 Defaults',mon='R3BANK',SINGLE_NB='1');before=len(exam_state())
                assert teacher.post(ep,data=f).status_code==302 and len(exam_state())==before+1
                row=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0];assert row['so_cau']==1 and row['thoi_gian_phut']==15
                for counts in ['zero','shortage']:
                    f=fields(ep);f.update({k+'_'+lv:'0' for k in definitions for lv in levels})
                    if counts=='shortage':f['SINGLE_NB']='999'
                    before=exam_state();assert teacher.post(ep,data=f).status_code<500 and exam_state()==before
            before=len(exam_state());f=dict(ten='R3 Legacy valid',mon='R3BANK',thoi_gian='15',nb_count='1',th_count='1',vd_count='0',vdc_count='0')
            assert teacher.post('/teacher/create-exam',data=f).status_code==302 and len(exam_state())==before+1
            row=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0];assert row['so_cau']==2 and len(m.build_exam(row))==2
            assert all(q['type']=='SINGLE' for q in m.build_exam(row))
            return details
        check('F006_valid_boundaries_defaults_zero_shortage_legacy',valid_validation)
        # Excel fixtures are harmless text and actual server-graded 5-type attempts.
        sql('DELETE FROM cau_hoi')  # Only unreferenced temporary fixtures from earlier checks.
        for t in markers:
            assert teacher.post('/teacher/student/add',data=dict(ma_hs=t,ho_ten=t,lop=t)).status_code==302
            sql("INSERT INTO cau_hoi(ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,hinh_anh) VALUES(?,?,?,?,?,?,?,?,?,'A',?)",(t,t,t,t,t,t,t,t,t,t))
        def workbook(url,name):
            r=teacher.get(url);assert r.status_code==200
            (args.output/name).write_bytes(r.data)
            with zipfile.ZipFile(BytesIO(r.data)) as z:assert z.testzip() is None
            return load_workbook(BytesIO(r.data),data_only=False)
        def text(cell,value):
            assert cell.value==value,(cell.coordinate,cell.value,value)
            assert cell.data_type=='s',(cell.coordinate,cell.data_type,cell.value)
        def students_export():
            wb=workbook('/teacher/students/export','students.xlsx');rows=list(wb.active.iter_rows(min_row=2));assert len(rows)==5
            for row in rows:
                assert row[0].value in markers
                for c in row:text(c,row[0].value)
            wb.close();return dict(markers=markers,text_columns=3,formula_cells=0)
        check('F008_students_text_identity_5_markers',students_export)
        def questions_export():
            wb=workbook('/teacher/export-questions','legacy-questions.xlsx');rows=list(wb.active.iter_rows(min_row=2));assert len(rows)==5
            for row in rows:
                marker=row[0].value;assert marker in markers
                for i,c in enumerate(row):text(c,'A' if i==9 else marker)
            wb.close();return dict(markers=markers,text_columns=11,formula_cells=0)
        check('F008_legacy_questions_all_text_columns',questions_export)
        qrows=[new_question('R3EXCEL_'+k,k,subject='R3EXCEL') for k in definitions]
        attempts=[];report_checks=[]
        def form(data,choices):
            f={}
            for i,q in enumerate(data):
                v=choices[i]
                if q['type']=='SINGLE':f['q_'+str(i)]=str(v)
                elif q['type']=='MULTI':f['q_'+str(i)]=[str(x) for x in v]
                else:
                    for j,x in enumerate(v):f[f'q_{i}_{j}']='' if x is None else str(x)
            return f
        # One workflow per marker. Setup is outside report assertions so all export groups run on R2 too.
        for i,t in enumerate(markers):
            f=dict(ten=t,mon='R3EXCEL',thoi_gian='15',hien_diem='on',**{k+'_NB':'1' for k in definitions})
            assert teacher.post('/teacher/create-exam',data=f).status_code==302
            eid=sql('SELECT MAX(id) FROM ky_thi')[0][0];c=m.app.test_client()
            assert c.post('/',data=dict(ma_hs=t,ky_thi_id=eid)).location.endswith('/exam')
            with c.session_transaction() as s:aid=s['attempt_id']
            data=json.loads(sql('SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0]);choices={}
            for index,q in enumerate(data):
                v=q['answer'] if q['type']!='FILL' else [a[0] for a in q['answer']]
                if q['type']=='MULTI':v=v[:1]
                elif q['type'] in ('TF','MATCH','FILL'):v=[v[0],None if q['type']=='MATCH' else '']
                choices[index]=v;assert c.post('/api/save-answer',json=dict(index=index,choice=v)).status_code==200
            assert c.post('/exam',data=form(data,choices)).status_code==302
            bt=dict(sql('SELECT * FROM bai_thi WHERE id=?',(aid,))[0]);stored={r['vi_tri_cau']:r['lua_chon'] for r in sql('SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))}
            assert bt['diem']==total_score(data,stored)==4.5 and bt['tong_so_cau']==5 and bt['so_cau_dung']==1
            assert '4.5/10' in c.get('/result').get_data(as_text=True)
            sql('UPDATE ky_thi SET mon=?,lop=? WHERE id=?',(t,t,eid))
            for q in qrows:sql('UPDATE cau_hoi SET ma_cau=?,mon=?,chu_de=?,noi_dung=? WHERE id=?',(t+q['question_type'],t,t,t,q['id']))
            response=teacher.get('/teacher/report/'+str(eid)+'/export');assert response.status_code==200
            filename=f'exam-report-{i}.xlsx';(args.output/filename).write_bytes(response.data)
            report_checks.append(dict(marker=t,eid=eid,aid=aid,filename=filename,bt=bt))
            attempts.append(dict(marker=t,eid=eid,aid=aid,bt=bt))
            for q in qrows:sql('UPDATE cau_hoi SET ma_cau=?,mon=?,chu_de=?,noi_dung=? WHERE id=?',(q['ma_cau'],q['mon'],q['chu_de'],q['noi_dung'],q['id']))
        def reports_export():
            out=[]
            for case in report_checks:
                t=case['marker'];bt=case['bt'];wb=load_workbook(args.output/case['filename'],data_only=False)
                summary=wb['TongQuan']
                for n in ['B2','B3','B4']:text(summary[n],t)
                for n,v in [('B5',5),('B8',1),('B9',4.5),('B10',4.5),('B11',4.5)]:assert summary[n].value==v and summary[n].data_type=='n'
                students=wb['KetQuaHocSinh'];assert students.max_row==2
                for i in [1,2,3]:text(students.cell(2,i),t)
                for i,key in [(4,'started_at'),(5,'submitted_at')]:text(students.cell(2,i),bt[key])
                for i,key in [(6,'so_cau_dung'),(7,'tong_so_cau'),(8,'diem')]:assert students.cell(2,i).value==bt[key] and students.cell(2,i).data_type=='n'
                rows=list(wb['PhanTichCauHoi'].iter_rows(min_row=2));assert len(rows)==5
                for row in rows:
                    assert row[0].value.startswith(t) and row[0].data_type=='s'
                    for i in [1,2,4]:text(row[i],t)
                    text(row[3],'NB')
                    assert row[5].value==1 and row[5].data_type=='n'
                    for i in [6,7]:assert row[i].data_type=='n'
                assert sum(row[6].value for row in rows)==bt['so_cau_dung']
                assert all(cell.data_type!='f' for sheet in wb for row in sheet for cell in row)
                wb.close();out.append(dict(marker=t,score=4.5,text_preserved=True,numerical_cells_unchanged=True))
            return out
        check('F008_exam_report_all_sheets_text_and_numeric',reports_export)
        def results_export():
            wb=workbook('/teacher/export-results','results.xlsx');rows=list(wb.active.iter_rows(min_row=2));assert len(rows)==5
            cases={x['marker']:x['bt'] for x in attempts}
            for row in rows:
                t=row[2].value;bt=cases[t]
                for i in [1,2,3,4]:text(row[i],t)
                for i,key in [(8,'started_at'),(9,'submitted_at')]:text(row[i],bt[key])
                assert row[0].data_type=='n'
                for i,key in [(5,'so_cau_dung'),(6,'tong_so_cau'),(7,'diem')]:assert row[i].value==bt[key] and row[i].data_type=='n'
            wb.close();return dict(markers=markers,score=4.5,numeric_and_timestamps_preserved=True)
        check('F008_results_text_numeric_and_time_identity',results_export)
        def points_export():
            for case in attempts:
                wb=workbook('/teacher/report/'+str(case['eid'])+'/points',f"points-{case['aid']}.xlsx")
                rows=list(wb.active.iter_rows(min_row=2));assert len(rows)==5
                for row in rows:
                    text(row[0],case['marker']);text(row[1],case['marker'])
                    assert all(row[i].data_type=='n' for i in [2,4,5,6])
                assert abs(sum(row[6].value for row in rows)-4.5)<1e-9
                wb.close()
            return 'Unchanged points export remains safe for all markers, five types and 4.5/10 partial weighting.'
        check('F008_related_points_existing_guard_preserved',points_export)
        def multi_export():
            for i,t in enumerate(markers):
                q=qrows[0];sql('UPDATE cau_hoi SET ma_cau=?,noi_dung=?,chu_de=? WHERE id=?',(t,t,t,q['id']))
                wb=workbook('/teacher/multi/excel?mon=R3EXCEL',f'multi-questions-{i}.xlsx')
                row=next(row for row in wb.active.iter_rows(min_row=2) if row[0].value==t)
                for col in [0,3,6]:text(row[col],t)
                assert row[9].value==4 and row[9].data_type=='n';text(row[10],'partial')
                wb.close()
            return 'Unchanged multi Excel guard preserves risky text and numeric scoring config.'
        check('F008_related_multi_export_existing_guard_preserved',multi_export)
        def helper_boundary():
            wb=Workbook();ws=wb.active;ws['A1']='=1+1';ws['B1']=-7.25;ws['C1']=datetime(2026,10,2,12,34,56);ws['D1']='=SUM(1,1)'
            m.excel_text_cells([ws['A1']])
            b=BytesIO();wb.save(b);wb.close();loaded=load_workbook(BytesIO(b.getvalue()),data_only=False)
            text(loaded.active['A1'],'=1+1');assert loaded.active['B1'].value==-7.25 and loaded.active['B1'].data_type=='n'
            assert loaded.active['C1'].value==datetime(2026,10,2,12,34,56) and loaded.active['C1'].data_type=='d'
            assert loaded.active['D1'].value=='=SUM(1,1)' and loaded.active['D1'].data_type=='f'
            loaded.close();return 'Selected user text sanitized; numeric/date and system formula in other columns preserved.'
        check('F008_selected_text_preserves_numeric_datetime_system_formula',helper_boundary)
        schema=[dict(r) for r in sql("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name")]
        (args.output/'schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
        logging.shutdown();shutil.copyfile(root/'app/logs/app.log',args.output/'runtime.log')
    record=dict(source=str(args.source.resolve()),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),results=results)
    (args.output/'results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    return 0 if all(r['status']=='PASS' for r in results) else 1
if __name__=='__main__':raise SystemExit(main())
