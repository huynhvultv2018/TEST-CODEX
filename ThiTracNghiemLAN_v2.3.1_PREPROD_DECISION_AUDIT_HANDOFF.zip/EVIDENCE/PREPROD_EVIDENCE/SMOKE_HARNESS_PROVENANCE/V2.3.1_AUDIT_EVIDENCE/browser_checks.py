"""Real browser checks against disposable local Waitress server, never deployed."""
import os,sys,tempfile,shutil,json,threading,traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
from waitress import create_server

ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'V2.3.1_AUDIT_EVIDENCE'

def main():
    result={'status':'FAIL','checks':[],'external_requests':[],'page_errors':[]}
    with tempfile.TemporaryDirectory(prefix='tnlan_browser_') as tmp:
        p=Path(tmp);shutil.copytree(ROOT/'baseline-v2.3.1/PHAN_MEM',p/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(p/'localappdata');sys.path.insert(0,str(p/'app'))
        import app as m
        m.init_db()
        server=create_server(m.app,host='127.0.0.1',port=0,threads=4)
        threading.Thread(target=server.run,daemon=True).start()
        url=f'http://127.0.0.1:{server.effective_port}'
        try:
            with sync_playwright() as pw:
                b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
                context=b.new_context(viewport={'width':1440,'height':1000})
                def local_only(route):
                    if route.request.url.startswith(url):route.continue_()
                    else:result['external_requests'].append(route.request.url);route.abort()
                context.route('**/*',local_only)
                page=context.new_page();page.on('pageerror',lambda exc:result['page_errors'].append(str(exc)))
                page.goto(url+'/teacher/login');page.fill('[name=username]','admin');page.fill('[name=password]','123456');page.click('button');page.wait_for_url(url+'/teacher')
                result['checks'].append('real_teacher_login')
                definitions={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
                for k,(items,answers) in definitions.items():
                    for lv in ['NB','TH','VD','VDC']:
                        r=context.request.post(url+'/teacher/multi/new',form=dict(ma_cau=k+lv,khoi_lop='8',mon='Toán',chu_de='Đại số',muc_do=lv,question_type=k,noi_dung=r'Tính $\frac{1}{2}$ và 4x^2',items=items,answers=answers,points='2',scoring_mode='partial'))
                        assert r.status==200
                page.goto(url+'/teacher/multi/new')
                page.fill('[name=noi_dung]',r'Tính $\frac{1}{2}$ và 4x^2, sqrt(4)')
                page.fill('[name=items]','x^2\n3/4')
                page.wait_for_function("document.querySelector('[data-math-preview] mjx-container svg') !== null")
                page.wait_for_function("document.querySelectorAll('[data-math-preview] mjx-container').length >= 3")
                result['mixed_explicit_plain_svg_count']=page.locator('[data-math-preview] mjx-container svg').count()
                result['mixed_text_auto']=page.evaluate("window.autoMathText('Tính $\\\\frac{1}{2}$ và 4x^2, sqrt(4)')")
                page.fill('[name=noi_dung]','Tính 4x^2 và sqrt(4)')
                page.wait_for_function("document.querySelectorAll('[data-math-preview] mjx-container').length >= 4")
                result['preview_svg_count']=page.locator('[data-math-preview] mjx-container svg').count()
                page.screenshot(path=str(E/'mathjax-preview.png'),full_page=True)
                result['checks'].append('offline_mathjax_editor_explicit_tex_power_root_fraction')
                context.request.post(url+'/teacher/student/add',form=dict(ma_hs='BROWSER1',ho_ten='Học sinh trình duyệt',lop='8A'))
                page.goto(url+'/teacher');page.wait_for_function("document.getElementById('av_SINGLE_NB').textContent==='1'")
                page.select_option('#exam_mon',label='Toán');page.check('input[name=chu_de][value="Đại số"]')
                page.wait_for_function("document.getElementById('availability_box').textContent.includes('20')")
                assert page.locator('#create_exam_btn').is_disabled()
                page.fill('#q_SINGLE_NB','2');assert page.locator('#create_exam_btn').is_disabled()
                for k in definitions:
                    for lv in ['NB','TH','VD','VDC']:page.fill(f'#q_{k}_{lv}','1')
                assert page.locator('#requested_total').inner_text()=='20'
                for k in definitions:assert page.locator('#row_total_'+k).inner_text()=='4'
                for lv in ['NB','TH','VD','VDC']:assert page.locator('#level_total_'+lv).inner_text()=='5'
                assert not page.locator('#create_exam_btn').is_disabled()
                page.fill('form[action="/teacher/create-exam"] [name=ten]','Browser audit 20')
                page.select_option('form[action="/teacher/create-exam"] [name=lop]','8A')
                page.screenshot(path=str(E/'matrix-20-cells.png'),full_page=True)
                page.click('#create_exam_btn');page.wait_for_load_state('networkidle')
                c=m.db();kt=c.execute('SELECT * FROM ky_thi ORDER BY id DESC').fetchone();c.close();assert kt['so_cau']==20
                result['checks'].append('matrix_dom_counts_totals_shortage_button_create_20_cells')
                context.request.post(url+'/teacher/student/add',form=dict(ma_hs='BROWSER1',ho_ten='Học sinh trình duyệt',lop='8A'))
                student=b.new_context(viewport={'width':1280,'height':1000});student.route('**/*',local_only)
                exam=student.new_page();exam.on('pageerror',lambda exc:result['page_errors'].append(str(exc)))
                exam.goto(url);exam.fill('[name=ma_hs]','BROWSER1');exam.select_option('[name=ky_thi_id]',str(kt['id']));exam.click('button');exam.wait_for_url(url+'/exam')
                c=m.db();bt=c.execute('SELECT * FROM bai_thi WHERE ma_hs="BROWSER1"').fetchone();c.close();items=json.loads(bt['de_json'])
                assert exam.locator('.question').count()==20
                exam.wait_for_function("document.querySelectorAll('.question mjx-container svg').length >= 20")
                result['exam_svg_count']=exam.locator('.question mjx-container svg').count()
                for i,q in enumerate(items):
                    if q['type']=='SINGLE':exam.check(f'input[name="q_{i}"][value="{q["answer"]}"]')
                    elif q['type']=='MULTI':
                        for a in q['answer']:exam.check(f'input[name="q_{i}"][value="{a}"]')
                    else:
                        for j,a in enumerate(q['answer']):
                            name=f'[name="q_{i}_{j}"]'
                            if q['type']=='FILL':exam.fill(name,a[0])
                            else:exam.select_option(name,str(a))
                exam.wait_for_function("Array.from(document.querySelectorAll('.question small[id]')).every(x=>x.textContent==='Đã lưu')")
                exam.reload();exam.wait_for_load_state('networkidle')
                for i,q in enumerate(items):
                    if q['type']=='SINGLE':assert exam.locator(f'input[name="q_{i}"][value="{q["answer"]}"]').is_checked()
                    elif q['type']=='MULTI':
                        for a in q['answer']:assert exam.locator(f'input[name="q_{i}"][value="{a}"]').is_checked()
                    else:
                        for j,a in enumerate(q['answer']):assert exam.locator(f'[name="q_{i}_{j}"]').input_value()==(a[0] if q['type']=='FILL' else str(a))
                exam.screenshot(path=str(E/'exam-five-types.png'),full_page=True)
                exam.on('dialog',lambda dialog:dialog.accept());exam.click('form#form > button');exam.wait_for_url(url+'/result')
                assert '10.0/10' in exam.inner_text('body')
                c=m.db();score=c.execute('SELECT diem FROM bai_thi WHERE id=?',(bt['id'],)).fetchone()[0];n=c.execute('SELECT COUNT(*) FROM cau_tra_loi WHERE bai_thi_id=?',(bt['id'],)).fetchone()[0];c.close()
                assert score==10 and n==20
                result['checks'].append('all_five_types_browser_answer_autosave_reload_submit_persist_display_10')
                result['score']=score;result['answer_count']=n
                assert not result['external_requests'] and not result['page_errors']
                result['status']='PASS';b.close()
        except Exception:result['traceback']=traceback.format_exc()
        finally:
            server.close();server.task_dispatcher.shutdown();
            import logging
            logging.shutdown()
            shutil.copyfile(p/'app/logs/app.log',E/'browser-runtime.log')
    (E/'browser-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':sys.exit(main())
