"""Deterministic DB scheduling of two legitimate concurrent submissions.
No application edits. Wrapper pauses after both reads saw submitted_at=NULL.
"""
import os,sys,json,shutil,tempfile,threading,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];E=ROOT/'V2.3.1_AUDIT_EVIDENCE'

def main():
    out={}
    with tempfile.TemporaryDirectory(prefix='tnlan_race_') as tmp:
        p=Path(tmp);shutil.copytree(ROOT/'baseline-v2.3.1/PHAN_MEM',p/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(p/'localappdata');sys.path.insert(0,str(p/'app'))
        import app as m
        from scoring import total_score
        m.init_db();t=m.app.test_client();t.post('/teacher/login',data=dict(username='admin',password='123456'))
        t.post('/teacher/multi/new',data=dict(ma_cau='RACE',khoi_lop='8',mon='Audit',chu_de='A',muc_do='NB',question_type='SINGLE',noi_dung='Chọn đúng',items='Đúng\nSai',answers='1'))
        t.post('/teacher/create-exam',data=dict(ten='Race',mon='Audit',thoi_gian='15',SINGLE_NB='1'))
        t.post('/teacher/student/add',data=dict(ma_hs='RACE1',ho_ten='Race test',lop='8A'))
        student=m.app.test_client();student.post('/',data=dict(ma_hs='RACE1',ky_thi_id='1'))
        with student.session_transaction() as s:session_data=dict(s)
        c=m.db();bt=c.execute('SELECT * FROM bai_thi').fetchone();c.close();items=json.loads(bt['de_json']);right=items[0]['answer']
        original_db=m.db;barrier=threading.Barrier(2);committed=threading.Event()
        class CachedCursor:
            def __init__(self,row):self.row=row
            def fetchone(self):return self.row
        class Connection:
            def __init__(self):self.c=original_db()
            def execute(self,query,args=()):
                cur=self.c.execute(query,args)
                if query=='SELECT submitted_at FROM bai_thi WHERE id=?':
                    row=cur.fetchone()
                    out.setdefault('reads',{})[threading.current_thread().name]=dict(row)
                    barrier.wait(timeout=15)
                    if threading.current_thread().name=='late_wrong':assert committed.wait(15)
                    return CachedCursor(row)
                return cur
            def commit(self):
                self.c.commit()
                if threading.current_thread().name=='first_correct':committed.set()
            def __getattr__(self,name):return getattr(self.c,name)
        m.db=Connection
        def submit(name,choice):
            try:
                client=m.app.test_client()
                with client.session_transaction() as s:s.update(session_data)
                r=client.post('/exam',data={'q_0':str(choice)})
                out.setdefault('responses',{})[name]=r.status_code
            except Exception:out.setdefault('errors',{})[name]=traceback.format_exc()
        threads=[threading.Thread(target=submit,args=('first_correct',right),name='first_correct'),threading.Thread(target=submit,args=('late_wrong',1-right),name='late_wrong')]
        for th in threads:th.start()
        for th in threads:th.join(20)
        m.db=original_db
        assert not any(th.is_alive() for th in threads)
        c=m.db();bt=c.execute('SELECT * FROM bai_thi').fetchone();choices={r['vi_tri_cau']:r['lua_chon'] for r in c.execute('SELECT * FROM cau_tra_loi')};c.close()
        out.update(stored_score=bt['diem'],stored_fully_correct=bt['so_cau_dung'],stored_choices=choices,regraded_from_stored_answers=total_score(items,choices))
        out['status']='FAIL' if out['stored_score']!=out['regraded_from_stored_answers'] else 'PASS'
        import logging
        logging.shutdown();shutil.copyfile(p/'app/logs/app.log',E/'race-runtime.log')
    (E/'race-probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
    return 1 if out['status']=='FAIL' else 0

if __name__=='__main__':sys.exit(main())
