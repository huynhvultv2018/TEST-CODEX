"""Synthetic pre-migration DATA only; baseline code always v2.3.1."""
import os,sys,json,sqlite3,tempfile,shutil,traceback
from pathlib import Path
from io import BytesIO
from openpyxl import Workbook,load_workbook
ROOT=Path(__file__).resolve().parents[1];E=ROOT/'V2.3.1_AUDIT_EVIDENCE'

def main():
    result={'results':[],'observations':{}}
    with tempfile.TemporaryDirectory(prefix='tnlan_legacy_') as tmp:
        p=Path(tmp);shutil.copytree(ROOT/'baseline-v2.3.1/PHAN_MEM',p/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(p/'localappdata');sys.path.insert(0,str(p/'app'))
        import app as m
        def check(name,fn):
            try:result['results'].append(dict(name=name,status='PASS',detail=fn()))
            except Exception:result['results'].append(dict(name=name,status='FAIL',traceback=traceback.format_exc()))
        def sql(q,args=()):
            c=m.db();rows=c.execute(q,args).fetchall();c.commit();c.close();return rows
        def migration():
            c=sqlite3.connect(m.DB_PATH)
            c.executescript('''
            CREATE TABLE hoc_sinh(id INTEGER PRIMARY KEY,ma_hs TEXT UNIQUE NOT NULL,ho_ten TEXT NOT NULL,lop TEXT NOT NULL);
            CREATE TABLE cau_hoi(id INTEGER PRIMARY KEY,ma_cau TEXT,mon TEXT,chu_de TEXT,muc_do TEXT,noi_dung TEXT NOT NULL,a TEXT NOT NULL,b TEXT NOT NULL,c TEXT NOT NULL,d TEXT NOT NULL,dap_an_dung TEXT NOT NULL);
            CREATE TABLE ky_thi(id INTEGER PRIMARY KEY,ten TEXT NOT NULL,lop TEXT,mon TEXT,so_cau INTEGER NOT NULL,thoi_gian_phut INTEGER NOT NULL,chu_de TEXT,muc_do TEXT,hien_diem INTEGER DEFAULT 1,trang_thai TEXT DEFAULT 'MO',created_at TEXT NOT NULL);
            CREATE TABLE bai_thi(id INTEGER PRIMARY KEY,ky_thi_id INTEGER NOT NULL,ma_hs TEXT NOT NULL,ho_ten TEXT NOT NULL,lop TEXT NOT NULL,started_at TEXT NOT NULL,deadline_at TEXT NOT NULL,submitted_at TEXT,de_json TEXT NOT NULL,so_cau_dung INTEGER,tong_so_cau INTEGER,diem REAL,UNIQUE(ky_thi_id,ma_hs));
            INSERT INTO hoc_sinh VALUES(1,'OLD1','Học sinh cũ','8A');
            INSERT INTO cau_hoi VALUES(1,'DS8_OLD','Toán','Chủ đề cũ','NB','Câu hỏi cũ','Hai','Ba','Bốn','Năm','A');
            INSERT INTO ky_thi VALUES(1,'Kỳ thi cũ','8A','Toán',1,15,'Chủ đề cũ','NB',1,'MO','2025-01-01 00:00:00');
            ''')
            snapshot=[dict(id=1,q='Câu hỏi cũ',image='',options=['Hai','Ba','Bốn','Năm'],answer=0)]
            c.execute("INSERT INTO bai_thi VALUES(1,1,'OLD1','Học sinh cũ','8A','2025-01-01 00:00:00','2025-01-01 00:15:00','2025-01-01 00:10:00',?,1,1,10)",(json.dumps(snapshot),));c.commit();c.close()
            m.init_db();m.init_db()
            q=sql('SELECT * FROM cau_hoi')[0];assert q['question_type']=='SINGLE' and q['payload']=='' and q['khoi_lop']=='8'
            assert len(m.build_exam(sql('SELECT * FROM ky_thi')[0]))==1
            assert sql('SELECT diem FROM bai_thi')[0][0]==10
            assert list(m.BACKUP_DIR.glob('before_v22_*.db'))
            assert sql('PRAGMA integrity_check')[0][0]=='ok'
            s=m.app.test_client();r=s.post('/',data=dict(ma_hs='OLD1',ky_thi_id='1'))
            assert r.status_code==302 and r.location.endswith('/result')
            assert '10.0/10' in s.get('/result').get_data(as_text=True)
            return 'Old-schema synthetic SQLite migrated twice; backup exists; question/class inferred; old exam/score preserved and result displayed.'
        check('synthetic_old_schema_migration_preservation',migration)
        t=m.app.test_client();t.post('/teacher/login',data=dict(username='admin',password='123456'))
        def excel_9():
            wb=Workbook();ws=wb.active;ws.append(['Mã câu','Khối','Môn','Chủ đề','Mức độ','Loại','Nội dung','Các mục','Đáp án']);ws.append(['OLD9','9','Tin học','Cũ','TH','TF','Hai ý','Ý một\nÝ hai','D\nS']);out=BytesIO();wb.save(out)
            t.post('/teacher/multi/import',data={'file':(BytesIO(out.getvalue()),'old9.xlsx')},content_type='multipart/form-data')
            row=sql('SELECT * FROM cau_hoi WHERE ma_cau="OLD9"')[0]
            rule=json.loads(row['payload'])['scoring'];assert rule['points']==1 and rule['mode']=='all'
            return 'Nine-column question workbook imports with default all/1, grade 9 preserved.'
        check('legacy_9_column_excel',excel_9)
        def excel_formula():
            sql("UPDATE hoc_sinh SET ho_ten='=1+1' WHERE id=1")
            data=t.get('/teacher/students/export').data;wb=load_workbook(BytesIO(data));cell=wb.active.cell(2,2)
            result['observations']['student_export_formula']=dict(value=cell.value,data_type=cell.data_type);wb.close()
            assert cell.data_type!='f','Untrusted student name became an Excel formula'
        check('student_excel_export_keeps_names_as_text',excel_formula)
        def edit_invalid():
            r=t.post('/teacher/question/edit/1',data=dict(ma_cau='DS8_OLD',mon='Toán',chu_de='Chủ đề cũ',muc_do='NB',noi_dung='Câu cũ',a='Hai',b='Ba',c='Bốn',d='Năm',dap_an_dung='INVALID'))
            row=sql('SELECT * FROM cau_hoi WHERE id=1')[0];de=None;error=None
            try:de=m.build_exam(sql('SELECT * FROM ky_thi WHERE id=1')[0])
            except Exception as e:error=type(e).__name__+': '+str(e)
            result['observations']['legacy_edit_invalid']=dict(edit_status=r.status_code,stored_answer=row['dap_an_dung'],build_error=error)
            sql("UPDATE cau_hoi SET dap_an_dung='A' WHERE id=1")
            assert row['dap_an_dung'] in ('A','B','C','D'),'Legacy editor committed empty answer; empty string is interpreted as A by str.index'
        check('legacy_editor_rejects_invalid_answer',edit_invalid)
        def role_checks():
            t.post('/teacher/accounts/add',data=dict(username='audit_teacher',ho_ten='Giáo viên',vai_tro='GIAOVIEN',password='audit-test-only'))
            s=m.app.test_client();assert s.post('/teacher/login',data=dict(username='audit_teacher',password='audit-test-only')).status_code==302
            for url in ['/teacher/accounts','/teacher/settings','/teacher/audit']:
                r=s.get(url);assert r.status_code==302 and r.location.endswith('/teacher')
            assert s.get('/teacher/multi').status_code==200
            anon=m.app.test_client();assert anon.get('/teacher/multi').status_code==302
            return 'Actual teacher account login; admin pages deny GIAOVIEN; anonymous teacher pages require login.'
        check('teacher_account_roles',role_checks)
        def restore():
            snapshot=p/'restore.db';m.create_sqlite_backup(snapshot)
            original=sql('SELECT COUNT(*) FROM cau_hoi')[0][0]
            sql("DELETE FROM cau_hoi WHERE ma_cau='OLD9'")
            assert sql('SELECT COUNT(*) FROM cau_hoi')[0][0]==original-1
            m.restore_database_from_path(snapshot)
            assert sql('SELECT COUNT(*) FROM cau_hoi')[0][0]==original
            assert sql('PRAGMA integrity_check')[0][0]=='ok'
            assert list(m.BACKUP_DIR.glob('before_restore_*.db'))
            return 'Isolated supported SQLite restore recovers question and creates pre-restore backup.'
        check('backup_restore_roundtrip',restore)
        import logging
        logging.shutdown();shutil.copyfile(p/'app/logs/app.log',E/'legacy-runtime.log')
    (E/'legacy-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
    return 1 if any(x['status']=='FAIL' for x in result['results']) else 0
if __name__=='__main__':sys.exit(main())
