"""Audit-only checks. Never edits baseline; all databases are disposable copies."""
import os, sys, json, shutil, tempfile, math, itertools, traceback
from pathlib import Path
from collections import Counter
from io import BytesIO
from openpyxl import Workbook, load_workbook

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'baseline-v2.3.1' / 'PHAN_MEM'
RESULTS = []
OBS = {}

def check(name, fn):
    try:
        detail = fn()
        RESULTS.append(dict(name=name, status='PASS', detail=detail))
    except Exception:
        RESULTS.append(dict(name=name, status='FAIL', traceback=traceback.format_exc()))
    print(name, RESULTS[-1]['status'], flush=True)

def main():
    with tempfile.TemporaryDirectory(prefix='tnlan_audit_') as tmp:
        p = Path(tmp)
        shutil.copytree(SOURCE, p/'app', ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA'] = str(p/'localappdata')
        sys.path.insert(0, str(p/'app'))
        import app as m
        from question_types import TYPES, parse_spec, normalize, snapshot, decode
        from scoring import grade, config, total_score
        m.init_db(); m.init_db()
        teacher = m.app.test_client()

        def sql(query, args=()):
            c=m.db()
            try:
                rows=c.execute(query,args).fetchall();c.commit();return rows
            finally: c.close()
        def count(table): return sql('SELECT COUNT(*) FROM '+table)[0][0]
        def auth():
            r=teacher.post('/teacher/login',data={'username':'admin','password':'123456'})
            assert r.status_code==302 and r.location.endswith('/teacher')
            with teacher.session_transaction() as s: assert s['teacher_role']=='ADMIN'
            return 'Real login through password verification; no injected teacher session.'
        check('teacher_real_login',auth)

        kinds=list(TYPES); levels=['NB','TH','VD','VDC']
        definitions={
            'SINGLE':('Hai\nBa\nBốn','1'),
            'MULTI':('Hai\nBa\nBốn','1,3'),
            'TF':('Hai chẵn\nBa chẵn','D\nS'),
            'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),
            'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
        ids={}
        def create_questions():
            for kind,level,subject,topic,rep in itertools.product(kinds,levels,['Toán','Tin học'],['Chủ đề A','Chủ đề B'],range(2)):
                items,answers=definitions[kind]
                code=f'{kind}_{level}_{subject}_{topic}_{rep}'
                f=dict(ma_cau=code,khoi_lop='8',mon=subject,chu_de=topic,muc_do=level,question_type=kind,
                       noi_dung=r'Tính $\frac{1}{2}$ và 4x^2 — Tiếng Việt '+code,items=items,answers=answers,
                       points='4',scoring_mode='partial',weights='1,3' if kind in ('TF','MATCH','FILL') else '')
                r=teacher.post('/teacher/multi/new',data=f)
                assert r.status_code==302
                row=sql('SELECT * FROM cau_hoi WHERE ma_cau=?',(code,))[0]
                spec=json.loads(row['payload']); assert spec['scoring']['points']==4
                assert teacher.get(f'/teacher/multi/edit/{row["id"]}').status_code==200
                ids[row['id']]=(kind,level,subject,topic)
            assert count('cau_hoi')==160
            return '160 questions created/read via real routes: 5 types × 4 levels × 2 subjects × 2 topics × 2 copies.'
        check('five_types_create_save_read',create_questions)

        def availability():
            j=teacher.get('/teacher/api/question-availability',query_string={'mon':'Toán','chu_de':'Chủ đề A'}).json
            assert j['ok'] and j['counts']['TOTAL']==40
            for kind in kinds:
                assert j['by_type'][kind]['TOTAL']==8
                for level in levels: assert j['by_type'][kind][level]==2
            assert teacher.get('/teacher/api/question-availability?mon=Missing').json['counts']['TOTAL']==0
            return j
        check('matrix_availability_subject_topic',availability)
        f=dict(ten='Audit 20 cells',lop='8A',mon='Toán',thoi_gian='15',chu_de='Chủ đề A',hien_diem='on')
        f.update({kind+'_'+level:'1' for kind in kinds for level in levels})
        eid=None
        def matrix():
            nonlocal eid
            n=count('ky_thi'); r=teacher.post('/teacher/create-exam',data=f)
            assert r.status_code==302 and count('ky_thi')==n+1
            kt=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0]; eid=kt['id']
            assert kt['so_cau']==20 and all(kt[x]==5 for x in ['nb_count','th_count','vd_count','vdc_count'])
            assert all(v==1 for d in json.loads(kt['type_quotas']).values() for v in d.values())
            draws=[]
            for _ in range(50):
                data=m.build_exam(sql('SELECT * FROM ky_thi WHERE id=?',(eid,))[0])
                assert len(data)==20 and len(set(q['id'] for q in data))==20
                actual=Counter(ids[q['id']][:2] for q in data)
                assert actual==Counter({(k,l):1 for k in kinds for l in levels})
                assert all(ids[q['id']][2:]==('Toán','Chủ đề A') for q in data)
                draws.append([q['id'] for q in data])
            assert len({tuple(sorted(x)) for x in draws})>1
            return dict(exam_id=eid,draws=50,cells=20,draw_sample=draws[:3])
        check('matrix_20_cells_create_persist_reload_random_unique',matrix)
        def shortage():
            before=count('ky_thi')
            for patch in [{'SINGLE_NB':'3'},{'mon':'Missing'},{'chu_de':'Missing'}]:
                r=teacher.post('/teacher/create-exam',data={**f,**patch},follow_redirects=True)
                assert r.status_code==200 and count('ky_thi')==before
                assert 'ngân hàng chưa đủ câu' in r.get_data(as_text=True)
            zero={**f,**{k+'_'+l:'0' for k in kinds for l in levels}}
            teacher.post('/teacher/create-exam',data=zero)
            assert count('ky_thi')==before
            return 'Shortage, nonexistent subject/topic and empty matrix reject without DB insertion.'
        check('matrix_shortage_empty_rejection',shortage)

        def students():
            for ma,lop in [('AUDIT1','8A'),('AUDIT2','8A'),('AUDIT3','8A'),('WRONGCLASS','7A')]:
                assert teacher.post('/teacher/student/add',data=dict(ma_hs=ma,ho_ten='Học sinh '+ma,lop=lop)).status_code==302
            teacher.post('/teacher/student/add',data=dict(ma_hs='AUDIT1',ho_ten='Tên cập nhật',lop='8A'))
            assert sql('SELECT ho_ten FROM hoc_sinh WHERE ma_hs="AUDIT1"')[0][0]=='Tên cập nhật'
            assert teacher.get('/teacher/students?lop=8A').status_code==200
            s=m.app.test_client(); r=s.post('/',data=dict(ma_hs='WRONGCLASS',ky_thi_id=eid))
            assert r.status_code==200 and 'không dành cho lớp' in r.get_data(as_text=True)
            return 'Student add/update, class filter and wrong-class login rejection.'
        check('student_management_class',students)

        student=m.app.test_client(); aid=None; data=[]
        def login_exam():
            nonlocal aid,data
            r=student.post('/',data=dict(ma_hs='AUDIT1',ky_thi_id=eid))
            assert r.status_code==302 and r.location.endswith('/exam')
            with student.session_transaction() as s: aid=s['attempt_id']
            bt=sql('SELECT * FROM bai_thi WHERE id=?',(aid,))[0];data=json.loads(bt['de_json'])
            html=student.get('/exam').get_data(as_text=True)
            for k in kinds: assert html.count(f'data-kind="{k}"')==4
            assert 'Tên cập nhật' in html
            return dict(attempt_id=aid,types=dict(Counter(q['type'] for q in data)))
        check('student_real_login_20_questions_render',login_exam)

        def full_chain():
            form={}
            for i,q in enumerate(data):
                v=q['answer'] if q['type']!='FILL' else [a[0] for a in q['answer']]
                if q['type']=='MULTI': v=v[:1]
                elif q['type'] in ('TF','MATCH','FILL'): v=[v[0],None if q['type']=='MATCH' else '']
                assert student.post('/api/save-answer',json=dict(index=i,choice=v)).json['ok']
                row=sql('SELECT lua_chon FROM cau_tra_loi WHERE bai_thi_id=? AND vi_tri_cau=?',(aid,i))[0]
                # SQLite INTEGER affinity returns numeric SINGLE answers as int.
                assert decode(row[0])==v
                if q['type']=='SINGLE': form[f'q_{i}']=str(v)
                elif q['type']=='MULTI': form[f'q_{i}']=[str(x) for x in v]
                else:
                    for j,x in enumerate(v): form[f'q_{i}_{j}']='' if x is None else str(x)
            assert student.get('/exam').status_code==200
            r=student.post('/exam',data=form);assert r.status_code==302
            row=sql('SELECT * FROM bai_thi WHERE id=?',(aid,))[0]
            # Per group: SINGLE 4, MULTI 2, TF/MATCH/FILL 1 each -> 9 / 20 -> 4.5/10.
            assert row['diem']==4.5 and row['so_cau_dung']==4 and row['tong_so_cau']==20
            html=student.get('/result').get_data(as_text=True)
            assert '4.5/10' in html
            out=teacher.get(f'/teacher/report/{eid}/points');assert out.status_code==200
            wb=load_workbook(BytesIO(out.data));rows=list(wb.active.values);wb.close()
            assert len(rows)==21 and abs(sum(r[6] for r in rows[1:])-4.5)<1e-9
            for u in [f'/teacher/report/{eid}',f'/teacher/report/{eid}/export',f'/teacher/monitor/{eid}',f'/teacher/api/monitor/{eid}']:
                assert teacher.get(u).status_code==200
            assert student.post('/api/save-answer',json=dict(index=0,choice=None)).status_code==409
            assert student.post('/exam',data={}).status_code==302
            assert sql('SELECT diem FROM bai_thi WHERE id=?',(aid,))[0][0]==4.5
            return dict(score=4.5,fully_correct=4,answer_rows=count('cau_tra_loi'),point_export_rows=20)
        check('five_types_save_reload_submit_grade_persist_result',full_chain)

        def score_suite():
            cases=0
            for k in kinds:
                spec=parse_spec(k,*definitions[k]);item=dict(type=k,**spec)
                correct=item['answer'] if k!='FILL' else [a[0] for a in item['answer']]
                for mode,points in itertools.product(['all','partial'],[0.001,1,4,1000]):
                    weights='1,3' if k in ('TF','MATCH','FILL') else ''
                    item['scoring']=config(dict(points=points,scoring_mode=mode,weights=weights),k,len(item['options']))
                    for v in [None,[],correct,'null',False,{},[99],[''],[None,None]]:
                        a,b=grade(item,v);assert math.isfinite(a) and math.isfinite(b) and 0<=a<=b==points;cases+=1
                    assert grade(item,correct)==(points,points)
                    assert grade(item,None)==(0,points)
            multi=dict(type='MULTI',options=['a','b','c'],answer=[0,2],scoring=dict(points=4,mode='partial'))
            for length in range(5):
                for v in itertools.product(range(3),repeat=length):
                    a,b=grade(multi,list(v)); assert 0<=a<=b==4;cases+=1
            assert grade(multi,[0,0,0])==(2,4)
            assert grade(multi,[0,1,2])==(2,4)
            assert total_score([], {})==0
            assert total_score([dict(type='SINGLE',answer=0)],{0:0})==10
            assert total_score([dict(type='SINGLE',answer=0)],{})==0
            assert normalize(' HAI  ')=='hai'
            assert normalize('ho\u0300a')==normalize('hòa') and normalize('hoa')!=normalize('hòa')
            # 0.005 rounds half up, with binary-exact division (1/2000*10).
            items=[dict(type='SINGLE',answer=0,scoring=dict(points=1)),dict(type='SINGLE',answer=0,scoring=dict(points=999)),dict(type='SINGLE',answer=0,scoring=dict(points=1000))]
            assert total_score(items,{0:0})==0.01
            return dict(bounded_grade_cases=cases,round_half_up='0.005 -> 0.01',legacy_default='1 point/all')
        check('scoring_all_partial_bounds_duplicates_unicode_rounding',score_suite)
        def invalid_rules():
            n=0
            for bad in ['nan','inf','-1','0','1001','abc']:
                try: config(dict(points=bad),'TF',2)
                except ValueError: n+=1
                else: raise AssertionError(bad)
            for weights in ['0,1','-1,1','nan,1','inf,1','1001,1','1','a,b']:
                try: config(dict(weights=weights),'TF',2)
                except ValueError:n+=1
                else:raise AssertionError(weights)
            return dict(rejected=n)
        check('scoring_input_validation',invalid_rules)

        def question_crud():
            qid=next(i for i,t in ids.items() if t==('FILL','NB','Tin học','Chủ đề B'))
            teacher.post(f'/teacher/multi/edit/{qid}',data=dict(ma_cau='EDIT',khoi_lop='8',mon='Tin học',chu_de='Chủ đề B',muc_do='NB',question_type='FILL',noi_dung='Đã sửa',items='Ô một\nÔ hai',answers='hai\nba',points='2',scoring_mode='all'))
            assert sql('SELECT noi_dung FROM cau_hoi WHERE id=?',(qid,))[0][0]=='Đã sửa'
            teacher.post(f'/teacher/question/delete/{qid}');assert not sql('SELECT id FROM cau_hoi WHERE id=?',(qid,))
            used=data[0]['id'];teacher.post(f'/teacher/question/delete/{used}')
            assert sql('SELECT id FROM cau_hoi WHERE id=?',(used,))
            return 'Edit/delete unused; refuse delete referenced question.'
        check('question_edit_delete_protect_used',question_crud)

        # These probe expected invariants and retain failures rather than repairing source.
        def invalid_time():
            r=teacher.post('/teacher/create-exam',data={**f,'thoi_gian':'abc'})
            OBS['invalid_time_status']=r.status_code
            assert r.status_code<500,'Non-numeric duration caused HTTP 500'
        check('invalid_duration_handled',invalid_time)

        def topic_comma():
            qid=data[0]['id'];sql('UPDATE cau_hoi SET chu_de=? WHERE id=?',('Chủ đề, có dấu phẩy',qid))
            k,l,_,_=ids[qid]
            ff=dict(ten='Comma topic',mon='Toán',thoi_gian='15',chu_de='Chủ đề, có dấu phẩy',**{k+'_'+l:'1'})
            before=count('ky_thi');teacher.post('/teacher/create-exam',data=ff)
            assert count('ky_thi')==before+1
            kt=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0];de=m.build_exam(kt)
            OBS['comma_topic']=dict(persisted_topic=kt['chu_de'],requested=kt['so_cau'],actual=len(de))
            sql('UPDATE cau_hoi SET chu_de=? WHERE id=?',('Chủ đề A',qid))
            assert len(de)==kt['so_cau'],'Saved topic is split on comma and cannot produce requested exam'
        check('topic_with_comma_roundtrip',topic_comma)

        def legacy_case():
            sql("INSERT INTO cau_hoi(ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,question_type,payload,khoi_lop) VALUES('LOWER','Legacy','Legacy','nb','Legacy','a','b','c','d','A','SINGLE','','8')")
            teacher.post('/teacher/create-exam',data=dict(ten='Legacy normalized',mon='Legacy',thoi_gian='15',SINGLE_NB='1'))
            kt=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0];de=m.build_exam(kt)
            OBS['legacy_case']=dict(available=m.question_availability('Legacy')[1]['SINGLE']['NB'],requested=kt['so_cau'],actual=len(de))
            assert len(de)==1,'Availability normalizes level but SQL sampler requires exact NB'
        check('legacy_lowercase_level_consistent',legacy_case)

        def legacy_normal():
            sql("UPDATE cau_hoi SET muc_do='NB' WHERE ma_cau='LOWER'")
            kt=dict(id=999,mon='Legacy',chu_de='',muc_do='NB',nb_count=0,th_count=0,vd_count=0,vdc_count=0,so_cau=1,type_quotas='')
            de=m.build_exam(kt); assert len(de)==1 and de[0]['type']=='SINGLE'
            assert 'scoring' not in de[0]
            assert grade(de[0],de[0]['answer'])==(1,1)
            return 'Synthetic old question (empty payload) and old exam (empty quotas) preserve default scoring.'
        check('legacy_question_exam_normal',legacy_normal)

        def clone_grade():
            qid=data[0]['id'];teacher.post(f'/teacher/question/clone/{qid}')
            row=sql('SELECT * FROM cau_hoi ORDER BY id DESC')[0]
            OBS['clone_grade']=dict(original=sql('SELECT khoi_lop FROM cau_hoi WHERE id=?',(qid,))[0][0],clone=row['khoi_lop'])
            assert row['khoi_lop']=='8','Clone omitted khoi_lop column'
        check('clone_preserves_grade',clone_grade)

        active=m.app.test_client();active.post('/',data=dict(ma_hs='AUDIT2',ky_thi_id=eid))
        with active.session_transaction() as s: aid2=s['attempt_id'];token2=s['client_token']
        data2=json.loads(sql('SELECT de_json FROM bai_thi WHERE id=?',(aid2,))[0][0])
        def malformed_answer():
            i=next(i for i,q in enumerate(data2) if q['type']=='TF')
            save=active.post('/api/save-answer',json=dict(index=i,choice=['D']))
            reload=active.get('/exam')
            OBS['short_answer']=dict(save_status=save.status_code,reload_status=reload.status_code)
            sql('DELETE FROM cau_tra_loi WHERE bai_thi_id=?',(aid2,))
            assert save.status_code==400 or reload.status_code==200,'Accepted short TF list breaks template reload'
        check('malformed_answer_cannot_break_reload',malformed_answer)
        def expired_post():
            sql("UPDATE bai_thi SET deadline_at='2000-01-01 00:00:00' WHERE id=?",(aid2,))
            form={}
            for i,q in enumerate(data2):
                v=q['answer'] if q['type']!='FILL' else [a[0] for a in q['answer']]
                if q['type']=='SINGLE':form[f'q_{i}']=str(v)
                elif q['type']=='MULTI':form[f'q_{i}']=[str(x) for x in v]
                else:
                    for j,x in enumerate(v):form[f'q_{i}_{j}']=str(x)
            assert active.post('/api/save-answer',json=dict(index=0,choice=None)).status_code==409
            active.post('/exam',data=form)
            score=sql('SELECT diem FROM bai_thi WHERE id=?',(aid2,))[0][0]
            OBS['expired_post']=dict(deadline='2000-01-01',saved_before_post=0,score=score)
            assert score==0,'Expired POST accepted fresh complete answers (10/10)'
        check('expired_post_uses_only_saved_answers',expired_post)
        def result_token():
            assert sql('SELECT diem FROM bai_thi WHERE id=?',(aid,))[0][0]==4.5
            intruder=m.app.test_client()
            with intruder.session_transaction() as s:s['attempt_id']=aid;s['client_token']='invalid-audit-token'
            html=intruder.get('/result').get_data(as_text=True)
            OBS['result_wrong_token']=dict(discloses_score='4.5/10' in html)
            assert '4.5/10' not in html,'Result endpoint omits validate_attempt_session'
        check('result_requires_valid_attempt_token',result_token)

        def unlock_revokes_old_session():
            s=m.app.test_client();s.post('/',data=dict(ma_hs='AUDIT3',ky_thi_id=eid))
            with s.session_transaction() as sess:third=sess['attempt_id']
            teacher.post(f'/teacher/unlock/{third}')
            r=s.post('/api/save-answer',json=dict(index=0,choice=None))
            OBS['unlock_old_session']=dict(save_status=r.status_code)
            assert r.status_code==409,'Cleared client_token permits existing old session before next login'
        check('teacher_unlock_revokes_old_session',unlock_revokes_old_session)

        def backup_integrity():
            target=p/'copy.db';m.create_sqlite_backup(target)
            import sqlite3
            c=sqlite3.connect(target);assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            assert c.execute('SELECT COUNT(*) FROM cau_hoi').fetchone()[0]==count('cau_hoi');c.close()
            return 'SQLite backup + integrity check + question-count equality.'
        check('database_backup_integrity',backup_integrity)

        # Boundary observations: invalid DB/snapshot rules bypass config(), not normal UI inputs.
        bad_cases=[dict(type='MULTI',options=['a','b'],answer=[],scoring=dict(points=1,mode='partial')),
                   dict(type='TF',answer=['D'],scoring=dict(points=1,mode='partial',weights=[0])),
                   dict(type='TF',answer=['D','S'],scoring=dict(points=1,mode='partial',weights=[1,-.5])),
                   dict(type='SINGLE',answer=0,scoring=dict(points=float('nan'))),
                   dict(type='SINGLE',answer=0,scoring=dict(points=-1))]
        OBS['invalid_snapshot_scoring']=[]
        for item,value in zip(bad_cases,[[0],['D'],['D','D'],0,0]):
            try:r=grade(item,value);o=dict(result=repr(r))
            except Exception as exc:o=dict(exception=type(exc).__name__,message=str(exc))
            OBS['invalid_snapshot_scoring'].append(dict(item=repr(item),**o))
        OBS['health']=teacher.get('/health').json
        OBS['foreign_keys']=sql('PRAGMA foreign_keys')[0][0]
        OBS['counts']={t:count(t) for t in ['hoc_sinh','cau_hoi','ky_thi','bai_thi','cau_tra_loi']}
        # Store application logs from this test only; contain no credentials.
        import logging
        logging.shutdown()
        shutil.copyfile(p/'app/logs/app.log',ROOT/'V2.3.1_AUDIT_EVIDENCE'/'audit-runtime.log')
    report=dict(results=RESULTS,observations=OBS)
    (ROOT/'V2.3.1_AUDIT_EVIDENCE'/'audit-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print('SUMMARY',Counter(r['status'] for r in RESULTS))
    return 1 if any(r['status']=='FAIL' for r in RESULTS) else 0

if __name__=='__main__':sys.exit(main())
