"""Run untouched original scripts/harnesses against an isolated selected source.
The stage uses the old baseline directory NAME to satisfy original harness paths;
its contents are the selected candidate, recorded and hashed in this runner.
"""
import argparse,pathlib,tempfile,shutil,subprocess,os,json,hashlib

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=pathlib.Path,required=True);parser.add_argument('--output',type=pathlib.Path,required=True)
    args=parser.parse_args();repo=pathlib.Path(__file__).resolve().parents[1]
    args.output.mkdir(parents=True,exist_ok=True);results=[]
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    python='/workspace/tnlan-audit-venv/bin/python'
    with tempfile.TemporaryDirectory(prefix='tnlan_r1_original_') as tmp:
        stage=pathlib.Path(tmp)
        shutil.copytree(args.source,stage/'baseline-v2.3.1')
        old=stage/'V2.3.1_AUDIT_EVIDENCE';old.mkdir()
        env['LOCALAPPDATA']=str(stage/'localappdata')
        appdir=stage/'baseline-v2.3.1/PHAN_MEM'
        for script in ['kiem_tra_v23.py','kiem_tra_v23_integration.py','kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_v222.py','kiem_tra_mathjax.py']:
            result=subprocess.run([python,script],cwd=appdir,env=env,capture_output=True,text=True,timeout=120)
            (args.output/(script+'.log')).write_text(result.stdout+result.stderr)
            results.append(dict(script=script,kind='original_test',source_sha256=hashlib.sha256((appdir/script).read_bytes()).hexdigest(),exit_code=result.returncode))
            print(script,result.returncode,flush=True)
        for script in ['audit_checks.py','legacy_checks.py','race_probe.py','browser_checks.py']:
            original=repo/'V2.3.1_AUDIT_EVIDENCE'/script
            target=old/script;shutil.copyfile(original,target)
            assert target.read_bytes()==original.read_bytes()
            result=subprocess.run([python,str(target)],cwd=stage,env=env,capture_output=True,text=True,timeout=120)
            (args.output/(script+'.log')).write_text(result.stdout+result.stderr)
            results.append(dict(script=script,kind='original_audit_harness',source_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),unchanged=True,exit_code=result.returncode))
            print(script,result.returncode,flush=True)
        for p in old.iterdir():
            if p.suffix!='.py':shutil.copyfile(p,args.output/p.name)
    (args.output/'runner-results.json').write_text(json.dumps(dict(source=str(args.source.resolve()),results=results),indent=2))
    # Keep raw failing audit outcomes. Caller compares them with baseline findings.
    return 1 if any(x['exit_code'] for x in results) else 0
if __name__=='__main__':raise SystemExit(main())
