"""Same invariants run against baseline and candidate; source is copied, never edited."""
import argparse,json,os,sys,shutil,tempfile,threading,traceback,sqlite3
from datetime import datetime,timedelta
from pathlib import Path
from collections import Counter
from werkzeug.datastructures import MultiDict

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    results=[];observations={}
    def check(name,fn):
        try:results.append(dict(name=name,status='PASS',detail=fn()))
        except Exception:results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()))
        print(name,results[-1]['status'],flush=True)
    with tempfile.TemporaryDirectory(prefix='tnlan_r1_') as tmp:
        root=Path(tmp);shutil.copytree(args.source,root/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(root/'localappdata');sys.path.insert(0,str(root/'app'))
        import app as m
        from question_types import decode,correct
        from scoring import total_score
        m.init_db();teacher=m.app.test_client()
        assert teacher.post('/teacher/login',data={'username':'admin','password':'123456'}).status_code==302
        def sql(query,params=()):
            c=m.db()
            try:rows=c.execute(query,params).fetchall();c.commit();return rows
            finally:c.close()
        definitions={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
        for mode in ['all','partial']:
            for kind,(items,answers) in definitions.items():
                r=teacher.post('/teacher/multi/new',data=dict(ma_cau=mode+kind,khoi_lop='8',mon='R1_'+mode,chu_de='A',muc_do='NB',question_type=kind,noi_dung='Câu '+kind,items=items,answers=answers,points='4',scoring_mode=mode,weights='1,3' if kind in ('TF','MATCH','FILL') else ''))
                assert r.status_code==302
        serial=0
        def attempt(mode='partial'):
            nonlocal serial
            serial+=1
            f=dict(ten='R1 '+str(serial),mon='R1_'+mode,lop='8A',thoi_gian='15',hien_diem='on')
            f.update({k+'_NB':'1' for k in definitions})
            assert teacher.post('/teacher/create-exam',data=f).status_code==302
            eid=sql('SELECT MAX(id) FROM ky_thi')[0][0];ma='R1HS'+str(serial)
            teacher.post('/teacher/student/add',data=dict(ma_hs=ma,ho_ten='Học sinh '+ma,lop='8A'))
            client=m.app.test_client();r=client.post('/',data=dict(ma_hs=ma,ky_thi_id=eid));assert r.status_code==302 and r.location.endswith('/exam')
            with client.session_transaction() as sess:session=dict(sess);aid=sess['attempt_id']
            data=json.loads(sql('SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0])
            assert len(data)==5 and {q['type'] for q in data}==set(definitions)
            return client,aid,data,session
        def values(data,which):
            out={}
            for i,q in enumerate(data):
                v=q['answer'] if q['type']!='FILL' else [a[0] for a in q['answer']]
                if which=='blank':v=None if q['type']=='SINGLE' else [] if q['type']=='MULTI' else [None,None] if q['type']=='MATCH' else ['','']
                if which=='partial':
                    if q['type']=='MULTI':v=v[:1]
                    elif q['type'] in ('TF','MATCH','FILL'):v=[v[0],None if q['type']=='MATCH' else '']
                out[i]=v
            return out
        def form(data,choices):
            f={}
            for i,q in enumerate(data):
                v=choices[i]
                if q['type']=='SINGLE':f[f'q_{i}']='' if v is None else str(v)
                elif q['type']=='MULTI':f[f'q_{i}']=[str(x) for x in v]
                else:
                    for j,x in enumerate(v):f[f'q_{i}_{j}']='' if x is None else str(x)
            return f
        def save(client,choices):
            for i,v in choices.items():assert client.post('/api/save-answer',json=dict(index=i,choice=v)).status_code==200
        def stored(aid):
            row=dict(sql('SELECT * FROM bai_thi WHERE id=?',(aid,))[0])
            answers=[dict(r) for r in sql('SELECT * FROM cau_tra_loi WHERE bai_thi_id=? ORDER BY vi_tri_cau',(aid,))]
            return row,answers
        def verify(aid,data,score):
            bt,rows=stored(aid);choices={r['vi_tri_cau']:r['lua_chon'] for r in rows}
            assert bt['submitted_at'] and bt['diem']==score,(bt['diem'],score)
            assert len(rows)==5 and total_score(data,choices)==bt['diem']
            assert sum(correct(q,choices.get(i)) for i,q in enumerate(data))==bt['so_cau_dung']
            return bt,rows
        def expired_empty():
            for mode in ['all','partial']:
                c,aid,data,_=attempt(mode);sql("UPDATE bai_thi SET deadline_at='2000-01-01 00:00:00' WHERE id=?",(aid,))
                assert c.post('/api/save-answer',json=dict(index=0,choice=values(data,'full')[0])).status_code==409
                assert c.post('/exam',data=form(data,values(data,'full'))).status_code==302
                bt,rows=stored(aid);observations.setdefault('expired_empty',[]).append(dict(mode=mode,score=bt['diem']))
                verify(aid,data,0)
                assert all(decode(r['lua_chon']) in (None,[],['',''],[None,None]) for r in rows)
            return 'ALL/PARTIAL × five types: late full form yields 0 from no saved answers.'
        check('F001_expired_POST_empty_five_types',expired_empty)
        def expired_saved(method='POST'):
            scores={}
            for mode,expected in [('all',2),('partial',4.5)]:
                c,aid,data,_=attempt(mode);choices=values(data,'partial');save(c,choices)
                sql("UPDATE bai_thi SET deadline_at='2000-01-01 00:00:00' WHERE id=?",(aid,))
                r=c.post('/exam',data=form(data,values(data,'full'))) if method=='POST' else c.get('/exam')
                assert r.status_code==302;verify(aid,data,expected)
                _,rows=stored(aid);assert {r['vi_tri_cau']:decode(r['lua_chon']) for r in rows}==choices
                assert f'{float(expected)}/10' in c.get('/result').get_data(as_text=True)
                scores[mode]=expected
            return scores
        check('F001_expired_POST_saved_ALL_PARTIAL_weights',expired_saved)
        check('F001_expired_GET_saved_ALL_PARTIAL_weights',lambda:expired_saved('GET'))
        class Clock(datetime):
            value=datetime(2026,10,2,12,0,0)
            @classmethod
            def now(cls,tz=None):return cls.value if tz is None else cls.value.astimezone(tz)
        def boundary():
            c,aid,data,_=attempt();deadline=Clock.value
            sql('UPDATE bai_thi SET deadline_at=? WHERE id=?',(deadline.strftime('%Y-%m-%d %H:%M:%S'),aid))
            old=m.datetime;m.datetime=Clock
            try:
                Clock.value=deadline-timedelta(microseconds=1)
                assert c.get('/exam').status_code==200
                assert stored(aid)[0]['submitted_at'] is None
                assert c.post('/api/save-answer',json=dict(index=0,choice=values(data,'full')[0])).status_code==200
                Clock.value=deadline
                assert c.post('/api/save-answer',json=dict(index=0,choice=None)).status_code==409
                c.post('/exam',data=form(data,values(data,'full')))
                assert {r['vi_tri_cau']:decode(r['lua_chon']) for r in stored(aid)[1]}[0]==values(data,'full')[0]
                verify(aid,data,2)
            finally:m.datetime=old
            return 'At deadline autosave rejected; 1µs before deadline remains open; late POST cannot fill other four questions.'
        check('F001_exact_deadline_boundary',boundary)
        def waits_past_deadline(is_save=False):
            c,aid,data,session=attempt();choices=values(data,'partial');save(c,choices)
            deadline=datetime(2026,10,2,13,0,0);sql('UPDATE bai_thi SET deadline_at=? WHERE id=?',(deadline.strftime('%Y-%m-%d %H:%M:%S'),aid))
            oldtime=m.datetime;Clock.value=deadline-timedelta(seconds=1);m.datetime=Clock
            original=m.db;reached=threading.Event();out={}
            class Connection:
                def __init__(self):self.c=original()
                def execute(self,q,args=()):
                    if q=='BEGIN IMMEDIATE' or q.startswith('INSERT INTO cau_tra_loi('):reached.set()
                    return self.c.execute(q,args)
                def __getattr__(self,n):return getattr(self.c,n)
            holder=original();holder.execute('BEGIN IMMEDIATE');m.db=Connection
            def request():
                try:
                    client=m.app.test_client()
                    with client.session_transaction() as s:s.update(session)
                    r=client.post('/api/save-answer',json=dict(index=0,choice=values(data,'full')[0])) if is_save else client.post('/exam',data=form(data,values(data,'full')))
                    out['status']=r.status_code;out['json']=r.get_json(silent=True)
                except Exception:out['error']=traceback.format_exc()
            th=threading.Thread(target=request);th.start()
            try:
                assert reached.wait(10),'Request did not reach contested write'
                Clock.value=deadline;holder.commit();holder.close();th.join(10)
                assert not th.is_alive() and 'error' not in out,out
            finally:
                holder.close();m.db=original;m.datetime=oldtime
            if is_save:
                assert out['status']==409,out
                assert {r['vi_tri_cau']:decode(r['lua_chon']) for r in stored(aid)[1]}==choices
            else:
                assert out['status']==302,out;verify(aid,data,4.5)
            observations['wait_save' if is_save else 'wait_submit']=out
            return out
        check('F001_submit_lock_wait_rechecks_deadline',waits_past_deadline)
        check('F001_autosave_lock_wait_rechecks_deadline',lambda:waits_past_deadline(True))
        def live_scoring():
            out={}
            for mode,expected in [('all',2),('partial',4.5)]:
                c,aid,data,_=attempt(mode);r=c.post('/exam',data=form(data,values(data,'partial')))
                assert r.status_code==302;verify(aid,data,expected);out[mode]=expected
            return out
        check('REGRESSION_live_ALL_PARTIAL_weights_five_types',live_scoring)
        def frozen_snapshot():
            c,aid,data,_=attempt();payloads={r['id']:r['payload'] for r in sql('SELECT id,payload FROM cau_hoi WHERE mon="R1_partial"')}
            try:
                for qid,text in payloads.items():
                    spec=json.loads(text);spec['scoring']=dict(points=1000,mode='all',weights=[])
                    sql('UPDATE cau_hoi SET payload=? WHERE id=?',(json.dumps(spec),qid))
                c.post('/exam',data=form(data,values(data,'partial')));verify(aid,data,4.5)
            finally:
                for qid,text in payloads.items():sql('UPDATE cau_hoi SET payload=? WHERE id=?',(text,qid))
            return 'Bank max_score/mode/weights changed after login; submitted snapshot remains 4.5/10.'
        check('REGRESSION_snapshot_scoring_frozen',frozen_snapshot)
        def repeat_submission():
            c,aid,data,_=attempt();c.post('/exam',data=form(data,values(data,'full')));verify(aid,data,10)
            before=stored(aid)
            assert c.post('/exam',data=form(data,values(data,'blank'))).status_code==302
            assert c.post('/api/save-answer',json=dict(index=0,choice=None)).status_code==409
            assert stored(aid)==before
            return 'Second submit and autosave leave full DB answer rows, score and submitted_at unchanged.'
        check('F002_sequential_duplicate_submit_and_autosave',repeat_submission)
        def parallel_submissions():
            observed=[]
            for mode in ['all','partial']:
                _,aid,data,session=attempt(mode);start=threading.Barrier(8);writes=Counter();responses={};original=m.db
                class Connection:
                    def __init__(self):self.c=original()
                    def execute(self,q,args=()):
                        if q.startswith('INSERT INTO cau_tra_loi('):writes[threading.current_thread().name]+=1
                        return self.c.execute(q,args)
                    def __getattr__(self,n):return getattr(self.c,n)
                m.db=Connection
                def request(index):
                    try:
                        client=m.app.test_client()
                        with client.session_transaction() as s:s.update(session)
                        start.wait(10)
                        r=client.post('/exam',data=form(data,values(data,['full','partial','blank'][index%3])));responses[index]=r.status_code
                    except Exception:responses[index]=traceback.format_exc()
                threads=[threading.Thread(target=request,args=(i,),name=f'submit_{i}') for i in range(8)]
                try:
                    for th in threads:th.start()
                    for th in threads:th.join(15)
                    assert not any(th.is_alive() for th in threads)
                finally:m.db=original
                bt,rows=stored(aid);assert len(responses)==8 and all(v==302 for v in responses.values()),responses
                verify(aid,data,bt['diem'])
                assert len(writes)==1 and sum(writes.values())==5,dict(writes)
                observed.append(dict(mode=mode,score=bt['diem'],responses=responses,writers=dict(writes)))
            observations['parallel_submits']=observed;return observed
        check('F002_eight_parallel_submits_single_writer',parallel_submissions)
        def delayed_autosave():
            c,aid,data,session=attempt();original=m.db;paused=threading.Event();release=threading.Event();out={}
            class Cursor:
                def __init__(self,row):self.row=row
                def fetchone(self):return self.row
            class Connection:
                def __init__(self):self.c=original();self.transaction=False
                def execute(self,q,args=()):
                    if threading.current_thread().name=='queued_autosave':
                        if q=='BEGIN IMMEDIATE':
                            paused.set();assert release.wait(10);self.transaction=True
                        elif q=='SELECT * FROM bai_thi WHERE id=?' and not self.transaction:
                            row=self.c.execute(q,args).fetchone();paused.set();assert release.wait(10);return Cursor(row)
                    return self.c.execute(q,args)
                def __getattr__(self,n):return getattr(self.c,n)
            m.db=Connection
            def autosave():
                try:
                    s=m.app.test_client()
                    with s.session_transaction() as state:state.update(session)
                    r=s.post('/api/save-answer',json=dict(index=0,choice=values(data,'blank')[0]));out['status']=r.status_code
                except Exception:out['error']=traceback.format_exc()
            th=threading.Thread(target=autosave,name='queued_autosave');th.start()
            try:
                assert paused.wait(10)
                assert c.post('/exam',data=form(data,values(data,'full'))).status_code==302
                release.set();th.join(10);assert not th.is_alive()
            finally:release.set();m.db=original
            verify(aid,data,10);assert out.get('status')==409,out
            return out
        check('F002_queued_autosave_cannot_overwrite_submitted',delayed_autosave)
        def autosave_first_timeout():
            _,aid,data,session=attempt();original=m.db;oldtime=m.datetime
            deadline=datetime(2026,10,2,14,0,0);sql('UPDATE bai_thi SET deadline_at=? WHERE id=?',(deadline.strftime('%Y-%m-%d %H:%M:%S'),aid))
            Clock.value=deadline-timedelta(seconds=1);m.datetime=Clock
            saved_waiting=threading.Event();submit_waiting=threading.Event();release=threading.Event();responses={}
            class Connection:
                def __init__(self):self.c=original();self.answer_write=False
                def execute(self,q,args=()):
                    if q.startswith('INSERT INTO cau_tra_loi('):self.answer_write=True
                    if threading.current_thread().name=='timeout_submit' and (q=='BEGIN IMMEDIATE' or self.answer_write):submit_waiting.set()
                    return self.c.execute(q,args)
                def commit(self):
                    if threading.current_thread().name=='autosave_first' and self.answer_write:
                        saved_waiting.set();assert release.wait(10)
                    return self.c.commit()
                def __getattr__(self,n):return getattr(self.c,n)
            m.db=Connection
            def request(is_save):
                try:
                    client=m.app.test_client()
                    with client.session_transaction() as s:s.update(session)
                    r=client.post('/api/save-answer',json=dict(index=0,choice=values(data,'full')[0])) if is_save else client.post('/exam',data=form(data,values(data,'full')))
                    responses['save' if is_save else 'submit']=r.status_code
                except Exception:responses['error']=traceback.format_exc()
            first=threading.Thread(target=request,args=(True,),name='autosave_first')
            second=threading.Thread(target=request,args=(False,),name='timeout_submit')
            try:
                first.start();assert saved_waiting.wait(10)
                Clock.value=deadline;second.start();assert submit_waiting.wait(10)
                release.set();first.join(10);second.join(10)
                assert not first.is_alive() and not second.is_alive()
            finally:release.set();m.db=original;m.datetime=oldtime
            assert responses=={'save':200,'submit':302},responses
            verify(aid,data,2)
            return 'Autosave admitted before deadline commits while timeout submit waits; submit reloads saved answers under lock and scores 2/10.'
        check('F001_F002_timeout_reloads_winning_autosave_under_lock',autosave_first_timeout)
        def rollback_error():
            c,aid,data,_=attempt();save(c,values(data,'partial'));before=stored(aid);original=m.db;connections=[]
            class Connection:
                def __init__(self):self.c=original();self.writes=0;self.closed=False;self.failed=False;connections.append(self)
                def execute(self,q,args=()):
                    if q.startswith('INSERT INTO cau_tra_loi('):
                        self.writes+=1
                        if self.writes==2:self.failed=True;raise sqlite3.OperationalError('R1 injected failure after first answer write')
                    return self.c.execute(q,args)
                def close(self):self.closed=True;self.c.close()
                def __getattr__(self,n):return getattr(self.c,n)
            m.db=Connection
            try:
                response=c.post('/exam',data=form(data,values(data,'full')));assert response.status_code==500
                m.db=original
                failed=[x for x in connections if x.failed];assert len(failed)==1 and failed[0].closed
                assert stored(aid)==before
                assert c.post('/exam',data=form(data,values(data,'full'))).status_code==302;verify(aid,data,10)
            finally:
                m.db=original
                for conn in connections:conn.close()
            return 'Injected transaction failure rolls back first answer, closes connection, and permits clean retry.'
        check('F002_transaction_failure_rollback_and_retry',rollback_error)
        def conditional_finalize():
            c,aid,data,_=attempt();save(c,values(data,'partial'));before=stored(aid)
            sql(f'''CREATE TRIGGER r1_ignore_submission BEFORE UPDATE OF submitted_at ON bai_thi WHEN NEW.id={aid} AND NEW.submitted_at IS NOT NULL BEGIN SELECT RAISE(IGNORE); END''')
            try:
                assert c.post('/exam',data=form(data,values(data,'full'))).status_code==302
                assert stored(aid)==before,'Failed conditional finalization committed answers'
            finally:sql('DROP TRIGGER r1_ignore_submission')
            return 'SQLite returns rowcount0 (test-only trigger): no answers or score are committed.'
        check('F002_failed_submission_claim_rolls_back_answers',conditional_finalize)
        def comma_roundtrip():
            topic='Chủ đề, có dấu phẩy';other='Chủ đề thường';meta={}
            for k,(items,answers) in definitions.items():
                for lv in ['NB','TH','VD','VDC']:
                    for mon,tp in [('R1_comma',topic),('R1_comma',other),('Other subject',topic)]:
                        teacher.post('/teacher/multi/new',data=dict(ma_cau=k+lv+mon+tp,khoi_lop='8',mon=mon,chu_de=tp,muc_do=lv,question_type=k,noi_dung='Comma test',items=items,answers=answers,points='4',scoring_mode='partial',weights='1,3' if k in ('TF','MATCH','FILL') else ''))
            for row in sql('SELECT * FROM cau_hoi WHERE mon IN ("R1_comma","Other subject")'):meta[row['id']]=(row['question_type'],row['muc_do'],row['mon'],row['chu_de'])
            cases=[]
            for topics,per_cell in [([topic],1),([topic,other],2)]:
                query=MultiDict([('mon','R1_comma')]+[('chu_de',t) for t in topics])
                available=teacher.get('/teacher/api/question-availability',query_string=query).json
                assert available['counts']['TOTAL']==20*per_cell
                fields=MultiDict([('ten','Comma 20'),('mon','R1_comma'),('thoi_gian','15')]+[('chu_de',t) for t in topics]+[(k+'_'+lv,str(per_cell)) for k in definitions for lv in ['NB','TH','VD','VDC']])
                n=sql('SELECT COUNT(*) FROM ky_thi')[0][0];assert teacher.post('/teacher/create-exam',data=fields).status_code==302
                assert sql('SELECT COUNT(*) FROM ky_thi')[0][0]==n+1
                eid=sql('SELECT MAX(id) FROM ky_thi')[0][0]
                for _ in range(10):
                    kt=sql('SELECT * FROM ky_thi WHERE id=?',(eid,))[0];de=m.build_exam(kt)
                    assert len(de)==20*per_cell and len({q['id'] for q in de})==20*per_cell
                    assert Counter(meta[q['id']][:2] for q in de)==Counter({(k,lv):per_cell for k in definitions for lv in ['NB','TH','VD','VDC']})
                    assert all(meta[q['id']][2]=='R1_comma' and meta[q['id']][3] in topics for q in de)
                cases.append(dict(topics=topics,stored=kt['chu_de'],requested=kt['so_cau'],actual=len(de)))
            observations['comma_roundtrip']=cases;return cases
        check('F003_comma_single_multi_topic_full_20_cell_roundtrip',comma_roundtrip)
        def legacy_topics():
            # No old row is rewritten. Exercise both legacy sampler and type-quota sampler.
            qids={}
            for topic in ['A','B','Chủ đề tiếng Việt','["Legacy JSON-looking name"]','TNLAN_TOPICS_V1:literal','TNLAN_TOPICS_V1:["legacy literal"]']:
                teacher.post('/teacher/multi/new',data=dict(ma_cau=topic,khoi_lop='8',mon='R1_legacy',chu_de=topic,muc_do='NB',question_type='SINGLE',noi_dung='Legacy',items='A\nB',answers='1'))
                qids[topic]=sql('SELECT MAX(id) FROM cau_hoi')[0][0]
            cases=[]
            for raw,names in [('',list(qids)),('A',['A']),(' A, B ',['A','B']),('Chủ đề tiếng Việt',['Chủ đề tiếng Việt']),('["Legacy JSON-looking name"]',['["Legacy JSON-looking name"]']),('TNLAN_TOPICS_V1:literal',['TNLAN_TOPICS_V1:literal']),('TNLAN_TOPICS_V1:["legacy literal"]',['TNLAN_TOPICS_V1:["legacy literal"]'])]:
                for quotas in ['',json.dumps({'SINGLE':{'NB':len(names)}})]:
                    kt=dict(id=-1,mon='R1_legacy',chu_de=raw,muc_do='NB',nb_count=len(names),th_count=0,vd_count=0,vdc_count=0,so_cau=len(names),type_quotas=quotas)
                    before=dict(kt);de=m.build_exam(kt)
                    assert {q['id'] for q in de}=={qids[t] for t in names},raw
                    assert kt==before
                    cases.append(dict(raw=raw,quota_sampler=bool(quotas),count=len(de)))
            return cases
        check('F003_backward_compatibility_14_legacy_sampler_cases',legacy_topics)
        def persisted_legacy():
            ids=[]
            for raw,quotas in [('A,B',''),('A,B',json.dumps({'SINGLE':{'NB':2}}))]:
                sql('''INSERT INTO ky_thi(ten,lop,mon,so_cau,thoi_gian_phut,chu_de,muc_do,nb_count,th_count,vd_count,vdc_count,hien_diem,trang_thai,created_at,type_quotas) VALUES('Persisted legacy','8A','R1_legacy',2,15,?,'NB',2,0,0,0,1,'MO',?,?)''',(raw,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),quotas))
                ids.append(sql('SELECT MAX(id) FROM ky_thi')[0][0])
            before=[dict(sql('SELECT * FROM ky_thi WHERE id=?',(eid,))[0]) for eid in ids]
            m.init_db();m.init_db()
            after=[dict(sql('SELECT * FROM ky_thi WHERE id=?',(eid,))[0]) for eid in ids]
            assert before==after
            for kt in after:assert len(m.build_exam(kt))==2
            observations['schema']=[dict(r) for r in sql("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name")]
            return 'Two persisted CSV exams (old/type quotas), init_db twice: entire rows unchanged, reload/build2, no migration.'
        check('F003_persisted_legacy_rows_unchanged_no_schema_migration',persisted_legacy)
        def tagged_name():
            topic='TNLAN_TOPICS_V1:["literal name"]'
            teacher.post('/teacher/multi/new',data=dict(ma_cau='TAG',khoi_lop='8',mon='R1_tag',chu_de=topic,muc_do='NB',question_type='SINGLE',noi_dung='Literal tag',items='A\nB',answers='1'))
            teacher.post('/teacher/create-exam',data=dict(ten='Literal tagged name',mon='R1_tag',chu_de=topic,thoi_gian='15',SINGLE_NB='1'))
            kt=sql('SELECT * FROM ky_thi ORDER BY id DESC')[0];de=m.build_exam(kt)
            assert len(de)==1 and sql('SELECT chu_de FROM cau_hoi WHERE id=?',(de[0]['id'],))[0][0]==topic
            return dict(topic=topic,stored=kt['chu_de'],actual=len(de))
        check('F003_new_literal_tagged_topic_roundtrip',tagged_name)
        import logging
        logging.shutdown();shutil.copyfile(root/'app/logs/app.log',args.output/'runtime.log')
    report=dict(source=str(args.source.resolve()),results=results,observations=observations,counts=dict(Counter(x['status'] for x in results)))
    (args.output/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('COUNTS',report['counts'])
    return 1 if any(x['status']=='FAIL' for x in results) else 0
if __name__=='__main__':sys.exit(main())
