# F012 — Historical report integrity

`F012_PREPROD = PRODUCT_DECISION_REQUIRED`

`CONTRACT = UNDEFINED` đối với metadata/nội dung/phân loại trong báo cáo lịch sử. Contract **scoring** đã xác định: chốt khi bắt đầu bài. Hai contract phải được phân biệt.

## Runtime workflow hoàn toàn qua UI endpoints hợp lệ

1. Teacher tạo SINGLE level NB, text SOURCE_BEFORE_NB, points=4/all qua `/teacher/multi/new`.
2. Teacher tạo kỳ thi, thêm học sinh; student login nhận snapshot, autosave đúng, submit → điểm 10.
3. Capture report HTML/context, exam-report Excel, result, analytics, monitor, điểm từng câu Excel, kết quả Excel; đọc attempt/answers từ DB fixture.
4. Teacher sửa chính câu qua `/teacher/multi/edit/<qid>`: NB→VD, text SOURCE_AFTER_VD, points=9.
5. Capture lại cùng các endpoints; không re-submit/re-grade/update attempt/answers, không SQL sửa câu trực tiếp.

Evidence `F012/results.json`, các file before_*/after_*, `probe_history.py`, `F012/history-secondary-comparison.json`. Tất cả response dùng trong so sánh HTTP 200; create/edit/submit trả 302 như flow hiện tại.

| Giá trị/view | BEFORE | AFTER |
|---|---|---|
| Bank row level/text/points | NB / SOURCE_BEFORE_NB / 4 | VD / SOURCE_AFTER_VD / 9 |
| Stored attempt score | 10 | 10 |
| Stored de_json question text/points | SOURCE_BEFORE_NB / 4 | Giữ nguyên byte string |
| Stored answer rows và toàn bộ attempt row | Captured | Hoàn toàn bằng BEFORE |
| Report qstats text/cognitive | SOURCE_BEFORE_NB / NB | SOURCE_AFTER_VD / VD |
| Report levels số lượt NB/VD | 1 / 0 | 0 / 1 |
| Report average, student result, monitor score | 10 | 10 |
| Excel PhanTichCauHoi | NB / text cũ | VD / text mới |
| Excel TheoMucDo lượt NB/VD | 1 / 0 | 0 / 1 |
| Excel KetQuaHocSinh/TongQuan | Score/summary 10 | Rows giữ nguyên |
| Excel DiemTungCau | earned/max=4/4, quy đổi 10 | Rows giữ nguyên dù bank points=9 |
| Excel BangDiem | 10 | Rows giữ nguyên |
| Analytics HTML | Điểm TB 10.0 và row 10.0 | Bodies bằng nhau, số vẫn 10.0 |
| Student result HTML | 10.0/10 | Bodies bằng nhau |

`analytics_contains_score10=false` trong raw results là phép tìm literal `10.0/10` không phù hợp markup analytics; không phải điểm analytics bị mất/sai. Saved HTML có `<h3>10.0</h3><p>Điểm TB toàn hệ thống`; kiểm tra offline bổ sung nằm trong history-secondary-comparison.json. Raw probe được giữ nguyên, không sửa assertion/source để PASS.

`REACHABLE_FROM_VALID_UI`: trạng thái thay đổi do teacher edit hợp lệ, không cần DB hỏng/restore/legacy manipulation.

## Source và UI/docs contract

- `app.py:1553` report: qstats/level_stats JOIN `cau_tra_loi → bai_thi → cau_hoi`; lấy ma_cau/noi_dung/muc_do từ bảng bank hiện tại. Count/dung lấy answers đã lưu. Các điểm/average lấy bai_thi.diem, không re-grade theo ngân hàng.
- `app.py:1675` exam-report Excel: JOIN tương tự, thêm mon/chu_de hiện tại; PhanTichCauHoi và TheoMucDo kế thừa dữ liệu này. KetQuaHocSinh/TongQuan dùng attempt score.
- `multi_routes.py:55` points export đọc de_json rồi grade với choices đã lưu; đã chứng minh không đổi khi bank points bị sửa. `app.py:2093` export-results dùng attempt score.
- `app.py:1816` analytics và `/teacher/api/monitor/<eid>` tổng hợp attempt/score; `/result` (`app.py:2356`) hiển thị stored score. Những view này không đổi trong scenario.
- `question_types.py:32` snapshot giữ q/image/type/options/answer/right/scoring/id, nhưng **không lưu cognitive/muc_do, mon, chu_de, ma_cau**. Fixture xác nhận fields thực: answer,id,image,options,q,scoring,type.
- `README_v2.3.txt:51–53`: “Cách chấm được chốt lúc học sinh bắt đầu bài. Đổi cấu hình trong ngân hàng chỉ ảnh hưởng các bài bắt đầu sau đó. Không tự tính lại bài đã nộp.” Cam kết này nói cách chấm, không nói đóng băng mọi metadata report.
- `templates/report.html` chỉ ghi “Báo cáo kỳ thi”, “Mức độ”, nội dung/thống kê; không ghi “tại thời điểm thi” hay “theo ngân hàng hiện tại”. Docs báo cáo/Excel hiện có không xác định rõ thời điểm metadata. Full text search source/docs/UI và numbered excerpts nằm trong SOURCE_EVIDENCE.md và contract-search.txt.

Source hiện thực dynamic bank view; đây là quan sát behavior, **không phải bằng chứng người dùng đã chọn contract B**. Cam kết snapshot scoring không đủ để tự chọn A cho toàn bộ report. Vì chưa có contract nghiệp vụ rõ nên cần quyết định, không tự patch/đổi severity để đạt PASS.

## Hai hành vi chính xác để người dùng quyết định

| Lựa chọn | Hành vi report/Excel | Dữ liệu cũ và hệ quả |
|---|---|---|
| A — SNAPSHOT TẠI THỜI ĐIỂM THI | Đóng băng ma_cau/mon/chu_de/muc_do và nội dung theo từng attempt lúc bắt đầu. Sửa bank NB→VD không đổi phân tích lịch sử; points/answers/score vẫn dùng snapshot. | Bổ sung metadata vào snapshot mới, lấy report từ per-attempt snapshot. Bài cũ có q nhưng không có level/topic/code; không thể khôi phục chính xác metadata lịch sử nếu không có backup đáng tin. Phải định nghĩa nhãn unknown/legacy hoặc chỉ backfill từ evidence xác thực; không dùng current bank rồi gọi là snapshot lịch sử. Khi cùng ID được sửa giữa các lần bắt đầu, grouping phải tôn trọng snapshot/version, không ghép sai cohort. |
| B — VIEW THEO NGÂN HÀNG HIỆN TẠI | Giữ JOIN hiện tại cho code/subject/topic/level/content; đổi NB→VD sẽ chuyển các lượt lịch sử sang VD và hiển thị text mới. Điểm/answers/snapshot bài thi giữ nguyên. | Cần ghi rõ nhãn/contract rằng phân tích dùng bank hiện tại; tránh trình bày metadata mới như câu học sinh thực sự đã thi. Ngữ nghĩa points export vẫn là scoring snapshot. |

Audit không chọn A hoặc B. Nếu người dùng chọn A, patch tối thiểu phải xử lý metadata snapshot và readers report/export nhất quán, regression NB→VD/text/code/topic/subject + nhiều snapshot cùng ID + legacy missing metadata, tuyệt đối không tự re-grade bài đã nộp. Nếu chọn B, cần xác nhận dynamic behavior và tài liệu/nhãn nhất quán; vẫn giữ regression score/snapshot/answers/Excel điểm không đổi. Không áp dụng lựa chọn nào trong vòng này.

Giới hạn: scenario một câu/attempt đã đủ chứng minh report drift; chưa kiểm nhiều đời snapshot/grouping vì đó thuộc lựa chọn/patch tương lai. Không có evidence contract lịch sử riêng ngoài bộ source/docs/UI baseline R3 được cung cấp.
