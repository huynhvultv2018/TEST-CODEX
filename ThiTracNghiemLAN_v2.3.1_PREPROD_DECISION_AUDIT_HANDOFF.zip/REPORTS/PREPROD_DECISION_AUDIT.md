# PRE-PRODUCTION DECISION AUDIT — ThiTracNghiemLAN v2.3.1

Ngày kiểm tra: 2026-10-02 UTC. Phạm vi duy nhất: F010/F011/F012 trên candidate R3 đã khóa.

`PREPROD_GATE = READY_FOR_PATCH_DECISION`

| Finding | Runtime evidence | Reachability | Impact | Decision |
|---|---|---|---|---|
| F010 | Snapshot fixture: chia 0/HTTP 500; điểm lưu 20, -10; NaN/Infinity → submitted với điểm NULL. Restore `.db` có SQLite integrity `ok`, nhận weights `[0,0]`, bài mới submit 500. | Form/Excel hiện tại chặn cấu hình hỏng. Nguồn gây hỏng là `ONLY_CORRUPTED/EXTERNAL_DATA`; đường tiếp nhận đã chứng minh là `REACHABLE_FROM_IMPORT` qua restore `.db`. Legacy thiếu rule hợp lệ chấm đúng 1/all. | Không thể chốt hoặc chốt kết quả sai khi đọc dữ liệu hỏng đã được tiếp nhận. | `F010_PREPROD = REQUIRED` |
| F011 | Server nhận POST thiếu token, thiếu/khác Origin/Referer. Chromium thực: form origin khác gửi cookie và thêm học sinh; cross-site cookie mới cũng thành công. Form `/exam` origin khác chốt bài test 0 điểm. | Phiên giáo viên/admin/học sinh hợp lệ và trang origin khác; không cần đọc cookie HttpOnly. JSON autosave khác origin bị preflight chặn trong probe tự nhiên. | Thao tác dưới quyền phiên nạn nhân, kể cả chốt bài học sinh; cùng cơ chế guard áp dụng các route quản trị trong inventory. | `F011_PREPROD = REQUIRED` |
| F012 | UI tạo NB → nộp 10 → UI sửa VD/nội dung/points. Report và Excel phân tích đổi NB→VD/nội dung mới; snapshot, đáp án, điểm, Excel kết quả/điểm từng câu giữ nguyên. | `REACHABLE_FROM_VALID_UI` | Phân loại/nội dung lịch sử thay đổi theo ngân hàng hiện tại. Contract cho metadata báo cáo chưa được định nghĩa rõ. | `F012_PREPROD = PRODUCT_DECISION_REQUIRED`; `CONTRACT = UNDEFINED` |

Đây là kết luận đủ bằng chứng để người dùng quyết định patch/phạm vi nghiệp vụ. Không có kết luận PRODUCTION READY. F010/F011 chưa được sửa trong vòng này; F012 chưa được chọn hành vi nghiệp vụ.

## Baseline và điều kiện vào audit

- Baseline duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip`.
- SHA-256 trước kiểm tra: `f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a`; khớp chính xác yêu cầu.
- Candidate: 863.183 byte, 62 file; ZIP đọc được. Source giải nén mới: `/workspace/preprod-r3-baseline`.
- Smoke trước decision audit: 83 nhóm/script/scenario PASS, 0 FAIL. Các finding F001/F002/F003/F004/F005/F006/F007/F008/F009/F017 đều PASS; `R3_BASELINE_REGRESSION = NOT_DETECTED`.
- Bằng chứng khóa và smoke: `baseline-lock.json`, `smoke-summary.json`, các thư mục `smoke-*`. Bằng chứng kiểm tra hash cuối: `source-lock-final.json`.

## Cơ sở quyết định

F010: native form, edit và Excel dùng cùng validation. Không chứng minh được chúng tạo cấu hình bất thường từ input hợp lệ. Tuy nhiên, chức năng restore có thật nhận `.db` hợp lệ về cấu trúc SQLite nhưng sai ngữ nghĩa scoring; bài thi mới được tạo qua UI sau restore gặp HTTP 500. Các snapshot fixture còn chứng minh khả năng lưu điểm ngoài miền hoặc NULL khi đã submitted. Yêu cầu tối thiểu là kiểm tra ngữ nghĩa lúc đọc, không tự chữa dữ liệu hay đổi công thức v2.3. Chi tiết write-path, từng probe và đề xuất regression nằm trong `F010_SCORING_AUDIT.md`.

F011: 34 route state-changing POST đã được inventory, không có PUT/PATCH/DELETE. Có một nonce riêng cho student-import-confirm nhưng không có cơ chế CSRF chung hay kiểm Origin/Referer. Cookie thực không phát SameSite/Secure, có HttpOnly và được ký. Trình duyệt thực xác nhận attack surface form POST; Signed session và token sở hữu attempt không thay thế CSRF token gửi riêng trong request. Phạm vi teacher/admin có thể bảo vệ riêng về kỹ thuật, nhưng probe `/exam` cho thấy không thể coi đó là bảo vệ toàn ứng dụng. Chi tiết cookie, CORS, giới hạn trình duyệt và phạm vi đề xuất nằm trong `F011_CSRF_AUDIT.md`.

F012: report JOIN ngân hàng hiện tại trong khi điểm lấy từ attempt/snapshot. Sửa câu hỏi qua UI làm đổi phân tích NB/VD và nội dung trong report/Excel. Tài liệu chỉ cam kết chốt cách chấm lúc bắt đầu bài, không xác định contract cho metadata báo cáo lịch sử. Hai hành vi để lựa chọn nằm trong `F012_HISTORY_REPORT_AUDIT.md`; audit không chọn thay người dùng.

## Khóa phạm vi và bàn giao

Không sửa source, schema/database thật, template/JavaScript, test gốc hay candidate; không tạo R4/version/candidate mới. Các ứng dụng test chạy trên bản sao tạm và database/LOCALAPPDATA tạm. Chỉ tạo harness ngoài baseline, fixture, báo cáo và evidence. Các lần lỗi cơ khí của harness mới được giữ nguyên và phân biệt với lỗi sản phẩm; không skip/XFAIL hay sửa test gốc để PASS.

HANDOFF chứa `REPORTS/` (7 báo cáo), `EVIDENCE/PREPROD_EVIDENCE/` và `CHECKSUMS.sha256`. Manifest mới dùng đường dẫn trong handoff và không ghi đè manifest R1 hiện có ở repository root. SHA-256 của handoff được ghi ngoài ZIP trong chứng cứ bàn giao, vì một ZIP không thể tự chứa hash của chính nó.

Chỉ HANDOFF ZIP được commit với message `Add v2.3.1 pre-production decision audit handoff` trên branch hiện tại. Handoff không chứa source/candidate ZIP mới. Sau bàn giao, dừng để người dùng quyết định; không patch F010/F011/F012 hoặc đưa lên Production.
