# F011 — CSRF security decision audit

`F011_PREPROD = REQUIRED`

Các thao tác dùng phiên đăng nhập nhận form POST origin khác khi browser gắn cookie; không cần đọc cookie hay biết session secret. Probe thực hiện hoàn toàn trên 2 HTTP server loopback và DB test tạm. Không có tấn công hệ thống thật.

## Inventory và cơ chế hiện tại

Runtime Flask url_map đã liệt kê 34 route POST có khả năng đổi trạng thái; không có PUT/PATCH/DELETE. Xem toàn bộ từng route, role/auth/token/cookie/Origin/Referer trong `PREPROD_ROUTE_INVENTORY.md` và `F011-server/results.json`. Source `app.py:81/90` kiểm phiên/role; multi_routes dùng cùng teacher_required. Hai before_request (`app.py:546/572`) chỉ kiểm giấy phép và maintenance, không kiểm CSRF.

Không route nào kiểm Origin/Referer trước business write. Việc dùng request.referrer làm URL redirect trong import không phải Referer validation. Tất cả teacher/admin POST dựa vào signed session, ngoại trừ login dùng credential. `/teacher/students/import-confirm` là ngoại lệ nonce riêng: so sánh `student_import_token` trong session với token của form bằng compare_digest (`app.py:1285`); nonce không được export. Không thể suy từ ngoại lệ này ra cơ chế CSRF toàn app.

Student client_token nằm trong cookie session, so khớp DB bởi validate_attempt_session. Đây là bảo vệ sở hữu attempt/revocation, không phải request nonce mà trang origin khác không tự gửi được. Browser tự gửi cùng cookie hợp lệ trong form CSRF; R1/R2 không ngăn loại request origin khác này.

Old password ở change-password và signed license key ở activation là điều kiện nghiệp vụ riêng; chúng hạn chế input/thao tác tương ứng, không thay cơ chế CSRF chung cho add/delete/restore/unlock/settings.

## Cookie/session thực tế

| Thuộc tính | Cấu hình/Set-Cookie quan sát |
|---|---|
| Name/domain/path | session; host-only (Domain không đặt); Path=/ |
| SameSite | Flask SESSION_COOKIE_SAMESITE = Python None; **attribute bị bỏ khỏi Set-Cookie**, khác với explicit `SameSite=None` |
| Secure | False; Set-Cookie không có Secure |
| HttpOnly | True; Set-Cookie có HttpOnly |
| Lifetime | Session cookie, không expires trong probe; PERMANENT_SESSION_LIFETIME mặc định 31 ngày không được dùng làm chứng minh thời gian sống permanent |
| Implementation | flask.sessions.SecureCookieSessionInterface: cookie phía client được ký, không có server-side session store; ký không ngăn browser tự gửi cookie |
| Browser interpretation | Chromium 151.0.7922.173 hiển thị SameSite=Lax hiệu lực cho cookie thiếu attribute |
| Transport hợp tài liệu/source | Waitress host 0.0.0.0 không TLS (`app.py:2411`); hướng dẫn dùng http://127.0.0.1 và http://192.168.1.29:5000. Không có HTTPS/reverse-proxy được cấu hình/test ở vòng này |

Evidence `F011-server/results.json` giữ attributes Set-Cookie và config thực, đã redact value; browser giữ cookie metadata không giữ giá trị. Không giả định rằng nhãn Lax hiệu lực sẽ chặn mọi POST. Probe cross-site mới đăng nhập (<1 giây) thành công như bảng dưới; không kéo dài/giả định kết quả cho cookie cũ hơn hoặc browser khác.

## Runtime server-side

| Fixture/request | Origin/Referer/token | Kết quả |
|---|---|---|
| ADMIN và GIAOVIEN POST student/add, mỗi role 4 trường hợp | Thiếu cả hai; Origin khác; Referer khác; cả hai khác; không CSRF nonce | 8/8 nhận 302, mỗi request thêm đúng 1 row test |
| ADMIN POST settings | Thiếu cả hai hoặc cả hai khác; không nonce | 2/2 nhận 302, school_name fixture được đổi |
| Anonymous POST student/add | Không phiên | 302 login, 0 row; authentication vẫn hoạt động |
| GIAOVIEN POST admin settings | Phiên teacher | Không đổi setting; admin role guard vẫn hoạt động |
| Student POST JSON autosave trong Flask client | Cookie/attempt token hợp lệ, Origin khác, không request nonce | 200, answer được lưu; đây là server acceptance, **không phải browser bypass CORS** |
| Import-confirm | Nonce sai | 302, 0 row |
| Import-confirm | Nonce session hợp lệ + Origin khác | 302, 1 row; confirms nonce thực, server không check Origin |

Evidence `F011-server/results.json` và runtime.log. Probes dùng account/student/settings/Excel mới vô hại trong DB tạm; không restore/delete dữ liệu thật để chứng minh CSRF.

## Chromium tự nhiên — không route/intercept request

Nguồn kết luận: `F011-browser-complete/results.json` + ảnh + WSGI wire observer. Observer chỉ ghi header metadata rồi gọi app nguyên trạng; không override headers/cookie/security flags. Đã có một run dùng Playwright routing làm sai phép đo CORS; run đó bị loại khỏi kết luận, xem `HARNESS_OBSERVATION_NOTES.md`. Bản kết luận không có route interception.

| Scenario | Browser/WSGI evidence | Trạng thái DB test |
|---|---|---|
| Teacher form POST từ cùng host nhưng port khác | Origin khác; Sec-Fetch-Site=same-site; Cookie attached; không token; 302 | Tạo học sinh fixture thành công |
| Teacher form POST từ localhost tới 127.0.0.1 sau login mới | Sec-Fetch-Site=cross-site; Cookie attached; không token; 302 | Tạo học sinh fixture thành công. Chỉ khẳng định cookie mới trong probe, không mọi tuổi cookie |
| Cross-site GET teacher/logout | Cookie attached; không token; 302 | Phiên test bị clear, mở teacher phải login |
| Student fetch JSON application/json từ cùng-site origin khác | Browser Failed to fetch; wire chỉ OPTIONS, không POST; server không phát Allow-Origin | 0 answer row. Playwright phát sự kiện request-intent POST không có nghĩa POST đã tới server |
| Student top-level HTML form POST `/exam` từ cùng-site origin khác | Cookie attached; không nonce; wire POST tới app | submitted_at từ NULL thành có giá trị; score từ NULL thành 0, redirect result |

JSON non-simple request bị preflight chặn trong trình duyệt này, nhưng CORS không chặn top-level form POST và không thay CSRF policy server. Browser probe chưa đo older-cookie >2 phút, Firefox/WebKit, origin Internet/public→private theo chính sách private-network của từng browser, hay mạng LAN/HTTPS vật lý. Các giới hạn đó không phủ định form origin khác đã thành công; không hạ rủi ro chỉ vì LAN.

## Attack surface/impact có chứng cứ

Phiên ADMIN có thể thực hiện route admin và teacher; phiên GIAOVIEN có các route teacher. Form POST kiểu x-www-form-urlencoded tới add/clone/create-exam/toggle/delete/unlock/settings được browser phép gửi mà không cần đọc response. Destructive route được xác định bằng source/guard inventory, không bị khai thác trong runtime. Restore/import yêu cầu file: form trang khác không tự chọn local file của nạn nhân; payload upload khả thi còn phụ thuộc browser/CORS/nguồn file, **không coi mọi route upload đã được khai thác**. Import-confirm nonce riêng hiện hạn chế request không biết nonce. Change-password còn yêu cầu old password; license còn yêu cầu key hợp lệ.

Login không đòi phiên cũ: source không CSRF nonce, login CSRF là bề mặt cần bảo vệ khi biết credential tài khoản của bên gửi; không claim lấy được mật khẩu nạn nhân. `/exam` đã probe chốt sớm khi chưa hết hạn; token ownership và R1 deadline/atomicity vẫn đúng vì request dùng chính phiên valid. Đây không phải regression của F001/F002, mà thiếu kiểm nguồn/nonce request (F011).

## Tác động của CSRF và phạm vi patch để duyệt

| Workflow | Thay đổi cần thiết nếu bảo vệ | Điều phải giữ |
|---|---|---|
| HTML teacher/admin forms | Hidden request nonce, check trước write cho cả direct/nested multi routes | Role/auth guard và validation nghiệp vụ hiện có |
| Teacher AJAX/fetch | Header nonce khi có mutation; GET availability/monitor không cần mutation nonce | Không làm hỏng 20-cell matrix/topics |
| Login teacher | Nonce gắn pre-auth session, rotate sau successful login | Failed-password/lockout và giấy phép; không chặn chỉ vì chưa có phiên authenticated |
| Import multipart/preview/confirm | Nonce chung cho preview/upload/confirm; giữ riêng operation nonce hiện có | Không ghi/save upload trước validation; không thay input Excel |
| Unlock/retake | Nonce trước unlock write | F017 revoke token, legacy semantics và retake snapshot |
| Logout | Mutation POST + nonce hoặc giải pháp kiểm nonce phù hợp; điều chỉnh link/form tương ứng | Không để GET có thể clear session ngoài ý muốn |
| Student login/submit | Nonce riêng cho form và check trước business mutation nếu phạm vi bao phủ student | Snapshot/scoring/deadline/atomicity/token ownership; không nhận late answers |
| Student autosave/ping | Nếu global guard thì JS gửi nonce header; giữ API JSON và không mở CORS bừa | Autosave deadline/status, submitted rejection, token refresh/unlock; token đủ sống cho kỳ thi tới 180 phút |

**Có thể bảo vệ riêng TEACHER/ADMIN về kỹ thuật**, dùng guard theo endpoint/namespace, bao gồm pre-auth teacher login và logout. Không bắt buộc refactor student/scorer/schema để đóng bề mặt teacher/admin. Scope này phải ghi rõ chỉ đóng F011 teacher/admin; `/exam` HTML attack vừa chứng minh vẫn còn, nên không thể gọi app đã có CSRF protection đầy đủ.

Phạm vi nhỏ nhất để đóng các **đường tấn công đã chứng minh trong audit**: teacher/admin mutation routes + login/logout và student HTML login/submit có request nonce gắn session/rotate khi đổi phiên. Giữ operation nonce import. Với JSON autosave/ping hiện preflight chặn browser cross-origin, có thể tách giai đoạn khỏi guard teacher; nếu chọn global CSRF guard thì phải cập nhật đồng bộ 2 API JS, không thêm guard làm student workflow lỗi. Trước bất kỳ kết luận pre-production tổng thể cần người dùng xác nhận phạm vi student còn mở hoặc chọn bảo vệ thống nhất. Không chỉ thêm SameSite hoặc kiểm cookie token rồi tuyên bố đã xử lý CSRF.

Đề xuất security policy: nonce session khó đoán, kiểm request form/header trước thay trạng thái, missing/wrong nonce trả lỗi kiểm soát; xử lý Origin/Referer theo origin app thực làm lớp bổ sung với policy rõ cho header thiếu. Cookie SameSite explicit có thể là lớp phụ; Secure=True cần HTTPS deployment và không được bật trên LAN HTTP rồi làm mất cookie. Đây là đề xuất, không cấu hình/patch nào đã áp dụng.

Regression cần có khi patch được duyệt: missing/wrong/valid nonce trên đủ 34 route, role/anonymous controls, pre-auth login/session rotation, origin/cross-site browser form cases, GET logout, multipart imports và nonce preview-confirm, unlock/relogin, student submit/expiry/race, autosave/ping JS, stale tabs/token lifetime/180 phút, result/scoring/snapshot và HTTPS/HTTP policy đã chọn. Không đổi test gốc hoặc cấu hình môi trường trong audit này.
