# PREPROD decision matrix

| Finding | Runtime evidence | Reachability | Impact | Decision |
|---|---|---|---|---|
| F010 | Snapshot fixture: chia 0/HTTP 500; điểm lưu 20, -10; NaN/Infinity → submitted với điểm NULL. Restore `.db` có SQLite integrity `ok`, nhận weights `[0,0]`, bài mới submit 500. | Form/Excel hiện tại chặn cấu hình hỏng. Nguồn gây hỏng là `ONLY_CORRUPTED/EXTERNAL_DATA`; đường tiếp nhận đã chứng minh là `REACHABLE_FROM_IMPORT` qua restore `.db`. Legacy thiếu rule hợp lệ chấm đúng 1/all. | Không thể chốt hoặc chốt kết quả sai khi đọc dữ liệu hỏng đã được tiếp nhận. | `F010_PREPROD = REQUIRED` |
| F011 | Server nhận POST thiếu token, thiếu/khác Origin/Referer. Chromium thực: form origin khác gửi cookie và thêm học sinh; cross-site cookie mới cũng thành công. Form `/exam` origin khác chốt bài test 0 điểm. | Phiên giáo viên/admin/học sinh hợp lệ và trang origin khác; không cần đọc cookie HttpOnly. JSON autosave khác origin bị preflight chặn trong probe tự nhiên. | Thao tác dưới quyền phiên nạn nhân, kể cả chốt bài học sinh; cùng cơ chế guard áp dụng các route quản trị trong inventory. | `F011_PREPROD = REQUIRED` |
| F012 | UI tạo NB → nộp 10 → UI sửa VD/nội dung/points. Report và Excel phân tích đổi NB→VD/nội dung mới; snapshot, đáp án, điểm, Excel kết quả/điểm từng câu giữ nguyên. | `REACHABLE_FROM_VALID_UI` | Phân loại/nội dung lịch sử thay đổi theo ngân hàng hiện tại. Contract cho metadata báo cáo chưa được định nghĩa rõ. | `F012_PREPROD = PRODUCT_DECISION_REQUIRED`; `CONTRACT = UNDEFINED` |

`PREPROD_GATE = READY_FOR_PATCH_DECISION`

Đủ runtime/source evidence cho ba quyết định; không dùng điểm số rủi ro tổng hợp. Không kết luận PRODUCTION READY. R3 smoke PASS chỉ xác nhận các finding đã sửa, không đóng F010/F011/F012.

| Finding | Evidence chính | Quyết định tiếp theo cần duyệt |
|---|---|---|
| F010 | F010-final/results.json, runtime.log; SOURCE_EVIDENCE.md: config/grade/total_score/snapshot/restore; source-write-map.json | Validator đọc snapshot/scoring + controlled errors/rollback, giữ legacy/defaults và toàn bộ scoring v2.3; cân nhắc restore preflight. Xem F010_SCORING_AUDIT.md. |
| F011 | F011-server/results.json; F011-browser-complete/results.json, wire headers/PNG; 34-route inventory | Nonce cho teacher/admin/login/logout; xác nhận scope student HTML đã chứng minh có thể bị chốt sớm. Nếu global guard, cập nhật autosave/ping JS đồng bộ. Xem F011_CSRF_AUDIT.md. |
| F012 | F012/results.json và before/after HTML/XLSX; README_v2.3:51; report/export JOIN và snapshot fields | Chọn A: metadata tại thời điểm thi, policy legacy không có metadata; hoặc B: bank hiện tại với nhãn/contract rõ. Audit không tự chọn. |

Các đề xuất chỉ để review; chưa áp dụng thay đổi nào. Dừng sau Git handoff và chờ người dùng quyết định.
