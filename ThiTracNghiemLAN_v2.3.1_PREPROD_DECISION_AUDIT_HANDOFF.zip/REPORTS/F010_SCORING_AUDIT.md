# F010 — Snapshot/scoring defensive validation

`F010_PREPROD = REQUIRED`

Form và Excel hiện tại kiểm tra đủ các cấu hình bất thường được probe; dữ liệu scoring hỏng không được tạo bởi những input đó. Quyết định REQUIRED dựa trên đường restore `.db` đã chứng minh tiếp nhận dữ liệu sai ngữ nghĩa rồi tạo bài mới gặp lỗi, cùng hậu quả chốt điểm sai từ snapshot hỏng. Đây là yêu cầu phòng vệ tại ranh giới đọc dữ liệu, không phải thay đổi scoring v2.3.

## Representation thực tế

`cau_hoi.payload` là JSON options/answer/right/scoring. `scoring` gồm `version`, `points`, `mode`, `weights`. `bai_thi.de_json` lưu toàn bộ snapshot từng câu lúc bắt đầu/retake. Không có input/column scoring tên literal `max_score`: maximum từng câu là `scoring.points` (`scoring.py:20`), maximum bài là tổng các points (`scoring.py:43`). Alias `max_score` ở analytics là MAX của điểm đã lưu, không phải writer cấu hình. Probe max_score âm/NaN/Infinity sử dụng đúng representation `points`, không thêm field mà scorer bỏ qua.

Python `json.loads` chấp nhận các literal mở rộng NaN/Infinity; `json.dumps` mặc định cũng phát chúng. Native config ngăn chúng bằng `math.isfinite`, nhưng reader snapshot/scorer không ngăn. Kết quả evidence JSON dùng object `{non_finite: ...}` và giữ chuỗi snapshot representation nguyên bản để không biến evidence thành JSON sai chuẩn.

## Toàn bộ write-path liên quan

Các line dưới đây thuộc đúng source R3, được giữ dưới dạng excerpt có số dòng trong `SOURCE_EVIDENCE.md`; inventory SQL trong `source-write-map.json`. Search tất cả Python runtime trong baseline không tìm writer scoring/snapshot khác ngoài các đường sau. Các script `kiem_tra_*` là test, không phải production writer.

| Entry/path | Validation → DB | Snapshot → reader/scoring | Reachability |
|---|---|---|---|
| POST `/teacher/multi/new`, `/teacher/multi/edit/<qid>` | `multi_routes.py:74` values → `question_types.py:10` parse_spec → `scoring.py:6` config → JSON dumps; INSERT tại multi_routes:85/156 hoặc UPDATE:156. Không dùng raw request payload. | build_exam → snapshot → login de_json → submit total_score | `REACHABLE_FROM_VALID_UI`; cấu hình bất thường được probe bị từ chối trước write. Edit dùng cùng values. |
| POST `/teacher/multi/import` | multi_routes:197–226 đọc 8/9/11/12 cột tương thích, chuyển từng row qua cùng values; prepare cả file trước INSERT transaction. | Như trên | `REACHABLE_FROM_IMPORT` (Excel); 7 invalid file bị reject, không có row mới. |
| POST `/teacher/question/add` | app:1010–1036 yêu cầu nội dung/4 options/ABCD; INSERT legacy, không ghi payload/scoring. | snapshot legacy dựng options/answer; scorer mặc định 1/all | `REACHABLE_FROM_VALID_UI`, không tạo weights/points bất thường. |
| POST `/teacher/question/edit/<qid>` | app:1038–1060 payload khác rỗng redirect multi_editor; legacy norm_answer/ABCD reject trước UPDATE. Không ghi scoring. | Snapshot đã bắt đầu không bị update | `REACHABLE_FROM_VALID_UI`; không có writer arbitrary payload. |
| POST `/teacher/import-questions` | app:1343–1417 kiểm toàn file options/ABCD/level rồi INSERT legacy, không payload/rule | Default 1/all | `REACHABLE_FROM_IMPORT` (legacy Excel), không tạo scoring bất thường. |
| POST `/teacher/question/clone/<qid>` | app:1125–1144 copy question_type/payload/khoi_lop nguyên trạng; không revalidate payload | Snapshot copy dữ liệu row đã chọn | `REACHABLE_FROM_VALID_UI` chỉ khuếch đại row đã hỏng; không phát sinh rule hỏng từ row hợp lệ. R3 clone payload byte-identical smoke PASS. |
| POST `/teacher/create-exam`, `/teacher/mixed-exam` | app:1440; multi_routes:255 lưu quota/type/topic/time vào ky_thi, không scoring/payload/de_json | app:494 build_exam hoặc quota sampler multi_routes:231–252 chọn row → question_types:32 snapshot | `REACHABLE_FROM_VALID_UI`; không tạo rule mới hoặc đọc raw scoring từ exam form. |
| POST `/` — bắt đầu bài mới | app:2114–2205 build_exam → json.dumps(data) INSERT bai_thi.de_json:2191 | Reader tại exam:2226/2250, autosave:2316, monitor:1901, points export multi_routes:62 | `REACHABLE_FROM_VALID_UI`; kế thừa rule DB, không semantic validation lại. |
| POST `/` — retake sau unlock | app:2142–2163 rebuild → UPDATE de_json:2152; resume chỉ đổi token/last_seen:2175 | Như trên | Snapshot retake mới; snapshot resume cũ không sửa. |
| init_db legacy/migration | app:271, multi_routes:31 thêm cột/defaults và suy luận khối; không ghi/chữa scoring hiện có | Row legacy payload rỗng hoặc payload v2.2 thiếu scoring được đọc bằng default | `REACHABLE_FROM_LEGACY_DATA` cho thiếu rule hợp lệ. Không có evidence writer legacy bình thường sinh zero/negative weights. |
| POST `/teacher/restore`, `/teacher/backup/restore/<name>` | app:2007–2084 chỉ kiểm có 4 table yêu cầu → SQLite backup copy toàn DB → init_db; không semantic validation payload/de_json/rule | Row/snapshot đã restore đi thẳng tới các reader trên | `REACHABLE_FROM_IMPORT` qua restore; origin dữ liệu sai là `ONLY_CORRUPTED/EXTERNAL_DATA`. Hai endpoint gọi cùng helper; uploaded restore đã probe runtime. |
| POST `/api/save-answer`, `/exam` và GET timeout `/exam` | app:2296/2207 ghi choices/dung vào cau_tra_loi; không ghi config hay de_json. Submit tính total_score rồi chốt diem | `correct` tin cấu trúc answer; `grade` tin points/weights, `total_score` không kiểm finite/bounds | Không cho student request trực tiếp viết config. POST muộn/đồng thời vẫn tuân thủ R1; snapshot fixture hỏng là trường hợp khác. |

## Validation trên đường native

`parse_spec` đòi SINGLE/MULTI có 2–20 options, answer đúng chỉ số và MULTI không rỗng; TF/MATCH/FILL có 1–30 mục, shape/đáp án hợp lệ. `config` chỉ nhận all/partial; points hữu hạn trong (0,1000]; explicit weights chỉ TF/MATCH/FILL, đúng số mục, từng weight hữu hạn trong (0,1000]. Weights rỗng là trường hợp hợp lệ dùng trọng số đều, khác với danh sách `[0,0]`.

Runtime POST tạo câu hỏi: MULTI answer rỗng, weights zero/negative, points negative/NaN/Infinity, mode lạ đều trả 200 với cảnh báo và delta DB = 0. Cùng 7 file Excel trả 302, delta DB = 0. Field form `payload="{malformed JSON"` bị bỏ qua: payload vẫn được dựng từ fields đã validate, rule valid points=4/partial/weights=[1,3]. Không gọi đây là đường arbitrary payload.

Evidence: `F010-final/results.json` → UI_write_probes/Excel_import_probes; các HTML và XLSX đầu vào nằm cùng thư mục. Không suy ra rằng HTTP 200/302 một mình có nghĩa validation PASS: chính delta DB và payload quyết định.

## Probe đọc/scoring và classification từng trường hợp

| Probe | Kết quả pure scorer và HTTP runtime | Classification |
|---|---|---|
| MULTI answer=[] + PARTIAL | grade/total ZeroDivisionError; exam GET 200, autosave 200, submit 500, chưa submitted | `ONLY_CORRUPTED/EXTERNAL_DATA` ở snapshot fixture; UI/Excel reject |
| TF weights=[0,0] | ZeroDivisionError; GET/save 200, submit 500 | `ONLY_CORRUPTED/EXTERNAL_DATA` ở snapshot fixture; bổ sung restore ingress đã chứng minh riêng bên dưới |
| TF weights=[-1,2], chỉ ý weight 2 đúng | earned 2 > maximum 1; total/stored score 20; submit 302, đã submitted | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| TF weights=[-1,2], chỉ ý weight -1 đúng | earned -1, total/stored score -10; submit 302 | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| points=-1, SINGLE đúng | earned/max=-1; quy đổi/stored score 10 dù maximum âm | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject. Không khẳng định riêng points âm luôn cho total âm. |
| points=NaN | pure earned/max/total NaN; HTTP submit 302, submitted_at có giá trị, SQLite diem=NULL | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| points=Infinity | pure earned/max Infinity, total NaN; HTTP submit 302, submitted_at có giá trị, SQLite diem=NULL | `ONLY_CORRUPTED/EXTERNAL_DATA`; native reject |
| Snapshot thiếu answer | KeyError; GET 200, autosave/submit 500, chưa submitted | `ONLY_CORRUPTED/EXTERNAL_DATA` |
| Item snapshot là string, không mapping | Pure grade/total AttributeError; không gán kết quả HTTP cho probe này | `ONLY_CORRUPTED/EXTERNAL_DATA` |
| de_json không parse được | GET/submit 500; không chốt | `ONLY_CORRUPTED/EXTERNAL_DATA` |
| MULTI hợp lệ nhưng thiếu toàn bộ scoring | Mặc định maximum=1/all; full answer chấm 10 | `REACHABLE_FROM_LEGACY_DATA`: representation v2.2 được hỗ trợ theo source/docs, fixture row v2.2 qua init_db/snapshot giữ thiếu scoring, chấm 10 |
| PARTIAL thiếu points/weights | Fallback maximum=1, weights đều; chấm 10 cho full answer | `ONLY_CORRUPTED/EXTERNAL_DATA` cho partial rule không đầy đủ: không tìm thấy writer legacy hợp lệ phát shape này. Chỉ probe tính tương thích reader, không coi là lỗi bắt buộc. |
| Legacy SINGLE thiếu type/scoring | Pure grade default SINGLE/1/all chấm 10 | `REACHABLE_FROM_LEGACY_DATA`; không buộc thêm scoring vào dữ liệu cũ |

Snapshot HTTP được thay bằng SQL chỉ trong database fixture tạm. Không có người dùng production hay student UI nào được gán quyền ghi de_json. Runtime lỗi này giữ nguyên trace/500 trong evidence, không sửa source để chạy qua.

### Restore ingress thực

Fixture `.db` tạo từ backup của app test, sửa duy nhất TF payload thành weights=[0,0] ngoài workflow; SQLite `PRAGMA integrity_check = ok`. Giáo viên POST `/teacher/restore`: 302; đọc DB xác nhận rule hỏng vẫn còn. Sau đó giáo viên tạo kỳ thi và học sinh login qua UI hợp lệ: snapshot chứa rule đó, autosave 200, submit 500. Evidence `F010-final/results.json:restore_ingress` và runtime.log.

Nguồn tạo sai = `ONLY_CORRUPTED/EXTERNAL_DATA`. Đường đưa sai vào app = `REACHABLE_FROM_IMPORT` (restore `.db`, không phải Excel). Integrity SQLite chỉ chứng minh file/structure, không chứng minh scoring semantics. Clone/restore không tạo sai từ dữ liệu tốt nhưng bảo toàn sai đã có. Không phát hiện đường legacy bình thường sinh điểm âm/zero weights; không coi thiếu rule legacy hợp lệ là hỏng.

## Đề xuất patch tối thiểu để duyệt, CHƯA áp dụng

1. Một validator dữ liệu đọc cho cấu trúc item/answer theo 5 types và scoring: nonempty answer đúng shape/range; explicit points/weights phải đúng miền hữu hạn như config hiện tại; weights explicit đúng chiều/sum dương; mode đúng. Giữ các default legacy 1/all và weights rỗng hợp lệ; không yêu cầu dữ liệu cũ có version/type/fields mới khi fallback hiện tại có nghĩa hợp lệ.
2. Dùng validator ở payload→snapshot và khi đọc de_json trước autosave/submit/points export; kiểm earned/maximum/total hữu hạn và trong miền hợp lệ trước commit. Không clamp điểm, không thay trọng số/đáp án/công thức làm tròn, không tự sửa DB.
3. Bắt lỗi validation cụ thể tại caller, thông báo dữ liệu không hợp lệ và rollback trước khi chốt; giữ nguyên R1 BEGIN IMMEDIATE, deadline recheck, submitted_at condition, atomic answer+score và R2 token/unlock. Với snapshot không parse được cần cùng đường lỗi có kiểm soát. Cấu hình đã valid phải cho kết quả byte/numeric-equivalent với scorer v2.3.
4. Reuse semantic validation cho restore preflight trước thay DB là lớp phòng vệ tiếp nhận đáng cân nhắc; kiểm toàn payload và attempt snapshot, không migration sửa dữ liệu. Nếu chỉ chấp nhận bản backup tin cậy, phải định nghĩa và kiểm tra điều kiện đó; hiện chưa có assurance như vậy. Không đổi đường native UI/Excel đã validate chỉ để làm lại validation form.

Regression đề xuất: toàn bộ các probe lỗi ở bảng trên với không write/chốt khi invalid; restore file integrity-ok nhưng zero/negative/nonfinite rule; legacy payload rỗng/v2.2 không scoring; all/partial × 5 types, weights hợp lệ/rỗng và max points; round-half-up/aggregate; stored answers re-grade = stored score; deadline/autosave/submit/race/unlock/result; clone/matrix/comma topics; export điểm từng câu. Không có regression mới được viết vào candidate trong vòng audit này.

Giới hạn: không có bằng chứng DB người dùng thực tế đã hỏng hay lỗi từ file Excel hợp lệ; REQUIRED là quyết định bảo vệ ranh giới đọc/restore đã được chứng minh, không nâng/hạ severity finding để đạt một nhãn PASS.
