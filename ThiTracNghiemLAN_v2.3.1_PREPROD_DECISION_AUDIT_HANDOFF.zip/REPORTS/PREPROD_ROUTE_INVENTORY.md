# PREPROD route inventory — F011

Inventory lấy từ runtime `app.url_map` của đúng R3 trong source copy/DB tạm, sau install_multi_routes. 34 route state-changing **POST**; không có PUT/PATCH/DELETE. HEAD/OPTIONS tự sinh không được tính thành business mutation. Role đọc decorator của view unwrapped và được kiểm source/negative auth controls, không giả định mọi `/teacher` đều admin. Toàn bộ route cũng đi qua license gate hiện có.

Teacher/ADMIN nghĩa GIAOVIEN hoặc ADMIN có teacher session; ADMIN nghĩa admin_required. STUDENT attempt nghĩa aid/client_token hợp lệ theo DB; token không là CSRF nonce độc lập. AUTH No pre-auth chỉ áp dụng login; không có nghĩa bypass credential/student code.

| METHOD | PATH | AUTH REQUIRED? | ROLE | CATEGORY | CURRENT CSRF | ORIGIN CHECK? | REFERER CHECK? | CUSTOM TOKEN? | SESSION COOKIE DEPENDENCY? | SOURCE |
|---|---|---|---|---|---|---|---|---|---|---|
| POST | `/` | No pre-auth; validates code/credential | Login credential/code | authentication | none general | No | No | none for CSRF; business inputs separately validated | Not needed beforehand; issues cookie on login | PHAN_MEM/app.py:2114 |
| POST | `/api/ping` | Yes | STUDENT attempt | student exam | none general | No | No | attempt client_token in session (not request CSRF nonce) | Yes | PHAN_MEM/app.py:2338 |
| POST | `/api/save-answer` | Yes | STUDENT attempt | student exam | none general | No | No | attempt client_token in session (not request CSRF nonce) | Yes | PHAN_MEM/app.py:2296 |
| POST | `/exam` | Yes | STUDENT attempt | student exam | none general | No | No | attempt client_token in session (not request CSRF nonce) | Yes | PHAN_MEM/app.py:2207 |
| POST | `/teacher/accounts/<int:uid>/reset-password` | Yes | ADMIN | authentication | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:757 |
| POST | `/teacher/accounts/<int:uid>/toggle` | Yes | ADMIN | admin accounts | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:734 |
| POST | `/teacher/accounts/add` | Yes | ADMIN | admin accounts | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:703 |
| POST | `/teacher/backup` | Yes | TEACHER/ADMIN | backup/restore | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1982 |
| POST | `/teacher/backup/restore/<path:name>` | Yes | TEACHER/ADMIN | backup/restore | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:2067 |
| POST | `/teacher/change-password` | Yes | TEACHER/ADMIN | authentication | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:660 |
| POST | `/teacher/create-exam` | Yes | TEACHER/ADMIN | teacher exam | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1440 |
| POST | `/teacher/delete-exam/<int:eid>` | Yes | TEACHER/ADMIN | teacher exam | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1517 |
| POST | `/teacher/import-questions` | Yes | TEACHER/ADMIN | import | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1343 |
| POST | `/teacher/import-students` | Yes | TEACHER/ADMIN | import | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1323 |
| POST | `/teacher/license` | Yes | ADMIN | admin settings/license | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:835 |
| POST | `/teacher/login` | No pre-auth; validates code/credential | Login credential/code | authentication | none general | No | No | none for CSRF; business inputs separately validated | Not needed beforehand; issues cookie on login | PHAN_MEM/app.py:579 |
| POST | `/teacher/mixed-exam` | Yes | TEACHER/ADMIN | teacher exam | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/multi_routes.py:255 |
| POST | `/teacher/multi/edit/<int:qid>` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/multi_routes.py:136 |
| POST | `/teacher/multi/import` | Yes | TEACHER/ADMIN | import | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/multi_routes.py:197 |
| POST | `/teacher/multi/new` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/multi_routes.py:136 |
| POST | `/teacher/question/add` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1010 |
| POST | `/teacher/question/clone/<int:qid>` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1125 |
| POST | `/teacher/question/delete/<int:qid>` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1062 |
| POST | `/teacher/question/edit/<int:qid>` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1038 |
| POST | `/teacher/questions/bulk-delete` | Yes | TEACHER/ADMIN | question management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1147 |
| POST | `/teacher/restore` | Yes | TEACHER/ADMIN | backup/restore | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:2042 |
| POST | `/teacher/settings` | Yes | ADMIN | admin settings/license | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:793 |
| POST | `/teacher/student/add` | Yes | TEACHER/ADMIN | student management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:934 |
| POST | `/teacher/student/delete/<int:sid>` | Yes | TEACHER/ADMIN | student management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:949 |
| POST | `/teacher/students/bulk` | Yes | TEACHER/ADMIN | student management | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:957 |
| POST | `/teacher/students/import-confirm` | Yes | TEACHER/ADMIN | import | session-bound form nonce | No | No | import-confirm operation nonce | Yes | PHAN_MEM/app.py:1285 |
| POST | `/teacher/students/import-preview` | Yes | TEACHER/ADMIN | import | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1260 |
| POST | `/teacher/toggle-exam/<int:eid>` | Yes | TEACHER/ADMIN | teacher exam | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1506 |
| POST | `/teacher/unlock/<int:attempt_id>` | Yes | TEACHER/ADMIN | exam unlock | none general | No | No | none for CSRF; business inputs separately validated | Yes | PHAN_MEM/app.py:1924 |

## Route family / state effect

| Family | State-changing effect |
|---|---|
| Authentication | Teacher login reset/update failed attempts/lockout/last login hoặc tạo session; student login tạo/resume/retake attempt; change/reset password |
| Admin accounts | Add account, toggle active, reset password; admin guard |
| Settings/license | Đổi branding/port/settings, nhận signed license activation; admin guard |
| Questions | Add/edit/clone/delete/bulk-delete; multi editor và Excel import ghi validated payload |
| Exam management | Create/mixed-exam ghi kỳ thi, toggle active, delete kỳ thi/answers/attempts |
| Student management | Add/delete/import/bulk update/xóa học sinh theo logic route |
| Restore/backup | Tạo backup, upload/saved restore thay DB; file và table-name validation có thật nhưng không CSRF chung |
| Unlock | force_relogin/client_token và quyền relogin/retake attempt |
| Student exam | Autosave answers/last_seen; ping last_seen; submit answers+score một transaction |

## GET side effects ngoài tập 34 mutation routes

`GET /teacher/logout` clear session và ghi logout audit; browser cross-site đã tái hiện. `GET /exam` cập nhật last_seen, hoặc finalize attempt khi deadline hết hạn theo chính sách hiện tại. Đây là các effect nghiệp vụ cần tính khi chọn policy, không được giả định GET hoàn toàn read-only.

Export GET có thể ghi file export/audit; trước request teacher có daily backup một lần/ngày. Các effect file/log này được ghi nhận, không xếp thành proof khai thác destructive mutation và không sửa maintenance trong audit. Guard CSRF chỉ chặn POST không tự loại tất cả side effects GET; cần review logout riêng.

Source tham chiếu trong SOURCE_EVIDENCE.md; machine inventory ở F011-server/results.json. Request.referrer redirect không phải kiểm Referer; signed license/old password là business credential, không custom CSRF nonce. Nonce import-confirm là ngoại lệ hẹp duy nhất; không đóng toàn bộ import preview/teacher workflow.
