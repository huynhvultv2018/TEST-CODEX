# PREPROD runtime report

`R3_BASELINE_REGRESSION = NOT_DETECTED`

`PREPROD_GATE = READY_FOR_PATCH_DECISION`

## Isolation và môi trường

SHA-256 baseline trước mọi smoke: `f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a`. Python 3.12.14; Flask 3.1.3; Waitress 3.0.2; openpyxl 3.1.5; Chromium 151.0.7922.173. Harness mới ở PREPROD_EVIDENCE, không đưa vào baseline/candidate. `audit_support.py` copy PHAN_MEM vào TemporaryDirectory, riêng LOCALAPPDATA/SQLite/file output; không import locked source in place, không viết pycache mới vào baseline. Smoke runner tương tự dùng stage tạm và giữ tên thư mục cũ chỉ để harness nguyên gốc resolve paths; **nội dung stage là R3, không chạy lại baseline cũ**.

Browser Waitress và attacker server bind 127.0.0.1 trên port tạm; không công khai server, không tới mạng ngoài trong browser probe. Không test Windows EXE hay LAN vật lý/production; không cấu hình TLS/cookie môi trường thật. Những giới hạn này không thay bằng suy đoán browser.

## Smoke/regression trước decision probes

| Suite | PASS | FAIL | Evidence |
|---|---:|---:|---|
| R1 regression F001/F002/F003 và scoring × 5 types | 18 | 0 | smoke-r1/results.json |
| R2 regression F004/F007/F009/F017 | 15 | 0 | smoke-r2/results.json |
| R3 regression F005/F006/F008 | 15 | 0 | smoke-r3/results.json |
| 6 test gốc: v23, v23_integration, v22, v221, v222, mathjax | 6 | 0 | smoke-original/runner-results.json và từng log |
| Audit harness gốc | 21 | 0 | smoke-original/audit-checks.json |
| Legacy harness gốc | 6 | 0 | smoke-original/legacy-checks.json |
| Race probe gốc | 1 | 0 | smoke-original/race-probe.json |
| Browser scenario gốc: mathjax, 20-cell matrix, five types | 1 | 0 | smoke-original/browser-checks.json và 3 ảnh |
| Tổng nhóm/script/scenario (không gọi là số assertion) | 83 | 0 | smoke-summary.json |

| Finding đã PASS | Smoke tái xác nhận |
|---|---|
| F001 | Expired POST/GET, exact deadline, wait-lock recheck, saved ALL/PARTIAL/weights, đủ 5 types |
| F002 | 8 parallel submit, duplicate/autosave sau submitted, queued autosave, atomic rollback/retry, race re-grade khớp stored score |
| F003 | Comma-topic 20-cell round-trip và 14 legacy cases, persisted row/schema tương thích |
| F004 | 20-cell type×level canonical/lowercase/space/Unicode, create/mixed/fallback sampler, score10 |
| F005 | Clone 4 grades × 5 types × 2 modes; legacy metadata/payload giữ nguyên |
| F006 | Invalid time/quota ở cả 2 flows, đúng notice/DB unchanged; valid boundary/defaults |
| F007 | Result valid/invalid/current/legacy tokens |
| F008 | Teacher Excel text literal exports, numeric cells giữ numeric, 5 types/points outputs |
| F009 | Invalid legacy ABCD edit reject before write; valid normalized answers score10 |
| F017 | Unlock revoke old save/submit/result; NULL legacy token; relogin/retake; queued writers |

Source SHA của 6 test gốc được ghi trong runner-results; 4 harness audit gốc là unchanged/byte-identical. Harness R3 smoke dùng đúng ui_observer đã PASS R3, không sửa nó trong vòng này. Không skip/XFAIL và không edit test gốc. Trace rollback injection trong smoke là assertion kiểm transaction, không được đếm thành regression chỉ vì log có ERROR.

## Decision runtime probes

| Run | Hoàn tất | Nội dung/bằng chứng |
|---|---|---|
| F010 final | Exit 0 | 12 pure scorer probes, 7 invalid UI rejects + raw payload ignored, 7 invalid Excel rejects, 9 HTTP corrupted snapshot scenarios, v2.2 legacy fixture, restore ingress. F010-final/results.json |
| F011 server | Exit 0 | 34-route inventory, cookie config/Set-Cookie, 8 teacher/admin add requests, 2 settings, auth/role controls, import nonce, student server JSON. F011-server/results.json |
| F011 browser complete — passive | Exit 0 | Same-site/cross-site fresh teacher POST, logout, student JSON OPTIONS-only, student HTML early submit. F011-browser-complete/results.json và 3 PNG |
| F012 legitimate history | Exit 0 | Create NB → submit10 → edit VD/text/points → before/after 7 views/exports; unchanged snapshot/answers/score; report/Excel metadata drift. F012/results.json và before_*/after_* |

Exit 0 ở decision harness có nghĩa **đã hoàn tất phép đo**, không có nghĩa F010/F011/F012 đã được sửa hoặc PASS. Những HTTP 500, score -10/20/NULL là finding evidence được tái hiện chủ động trên DB fixture, không phải regression các finding đã hotfix. JSON schema output giữ nonfinite dưới representation rõ, không che NaN.

Lệnh thực thi (cwd repository, output không trùng lần trước):

```sh
/workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source /workspace/preprod-r3-baseline/PHAN_MEM --output PREPROD_EVIDENCE/smoke-r1
/workspace/tnlan-audit-venv/bin/python HOTFIX_R2_EVIDENCE/r2_regression.py --source /workspace/preprod-r3-baseline/PHAN_MEM --output PREPROD_EVIDENCE/smoke-r2
/workspace/tnlan-audit-venv/bin/python HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py --source /workspace/preprod-r3-baseline/PHAN_MEM --output PREPROD_EVIDENCE/smoke-r3
/workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/run_original_checks.py --source /workspace/preprod-r3-baseline --output PREPROD_EVIDENCE/smoke-original
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_scoring.py --output PREPROD_EVIDENCE/F010-final
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_csrf_server.py --output PREPROD_EVIDENCE/F011-server
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_csrf_browser_complete.py --output PREPROD_EVIDENCE/F011-browser-complete
/workspace/tnlan-audit-venv/bin/python PREPROD_EVIDENCE/probe_history.py --output PREPROD_EVIDENCE/F012
```

Các smoke harness phụ thuộc bố cục repository gốc; copies/hash chỉ là provenance nguyên trạng, không giả định handoff tự chứa application để chạy độc lập. Để tái lập cần lấy đúng candidate R3 có SHA trên và dependencies; handoff intentionally không chứa source/candidate mới.

## Raw run thất bại và phép đo bị loại

`HARNESS_OBSERVATION_NOTES.md` giải thích đầy đủ. F010 initial: fixture legacy thiếu 4 NOT NULL option columns, runner preparation IntegrityError; bổ sung fields của **fixture mới**, final đầy đủ. F011 initial: exact response URL observer timeout tại GET logout; observer mới đối chiếu URL bỏ query suffix và quan sát navigation/response thực. Nguyên nhân ở observer không được suy thành lỗi ứng dụng. Run browser có network routing cho kết quả POST JSON tới app không phù hợp phép đo CORS tự nhiên, bị loại. Hai run passive sau đó xác nhận wire chỉ OPTIONS/0 writes cho JSON và complete thêm student HTML submit; kết luận dựa trên complete passive. Raw logs và partial outputs các run ban đầu giữ nguyên; các bản browser harness được giữ riêng, chỉ sửa cách dựng fixture mới F010. Không sửa source/test assertion gốc để làm PASS.

## Bằng chứng cuối và giới hạn

62/62 source files đã giải nén được hash so lại, file set không đổi; candidate SHA và size vẫn khớp. Manifest/checksum/package được kiểm tra read/CRC và từng member; chỉ handoff ZIP commit. Xem source-lock-final.json và package validation ngoài ZIP. Không có patch, candidate mới, migration DB thật, hotfix R4, bump version hoặc production.
