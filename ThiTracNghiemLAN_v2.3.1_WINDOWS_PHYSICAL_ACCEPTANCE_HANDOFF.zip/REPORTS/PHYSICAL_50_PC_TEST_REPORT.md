# PHYSICAL 50-PC TEST REPORT

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

PHYSICAL_CLIENTS_AVAILABLE = 0 (máy vật lý được cung cấp cho phiên này)
PHYSICAL_50_PC_LAN = NOT_TESTED
LOGIN_SUCCESS = NOT_MEASURED
LOGIN_FAILED = NOT_MEASURED
SUBMIT_SUCCESS = NOT_MEASURED
SUBMIT_FAILED = NOT_MEASURED
HTTP_500_COUNT = NOT_MEASURED
DB_LOCK_ERRORS = NOT_MEASURED
LOST_AUTOSAVE = NOT_MEASURED

Chưa có inventory máy thật, browser thật tại phòng máy, tài khoản HS hoặc physical acceptance exam. Không tạo attempt/account để thay thế physical test. 50 hàng trong ma trận là planned slots chưa gán thiết bị; không phải bằng chứng N=50. Con số 0 là số thiết bị được cung cấp cho phiên nghiệm thu, không phải tổng số máy ngoài phiên.

## Workload chưa thực hiện

Chưa đo 50 máy kết nối/login/load; kiểm tên HS/đề/nội dung/5 loại/MathJax/hình; autosave/thay đáp án/burst; ngắt mạng một nhóm ít nhất 5 máy và resume; teacher read-only monitoring; 50 HS nộp gần đồng thời từ từng browser; đối chiếu kết quả từng người.

GV phải ra hiệu login/autosave/submit trong phòng thật. Không dùng simulation hoặc submit thay HS để ghi PASS. Mỗi máy có một tài khoản/phiên độc lập; ghi ảnh hoặc quan sát ẩn danh theo CLIENT ID và timestamp.

Nếu sau này chỉ có N<50, báo riêng PHYSICAL_N_PC_LAN và giữ PHYSICAL_50_PC_LAN = NOT_TESTED. Để PASS 50 phải đủ 50 máy xác thực và tất cả bước kết nối, login, load, autosave/burst, submit, không mất/lẫn bài, scoring và integrity có evidence.
