# WINDOWS ACCEPTANCE REPORT

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

WINDOWS_RUNTIME = NOT_VERIFIED
WINDOWS_CLEAN_START = NOT_TESTED
WINDOWS_MACHINE_ID_STABILITY = NOT_TESTED
WINDOWS_LICENSE_GATE = PENDING
FINAL_PHYSICAL_ACCEPTANCE = PENDING

## Môi trường

| Trường Windows thật | Giá trị |
|---|---|
| WINDOWS_VERSION / WINDOWS_EDITION | NOT_COLLECTED |
| SYSTEM_ARCH / HOSTNAME / PYTHON_VERSION | NOT_COLLECTED |
| SERVER_LAN_IP / SERVER_PORT | NOT_COLLECTED |
| CPU / RAM | NOT_COLLECTED |

Không điền các thông số Linux vào bảng Windows. Không suy ra FAIL của sản phẩm từ việc không có máy Windows.

## Deployment và workflow

Chưa tạo thư mục deployment Windows, extract tại Windows, cài dependencies Windows, start server, xác minh relative/database paths hoặc writable directories. Chưa có teacher login/dashboard, tạo kỳ thi, học sinh làm bài/autosave/submit/result, backup/restore hoặc CSRF smoke trên Windows.

Candidate là source package; không có `ThiTracNghiemLAN.exe` trong ZIP. Launcher `CHAY_MAY_CHU.bat` yêu cầu EXE. Acceptance source runtime cần chạy chính `PHAN_MEM/app.py` với Python/dependencies trên Windows, hoặc ghi riêng nếu dùng build từ đúng source; không suy ra Windows EXE PASS từ Python/Linux. Chưa build EXE trong phiên này.

Các yêu cầu được ánh xạ trong `EVIDENCE/acceptance-scenario-matrix.csv`. Khi có Windows thật, thực hiện runbook, ghi evidence cho các bước bắt buộc; chỉ nâng gate khi bằng chứng đầy đủ. Không nâng Production.
