# PHYSICAL DATA INTEGRITY REPORT

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

DATABASE_INTEGRITY_AFTER_PHYSICAL_TEST = NOT_TESTED
CROSS_STUDENT_CONTAMINATION = NOT_MEASURED
SCORE_MISMATCH_COUNT = NOT_MEASURED
INDEPENDENT_PHYSICAL_RE_GRADE_COUNT = 0
F012_PHYSICAL_CONFIRMATION = NOT_TESTED
WINDOWS_BACKUP_RESTORE = NOT_TESTED
POST_EXAM_RESTART = NOT_TESTED
WINDOWS_CSRF_SMOKE = NOT_TESTED

Chưa có database Windows acceptance hoặc 50 bài vật lý. Không truy cập/sửa các database simulation hoặc database cũ để làm bằng chứng mới. Không mặc định contamination/mismatch bằng 0 khi chưa kiểm tra.

## Kiểm chứng còn thiếu

Với đúng kỳ thi physical và 50 alias HS, ghi mapping student→attempt, submitted_at, answer count, snapshot hash, stored score và re-grade. Một attempt chỉ chốt một lần; không duplicate result/answer, không thiếu/cross-student rows hoặc finalized state không hợp lệ. Kiểm qid/position theo snapshot; đối chiếu đáp án dự kiến riêng từng HS nếu cần phát hiện mất/lẫn autosave. Không chỉ dựa PRAGMA foreign_key_check khi schema không khai foreign keys.

Re-grade dùng stored answers + snapshot scoring tại thời điểm thi; giữ đúng ALL/PARTIAL, weights, max_score và phép cộng/chia binary-float v2.3 cùng ROUND_HALF_UP. Oracle phân số lý tưởng từng gây chênh 0.01 ở tie boundaries trong validation trước; không đổi scoring để khớp oracle sai contract. Các hàm independent v2.3 trong gói tham chiếu có thể dùng sau khi có dữ liệu thật, nhưng chưa re-grade bài vật lý trong phiên này.

Trên test data, kiểm lịch sử F012 contract A bằng report BEFORE/AFTER edit bank NB→VD/nội dung qua UI: attempt snapshot, điểm và report cũ giữ nguyên dữ liệu lúc thi. Backup/restore qua workflow native nếu an toàn; không trực tiếp sửa DB hoặc trial state. Sau kỳ thi phải stop/start cùng server và đối chiếu license, dữ liệu/result/history. Smoke CSRF thật: valid browser nonce hoạt động; missing/invalid bị reject, không ghi token vào evidence.

Không bàn giao database có dữ liệu cá nhân hoặc activation secrets vào artifact public. Thu summary ẩn danh và evidence đã loại bỏ bí mật, giữ bản gốc trong môi trường nghiệm thu có kiểm soát.
