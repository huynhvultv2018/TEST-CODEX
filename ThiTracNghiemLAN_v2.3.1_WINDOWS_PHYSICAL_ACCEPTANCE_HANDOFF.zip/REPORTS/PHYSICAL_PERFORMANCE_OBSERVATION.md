# PHYSICAL PERFORMANCE OBSERVATION

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

| Thời điểm | CPU | RAM | DISK | NETWORK | SERVER RESPONSE |
|---|---|---|---|---|---|
| IDLE | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED |
| LOGIN BURST | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED |
| AUTOSAVE BURST | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED |
| SUBMIT BURST | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED | NOT_MEASURED |

Chưa có Windows server hoặc physical workload. Không dùng CPU/RAM/latency Linux hoặc các số simulation trước làm số đo physical. Không tạo ngưỡng/SLO tùy ý.

Khi đo được, ghi Windows tool/counter, server PID, UTC timestamp, phase window và đơn vị; CPU process cần nêu cách quy đổi theo số core, RAM working set/private bytes cần phân biệt, disk/network cần chỉ rõ counter/rate. Ghi latency từ browser/network tab hoặc cách đo cụ thể, không suy ra chỉ từ thời gian ra hiệu của GV. Gắn error log và các ca server/DB lock mất phản hồi kéo dài để đánh giá correctness gate.
