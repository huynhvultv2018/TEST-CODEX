# WINDOWS LAN REPORT

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

SERVER_LAN_IP = NOT_COLLECTED
SERVER_PORT = NOT_COLLECTED
BIND_ADDRESS = NOT_COLLECTED
WINDOWS_LAN_BIND = NOT_TESTED
WINDOWS_FIREWALL_READY = NOT_TESTED

Chưa có listener Windows được quan sát hoặc trình duyệt của một máy LAN khác truy cập server. Static native startup dùng host `0.0.0.0`, default port 5000 hoặc port trong settings; đây là code inspection, không phải kết quả LAN bind/firewall trên Windows.

Máy con phải dùng địa chỉ LAN thật của server, không dùng localhost/127.0.0.1. Ghi per-client connectivity và loại lỗi DNS/IP/FIREWALL/TIMEOUT/HTTP/APPLICATION. Cần so sánh listener PID/port với process acceptance, tránh test nhầm dịch vụ cũ.

Không tắt Windows Firewall. Không chạy script firewall bundled trong phiên này. Script đó có lệnh xóa rule cùng tên; hướng dẫn ưu tiên kiểm tra rule hiện có và chỉ đề xuất rule TCP inbound phù hợp port/profile/phạm vi LAN cho quản trị viên khi thật sự cần. Không sửa cấu hình Work hoặc thử truy cập mục tiêu không được cung cấp.
