# FINAL PHYSICAL ACCEPTANCE

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

FINAL_PHYSICAL_ACCEPTANCE = PENDING
REASON = WINDOWS_AND_PHYSICAL_LAN_NOT_AVAILABLE

| Gate | Kết quả |
|---|---|
| Candidate hash / CRC / source freeze | PASS |
| Uploaded reference CRC / 182 checksum entries | PASS |
| Windows clean deployment/start | NOT_TESTED |
| Initial license / app restart / repeated 5 restarts | NOT_TESTED |
| Windows machine identity / required reboot | NOT_TESTED |
| WINDOWS_LICENSE_GATE | PENDING |
| LAN bind / firewall / physical connectivity | NOT_TESTED |
| WINDOWS_RUNTIME | NOT_VERIFIED |
| PHYSICAL_CLIENTS_AVAILABLE | 0, supplied to session |
| Physical login / load / autosave / burst / monitoring / disconnect | NOT_TESTED |
| Physical 50 submit / result / independent re-grade / DB integrity | NOT_TESTED |
| Physical F012 / post-exam restart / backup-restore / security smoke | NOT_TESTED |
| PHYSICAL_50_PC_LAN | NOT_TESTED |
| Physical performance | NOT_MEASURED |

Không có failure mới được tái hiện trên Windows; không khai FAIL chỉ vì thiếu thiết bị. PENDING là thiếu bằng chứng bắt buộc. Gói hồ sơ này không hoàn tất nghiệm thu và không cho phép nâng Production.

Artifact chỉ chứa 7 REPORTS, evidence về lock/reference/capability/source freeze, hồ sơ các kết quả chưa đo và biểu mẫu/hướng dẫn cho lần có môi trường thật. Không source candidate mới, DB, license file, trial state, cookie/token, cache hoặc activation secret.

Commit riêng HANDOFF ZIP theo message yêu cầu. Branch/commit/hash/delivery verification được báo bên ngoài ZIP sau commit để tránh checksum tự tham chiếu. Không sửa báo cáo đã đóng gói để chèn commit hash.

Điều kiện tiếp tục: Windows test server, cùng R4 candidate đã hash-lock, và đủ số máy LAN vật lý; thực hiện runbook và thu evidence thật. Dừng sau bàn giao hiện tại. Không sửa source/license, tạo R5, bump version hoặc nâng Production.
