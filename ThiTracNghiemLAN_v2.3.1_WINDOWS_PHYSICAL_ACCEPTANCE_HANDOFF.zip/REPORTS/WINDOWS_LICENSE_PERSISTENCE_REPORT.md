# WINDOWS LICENSE PERSISTENCE REPORT

Thời điểm lập hồ sơ: 2026-10-02T13:16:34.619179+00:00 (UTC).

Candidate duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
BASELINE_SHA256 = `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
INPUT_LOCK = PASS; không tạo candidate mới.

Người dùng xác nhận **“không có”** môi trường Windows/LAN để cung cấp cho phiên nghiệm thu. Executor được quan sát là Linux. Không có hostname/IP hoặc kết nối Windows đã cấu hình; không thử dò tìm máy hay bypass mạng/quyền. Không khởi động ứng dụng, không chạy lại audit/HOTFIX hoặc mô phỏng LAN trong nhiệm vụ này.

Các kết quả Linux/simulation trước là dữ liệu tham chiếu, không phải bằng chứng Windows hoặc máy vật lý. `NOT_TESTED`/`NOT_VERIFIED` là chưa kiểm chứng; `NOT_MEASURED` là chưa đo. Không có lỗi sản phẩm được tái hiện trong nhiệm vụ này và cũng không có cơ sở kết luận sản phẩm PASS.

| Kiểm tra | Kết quả |
|---|---|
| LICENSE_INITIAL | NOT_TESTED |
| MACHINE_ID_HASH_BEFORE | NOT_COLLECTED |
| APP_RESTART_MACHINE_ID / APP_RESTART_LICENSE | NOT_TESTED |
| RUN 1 / RUN 2 / RUN 3 / RUN 4 / RUN 5 | NOT_TESTED |
| WINDOWS_MACHINE_ID_STABILITY | NOT_TESTED |
| WINDOWS_REBOOT_MACHINE_ID / WINDOWS_REBOOT_LICENSE | NOT_TESTED |
| WINDOWS_REBOOT_2 | NOT_TESTED |
| WINDOWS_LICENSE_GATE | PENDING |

## Contract và evidence cần có

Static read của candidate cho thấy `app.machine_id()` lấy platform.node/system/machine và native `uuid.getnode()`, SHA-256 rồi lấy 20 ký tự uppercase. Chưa thực thi cơ chế đó trên Windows. Cần so sánh fingerprint của cùng cơ chế qua các process thực, không thay getter/UUID, không hard-code hoặc monkeypatch.

License/trial có trạng thái ngoài database; restore DB không thay thế test reboot. Cần giữ nguyên thư mục, config, local trial state và system trial state; ghi license kind/active cùng teacher dashboard trước/sau mỗi lần dừng/khởi động. Không công khai activation code hoặc raw machine identifier. Không reset trial, không tạo activation giả, không sửa license DB.

Một application restart, tối thiểu 5 lần start/license/stop, và một Windows reboot thật là các bước bắt buộc. Reboot thứ hai là tùy điều kiện nhưng phải ghi NOT_TESTED khi chưa làm. Trước/sau reboot cần timestamp boot của Windows, fingerprint, license và teacher login. Nếu identity đổi hoặc license mất trên Windows, ghi FAIL ở bước thật và tái hiện; không tự sửa.

Lần trước Linux/Codex có unstable identity và native restart raw FAIL. Đó là tham chiếu về giới hạn môi trường, không là Windows FAIL và không là Windows PASS. Chưa có raw Windows output mới.
