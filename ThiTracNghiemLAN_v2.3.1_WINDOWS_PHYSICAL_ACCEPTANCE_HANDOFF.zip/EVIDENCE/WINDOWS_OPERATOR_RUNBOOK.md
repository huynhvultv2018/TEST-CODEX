# Runbook cho người vận hành Windows/LAN thật

**CHƯA THỰC HIỆN.** Các lệnh dưới đây là hướng dẫn, không là output Windows. Chỉ chạy trên máy nghiệm thu và dữ liệu test. Không thay source/scoring/CSRF/license/getter, không reset trial, không chạy audit/HOTFIX lại hoặc tạo candidate mới.

## 1. Lock và deployment

Trên Windows thật, dùng `Get-FileHash -Algorithm SHA256` kiểm R4 ZIP phải bằng `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Mismatch thì BLOCKED/BASELINE_MISMATCH và dừng.

Ghi Get-CimInstance Win32_OperatingSystem (Caption, Version, OSArchitecture, LastBootUpTime), Win32_Processor (Name) và Win32_ComputerSystem (Name, TotalPhysicalMemory), phiên bản Python và IP LAN/port thực. Không ghi Windows key, registered owner, password hoặc activation code. Dùng alias máy con thay dữ liệu người dùng.

Extract nguyên ZIP vào thư mục sạch chưa có deployment khác. Venv/dependency cache đặt ngoài source; cài requirements của `PHAN_MEM/requirements.txt` bằng Python tương thích qua cơ chế pip/TLS mặc định. Không disable TLS/checksum/signature hoặc sửa requirements. Ghi chính xác Python/Flask/Waitress/openpyxl/cryptography versions đã dùng; source package không có EXE, đừng dùng launcher yêu cầu EXE như bằng chứng source đã start.

Từ thư mục `PHAN_MEM`, chạy Python native `app.py`, không app.run/debug/testclient/custom WSGI để thay thế startup. Khi ghi log stdout, loại dòng account bootstrap/password trước khi đưa vào handoff. DB native nằm `PHAN_MEM/thi_trac_nghiem.db` khi chạy source; uploads/imports/exports/backups/logs bên cạnh source. Chứng minh UI vận hành, writes đúng chỗ và không có app dependency lẩn từ workspace cũ. Chỉ start/license lần đầu theo policy native, không xóa trial state cũ trong Windows profile.

## 2. Fingerprint và license

Thu fingerprint trước/sau theo đúng `machine_id()` của R4. Có thể đọc source nguyên vẹn, lấy riêng function AST và chạy với stdlib native; không import app vì import có side effects. Ví dụ Python **chỉ đọc**, chạy bằng cùng interpreter trên Windows:

```python
import ast, hashlib, pathlib, platform, uuid, zipfile
assert platform.system() == 'Windows', 'This is not a Windows observation'
candidate = pathlib.Path(r'C:\ACCEPTANCE_INPUT\ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip')
app_path = pathlib.Path(r'C:\ACCEPTANCE_DEPLOYMENT\PHAN_MEM\app.py')
assert hashlib.sha256(candidate.read_bytes()).hexdigest() == '68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2'
with zipfile.ZipFile(candidate) as z:
    expected_source = z.read('PHAN_MEM/app.py')
source = app_path.read_bytes()
assert source == expected_source
tree = ast.parse(source.decode('utf-8'))
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'machine_id')
namespace = {'platform': platform, 'uuid': uuid, 'hashlib': hashlib}
exec(compile(ast.Module(body=[fn], type_ignores=[]), str(app_path), 'exec'), namespace)
print('MACHINE_ID_HASH =', hashlib.sha256(namespace['machine_id']().encode('utf-8')).hexdigest())
```

Đổi **đường dẫn input**, không đổi getter/body hay baseline/hash. Đây là observation từ một process native riêng; cần đối chiếu với machine identity app hiển thị trong UI, hash cùng cách, để chứng minh app/server thực dùng cùng identity. Không công khai raw ID hoặc activation UI. Lưu SHA-256 fingerprint, timestamp, phase và boot timestamp; chỉ ghi license kind/active cùng kết quả teacher login/dashboard, không code/owner.

Thực hiện initial rồi application restart: stop đúng PID do acceptance start, chờ process và listener đóng hoàn toàn, start lại từ cùng folder/interpreter/config. Không dừng dịch vụ khác. Lặp thêm 5 start/license/stop và ghi từng run. Chỉ PASS ổn định khi fingerprint và license/dashboard đúng ở mọi run.

Ghi trước reboot; operator reboot **máy Windows nghiệm thu**, không host Production. Sau boot mở lại cùng folder, không restore/reset license/trial/config, thu boot timestamp mới, fingerprint, license và teacher login. Reboot thứ hai nếu có thể; nếu chưa làm ghi NOT_TESTED. Identity đổi/license mất: ghi bước FAIL, thu logs và tái hiện; không sửa/bypass.

## 3. LAN và firewall

Ghi `Get-NetTCPConnection -State Listen -LocalPort <actual_port>` cùng PID, local address và native process. Static 0.0.0.0 không đủ: browser ở một máy vật lý khác phải truy cập `http://<actual_windows_lan_ip>:<actual_port>`.

Kiểm profile/rules Windows Firewall hiện có, không tắt firewall hoặc chạy script xóa rule. Nếu cần rule mới, ghi đề xuất TCP inbound đúng port/profile và phạm vi subnet acceptance để admin áp dụng có kiểm soát; không áp dụng trong Work. Ghi connectivity mọi client và phân loại DNS/IP/FIREWALL/TIMEOUT/HTTP/APPLICATION.

## 4. Inventory và kỳ thi thực

Đếm thiết bị thật, ghi alias, browser/version, xác nhận có operator/HS ngồi ở máy; 50 hàng biểu mẫu chưa phải inventory. Chuẩn bị tài khoản HS TEST riêng từng máy và exam TEST 20–40 câu đủ 5 loại/matrix phù hợp. Dùng form/UI native và nonce thật, không chèn DB/SQL/config hay hard-code token. Không chia sẻ account/cookie giữa máy.

Gắn alias student→client→attempt, timestamp và snapshot hash ở hệ thống bằng mapping riêng kín; evidence public chỉ alias. GV ra hiệu 50 login, mở exam, kiểm tên/đề và render MathJax/hình/5 loại. Sau từng thay đổi đáp án, xác nhận autosave thật và tính nhất quán; cho cả phòng burst thay câu gần đồng thời. Ghi server log/error/HTTP thật, không bắt buộc đồng bộ millisecond.

Chọn ít nhất 5 máy đã save, ngắt mạng ngắn rồi reconnect/reload/resume; xác nhận cùng HS/attempt/đáp án đã lưu, các máy khác vẫn autosave. Teacher dùng monitoring read-only trong thời gian này. GV ra hiệu 50 HS tự submit qua browser gần đồng thời; ghi success/failure và result của từng máy. N<50 thì ghi gate N riêng, 50 luôn NOT_TESTED.

## 5. Data/score audit chỉ đọc

Sau physical submit, dùng đúng DB test từ Windows/đúng exam ID vừa thi, không dùng DB simulation. Cho app quiescent, chọn read-only SQLite URI `Path(db_path).resolve().as_uri() + '?mode=ro'`, `sqlite3.connect(..., uri=True)` và `PRAGMA query_only=ON`; không import app/db helpers vì helper có thể thay journal mode. Không dùng `immutable=1` trên active WAL, không copy mỗi main .db thiếu WAL. Backup native có thể làm snapshot nhất quán qua workflow test.

Chạy `PRAGMA integrity_check`, `PRAGMA foreign_key_check`. Đếm orphan `bai_thi→ky_thi/hoc_sinh`, `cau_tra_loi→bai_thi`; duplicate `(ky_thi_id,ma_hs)` và `(bai_thi_id,vi_tri_cau)`; kiểm submitted_at/tong_so_cau/diem hợp lệ, đầy đủ answer count và position/qid đúng snapshot. PRAGMA FK rỗng không thay thế kiểm orphan vì schema có thể không khai foreign keys.

Đối chiếu 50 student/attempt alias với inventory và những đáp án TEST dự kiến trước submit để phát hiện mất/lẫn dữ liệu. Re-grade **stored answers với stored snapshot**, giữ phép tính float v2.3 ALL/PARTIAL/weights/points/max_score và Decimal(str(total)).ROUND_HALF_UP. Không sửa test để dùng rational oracle gây 0.01 tie difference hoặc đổi scoring để làm PASS. Các oracle độc lập có trong FINAL_RELEASE_VALIDATION_HANDOFF dưới `EVIDENCE/FINAL_RELEASE_EVIDENCE/reproduction-harnesses/`; verifier cần đọc integer SQLite affinity cũng như JSON text đúng policy. Ghi 50 comparison rows thật và mismatch thực; chưa chạy thì NOT_MEASURED. Không lưu DB, học sinh thật, session token hoặc activation vào public handoff.

## 6. Sau kỳ thi và security

Stop/start cùng server, đối chiếu license/exam/result/history và DB logical summaries trước/sau. F012 contract A: lưu historical report trước, edit câu TEST trong bank NB→VD/nội dung qua UI, mở lại report cũ; nội dung/lịch sử/điểm attempt không thay. Thu output BEFORE/AFTER đã ẩn danh.

Tạo backup bằng workflow native, xác nhận tồn tại, restore chỉ trên dữ liệu TEST nếu an toàn; kiểm app/license/result. Không reset trial hoặc restore dữ liệu quan trọng. Smoke Windows CSRF từ browser/session thật: valid teacher action/valid student autosave-submit hoạt động, missing/invalid nonce 403 và không mutation. Chỉ lưu status/timestamp/alias; loại cookies/token khỏi HAR/screenshot/log.

Quan sát Windows server PID CPU/RAM/disk/network/response theo 4 phase idle/login/autosave/submit, ghi tool/unit/timestamp; mục không đo được NOT_MEASURED. Không tạo SLO tùy ý hoặc lấy số Linux thay physical.

## 7. Kết luận

Thu minimum evidence cho 31 scenarios, restart/reboot và từng client. Các template CSV phải điền số thực và gắn nguồn, không thay NOT_TESTED thành PASS hàng loạt. Windows gate chỉ PASS khi clean start/identity/license/application restart/5 runs/Windows reboot/LAN và workflow có bằng chứng. Physical 50 gate chỉ PASS khi đủ 50 thiết bị, tất cả workflow submit/integrity/score consistency và không có release-blocking 500/DB lock. Thiếu evidence PENDING; lỗi thật FAIL với reproduction. Không nâng Production tự động.
