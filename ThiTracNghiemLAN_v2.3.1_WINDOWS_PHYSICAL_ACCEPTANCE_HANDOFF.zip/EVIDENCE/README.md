# Phân loại bằng chứng

`baseline-lock.json`, `reference-verification.json`, `execution-environment.json`, `source-freeze.json` và `user-access-confirmation.json` ghi các quan sát thật trong Work. Chúng không chứng minh ứng dụng chạy trên Windows.

`reference-final-release-gate.txt` là bản sao nguyên văn kết luận lần trước: simulation PASS, Windows/physical chưa verify và tổng thể PENDING. Không tái sử dụng số liệu simulation thành số liệu physical.

`windows-environment-record.json`, `windows-restart-results.json`, `physical-test-results.json`, `physical-database-integrity.json` và `physical-resource-observations.json` ghi **thiếu evidence** bằng null/NOT_TESTED/NOT_MEASURED. Không có server log, error log, reboot evidence, physical submission hoặc database thực tế được cung cấp; không tạo log giả hay screenshot giả.

`TEMPLATES/` chỉ là biểu mẫu tương lai. 50 nhãn CLIENT_01…CLIENT_50 không phải 50 máy đã đếm, 50 phiên đã tạo hoặc 50 bài đã nộp. Cần điền từ quan sát thực tế và gắn evidence riêng trước khi kết luận PASS.

`WINDOWS_OPERATOR_RUNBOOK.md` là hướng dẫn chưa được chạy trên Windows trong phiên này. Không dùng hướng dẫn hoặc biểu mẫu làm kết quả kiểm thử.

Không lưu password, activation key, cookie, CSRF nonce, client token, session secret, private key hoặc database có dữ liệu học sinh. Dùng tài khoản test và alias ẩn danh khi thu evidence sau này; giữ ảnh/log đầy đủ trong vùng kiểm soát, chỉ bàn giao bản đã loại bỏ các giá trị nhạy cảm.
