const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=__dirname;
const read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const p2=read('REGRESSION/PHASE2/ENGINES/results.json'),p3=read('REGRESSION/PHASE3/ENGINES/results.json'),iso=read('REGRESSION/ISOLATION/profile-isolation.json');
assert.deepEqual(p3.real,p2.real);assert.deepEqual(p3.visual,p2.visual);assert.deepEqual(p3.assertions,p2.assertions);
for(const r of [p2,p3]){
 assert.equal(r.real.length,5);assert.equal(r.visual.length,44);assert.equal(r.assertions.length,15);
 assert.deepEqual(r.errors,[]);assert.deepEqual(r.external,[]);
 assert.equal(r.visual.filter(s=>s.overflow||s.horizontal).length,0);
 assert.equal(r.real.flatMap(x=>x.states).filter(s=>s.overflow||s.horizontal).length,0);
 assert(r.real.every(x=>x.lessonUnchanged));
}
assert.equal(iso.algebraProfileIsolation,'PASS');assert.equal(iso.informaticsProfileIsolation,'PASS');assert.equal(iso.legacyOptionalMetadata,'PASS');assert.equal(iso.demoMatch,true);assert.equal(iso.cases.length,14);assert(iso.cases.every(c=>c.result==='PASS'));assert.deepEqual(iso.errors,[]);
const result={result:'PASS',freshRun:true,browser:p3.browser,legacyRuntimeRegression:'PASS',algebraProfileIsolation:'PASS',informaticsProfileIsolation:'PASS',pairedRealPackages:p3.real.map(r=>({package:r.package,screens:r.screens,states:r.states.length})),realScreensPerRuntime:p3.real.reduce((n,r)=>n+r.screens,0),realStatesPerRuntime:p3.real.reduce((n,r)=>n+r.states.length,0),demoScreens:iso.demoScreens,demoStates:iso.demoStates,pairedMetricsPerRuntime:p3.visual.length,assertionsPerRuntime:p3.assertions.length,isolationAndNegativeCases:iso.cases.length,zeroOverflow:true,zeroExceptions:true,zeroExternalRequests:true,lessonSourcesUnchanged:true,scope:'Real original packages + Demo are paired with Phase2; interface/negative isolation fixtures are regression probes, not real pedagogical lesson evidence. Windows/audio acceptance UNRUN.'};
fs.writeFileSync(path.join(root,'REGRESSION_SUMMARY.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
