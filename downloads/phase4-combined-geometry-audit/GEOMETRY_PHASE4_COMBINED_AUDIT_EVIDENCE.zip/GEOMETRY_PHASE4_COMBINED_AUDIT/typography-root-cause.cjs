const {chromium}=require('playwright'),fs=require('fs'),assert=require('assert/strict');let b;
(async()=>{
 b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});const ctx=await b.newContext({viewport:{width:1366,height:768}}),errors=[],cases=[];ctx.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
 const t=await ctx.newPage();await t.goto('http://127.0.0.1:8773/WEB_LIVE/teacher.html');await t.locator('#zipfile').setInputFiles('/workspace/g4-f01-fixture-revalidation/HINH8_VD2_GEOMETRY_PROFILE_TEST_G4F01_PATCHED.zip');await t.waitForFunction(()=>lesson?.subject_engine==='geometry');const pending=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await pending;await tv.waitForLoadState();
 const settle=async()=>{const v=await t.evaluate(()=>stateVersion);await tv.waitForFunction(v=>lastState?.stateVersion>=v,v);await tv.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));};
 for(const size of [[1920,1080],[3840,2160]]){
  await tv.setViewportSize({width:size[0],height:size[1]});
  for(const index of [5,7,9]){
   await t.locator('#jump').selectOption(String(index));await settle();
   if(index===7)for(let k=0;k<4;k++)await t.locator('#analysisBtn').click();
   if(index===9)for(let k=0;k<2;k++)await t.locator('button[onclick="revealStep()"]').click();await settle();
   const result=await tv.evaluate(()=>{
    const matching=n=>{
     const matches=[];
     function scan(rules,url,active=true){for(const r of rules){let a=active;if(r.conditionText&&r.constructor.name==='CSSMediaRule')a=a&&matchMedia(r.conditionText).matches;if(r.cssRules?.length)scan(r.cssRules,url,a);if(a&&r.selectorText&&(r.style?.fontSize||r.style?.getPropertyValue('--tv-main-size'))){try{if(n.matches(r.selectorText))matches.push({url,selector:r.selectorText,fontSize:r.style.fontSize,tvMainSize:r.style.getPropertyValue('--tv-main-size'),important:r.style.getPropertyPriority('font-size')});}catch(_){}}}}
     for(const s of document.styleSheets)scan(s.cssRules,s.href);return matches;
    };
    const pane=document.querySelector('.textPane');return{index:lastState.index,viewport:{width:innerWidth,height:innerHeight,dpr:devicePixelRatio},overflow:pane.scrollHeight>pane.clientHeight+2,fonts:[...document.querySelectorAll('.geometryStatementText,#answer .focusBlock,#analysis .focusBlock')].filter(n=>n.getClientRects().length&&getComputedStyle(n).display!=='none').map(n=>({text:n.innerText,computedFontPx:parseFloat(getComputedStyle(n).fontSize),ancestors:Array.from((function*(){let a=n;for(let i=0;a&&i<6;i++,a=a.parentElement)yield a;})()).map(a=>({tag:a.tagName,id:a.id,className:a.className,computedFont:getComputedStyle(a).fontSize,inlineFont:a.style.fontSize,matchedFontDeclarations:matching(a)}))}))};
   });cases.push(result);
  }
 }
 assert.equal(cases.length,6);assert.deepEqual(errors,[]);
 const result={result:'COMPLETE',browser:b.version(),sourceScope:'Existing G4-F01 auxiliary fixture; not uploaded Tiết09/10 real files',newRealFileTest:'UNRUN_INPUT_TRANSFER_BLOCKED',physicalTV:'UNRUN',cases,errors};fs.writeFileSync(__dirname+'/TYPOGRAPHY_ROOT_CAUSE.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({cases:cases.length,fonts4K:cases.filter(c=>c.viewport.width===3840).flatMap(c=>c.fonts.map(f=>f.computedFontPx)),errors}));await b.close();
})().catch(async e=>{console.error(e);await b?.close();process.exitCode=1});
