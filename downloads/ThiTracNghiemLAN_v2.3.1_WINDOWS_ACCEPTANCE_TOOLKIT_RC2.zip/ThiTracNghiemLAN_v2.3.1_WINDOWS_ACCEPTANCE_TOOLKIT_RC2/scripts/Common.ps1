﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:Root = Split-Path $PSScriptRoot -Parent
$script:Results = Join-Path $script:Root 'RESULTS'
$script:Expected = '68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2'
function Initialize-Results {
    New-Item -ItemType Directory -Path $script:Results -Force | Out-Null
}
function Read-Choice([string]$Prompt,[string[]]$Choices) {
    do { $v = (Read-Host "$Prompt [$($Choices -join '/')]").Trim().ToUpperInvariant() } until ($Choices -contains $v)
    return $v
}
function Read-Number([string]$Prompt,[int]$Min=0,[int]$Max=100000) {
    do { $v = Read-Host $Prompt; $n = 0; $ok = [int]::TryParse($v,[ref]$n) -and $n -ge $Min -and $n -le $Max } until ($ok)
    return $n
}
function Get-Baseline([string]$Path) {
    $found = Test-Path -LiteralPath $Path -PathType Leaf
    $actual = 'MISSING'
    if ($found) { $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
    return [pscustomobject]@{ Found=$found; Actual=$actual; Match=($actual -eq $script:Expected); Expected=$script:Expected }
}
function Require-Baseline {
    $default = Join-Path $script:Root 'ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip'
    Write-Host 'Chọn R4 CANDIDATE.zip, không chọn HANDOFF.zip; không giải nén candidate để kiểm SHA.'
    $p = Read-Host 'Kéo tệp candidate ZIP vào đây rồi Enter (Enter để dùng ZIP cạnh toolkit)'
    if ([string]::IsNullOrWhiteSpace($p)) { $p=$default } else { $p=$p.Trim().Trim('"') }
    $b = Get-Baseline $p
    return [pscustomobject]@{ Path=$p; Found=$b.Found; Actual=$b.Actual; Match=$b.Match; Expected=$b.Expected }
}
function Write-Report([string]$Name,[object[]]$Lines) {
    $text = @(('TIMESTAMP = '+(Get-Date).ToString('o')),('COMPUTER_NAME = '+[Environment]::MachineName)) + $Lines
    $text | Set-Content -LiteralPath (Join-Path $script:Results $Name) -Encoding UTF8
    $text | ForEach-Object { Write-Host $_ }
}
function Get-LanAddresses {
    return @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
        $_.IPAddress -ne '127.0.0.1' -and $_.IPAddress -notlike '169.254.*' -and $_.AddressState -eq 'Preferred'
    } | Sort-Object InterfaceIndex,IPAddress)
}
function Get-HttpResult([string]$Url) {
    # Read headers only; do not collect response bodies, cookies, credentials or redirects.
    $response=$null
    try {
        $req=[System.Net.HttpWebRequest]::Create($Url)
        $req.Timeout=5000; $req.ReadWriteTimeout=5000; $req.AllowAutoRedirect=$false; $req.Proxy=$null
        $response=$req.GetResponse()
        $status=[int]$response.StatusCode
        return "HTTP_STATUS = $status; HTTP_ACCESS = PASS"
    } catch [System.Net.WebException] {
        $response=$_.Exception.Response
        if ($null -ne $response) {
            $status=[int]$response.StatusCode
            return "HTTP_STATUS = $status; HTTP_ACCESS = FAIL; SERVER_RESPONDED = TRUE"
        }
        return 'HTTP_ACCESS = FAIL; HTTP_STATUS = UNAVAILABLE'
    } finally { if ($null -ne $response) { $response.Close() } }
}
function Get-Identity {
    $appHash='UNAVAILABLE'; $source='UNCONFIRMED'; $guidHash='UNAVAILABLE'; $nodeSource='UNAVAILABLE'
    try {
        $guid=(Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
        $sha=[System.Security.Cryptography.SHA256]::Create()
        try { $guidHash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($guid)))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
    } catch { }
    # Do not import app.py, read license files, activate or reset anything.
    $helper=Join-Path $PSScriptRoot 'Identity.py'
    try {
        if (Get-Command py.exe -ErrorAction SilentlyContinue) { $value=& py.exe -3 $helper 2>$null }
        elseif (Get-Command python.exe -ErrorAction SilentlyContinue) { $value=& python.exe $helper 2>$null }
        else { $value='' }
        $parts=@($value)
        if ($LASTEXITCODE -eq 0 -and $parts.Count -eq 2 -and $parts[0] -match '^[a-f0-9]{64}$') {
            $appHash=$parts[0]; $nodeSource=$parts[1]; $source='CONFIRMED_R4_SOURCE_ALGORITHM; RUNTIME_EQUIVALENCE_UNCONFIRMED'
        }
    } catch { }
    return [pscustomobject]@{ AppHash=$appHash; Source=$source; GuidHash=$guidHash; NodeSource=$nodeSource }
}
function Save-LicenseRow([object]$Row) {
    $p=Join-Path $script:Results '02_LICENSE_RESTART.csv'
    if (Test-Path -LiteralPath $p) { $Row | Export-Csv -LiteralPath $p -NoTypeInformation -Encoding UTF8 -Append }
    else { $Row | Export-Csv -LiteralPath $p -NoTypeInformation -Encoding UTF8 }
}
function Get-RoomVerdict([int]$Count,[int]$LoginOK,[int]$LoginFail,[int]$SubmitOK,[int]$SubmitFail,[string[]]$Errors) {
    if ($Count -lt 50) { return 'NOT_TESTED' }
    if ($LoginOK -ne $Count -or $LoginFail -ne 0 -or $SubmitOK -ne $Count -or $SubmitFail -ne 0 -or $Errors -contains 'Y') { return 'FAIL' }
    return 'EVIDENCE_RECORDED_REVIEW_REQUIRED'
}
function Package-Results {
    $files=@(Get-ChildItem -LiteralPath $script:Results -File -Recurse -Force)
    if ($files.Count -eq 0) { throw 'RESULTS chưa có evidence. Hãy chạy các bước kiểm tra trước.' }
    $dest=Join-Path $script:Root ('ThiTracNghiemLAN_v2.3.1_WINDOWS_ACCEPTANCE_RESULTS_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')+'.zip')
    # ZipFile includes hidden evidence; ZIP stays outside RESULTS to avoid recursion.
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($script:Results,$dest)
    $hash=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $([IO.Path]::GetFileName($dest))" | Set-Content -LiteralPath ($dest+'.sha256') -Encoding ASCII
    return [pscustomobject]@{ Path=$dest; Hash=$hash; Count=$files.Count }
}
