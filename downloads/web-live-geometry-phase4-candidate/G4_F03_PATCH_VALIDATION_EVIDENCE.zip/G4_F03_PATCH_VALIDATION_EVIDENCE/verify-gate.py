from pathlib import Path
import hashlib
import json
import zipfile

audit = Path(__file__).resolve().parent
source = Path('/workspace/TEST-CODEX/WEB_LIVE_GEOMETRY_PHASE3_CANDIDATE')
working = audit / 'working/WEB_LIVE_GEOMETRY_PHASE4_WORKING_COPY'
approved_zip = Path('/workspace/output/web-live-geometry-phase3/WEB_LIVE_GEOMETRY_PHASE3_CANDIDATE.zip')
approved_sha = '8817889abb9e98e9e3c60e191be510215e02030d309c2aacaaad1e1f663dd23c'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def manifest(root):
    assert not any(f.is_symlink() for f in root.rglob('*'))
    return {f.relative_to(root).as_posix(): sha(f.read_bytes()) for f in sorted(root.rglob('*')) if f.is_file()}

def read(name):
    return json.loads((audit / name).read_text())

before = read('SOURCE_MANIFEST_BEFORE.json')
after = manifest(source)
patched = manifest(working)
assert sha(approved_zip.read_bytes()) == approved_sha
with zipfile.ZipFile(approved_zip) as archive:
    assert archive.testzip() is None
    approved = {n.split('/', 1)[1]: sha(archive.read(n)) for n in archive.namelist() if not n.endswith('/')}
assert before == after == approved
assert len(before) == len(patched) == 1227
assert before.keys() == patched.keys()
changed = [n for n in before if before[n] != patched[n]]
assert changed == ['WEB_LIVE/geometry-profile.css']
expected = (source / changed[0]).read_bytes().replace(
    b'.geometryProfile[data-geometry-answer-mode="steps"] #answer .proofStep.previous:not(.isFocused){display:none}',
    b'.geometryProfile[data-geometry-answer-mode="steps"] #answer .proofStep.previous:not(.isFocused){opacity:.75}'
).replace(
    b'.geometryProfile[data-geometry-focus-region="answer"] #answer .focusBlock:not(.isFocused){display:none}',
    b'.geometryProfile[data-geometry-focus-region="answer"] #answer .focusBlock:not(.isFocused){opacity:.52}'
)
assert (working / changed[0]).read_bytes() == expected
target = read('G4_F03_TARGETED.json')
assert target['result'] == 'PASS' and target['originalFailureReproduced'] and target['patchPass']
assert not target['errors'] and not target['coreModified']
geometry = read('GEOMETRY_RUNTIME/geometry-runtime.json')
assert len(geometry['checks']) == 14 and all(c['result'] == 'PASS' for c in geometry['checks'])
assert not geometry['errors'] and geometry['sourceUnchanged']
classroom = read('CLASSROOM_VALIDATION.json')
failures = [c for c in classroom['checks'] if c['result'] != 'PASS']
deferred = {'name': 'Same-figure navigation preserves zoom', 'result': 'FAIL', 'evidence': {'before': 1.15, 'after': 1, 'from': 9, 'to': 10}}
prior = json.loads(Path('/workspace/phase4-geometry-combined-audit/CLASSROOM_VALIDATION.json').read_text())
assert failures == [deferred]
assert deferred in prior['checks']
same = next(x for x in classroom['stateTests'] if x['test'] == 'same-figure-navigation')
assert same['figurePreserved'] and same['annotationPreserved'] and not same['zoomPreserved']
assert len(classroom['checks']) == 16 and not classroom['errors'] and classroom['sourceLessonUnchanged']
assert next(x for x in classroom['checks'] if x['name'] == 'Focus retains all previously disclosed proof context')['result'] == 'PASS'
tv = read('WHOLE_LESSON_TV.json')
assert tv['states'] == 140 and not tv['overflowCases'] and not tv['errors']
regression = read('REGRESSION_SUMMARY.json')
assert regression['result'] == 'PASS' and regression['freshRun']
for key in ['legacyRuntimeRegression', 'algebraProfileIsolation', 'informaticsProfileIsolation']:
    assert regression[key] == 'PASS'
f01 = read('TARGETED_G4F01.json')
assert f01['result'] == 'PASS' and not f01['errors']
fixture = Path('/workspace/g4-f01-fixture-revalidation/HINH8_VD2_GEOMETRY_PROFILE_TEST_G4F01_PATCHED.zip')
assert sha(fixture.read_bytes()) == '4488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8'
assert sha((source / 'GEOMETRY_PHASE3_TEST_PACKAGES/HINH8_VD2_GEOMETRY_PROFILE_TEST.zip').read_bytes()) == 'b502802ab694aa4ee2cc57bb7e053a06fd534580d8d7285f8a55d91428945bd7'
gate = {
    'result': 'PASS', 'gate': 'Approved G4-F03-only technical scope, not real classroom acceptance',
    'phase3SHA256Before': approved_sha, 'phase3SHA256After': sha(approved_zip.read_bytes()),
    'phase3CandidateMutated': False, 'sourceFiles': len(before), 'unchangedWorkingFiles': len(before) - len(changed),
    'changedFiles': changed, 'webLiveCoreModified': False, 'sourceScopeViolation': False, 'productionModified': False,
    'targetedG4F03': 'PASS', 'geometryFocus': 'PASS', 'geometryRuntimeChecksPass': len(geometry['checks']),
    'classroomAuxiliaryChecksPass': 15, 'classroomAuxiliaryRawFailures': failures,
    'acceptedExistingDeferral': 'G4-F02 identical prior zoom reset; Core unchanged; figure/annotation retained',
    'wholeLessonTVStates': tv['states'], 'wholeLessonTVOverflow': 0,
    'legacyRuntimeRegression': 'PASS', 'algebraProfileIsolation': 'PASS', 'informaticsProfileIsolation': 'PASS',
    'g4F01SupplementalRegression': 'PASS (no further fixture patch)',
    'realFileValidation': 'NOT_RUN_BY_GV_DECISION', 'realClassroomTrial': 'UNRUN',
    'remainingDeferredFindings': ['G4-F02', 'G4-F04'], 'remainingValidationPending': ['G4-F05']
}
for name, data in [('SOURCE_MANIFEST_AFTER.json', after), ('PHASE4_PAYLOAD_MANIFEST.json', patched), ('PREPACKAGE_GATE.json', gate)]:
    (audit / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(gate, ensure_ascii=False))
