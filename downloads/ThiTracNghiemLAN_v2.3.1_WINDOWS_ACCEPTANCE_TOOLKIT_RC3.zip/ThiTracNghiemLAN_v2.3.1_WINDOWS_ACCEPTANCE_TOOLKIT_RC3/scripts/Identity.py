# Read-only replica of PHAN_MEM/app.py machine_id(), without importing app.
import hashlib, platform, uuid
raw = f"{platform.node()}|{platform.system()}|{platform.machine()}|{uuid.getnode()}"
mid = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20].upper()
print(hashlib.sha256(mid.encode("utf-8")).hexdigest())
print("RANDOM_OR_MULTICAST_NODE" if uuid.getnode() & (1 << 40) else "HARDWARE_NODE")
