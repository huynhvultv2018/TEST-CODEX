﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][ValidateRange(1,6)][int]$Task)
. (Join-Path $PSScriptRoot 'Common.ps1')
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Toolkit này cần Windows và Windows PowerShell 5.1.' }
    Initialize-Results
    switch ($Task) {
        1 {
            $os=Get-CimInstance Win32_OperatingSystem
            $cpu=@(Get-CimInstance Win32_Processor)
            $cs=Get-CimInstance Win32_ComputerSystem
            $python='NOT_INSTALLED (không bắt buộc cho toolkit)'
            if (Get-Command py.exe -ErrorAction SilentlyContinue) { $python=(& py.exe -3 --version 2>&1 | Out-String).Trim() }
            elseif (Get-Command python.exe -ErrorAction SilentlyContinue) { $python=(& python.exe --version 2>&1 | Out-String).Trim() }
            $b=Require-Baseline
            if ($b.Match) { & (Join-Path $PSScriptRoot 'SelfTest.ps1') -CandidatePath $b.Path }
            $lines=@('[PASS] Đã nhận diện Windows',"WINDOWS = $($os.Caption); VERSION = $($os.Version)","CPU = $(($cpu.Name) -join '; ')","RAM_GB = $([Math]::Round($cs.TotalPhysicalMemory/1GB,2))","ARCHITECTURE = $($os.OSArchitecture)","POWERSHELL = $($PSVersionTable.PSVersion)","PYTHON = $python","CANDIDATE_EXISTS = $($b.Found)","CANDIDATE_SHA256 = $($b.Actual)","R4_EXPECTED_SHA256 = $($b.Expected)","BASELINE_MATCH = $($b.Match.ToString().ToUpperInvariant())")
            foreach ($ip in (Get-LanAddresses)) { $lines+="IPv4 = $($ip.IPAddress); INTERFACE = $($ip.InterfaceAlias)" }
            if ($b.Match) { $lines+='[PASS] SHA-256 đúng R4 Candidate' }
            else { $lines+='[FAIL] SAI R4 CANDIDATE — DỪNG NGHIỆM THU.' }
            Write-Report '01_PRECHECK.txt' $lines
            if (-not $b.Match) { exit 2 }
        }
        2 {
            $b=Require-Baseline
            if (-not $b.Match) { Write-Report '02_BASELINE_FAILURE.txt' @('BASELINE_MATCH = FALSE','SAI R4 CANDIDATE — DỪNG NGHIỆM THU.'); exit 2 }
            Write-Host 'Chỉ nhìn tình trạng license trên ứng dụng. Không nhập mã kích hoạt, mật khẩu hoặc thông tin bí mật.'
            $phase=Read-LicenseObservation
            $observation=Read-Choice 'License còn đúng và hợp lệ? PASS / FAIL / UNKNOWN' @('PASS','FAIL','UNKNOWN')
            $id=Get-Identity
            $boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime
            Save-LicenseRow ([pscustomobject][ordered]@{
                TIMESTAMP=(Get-Date).ToString('o'); WINDOWS_BOOT_TIME=$boot.ToString('o'); COMPUTER_NAME=[Environment]::MachineName
                MACHINE_ID_HASH=$id.AppHash; APP_MACHINE_ID_SOURCE=$id.Source; WINDOWS_MACHINEGUID_HASH=$id.GuidHash; UUID_NODE_SOURCE=$id.NodeSource
                LICENSE_OBSERVATION=$observation; NOTE=$phase; BASELINE_MATCH='TRUE'; CANDIDATE_SHA256=$b.Actual
            })
            Write-Host '[PASS] Đã nối thêm một dòng vào RESULTS\02_LICENSE_RESTART.csv.'
            Write-Host "APP_MACHINE_ID_SOURCE = $($id.Source)"
            if ($id.NodeSource -eq 'RANDOM_OR_MULTICAST_NODE') { Write-Host '[CẢNH BÁO] Nguồn uuid.getnode có bit multicast/random. Không kết luận ID ổn định giữa các lần mở; toolkit không sửa nguồn identity.' }
            Write-Host 'Nếu MACHINE_ID_HASH không lấy được, chỉ dùng MachineGuid HASH để đối chiếu Windows; đây không phải ID ứng dụng.'
        }
        3 {
            $b=Require-Baseline
            if (-not $b.Match) { Write-Report '03_BASELINE_FAILURE.txt' @('BASELINE_MATCH = FALSE','SAI R4 CANDIDATE — DỪNG NGHIỆM THU.'); exit 2 }
            $port=Read-Number 'Nhập PORT máy chủ (ví dụ 5000)' 1 65535
            $lines=@("PORT = $port",'BASELINE_MATCH = TRUE')
            try {
                $listeners=@(Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction Stop)
                foreach ($l in $listeners) { $lines+="LISTEN_ADDRESS = $($l.LocalAddress); PID = $($l.OwningProcess)" }
                if (@($listeners | Where-Object { $_.LocalAddress -ne '127.0.0.1' -and $_.LocalAddress -ne '::1' }).Count -gt 0) { $lines+='LAN_BINDING = PRESENT; REMOTE_ACCESS_NOT_YET_CONFIRMED' }
                else { $lines+='LAN_BINDING = LOOPBACK_ONLY; Hãy kiểm tra cấu hình bind ứng dụng.' }
            } catch { $lines+='LISTENING_PORT = NOT_FOUND_OR_UNREADABLE' }
            $ips=Get-LanAddresses
            if ($ips.Count -eq 0) { $lines+='IPv4_LAN = NOT_FOUND' }
            foreach ($ip in $ips) {
                $url="http://$($ip.IPAddress):$port/"
                $lines+="IP MÁY CHỦ = $($ip.IPAddress); CARD = $($ip.InterfaceAlias)"
                $lines+="ĐỊA CHỈ MÁY CON CẦN MỞ = $url"
                $lines+="$url : $(Get-HttpResult $url)"
            }
            $lines+="LOOPBACK : $(Get-HttpResult ('http://127.0.0.1:'+ $port + '/'))"
            try { foreach ($profile in (Get-NetFirewallProfile)) { $lines+="FIREWALL_PROFILE = $($profile.Name); ENABLED = $($profile.Enabled); INBOUND_DEFAULT = $($profile.DefaultInboundAction)" } }
            catch { $lines+='FIREWALL_STATE = UNKNOWN (có thể thiếu quyền đọc)' }
            try { foreach ($profile in (Get-NetConnectionProfile)) { $lines+="ACTIVE_NETWORK = $($profile.InterfaceAlias); CATEGORY = $($profile.NetworkCategory)" } } catch { $lines+='ACTIVE_NETWORK = UNKNOWN' }
            $lines+='FIREWALL_BLOCK_STATUS = UNCONFIRMED; chỉ kiểm tra từ máy con mới chứng minh đường đi mạng.'
            $lines+='Nếu máy con không truy cập được: FIREWALL_ACTION_REQUIRED = REVIEW. Nhờ quản trị kiểm tra rule inbound TCP đúng port và profile LAN; không tắt firewall.'
            $lines+='Nếu có nhiều IP: chọn IP của card nối cùng mạng phòng máy; bỏ qua VPN/card ảo không dùng.'
            Write-Report '03_LAN_SERVER.txt' $lines
        }
        4 {
            $address=$null
            do { $ip=(Read-Host 'Nhập IPv4 máy chủ (không nhập URL)').Trim(); $ok=[Net.IPAddress]::TryParse($ip,[ref]$address) -and $address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork } until ($ok)
            $port=Read-Number 'Nhập PORT máy chủ' 1 65535
            $ping=Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue
            $tcp=Test-NetConnection -ComputerName $ip -Port $port -InformationLevel Quiet -WarningAction SilentlyContinue
            $lines=@("SERVER_IP = $ip","SERVER_PORT = $port","PING = $ping (ICMP có thể bị chặn; không quyết định TCP)","TCP_ACCESS = $tcp")
            if ($tcp) { $lines+='[PASS] TÌM THẤY MÁY CHỦ; PORT TRUY CẬP ĐƯỢC' } else { $lines+='[FAIL] PORT KHÔNG TRUY CẬP ĐƯỢC; kiểm tra server, cùng LAN, port và firewall.'; $lines+='FIREWALL_ACTION_REQUIRED = REVIEW (chưa kết luận firewall là nguyên nhân)' }
            $http=Get-HttpResult "http://${ip}:$port/"
            $lines+=$http
            if ($http -match 'HTTP_ACCESS = PASS') { $lines+='[PASS] WEB SERVER PHẢN HỒI' } else { $lines+='[FAIL] HTTP chưa đạt; xem mã HTTP nếu có.' }
            $lines+='BASELINE_MATCH = NOT_CHECKED_ON_CLIENT; đối chiếu 01_PRECHECK của máy chủ.'
            $safeName=[Environment]::MachineName -replace '[^a-zA-Z0-9_-]','_'
            Write-Report ("CLIENT_TEST_$safeName.txt") $lines
            if (-not $tcp -or $http -notmatch 'HTTP_ACCESS = PASS') { exit 3 }
        }
        5 {
            $b=Require-Baseline
            if (-not $b.Match) { Write-Report '05_BASELINE_FAILURE.txt' @('BASELINE_MATCH = FALSE','SAI R4 CANDIDATE — DỪNG NGHIỆM THU.'); exit 2 }
            $n=Read-Number 'SỐ MÁY THAM GIA' 1 100000
            do {
                $lo=Read-Number 'LOGIN THÀNH CÔNG' 0 $n; $lf=Read-Number 'LOGIN THẤT BẠI' 0 $n
                if ($lo+$lf -ne $n) { Write-Host 'Tổng login thành công và thất bại phải bằng số máy.' }
            } until ($lo+$lf -eq $n)
            do {
                $so=Read-Number 'NỘP BÀI THÀNH CÔNG' 0 $n; $sf=Read-Number 'NỘP BÀI THẤT BẠI' 0 $n
                if ($so+$sf -ne $n) { Write-Host 'Tổng nộp thành công và thất bại phải bằng số máy; máy chưa nộp tính thất bại.' }
            } until ($so+$sf -eq $n)
            $lost=Read-Choice 'CÓ MẤT ĐÁP ÁN KHÔNG?' @('Y','N')
            $mixed=Read-Choice 'CÓ NHẦM DỮ LIỆU HỌC SINH KHÔNG?' @('Y','N')
            $http500=Read-Choice 'CÓ HTTP 500 KHÔNG?' @('Y','N')
            $locked=Read-Choice 'CÓ DATABASE LOCK KHÔNG?' @('Y','N')
            $verdict=Get-RoomVerdict $n $lo $lf $so $sf @($lost,$mixed,$http500,$locked)
            Write-Report '05_PHYSICAL_LAN_TEST.txt' @('BASELINE_MATCH = TRUE',"SO_MAY_THAM_GIA = $n","LOGIN_THANH_CONG = $lo","LOGIN_THAT_BAI = $lf","NOP_BAI_THANH_CONG = $so","NOP_BAI_THAT_BAI = $sf","MAT_DAP_AN = $lost","NHAM_DU_LIEU_HS = $mixed","HTTP_500 = $http500","DATABASE_LOCK = $locked","PHYSICAL_50_PC_LAN = $verdict",'Kết quả do người dùng ghi nhận; cần đối chiếu evidence, không tự chứng nhận 50-PC PASS.')
        }
        6 {
            $package=Package-Results
            Write-Host "ĐÃ TẠO GÓI KẾT QUẢ: $($package.Path)"
            Write-Host "SHA256: $($package.Hash)"
            Write-Host "SỐ TỆP EVIDENCE: $($package.Count)"
        }
    }
    exit 0
} catch {
    Write-Host '[FAIL] Không hoàn tất tác vụ. Không tiếp tục nếu precheck chưa PASS.'
    # Exception messages may contain user-entered paths only; never dump environment or license files.
    Write-Host $_.Exception.Message
    exit 1
}
