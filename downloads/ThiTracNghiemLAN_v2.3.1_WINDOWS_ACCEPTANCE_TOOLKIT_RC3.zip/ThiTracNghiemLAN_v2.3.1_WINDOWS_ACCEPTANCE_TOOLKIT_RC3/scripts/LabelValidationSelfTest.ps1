﻿#requires -Version 5.1
# Non-interactive: tests only toolkit input, never app identity or license state.
. (Join-Path $PSScriptRoot 'Common.ps1')
function Assert-LabelTest([bool]$OK,[string]$Name) {
    if (-not $OK) { throw "FAIL: $Name" }
    Write-Output "PASS: $Name"
}
foreach ($labelCase in @('BEFORE','SERVER_REOPEN','APP_REOPEN','WINDOWS_REBOOT1')) {
    Assert-LabelTest ((Convert-LicenseObservationLabel $labelCase) -ceq $labelCase) "ACCEPT $labelCase"
}
Assert-LabelTest ((Convert-LicenseObservationLabel ' WINDOWS_REBOOT1 ') -ceq 'WINDOWS_REBOOT1') 'ACCEPT trimmed WINDOWS_REBOOT1'
foreach ($labelCase in @('WINDOWS_REBOOT','REBOOT1','ABC','')) {
    Assert-LabelTest ($null -eq (Convert-LicenseObservationLabel $labelCase)) "REJECT [$labelCase]"
}
Assert-LabelTest ((Convert-LicenseObservationLabel 'app_reopen') -ceq 'APP_REOPEN') 'uppercase normalization'
foreach ($labelCase in @('   ',"`t",'WINDOWS_ REBOOT1','WINDOWS_REBOOT11')) {
    Assert-LabelTest ($null -eq (Convert-LicenseObservationLabel $labelCase)) "REJECT extra invalid [$labelCase]"
}
function Test-ObservationPrompt([string[]]$Inputs,[string]$Accepted,[int]$InvalidCount,[bool]$MustThrow=$false) {
    # Scoped input/output substitutes: finite queue, no real Read-Host and no R4 imports.
    $queue=New-Object 'System.Collections.Generic.Queue[string]'
    foreach ($entry in $Inputs) { $queue.Enqueue($entry) }
    $prompts=New-Object 'System.Collections.Generic.List[string]'
    $messages=New-Object 'System.Collections.Generic.List[string]'
    function Read-Host([string]$Prompt) {
        if ($queue.Count -eq 0) { throw 'TEST_INPUT_EXHAUSTED: interactive loop did not terminate' }
        $prompts.Add($Prompt)
        return $queue.Dequeue()
    }
    function Write-Host([string]$Object) { $messages.Add($Object) }
    $result=$null; $failure=$null
    try { $result=Read-LicenseObservation } catch { $failure=$_.Exception.Message }
    if ($MustThrow) {
        Assert-LabelTest ($null -ne $failure -and $failure -like 'Da nhap sai 20 lan.*') 'retry limit ends after 20 invalid inputs'
    } else {
        Assert-LabelTest ($null -eq $failure -and $result -ceq $Accepted) "prompt returns $Accepted immediately"
    }
    Assert-LabelTest ($queue.Count -eq 0) 'exact input consumption'
    Assert-LabelTest ($prompts.Count -eq $Inputs.Count) 'no extra prompt after valid input'
    Assert-LabelTest ($messages.Count -eq $InvalidCount) 'every invalid input has a clear message'
    foreach ($promptText in $prompts) {
        Assert-LabelTest ($promptText -ceq 'Lan ghi nhan: BEFORE / SERVER_REOPEN / APP_REOPEN / WINDOWS_REBOOT1') 'prompt and allowed-values agree'
    }
    foreach ($messageText in $messages) {
        Assert-LabelTest ($messageText -like '[[]INVALID[]] Chi nhap mot trong:*WINDOWS_REBOOT1*Hay nhap lai*') 'invalid input explains valid choices and retry'
    }
}
foreach ($labelCase in @('BEFORE','SERVER_REOPEN','APP_REOPEN','WINDOWS_REBOOT1')) {
    Test-ObservationPrompt @($labelCase) $labelCase 0
}
Test-ObservationPrompt @(' windows_reboot1 ') 'WINDOWS_REBOOT1' 0
Test-ObservationPrompt @('WINDOWS_REBOOT','REBOOT1','ABC','','BEFORE') 'BEFORE' 4
Test-ObservationPrompt (@('ABC') * 20) '' 20 $true
Write-Output 'LABEL_VALIDATION_SELF_TEST = PASS; LICENSE_REBOOT_ACCEPTANCE = NOT_TESTED'
