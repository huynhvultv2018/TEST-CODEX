﻿#requires -Version 5.1
param([string]$CandidatePath)
. (Join-Path $PSScriptRoot 'Common.ps1')
Initialize-Results
$reportPath=Join-Path $script:Results '00_TOOLKIT_RUNTIME_SELF_TEST.txt'
$lines=New-Object 'System.Collections.Generic.List[string]'
function Check([bool]$OK,[string]$Label) {
    if (-not $OK) { throw "FAIL: $Label" }
    $lines.Add("PASS: $Label")
}
$temp=Join-Path ([IO.Path]::GetTempPath()) ('RC2 test có dấu & spaces '+[Guid]::NewGuid().ToString('N'))
$realRoot=$script:Root
try {
    foreach ($bat in (Get-ChildItem -LiteralPath $realRoot -Filter '*.bat')) {
        $bytes=[IO.File]::ReadAllBytes($bat.FullName)
        $bom=$bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191
        $first=([Text.Encoding]::ASCII.GetString($bytes) -split "`r?`n")[0]
        $lines.Add("FILE = $($bat.Name); FIRST_3_BYTES = $([BitConverter]::ToString($bytes[0..2])); HAS_UTF8_BOM = $($bom.ToString().ToUpperInvariant()); FIRST_LINE = $first")
        Check (-not $bom -and $first -ceq '@echo off') "BAT bytes $($bat.Name)"
        Check (@($bytes | Where-Object { $_ -gt 127 }).Count -eq 0) "BAT ASCII $($bat.Name)"
        $batText=[Text.Encoding]::ASCII.GetString($bytes)
        $withoutCRLF=$batText.Replace("`r`n",'')
        Check ($batText.Contains("`r`n") -and -not $withoutCRLF.Contains("`r") -and -not $withoutCRLF.Contains("`n")) "BAT CRLF only $($bat.Name)"
        Check ([Text.Encoding]::ASCII.GetString($bytes).Contains('%~dp0scripts\Run.ps1')) "relative BAT target $($bat.Name)"
    }
    foreach ($ps in (Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1')) {
        $tok=$null; $err=$null
        [System.Management.Automation.Language.Parser]::ParseFile($ps.FullName,[ref]$tok,[ref]$err) | Out-Null
        Check ($err.Count -eq 0) "PowerShell parse $($ps.Name)"
    }
    $labelLines=@(& (Join-Path $PSScriptRoot 'LabelValidationSelfTest.ps1'))
    foreach ($labelLine in $labelLines) { $lines.Add([string]$labelLine) }
    Check ($labelLines -contains 'LABEL_VALIDATION_SELF_TEST = PASS; LICENSE_REBOOT_ACCEPTANCE = NOT_TESTED') 'bounded non-interactive observation label tests'
    New-Item -ItemType Directory -Path $temp | Out-Null
    $script:Root=$temp; $script:Results=Join-Path $temp 'RESULTS'
    Initialize-Results
    $wrong=Join-Path $temp 'wrong.zip'
    'not candidate' | Set-Content -LiteralPath $wrong -Encoding ASCII
    Check (-not (Get-Baseline $wrong).Match) 'wrong candidate rejected'
    Check (-not (Get-Baseline (Join-Path $temp 'absent.zip')).Match) 'missing candidate rejected'
    if ($CandidatePath) { Check ((Get-Baseline $CandidatePath).Match) 'real R4 SHA verified' }
    Write-Report 'test.txt' @('Tiếng Việt RC2')
    Check ((Get-Content -LiteralPath (Join-Path $script:Results 'test.txt') -Raw) -match 'Tiếng Việt RC2') 'UTF8 logging'
    $row=[pscustomobject][ordered]@{ TIMESTAMP=(Get-Date).ToString('o'); WINDOWS_BOOT_TIME='TEST_ONLY'; COMPUTER_NAME='SELF_TEST'; MACHINE_ID_HASH='TEST_ONLY'; LICENSE_OBSERVATION='UNKNOWN'; NOTE='BEFORE' }
    Save-LicenseRow $row; $row.NOTE='WINDOWS_REBOOT'; Save-LicenseRow $row
    $rows=@(Import-Csv -LiteralPath (Join-Path $script:Results '02_LICENSE_RESTART.csv'))
    Check ($rows.Count -eq 2 -and $rows[0].NOTE -eq 'BEFORE' -and $rows[1].NOTE -eq 'WINDOWS_REBOOT') 'CSV append'
    $csvPath=Join-Path $script:Results '02_LICENSE_RESTART.csv'
    $oldCsv=[IO.File]::ReadAllBytes($csvPath)
    $row.NOTE='WINDOWS_REBOOT1'; Save-LicenseRow $row
    $newCsv=[IO.File]::ReadAllBytes($csvPath)
    Check ($newCsv.Length -gt $oldCsv.Length -and [Convert]::ToBase64String($oldCsv) -ceq [Convert]::ToBase64String($newCsv[0..($oldCsv.Length-1)])) 'CSV existing bytes preserved on append'
    $rows=@(Import-Csv -LiteralPath $csvPath)
    Check ($rows.Count -eq 3 -and $rows[0].NOTE -eq 'BEFORE' -and $rows[1].NOTE -eq 'WINDOWS_REBOOT' -and $rows[2].NOTE -eq 'WINDOWS_REBOOT1' -and $rows[2].LICENSE_OBSERVATION -eq 'UNKNOWN') 'CSV new label appended without rewriting historical labels or claiming license PASS'
    Check ((Get-RoomVerdict 49 49 0 49 0 @('N','N','N','N')) -eq 'NOT_TESTED') '49 PCs NOT_TESTED'
    Check ((Get-RoomVerdict 50 50 0 50 0 @('N','N','N','N')) -eq 'EVIDENCE_RECORDED_REVIEW_REQUIRED') '50 PCs no automatic PASS'
    foreach ($i in 0..3) {
        $flags=@('N','N','N','N'); $flags[$i]='Y'
        Check ((Get-RoomVerdict 50 50 0 50 0 $flags) -eq 'FAIL') "room error $i fails"
    }
    $package=Package-Results
    Check ((Get-FileHash -LiteralPath $package.Path -Algorithm SHA256).Hash.ToLowerInvariant() -eq $package.Hash) 'ZIP SHA256'
    $zip=[IO.Compression.ZipFile]::OpenRead($package.Path)
    try { Check ($null -ne $zip.GetEntry('test.txt') -and $null -ne $zip.GetEntry('02_LICENSE_RESTART.csv')) 'ZIP evidence contents' } finally { $zip.Dispose() }
    $lines.Add('CORE_RUNTIME_SELF_TEST = PASS')
    $lines.Add('WINDOWS_LAN_LICENSE_PHYSICAL_TEST = NOT_PERFORMED_BY_SELF_TEST')
    $lines.Add('BAT_NATIVE_DISPATCH = NOT_TESTED_BY_THIS_SCRIPT (bước 01 gọi thành công script không chứng minh các BAT còn lại đã chạy)')
    $lines.Add('RUNTIME = '+$PSVersionTable.PSVersion.ToString()+'; OS = '+[Environment]::OSVersion.Platform)
    $lines | Set-Content -LiteralPath $reportPath -Encoding UTF8
    Write-Host '[PASS] Tự kiểm tra byte BAT, cú pháp, SHA, ghi log, CSV và ZIP. Xem RESULTS/00_TOOLKIT_RUNTIME_SELF_TEST.txt.'
} catch {
    $lines.Add('CORE_RUNTIME_SELF_TEST = FAIL: '+$_.Exception.Message)
    $lines | Set-Content -LiteralPath $reportPath -Encoding UTF8
    throw
} finally {
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force }
}
