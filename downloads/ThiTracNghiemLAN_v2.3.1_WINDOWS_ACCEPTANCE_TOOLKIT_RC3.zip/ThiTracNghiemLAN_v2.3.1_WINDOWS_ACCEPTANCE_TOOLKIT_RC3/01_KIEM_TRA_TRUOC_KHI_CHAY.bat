@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
where powershell.exe >nul 2>&1
if errorlevel 1 (
 echo [FAIL] Can Windows PowerShell 5.1. Hay lien he nguoi quan tri.
 pause
 exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Run.ps1" -Task 1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo [FAIL] Tac vu chua hoan tat. Xem RESULTS va thong bao tren man hinh.
pause
exit /b %RC%
