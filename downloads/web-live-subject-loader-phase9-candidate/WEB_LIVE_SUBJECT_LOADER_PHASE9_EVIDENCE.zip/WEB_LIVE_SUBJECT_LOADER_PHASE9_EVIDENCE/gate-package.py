import json,pathlib,hashlib,zipfile
P=pathlib.Path(__file__).parent
def read(n):return json.loads((P/n).read_text())
def save(n,d):(P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def manifest(root):return {str(f.relative_to(root)):sha(f) for f in sorted(root.rglob('*')) if f.is_file()}
assert read('TARGETED_RESULTS.json')['result']=='PASS';assert len(read('TARGETED_RESULTS.json')['checks'])==15
root=P/'working/WEB_LIVE_SUBJECT_LOADER_PHASE9_WORKING_COPY';old=read('RC1_MANIFEST_BEFORE.json');new=manifest(root)
changed=[n for n in old if old[n]!=new.get(n)];added=sorted(set(new)-set(old));removed=sorted(set(old)-set(new))
assert changed==['WEB_LIVE/teacher.html','WEB_LIVE/zip.js'];assert added==['WEB_LIVE/subject-loader.css','WEB_LIVE/subject-loader.js'];assert removed==[]
protected=['WEB_LIVE/core-profiles.js','WEB_LIVE/common.js','WEB_LIVE/teacher.js','WEB_LIVE/tv.html','WEB_LIVE/geometry-profile.js','WEB_LIVE/geometry-profile.css','WEB_LIVE/tv-layout-geometry.js','WEB_LIVE/tv-layout-algebra.js','WEB_LIVE/algebra-profile.css','WEB_LIVE/tv-layout-computer.js','WEB_LIVE/informatics-profile.css']
assert all(old[n]==new[n] for n in protected)
save('SOURCE_SCOPE.json',{'result':'PASS','changed':changed,'added':added,'removed':removed,'unchangedInheritedFiles':len(old)-len(changed),'candidateFiles':len(new),'protectedFilesUnchanged':protected,'coreChangeRequired':False,'webLiveCoreMutated':False,'profileEnginesMutated':False,'lessonPedagogyMutated':False,'productionModified':False})
pairs=[('GEOMETRY','GEOMETRY_RUNTIME/geometry-runtime.json'),('ALGEBRA','ALGEBRA_TARGETED.json'),('INFORMATICS','INFORMATICS/INFORMATICS_TARGETED.json'),('LEGACY','ENGINES/results.json')]
def normalize(d,subject):
 if isinstance(d,dict):return {k:normalize(v,subject) for k,v in d.items() if not(subject=='GEOMETRY' and k=='lessonActivation') and not(subject=='INFORMATICS' and k=='currentTime')}
 if isinstance(d,list):return [normalize(v,subject) for v in d]
 return d
comparison={}
for name,rel in pairs:
 a=read('REGRESSION/RC1/'+rel);b=read('REGRESSION/PHASE9/'+rel)
 assert not a['errors'] and not b['errors']
 if 'checks' in b:assert all(c['result']=='PASS' for c in a['checks']+b['checks'])
 assert normalize(a,name)==normalize(b,name),name+' regression differs'
 comparison[name]={'result':'PASS','reference':'REGRESSION/RC1/'+rel,'phase9':'REGRESSION/PHASE9/'+rel,'checks':len(b.get('checks',b.get('assertions',[]))),'normalization':{'GEOMETRY':'lessonActivation per-import UUID only; intra-run parity remains exact','INFORMATICS':'Manual video playback currentTime only; both independent playback assertions >0 remain'}.get(name,'NONE')}
save('REGRESSION_COMPARISON.json',comparison)
rc=pathlib.Path('/workspace/output/web-live-multi-profile-rc1/WEB_LIVE_MULTI_PROFILE_RC1.zip');before=(P/'RC1_SHA256_BEFORE.txt').read_text().strip();assert sha(rc)==before
assert manifest(pathlib.Path('/workspace/phase7-multi-profile-integration/packaged-smoke/WEB_LIVE_MULTI_PROFILE_RC1'))==old
save('RC1_INTEGRITY.json',{'sha256Before':before,'sha256After':sha(rc),'mutated':False,'referenceDirectoryAll1239FilesUnchanged':True})
save('PREPACKAGE_GATE.json',{'result':'PASS','targetedChecks':15,'regression':{n:'PASS' for n,_ in pairs},'noTeachAhead':'PASS','sourceScope':'PASS','rc1Integrity':'PASS','openPhase9Findings':{'P0':0,'P1':0,'P2':0,'P3':0}})
O=pathlib.Path('/workspace/output/web-live-subject-loader-phase9-candidate');O.mkdir(exist_ok=True)
z=O/'WEB_LIVE_SUBJECT_LOADER_PHASE9_CANDIDATE.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for rel in new:f.write(root/rel,'WEB_LIVE_SUBJECT_LOADER_PHASE9_CANDIDATE/'+rel)
fresh=P/'packaged-smoke';fresh.mkdir(exist_ok=True)
with zipfile.ZipFile(z) as f:assert f.testzip() is None;f.extractall(fresh)
assert manifest(fresh/'WEB_LIVE_SUBJECT_LOADER_PHASE9_CANDIDATE')==new
save('CANDIDATE_PAYLOAD_MANIFEST.json',new)
save('PACKAGE_IDENTITY.json',{'name':'WEB_LIVE_SUBJECT_LOADER_PHASE9_CANDIDATE','sha256':sha(z),'bytes':z.stat().st_size,'files':len(new),'crc':'PASS','freshExtractionByteEquality':'PASS','production':False})
print('PREPACKAGE_GATE = PASS; candidate',sha(z),len(new),'files')
