import pathlib,json,hashlib,shutil,zipfile
P=pathlib.Path(__file__).parent;O=pathlib.Path('/workspace/output/web-live-subject-loader-phase9-candidate')
def read(n):return json.loads((P/n).read_text())
def write(n,s):(P/n).write_text(s.strip()+'\n')
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
identity=read('PACKAGE_IDENTITY.json');scope=read('SOURCE_SCOPE.json');target=read('TARGETED_RESULTS.json');pack=read('PACKAGED_SMOKE/TARGETED_RESULTS.json');assets=read('PACKAGED_SMOKE/PACKAGED_ASSETS.json');rc=read('RC1_INTEGRITY.json')
assert target['result']==pack['result']==assets['result']=='PASS';assert len(pack['checks'])==15 and len(assets['assets'])==60
assert read('ENVIRONMENT_SETTINGS_EVIDENCE.json')['fullDraftUnchanged']
write('RELEASE_GATE.json',json.dumps({'result':'PASS','targetedChecks':15,'packagedTargetedChecks':15,'servedAssets':60,'fourProfileRegression':'PASS','sourceScope':'PASS','rc1Immutable':True,'coreChangeRequired':False,'productionModified':False,'phase8PhysicalAcceptance':'PENDING_UNRUN'},indent=2))
write('SUBJECT_LOADER_PHASE9_IMPLEMENTATION_REPORT.md',f'''# Phase9 — Subject-aware lesson loader

PHASE9_STATUS = PASS (cloud technical tests). Candidate only; no Production/Phase10.

## Implemented behavior

Teacher now selects HÌNH HỌC / ĐẠI SỐ / TIN HỌC / BÀI CŨ–LEGACY, selects ZIP/JSON or saved lesson, sees metadata preview, then explicitly clicks NẠP BÀI. Valid selection alone never replaces the active lesson. Mismatch shows selected subject and declared lesson subject on separate lines and disables load. Small Teacher indicator reflects the actual active profile; staged selection never changes it. Saved library filtered from actual saved lesson metadata, not titles. Existing built-in sample is accurately presented as Legacy (it has no subject_engine).

Subject truth: only top-level lesson.subject_engine; trimmed/case-normalized supported ids. Missing field or explicit legacy/default means Legacy; present null/nonstring/empty/unknown rejected. No filename, folder, subject-name, question-text or keyword inference. Registry supplies labels/mapping, so future registered subjects can be added without rewriting loading control flow.

## Transaction and integrity

New prepareLessonZip returns parsed lesson/source key/ZIP entries without persistence. Existing importZip API delegates to preparation then saveLesson, keeping backward compatibility for internal consumers. Existing ZIP parser additionally checks entry CRC. Required lesson.json, valid JSON/non-empty object screens, safe ZIP paths/size limits, image references/decoding and declared Informatics media resources validated before any native start. ZIP image media can use data-image supported by unchanged profile. Video embedded only in ZIP cannot be published through the frozen profile's data-video contract; it needs an existing local runtime URL with identical bytes or is blocked. No new media execution/renderer or engine behavior.

Latest asynchronous selection wins; close/change cancels stale pending work. On explicit valid commit, a detached copy is persisted, library UI preflight runs, then unchanged native start performs original activation/reset/render/sync. Persistence/UI failure rolls back saved keys before any new native publication. Unexpected native-start failure restores prior native values/controller model maps and re-syncs the old lesson. Teacher indicator restored as well. No new Core state keys/channel/navigation or profile semantics.

## Source scope

Changed existing files: WEB_LIVE/teacher.html (Teacher loader markup/script/CSS links), WEB_LIVE/zip.js (package preparation/CRC). Added: WEB_LIVE/subject-loader.js, WEB_LIVE/subject-loader.css. Removed: none. {scope['unchangedInheritedFiles']} inherited files unchanged; candidate {identity['files']} files.

Core common.js/core-profiles.js/teacher.js, TV HTML/scripts/CSS, state/navigation/sync, every Geometry/Algebra/Informatics/Legacy profile behavior, all lesson fixtures/pedagogy and source teaching materials remain byte-identical. Loader calls/wraps existing public Teacher entry points; native start implementation unchanged. CORE_CHANGE_REQUIRED = NO; WEB_LIVE_CORE_MUTATED = NO. Source classification and hashes in SOURCE_SCOPE.json and payload manifests; no code refactor outside importer/UI scope.

RC1 SHA BEFORE = AFTER = {rc['sha256Before']}; RC1_MUTATED = NO. Frozen reference directory all1239file hashes unchanged. Environment Settings revision12 unchanged/unpublished.

## Validation and delivery

15 targeted groups PASS; fresh reference/candidate Legacy15 assertions, Geometry14, Algebra20, Informatics26 PASS. Candidate freshly extracted, all1241file hashes exact; packaged targeted15groups and60served asset hashes/modal lifecycle PASS. RELEASE_GATE PASS. See evidence/regression reports for normalization and retained helper failures.

Candidate: {identity['name']}. SHA256: {identity['sha256']}.

Physical Windows/TV and Phase8 acceptance remain UNRUN/PENDING. No physical/real-classroom/SGK lesson claim. G4-F02/F04 deferred, G4-F03 fixed, G4-F05 pending and waived real-file disposition unchanged. New confirmed Phase9 open P0/P1/P2/P3=0. STOP / WAIT_FOR_GV_APPROVAL.
''')
write('SUBJECT_LOADER_CONTRACT.md','''# Subject loader contract

## Responsibility and routing

SELECT → VALIDATE → ROUTE → LOAD only. Teacher-only UI. subject_engine top-level lesson metadata is authoritative. geometry→Geometry, algebra→Algebra, informatics→Informatics, absent/legacy/default→Legacy. Trim/case normalization matches native resolver; present empty/null/nonstring/unsupported values block. subject/file/folder/content keywords never select the profile. Manifest fields do not override lesson subject_engine. New subjects require registry plus existing Core support; no heuristic fallback to a subject-specific profile.

Preview shows only scalar values actually present on lesson metadata: subject, grade or class, week, period, title, subject_engine. Zero values displayed; no inferred grade/week/period and no curriculum content generated. Strings inserted with textContent; no HTML execution. Active-profile indicator updates only after successful native load. Unknown staged profile cannot alter current indicator.

## Inputs and validation

Native ZIP/JSON picker, existing sample and saved-library selections all stage and require explicit NẠP BÀI. ZIP requires exactly one lesson.json; native manifest JSON must parse when present. Nonempty screens must contain objects. Image files referenced by native screen visual fields must be embedded or present in ZIP and decode. Native existing ZIP size/path/compression limits retained, entry CRC checked. Required files means lesson.json and actual referenced assets; no new mandatory schema or manifest structure introduced.

Informatics declared MEDIA src must satisfy existing local/data-image renderer contract and have a usable asset. ZIP-contained images become supported data-image on the detached staged lesson; original package untouched. Packaged video remains manual-play with existing local supported URL; if ZIP supplies video at that URL, served bytes must match. No blob/data-video engine extension. Existing intentionally absent optional metadata stays optional.

## Commit and failed-load behavior

Validation and preview never call saveLesson/start. Changing selection revalidates pending subject; cancel/close invalidates async tickets; later stale completion cannot publish. Failure preserves active lesson, activation/index/hint/answer/proof/Focus/zoom/annotations/sample and saved library. Subject mismatch blocks immediate load; GV may change selected subject to match pending metadata and explicitly commit.

Commit order: final metadata/subject recheck → detached lesson copy → existing persistence → saved-library UI preflight → native start/reset/render/sync. Loader keeps original storage/native controller values for exception rollback. Native start assigns fresh lessonActivation and original profile/scene lifecycle; it resets foreground disclosure/Focus/zoom/layout. Geometry own-scene persisted annotations retain existing frozen semantics; never transfer into another profile/lesson scope. Internal importZip remains its historical persisting API; public Teacher import controls use staged preparation.

Native sync counters and TTS transport status can advance independently while a modal is open or during rollback; semantic lesson/state remains protected. No claim of distributed ACID across multiple simultaneous Teacher tabs; one active Teacher import transaction tested. No state schema/Core/profile change, no new synchronization channel.

Error text records failed read/validation/commit; native lesson stays active. Exceptional preflight/persistence errors reopen/retain importer with visible error. Unexpected native start exceptions restore native controller maps/state and old indicator and re-sync. Failed loading is never solved by modifying lesson pedagogy or profile engine.

Source boundary: teacher.html, importer helper zip.js, new subject-loader.js/css only. No alteration of Core routing/default fallback used by internal runtime callers; new public Loader is stricter about malformed engine metadata before calling Core.
''')
write('SUBJECT_LOADER_PHASE9_TEST_EVIDENCE.md',f'''# Phase9 — Test evidence

Linux Chromium {target['browser']}, existing Node/Playwright/static Python runtime. Windowsphysical/physicalTV/realclassroom UNRUN. No new install/build or Environment Settings writes. Use NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules.

## Targeted groups — actual executions

TARGETED_RESULTS.json / TARGETED_RUN.log = PASS, 15groups:
{chr(10).join('- '+c['name']+' = '+c['result'] for c in target['checks'])}

Four matching profiles, three required mismatches, seven invalid-engine forms, legacy/default/normalized ids; six original malformed JSON/screen/image/media probes plus invalid embedded image; five ZIP corruption/missing/JSON/image/CRC probes; authored ZIP media success; async latest-wins/close; simulated storage quota; injected prepublish native start exception; injected library UI-preflight failure; Geometry→Algebra→Informatics→Legacy→Geometry with dirty annotation/proof/zoom/layout/math Focus and confirmed checkpoint/sample; saved-library gating. Native popup TV and embedded Preview used with original controls. Private/future/sample disclosure covered also by profile regressions. Collected page runtime errors/external runtime requests =0.

Failed-load snapshots compare lesson bytes, activation/index, hint/answer/proof/Focus/zoom/layout and saved storage. Native stateVersion counter normalized in stored sync record, and only two TTS transport registry/status keys omitted because native ready/cancel updates them independently; semantic state/storage remains exact. Unexpected restored native start may re-sync and advance version, explicitly recorded. No product assertion removed to obtain PASS.

Screenshots: SUBJECT_LOADER_PREVIEW.png and SUBJECT_LOADER_MISMATCH.png; final packaged versions also included. Visible four-step Teacher UI, small actual-profile indicator, green valid message and multiline mismatch with disabled button. Native Close/reopen supported.

## Fresh regression / commands

Reference RC1 root /workspace/phase7-multi-profile-integration/packaged-smoke/WEB_LIVE_MULTI_PROFILE_RC1 served8782; Phase9 working root served8783. External helpers under REGRESSION/RC1 and REGRESSION/PHASE9. Geometry uses existing auxiliary approved G4-F01 corrected ZIP unchanged. Algebra/Informatics use bundled synthetic fixtures; Legacy five original ZIP packages.

node /workspace/phase9-subject-loader/targeted-loader.cjs
Geometry helper: node REGRESSION/<target>/geometry-runtime.cjs (root/port bound in helper).
Algebra helper: WEB_LIVE_ALGEBRA_ROOT=<root> WEB_LIVE_ALGEBRA_BASE=<url> node REGRESSION/<target>/targeted-algebra.cjs.
Informatics helper: INFORMATICS_ROOT=<root> INFORMATICS_BASE=<url> INFORMATICS_EVIDENCE=<external-out> node REGRESSION/<target>/targeted-informatics.cjs.
Legacy helper: WEB_LIVE_TEST_ROOT=<root> WEB_LIVE_BROWSER_BASE=<url> PHASE2_EVIDENCE=<external-out> node REGRESSION/<target>/engines.cjs.
All commands from audit directory with NODE_PATH set; no evidence written inside frozen/candidate payload. Phase9 import-driving helper adds actual subject selection and explicit load; profile assertions unchanged. Main helpers may call native start/direct TV rendering for independent inherited presentation fixtures, while targeted tests enforce new public Loader path.

## Preserved harness diagnoses

HARNESS_HISTORY/ATTEMPT1: initially compared unrelated TTS transport counters and native sync-version exactly while TV-ready/modal cancellation advanced them. Semantic lesson/disclosure/storage unchanged. External snapshot now compares semantic native state and exact lesson/library, excluding only those transport fields. No application patch for that diagnosis.
HARNESS_HISTORY/LEGACY_IMPORTER_CLOSED: existing Legacy helper closes modal before loading; new visible select action needed explicit showImporter(). External helper corrected to open native modal then choose Legacy/commit. Original failure/helper preserved; final entire Legacy suite rerun PASS. No disabled profile assertion.

## Packaged candidate and scope

PREPACKAGE_GATE.json = PASS; candidate ZIP CRC/extracted1241file hashes exact. PACKAGED_SMOKE/TARGETED_RESULTS.json = PASS,15groups on fresh candidate at8784. PACKAGED_SMOKE/PACKAGED_ASSETS.json = PASS,60served runtime/profile/MathJax/media/fixture resources and native modal lifecycle; hashes match extracted payload. RELEASE_GATE.json PASS. RC1_INTEGRITY.json unchanged approved ZIP+all1239reference files. SOURCE_SCOPE.json only2existing changes+2new files; all Core/profile/pedagogy files unchanged.

Package SHA256 {identity['sha256']}. Physical acceptance and actual SGK/SOẠN_TRƯỚC packages remain unvalidated; waived >32MiB files not requested. Environment startup draft revision12 unchanged, DRAFT_PENDING_SAVE_PUBLISH.
''')
write('SUBJECT_LOADER_PHASE9_REGRESSION_REPORT.md','''# Phase9 — Regression against frozen RC1

Fresh reference and Phase9 runs completed all suites:

| Profile | Checks per target | Coverage | Result |
|---|---|---|---|
| Legacy/default | 15 assertions | 5packages171screens342states44metrics | PASS |
| Geometry | 14checks | 35screens70states23visual records | PASS |
| Algebra | 20checks | 10fixture screens30question/12disclosed viewport cases | PASS |
| Informatics | 26checks | 21screens126hidden/full viewport cases +3sample/comparison cases | PASS |

REGRESSION_COMPARISON.json: Geometry exact after only per-import lessonActivation UUID normalization; native intra-run Teacher/Preview/TV parity still tested. Algebra fully exact; Informatics only manual video currentTime normalized (both assert playback >0). Legacy fully exact. Raster screenshot hashes not asserted identical; functional/DOM/geometry/layout evidence exact. All recorded error/request collections clean and source memory unchanged. Offline native navigation/MathJax and vertical MCQ preserved.

Required Geometry→Algebra→Informatics→Legacy→Geometry tested through actual new Loader with state dirtied before switch (Geometry annotation/proof/zoom/layout/Focus; Algebra math steps/Focus/hint; Informatics checkpoint/sample; Legacy disclosure). New successful native activation/reset and profile CSS/control ownership PASS. No cross-reveal/foreign figure/Focus or sample leak. Own-scene persisted Geometry annotations keep accepted original behavior.

NO_TEACH_AHEAD_GLOBAL PASS for finite tested fixtures: future proof/math/code, private Teacher notes, unapproved sample and concealed hints remain protected; loader never creates lesson content. All3subject engines/Core/TV and lesson payloads byte-identical to RC1. Two importer/UI existing files changed, two loader UI files added only.

Packaged final candidate reruns complete targeted15groups plus60asset hashes/modal lifecycle. Initial failed helper assumptions preserved and corrected externally without weakening profile checks. Phase8 physical acceptance remains PENDING/UNRUN; no physical or real-classroom PASS inferred from these tests.
''')
write('SUBJECT_LOADER_PHASE9_RISK_REGISTER.md','''# Phase9 — Risk register

Confirmed open new Phase9 findings: P0=0, P1=0, P2=0, P3=0. Technical candidate only; no Production/Phase10.

G4-F02 OPEN_DEFERRED, G4-F03 FIXED, G4-F04 OPEN_DEFERRED, G4-F05 VALIDATION_PENDING remain unchanged. REAL_FILE_VALIDATION NOT_RUN_BY_GV_DECISION. Phase8 WINDOWS_PHYSICAL_RUNTIME/PHYSICAL_TV_VALIDATION and REAL_CLASSROOM_TRIAL UNRUN/PENDING. No physical evidence received or converted into PASS. Counts exclude inherited accepted Geometry items.

ZIP video without an existing matching served local URL is blocked because frozen Informatics renderer does not accept data-video/blob transport; no engine patch made to hide this limitation. ZIP images can be embedded using existing supported data-image contract. Preview reads lesson metadata only, not manifest metadata overrides; absent grade/class/week/period stay absent. Optional media without src remains absent rather than generated. Existing ZIP64/size/compression restrictions retained.

Single active Teacher transaction tested. Native sync-version/TTS transport metadata may advance independently and during compensating native-start restoration; no distributed cross-tab ACID guarantee. Existing runtime state/reset/sync implementation remains frozen. Storage quota and UI/native-start exceptions were injected and current semantic lesson/storage restored. Native annotation persistence remains scoped to its original Geometry scene; this phase does not erase saved teacher drawings.

Invalid-data coverage is finite. Tests validate package/metadata/screens/referenced assets and required failure classes, not every possible malformed pedagogy payload or real SGK/SOẠN_TRƯỚC package. No schema/pedagogical migrations or inferred metadata. Synthetic fixtures are test-only.

Helper incidents: TTS/sync transport snapshot assumption and closed-importer Legacy select action; proven harness root causes, original failures preserved, affected suites rerun PASS. No application defect invented or automatic frozen reference patch.

Environment Settings revision12 unchanged/unpublished, ENVIRONMENT_STARTUP_INSTRUCTIONS DRAFT_PENDING_SAVE_PUBLISH. No installation/settings changes needed for current static runtime validation. Future work requires GV review; STOP after candidate/report.
''')
lines=['RC1_SHA256_BEFORE = '+rc['sha256Before'],'RC1_SHA256_AFTER = '+rc['sha256After'],'RC1_MUTATED = NO','']
for n in ['SUBJECT_LOADER','GEOMETRY_LOAD','ALGEBRA_LOAD','INFORMATICS_LOAD','LEGACY_LOAD','SUBJECT_METADATA_VALIDATION','SUBJECT_MISMATCH_BLOCK','INVALID_PACKAGE_SAFETY','TRANSACTIONAL_LOAD','CURRENT_LESSON_PRESERVATION','PROFILE_STATE_RESET','SUBJECT_INDICATOR','LEGACY_RUNTIME_REGRESSION','GEOMETRY_PROFILE_REGRESSION','ALGEBRA_PROFILE_REGRESSION','INFORMATICS_PROFILE_REGRESSION','NO_TEACH_AHEAD_GLOBAL']:lines.append(n+' = PASS')
lines+=['','CORE_CHANGE_REQUIRED = NO','WEB_LIVE_CORE_MUTATED = NO','','P0_COUNT = 0','P1_COUNT = 0','P2_COUNT = 0','P3_COUNT = 0','','SOURCE_SCOPE_VIOLATION = NO','PRODUCTION_MODIFIED = NO','','PHASE9_CANDIDATE = '+identity['name'],'PHASE9_CANDIDATE_SHA256 = '+identity['sha256'],'','PHASE9_STATUS = PASS','RECOMMENDED_NEXT_ACTION = WAIT_FOR_GV_APPROVAL','','STOP']
write('FINAL_STATUS.txt','\n'.join(lines))
write('CANDIDATE_MANIFEST.md',f'''# Phase9 candidate identity

Name: {identity['name']}
ZIP SHA256: {identity['sha256']}
Bytes: {identity['bytes']}; Files: {identity['files']}.
Root: WEB_LIVE_SUBJECT_LOADER_PHASE9_CANDIDATE/.
Lineage: immutable approved RC1 {rc['sha256Before']}.
Only teacher.html/zip.js changed; subject-loader.js/css added; other1237inherited files exact. CRC/extracted manifest/packaged tests PASS. Existing Windows launchers carried unchanged, not physically accepted in this phase. External current reports/manifests identify Phase9; inherited reports/checksums inside runtime ZIP are historical. No Production.
''')
selected=['AUTHORIZE_PHASE9.txt','FINAL_STATUS.txt','SUBJECT_LOADER_PHASE9_IMPLEMENTATION_REPORT.md','SUBJECT_LOADER_CONTRACT.md','SUBJECT_LOADER_PHASE9_TEST_EVIDENCE.md','SUBJECT_LOADER_PHASE9_REGRESSION_REPORT.md','SUBJECT_LOADER_PHASE9_RISK_REGISTER.md','CANDIDATE_MANIFEST.md','PACKAGE_IDENTITY.json','CANDIDATE_PAYLOAD_MANIFEST.json','SOURCE_SCOPE.json','RC1_INTEGRITY.json','REGRESSION_COMPARISON.json','PREPACKAGE_GATE.json','RELEASE_GATE.json','ENVIRONMENT_SETTINGS_EVIDENCE.json']
for n in selected:shutil.copy2(P/n,O/n)
z=O/'WEB_LIVE_SUBJECT_LOADER_PHASE9_EVIDENCE.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for p in sorted(P.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(P)
  if rel.parts[0] in ['working','packaged-smoke','download-verification'] or p.name.endswith('SERVER.log') or p.name=='SERVER.log' or p.name.startswith('remote-refs'):continue
  f.write(p,'WEB_LIVE_SUBJECT_LOADER_PHASE9_EVIDENCE/'+str(rel))
with zipfile.ZipFile(z) as f:assert f.testzip() is None
(O/'CHECKSUMS_SHA256.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(O.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.txt'))
print('Five required reports, plain final status, checksums and external evidence delivered')
