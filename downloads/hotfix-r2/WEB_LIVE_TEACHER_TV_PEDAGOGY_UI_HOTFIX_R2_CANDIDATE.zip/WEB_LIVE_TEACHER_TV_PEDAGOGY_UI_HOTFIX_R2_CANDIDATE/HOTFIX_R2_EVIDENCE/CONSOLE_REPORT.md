# Console / exception trace

Before patch: 0 JS pageerrors for baseline, RC2, R1 during page load/modal open/Close/Escape/Close again. V8 coverage confirms handler executed twice.

Two network console errors only, both at page load on comparison static servers:

- ERROR: Failed to load resource: the server responded with a status of 404 (File not found)
- FILE/URL: http://127.0.0.1:8767/favicon.ico (pre-cockpit baseline), http://127.0.0.1:8768/favicon.ico (RC2)
- LINE: 0, COLUMN: 0 (network resource diagnostic)
- STACK: N/A — HTTP resource error, not a JavaScript exception.

These do not prevent initialization or handler execution. No favicon patch was made. R1 production HTTP at 47382 produced no console error in this reproduction.

After R2 patch: modal-native.json records 0 pageerrors and 0 console errors across page load/open/Close/Escape/import/reload; cockpit-native.json records 0 pageerrors. No mocked errors/providers/handlers. This is native Linux Chromium evidence, not Windows console evidence.
