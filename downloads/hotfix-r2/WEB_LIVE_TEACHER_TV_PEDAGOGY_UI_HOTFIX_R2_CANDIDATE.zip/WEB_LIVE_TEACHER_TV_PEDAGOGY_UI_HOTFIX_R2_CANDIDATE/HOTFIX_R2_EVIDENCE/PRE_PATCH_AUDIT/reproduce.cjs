const {chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'),fs=require('fs'),assert=require('assert');
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),results=[];
 for(const [version,base] of [['pre-cockpit baseline','http://127.0.0.1:8767'],['RC2','http://127.0.0.1:8768'],['R1','http://127.0.0.1:47382']]){
  const c=await b.newContext({viewport:{width:1366,height:768}}),p=await c.newPage();let phase='page load';const errors=[],consoleLog=[];
  p.on('pageerror',e=>errors.push({phase,error:e.message,stack:e.stack}));p.on('console',m=>consoleLog.push({phase,type:m.type(),text:m.text(),location:m.location()}));
  const cd=await c.newCDPSession(p);await cd.send('Profiler.enable');await cd.send('Profiler.startPreciseCoverage',{callCount:true,detailed:true});
  await p.goto(base+'/WEB_LIVE/teacher.html');await p.waitForFunction(()=>typeof hideImporter==='function');
  const snap=()=>p.evaluate(()=>{const m=document.getElementById('importer'),x=document.getElementById('closeBtn'),r=x.getBoundingClientRect();return{lessonNull:lesson===null,inlineDisplay:m.style.display,computedDisplay:getComputedStyle(m).display,modalVisible:!!m.getClientRects().length,modalCount:document.querySelectorAll('#importer').length,buttonCount:document.querySelectorAll('#closeBtn').length,buttonOnclick:x.getAttribute('onclick'),handler:hideImporter.toString(),focusedId:document.activeElement.id,hitAtButtonCenter:document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)?.closest('button')?.id}});
  const initial=await snap();assert(initial.lessonNull&&initial.modalVisible&&initial.modalCount===1&&initial.buttonCount===1);assert.equal(initial.hitAtButtonCenter,'closeBtn');
  phase='modal open';await p.evaluate(()=>{window.closeClicks=[];document.getElementById('closeBtn').addEventListener('click',e=>closeClicks.push({trusted:e.isTrusted,defaultPrevented:e.defaultPrevented}))});
  phase='click Close';await p.locator('#closeBtn').click();const afterClick=await snap();assert(afterClick.modalVisible);assert.equal(afterClick.focusedId,'closeBtn');
  phase='press Escape';await p.keyboard.press('Escape');const afterEscape=await snap();assert(afterEscape.modalVisible);
  phase='click Close again';await p.locator('#closeBtn').click();const afterAgain=await snap();assert(afterAgain.modalVisible);
  const cov=await cd.send('Profiler.takePreciseCoverage');const file=cov.result.find(s=>s.url.endsWith('/teacher.js'));const hide=file.functions.find(f=>f.functionName==='hideImporter');assert(hide.ranges[0].count>=2);
  phase='load existing sample';await p.getByRole('button',{name:'🧪 BÀI MẪU HÌNH HỌC',exact:true}).click();await p.waitForFunction(()=>lesson&&document.getElementById('importer').style.display==='none');
  phase='reopen with lesson';await p.evaluate(()=>showImporter());await p.locator('#closeBtn').click();const loadedClose=await snap();assert(!loadedClose.modalVisible);
  phase='loaded Escape contract';await p.evaluate(()=>showImporter());await p.keyboard.press('Escape');const loadedEscape=await snap();assert(loadedEscape.modalVisible);assert.equal(errors.length,0);
  if(version==='R1'){await p.screenshot({path:'/workspace/hotfix-r2-audit/R1_LOADED_ESCAPE.png'});await p.reload();await p.evaluate(()=>{localStorage.clear()});await p.reload();await p.locator('#closeBtn').click();await p.screenshot({path:'/workspace/hotfix-r2-audit/R1_CLOSE_FAIL.png'});}
  results.push({version,origin:base,initial,afterClick,afterEscape,afterAgain,closeClicks:await p.evaluate(()=>window.closeClicks||[]),hideImporterV8Coverage:hide,loadedClose,loadedEscape,errors,console:consoleLog});await c.close();
 }
 await b.close();fs.writeFileSync('/workspace/hotfix-r2-audit/reproduction.json',JSON.stringify({browser:'native Chromium; no app/speech/event/handler mocks',results},null,2));console.log(JSON.stringify(results.map(x=>({version:x.version,initialLessonNull:x.initial.lessonNull,clickClosed:!x.afterClick.modalVisible,handlerInvocationCount:x.hideImporterV8Coverage.ranges[0].count,escapeClosed:!x.afterEscape.modalVisible,withLessonClosed:!x.loadedClose.modalVisible,pageErrors:x.errors.length})),null,2));
})().catch(e=>{console.error(e);process.exit(1)});
