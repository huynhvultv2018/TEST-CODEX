# HOTFIX R2 Candidate

**PRODUCTION READY = NO. WINDOWS RE-TEST REQUIRED = YES.**

R2 chỉ sửa ĐÓNG modal ở lần mở đầu chưa có lesson. hideImporter luôn đặt display:none; HTML/CSS/IDs/import/lesson/render/Launcher giữ nguyên. Esc không đóng modal theo baseline. R1 TTS fix giữ nguyên.

Đọc HOTFIX_R2_ROOT_CAUSE_REPORT.md / HOTFIX_R2_ACCEPTANCE_REPORT.md. Dùng HOTFIX_R2_CHECKSUMS_SHA256.txt cho R2; các báo cáo/checksum kế thừa của R1 và RC cũ là lịch sử.

Windows: giải nén toàn bộ R2 riêng, dừng đúng dịch vụ root R1 cũ bằng Ctrl+C, chạy START_WEB_LIVE.bat. Teacher URL: http://127.0.0.1:47382/WEB_LIVE/teacher.html. Kiểm trên browser profile mới/không có bài lưu, click ĐÓNG → modal/overlay biến mất; mở System → THƯ VIỆN / NHẬP BÀI → ĐÓNG lại; import ZIP/JSON/bài mẫu. Không sửa source trong retest; nếu FAIL ghi steps/actual/console/screenshot và dừng. Sau modal Windows PASS mới tiếp tục các gate còn thiếu. Python/Chrome/voices/Word/GeoGebra vẫn là prerequisite baseline.
