from pathlib import Path
import json,shutil,hashlib,zipfile
r=Path(__file__).resolve().parent;out=Path('/workspace/output/web-live-informatics-phase6-candidate');read=lambda n:json.loads((r/n).read_text());package=read('PACKAGE_IDENTITY.json');target=read('INFORMATICS_TARGETED.json');reg=read('REGRESSION_SUMMARY.json');scope=read('SOURCE_SCOPE.json');smoke=read('PACKAGED_SMOKE/INFORMATICS_TARGETED.json');assets=read('PACKAGED_ASSETS.json');cloud=read('CLOUD_DRAFT_STATUS.json')
assert target['result']==reg['result']==scope['result']==smoke['result']==assets['result']=='PASS'
assert len(target['checks'])==len(smoke['checks'])==26 and len(assets['assets'])==58
sha4=package['geometryReferenceSHA256'];sha5=package['algebraReferenceSHA256'];sha6=package['sha256'];raster=read('ALGEBRA_RASTER_COMPARISON.json')
status=f'''GEOMETRY_PHASE4_CANDIDATE = WEB_LIVE_GEOMETRY_PHASE4_CANDIDATE (FROZEN)
GEOMETRY_PHASE4_SHA256 = {sha4}
GEOMETRY_PHASE4_MUTATED = NO

ALGEBRA_PHASE5_CANDIDATE = WEB_LIVE_ALGEBRA_PHASE5_CANDIDATE (FROZEN)
ALGEBRA_PHASE5_SHA256 = {sha5}
ALGEBRA_PHASE5_MUTATED = NO

INFORMATICS_PROFILE = IMPLEMENTED

ACTIVE_LEARNING_FLOW = PASS
INSTRUCTION_RENDERING = PASS
DEMO_RENDERING = PASS
PRACTICE_RENDERING = PASS

CODE_RENDERING = PASS
CODE_HIGHLIGHT = PASS
ALGORITHM_RENDERING = PASS
TABLE_RENDERING = PASS
MEDIA_RENDERING = PASS

CHECKPOINT_CONTROL = PASS
INFORMATICS_FOCUS = PASS

HINT_CONTROL = PASS
ANSWER_CONTROL = PASS
STUDENT_PRODUCT = PASS
SAMPLE_PRODUCT_CONTROL = PASS
NO_TEACH_AHEAD = PASS

CORE_CHANGE_REQUIRED = NO
WEB_LIVE_CORE_MUTATED = NO

LEGACY_RUNTIME_REGRESSION = PASS
GEOMETRY_PROFILE_REGRESSION = PASS
ALGEBRA_PROFILE_REGRESSION = PASS

P0_COUNT = 0
P1_COUNT = 0
P2_COUNT = 0
P3_COUNT = 0

SOURCE_SCOPE_VIOLATION = NO
PRODUCTION_MODIFIED = NO

PHASE6_CANDIDATE = WEB_LIVE_INFORMATICS_PHASE6_CANDIDATE
PHASE6_CANDIDATE_SHA256 = {sha6}

PHASE6_STATUS = PASS
RECOMMENDED_NEXT_PHASE = WAIT_FOR_GV_APPROVAL

STOP
'''
(r/'FINAL_STATUS.txt').write_text(status)
preserved='G4-F01 TARGETED_PASS; G4-F02 OPEN_DEFERRED P3; G4-F03 FIXED; G4-F04 OPEN_DEFERRED P3; G4-F05 VALIDATION_PENDING. REAL_FILE_VALIDATION=NOT_RUN_BY_GV_DECISION; REAL_CLASSROOM_TRIAL=UNRUN.'
implementation=f'''# INFORMATICS_PHASE6_IMPLEMENTATION_REPORT

Phase6 Informatics Profile đã được triển khai theo AUTHORIZE_PHASE6.txt, PASS targeted/global regression và fresh-package validation. Không cần thay Core. Không Production, không merge profile, không chuyển phase tiếp theo.

## Frozen baselines

Geometry Phase4 FROZEN: `{sha4}`, 1.227 file khớp ZIP/manifest trước và sau. Algebra Phase5 FROZEN: `{sha5}`, 1.233 file khớp ZIP/manifest trước và sau. Không sửa baseline JS/CSS/contract/fixture/candidate ZIP. {preserved}

## Phạm vi và kiến trúc

Bản làm việc riêng `working/WEB_LIVE_INFORMATICS_PHASE6_WORKING_COPY` sao chép từ Algebra Phase5 frozen. Chỉ thay một file payload đã có: `WEB_LIVE/tv-layout-computer.js`. Giữ nguyên 538 byte `TVComputerEngine` cũ, thêm `WebLiveInformatics` đăng ký `WebLiveProfiles.registerAdapter('informatics', {{presentation}})` và onDispose. 1.232 file Phase5 khác giữ nguyên byte. Sáu file thêm gồm CSS riêng, ba media kiểm thử cục bộ, JSON test nhỏ và README. Tổng payload 1.239 file; xem SOURCE_SCOPE.json và INFORMATICS_PHASE6_RUNTIME.patch.

Không sửa Core registry, common, importer, lesson state, navigation, native reveal/hint/answer, sync/storage, HTML, shared CSS/math/TTS, launcher, Geometry/Algebra. Không tạo engine Tin học độc lập hoặc duplicate Core. Core descriptor REGISTERED_STUB là metadata scaffold Phase2 bất biến, không gate dispatch. Actual runtime API `WebLiveInformatics.status=IMPLEMENTED` cùng adapter/getState được kiểm chứng. Không sửa Core chỉ để đổi label.

Native `tv.html?preview=1` iframe đã tải file computer adapter; adapter preview gắn Teacher controls riêng vào Teacher DOM cùng origin, không sửa Teacher HTML/JS. UI có XÁC NHẬN CHECKPOINT và HIỆN/ẨN SẢN PHẨM MẪU; teacher note/demo note/control note chỉ ở Teacher. onDispose tháo panel; stale detached button được chặn theo context.

## Hành vi đã triển khai

Chín nhãn activity tùy chọn từ dữ liệu: TÒ MÒ, QUAN SÁT, SUY NGHĨ, DỰ ĐOÁN, TRAO ĐỔI, PHÁT HIỆN, GV CHUẨN HÓA, KIỂM TRA HIỂU, VẬN DỤNG. Không ép đủ chuỗi; thiếu metadata giữ native content. Không sinh kiến thức/code/lesson/pedagogy.

Activity có task/instruction/action/response/checkpoint/result/self-check/conclusion/resource khi nguồn cung cấp. Native steps là chuỗi giữ Core contract; metadata bổ sung chỉ mount khi explicit afterStep đã được reveal. Code là textContent, giữ nguyên newline/indentation, không chạy hoặc sửa code. Code và algorithm highlight/Focus dùng native current step và mapping source-authored. Algorithm hỗ trợ input/process/output/sequence/branch/loop; table giữ semantic header/rows/cells. Media local/data image, video có controls và không autoplay; GIF/ảnh/screenshot/diagram giữ aspect ratio, không che task. Không chạy exe hoặc phụ thuộc Local Launcher.

Expected product, supplied student product và sample product tách nhau. Sản phẩm là snapshot text từ lesson, không tự thu thập/sinh sản phẩm. Sample mặc định hidden; cần native checkpointStep đạt, GV xác nhận checkpoint và GV reveal sample riêng. Full Answer/Hints/Focus không reveal sample. Comparison cần source-authored afterStep và sample đã được GV reveal. Hide/below-checkpoint reset checkpoint/sample; re-import tạo activation mới bắt đầu hidden. Profile-local booleans dùng localStorage/BroadcastChannel keyed bởi activation/source/index; không thêm vào Core state. Channel chỉ yêu cầu refresh context tương ứng, không nhận lesson/state mới.

Focus: bước hiện tại mạnh, trước đã reveal visible/dim, tương lai không có trong DOM; native XÓA TẬP TRUNG khôi phục đúng disclosure/current state. Toggle Focus chỉ bật/tắt picking mode như baseline. Scoped CSS giữ activity visible bên cạnh native steps; MCQ vẫn full-width vertical, instruction riêng.

## Gate, candidate và giới hạn

Targeted26checks PASS; 126 hidden/full viewport cases +3sample/compare cases; boundary19cases PASS; Legacy/Geometry/Algebra regression PASS; fresh ZIP targeted26checks +58served assets exact byte +native modal smoke PASS. Hai P2 Phase6 đã FIXED/retest; open Phase6 P0/P1/P2/P3=0. Các finding Geometry được giữ nguyên, không cộng/trừ giả vào Phase6.

Candidate `{package['zip']}`, SHA256 `{sha6}`, {package['bytes']:,}bytes. Test trước packaging gate PASS; ZIP CRC/manifest exact tested payload và fresh unpacked native test PASS. Năm báo cáo ở ngoài ZIP là tài liệu release hiện hành. Docs/checksums Phase3/4/5 được kế thừa trong payload là lịch sử, không đại diện SHA Phase6.

Browser Chromium {target['browser']} trên Linux. Native Windows/TV vật lý/cuối lớp/âm thanh TTS/thử lớp 45phút UNRUN. Fixture synthetic, không SGK/real SOẠN_TRƯỚC validation. Cấu hình startup lưu draft only; review/save/Publish trong Environment Settings để áp dụng, fresh-task restoration chưa xác minh.
'''
(r/'INFORMATICS_PHASE6_IMPLEMENTATION_REPORT.md').write_text(implementation)
contract='''# INFORMATICS_PROFILE_CONTRACT

## Selection, roles và ownership

Explicit lesson `subject_engine: "informatics"` chọn adapter; không suy ra từ tên môn/text. Missing/unknown/invalid giữ Legacy fallback của Core. Core schema/state/registry unchanged. REGISTERED_STUB trong immutable Core là scaffold metadata; actual API `WebLiveInformatics.status`, registered adapter và getState xác định implementation. Adapter chỉ presentation cho TV/native preview. Teacher parent controls chỉ mount bởi preview iframe same origin và dispose khi rời Informatics; Teacher source/answer panels nguyên native, luôn teacher-only.

SOẠN_TRƯỚC là source of truth; lesson JSON được import bằng native importer. Profile đọc nguồn, không mutate lesson/storage payload/Core state, không rewrite lesson/knowledge/pedagogy/code hoặc tự thực thi thao tác/phần mềm. Fixture synthetic không phải SGK hoặc acceptance SOẠN_TRƯỚC thật.

## Native disclosure và metadata tùy chọn

Screen.steps giữ array string; answer/conclusion/hint/teacherNote vẫn native. Profile bổ sung screen.informatics:

- stage: optional one of CURIOSITY, OBSERVE, THINK, PREDICT, DISCUSS, DISCOVER, STANDARDIZE, CHECK, APPLY. Không biết/thiếu stage không tạo chuỗi hay knowledge.
- blocks: optional array of source-authored records. kind: TASK, INSTRUCTION, STUDENT_ACTION, STUDENT_RESPONSE, EXPECTED_PRODUCT, STUDENT_PRODUCT, CHECKPOINT, RESULT, SELF_CHECK, DEMO, SCREEN_REFERENCE, RESOURCE, CONCLUSION, CODE, ALGORITHM, TABLE, MEDIA, PRODUCT_COMPARISON.
- Mỗi block bắt buộc explicit afterStep integer 0..native total. 0 là nguồn chủ động cho phép hiện ở QUESTION; >0 chỉ mount khi native disclosed count đạt. Missing/string/negative/out-of-range gate bị bỏ qua fail closed. Metadata không tạo native steps hoặc thay step count. Không đánh giá câu trả lời học sinh tự động.
- Optional focusStep integer1..total ánh xạ native answer step. Selected Focus hợp lệ ưu tiên; nếu không thì current native disclosure step. Block hiện tại mạnh, trước đã reveal dim, tương lai chưa mount. Task nguồn chính còn hỗ trợ native content Focus index0.
- HINT/ANSWER/SAMPLE_PRODUCT/TEACHER_NOTE không được nhét vào ordinary block kinds: bị từ chối. Hint/answer dùng native controls; sample có policy riêng; teacher notes không mount student DOM. Nguồn không được đặt kiến thức bí mật trong screen.content/options/blocks afterStep0; renderer tuân theo dữ liệu, không tự phân loại nội dung sư phạm.

Count: hidden=0; steps=bounded answerStep; full=native total. DTO getState chỉ chứa context scalars, count/total, source stage, checkpoint/sample booleans, per-step REVEALED/UNREVEALED và CURRENT/COMPLETED/UNREVEALED flags; không chứa source text của bước tương lai. Full Answer được phép reveal toàn bộ native answers theo quyết định GV; sample vẫn độc lập.

## Code, algorithm, table, media

CODE block: lines:[{text:string,afterStep:integer}], highlightLinesByStep:{"1":[1],"2":[2]} dùng 1-based original line numbers; only disclosed authored lines mount. TextContent giữ newline giữa dòng đã cung cấp, spaces/tabs/indentation trong từng text nguyên byte; không syntax rewrite/solver/execute. Noncontiguous gates giữ original line identity, không tự chèn hidden text. Current/valid earlier Focus chọn authored line map; invalid future Focus bị bỏ qua. Long unavoidable source code giữ scrolling trong code wrapper, không clip hoặc character-wrap; representative code fit TV.

ALGORITHM block: items:[{kind:INPUT|PROCESS|OUTPUT|SEQUENCE|BRANCH|LOOP,text,afterStep,focusStep?}]. Explicit authored gates áp dụng từng item; focusStep link tùy chọn, không tự suy ra thuật toán hoặc branch/loop outcome. Layout là các hàng dễ đọc, không flowchart tự sinh.

TABLE block: headers:string[], rows:string[][] với mỗi row cùng độ dài headers. Semantic table/th scope=col/tbody/td, cells giữ nguồn. Shape invalid được bỏ qua và ghi diagnostic; không flatten/rewrite/clip. Trường hợp nguồn quá rộng dùng local wrapper scroll; fixture không overflow ngang.

MEDIA block: type IMAGE|VIDEO|ANIMATION|SCREENSHOT|DIAGRAM, src, alt?, caption?. Src local same-origin .png/.jpg/.jpeg/.gif/.svg/.webp hoặc .webm/.mp4 cho video; data image PNG/JPEG/GIF/WebP/SVG được hỗ trợ. Remote/executable/protocol khác/URL credentials bị từ chối. Relative src tính từ WEB_LIVE; không resolve file OS hoặc launch exe. Video có controls, preload metadata, playsInline, autoplay=false; animation dùng image asset như GIF. Giữ object-fit contain/aspect ratio; height bounded khi step disclosure. Codec ngoài WebM VP9 fixture chưa certify. Native refresh/re-render video có thể reset playback; không đồng bộ media transport state mới vào Core.

## Products và independent control

EXPECTED_PRODUCT/STUDENT_PRODUCT là supplied read-only text snapshots, subject to authored gate. Không tự capture/upload/grade file học sinh.

sampleProduct:{text:string,checkpointStep:integer1..native total}. Checkpoint không hợp lệ/không có sample text thì hidden và không tạo reveal button. Cần native checkpointStep đạt → GV XÁC NHẬN CHECKPOINT → GV HIỆN SẢN PHẨM MẪU. Confirmation không tự reveal; hint/answer/Focus không reveal. PRODUCT_COMPARISON chỉ hiện khi afterStep đạt VÀ sample đã explicit reveal. Nút ẨN removes sample+comparison DOM. Hide/below-checkpoint resets both booleans; same-activation TV reload khôi phục only authorized reveal; new import activation resets.

Profile-local context key gồm lessonActivation, lessonSourceKey, native index; localStorage lưu only checkpoint/sample booleans, BroadcastChannel/storage events notify refresh only. Không chèn fields vào Core state, không bắt Core xử lý protocol mới, không duplicate navigation/controller. Stale teacher buttons kiểm lại current key/count/checkpoint. Same-origin storage availability là runtime prerequisite; unsupported storage báo diagnostic và sample không được falsely PASS.

teacherNote/demoNote/teacherControl là source-authored Teacher-only text; không chuyển sang student content hoặc sample/answer state. Parent source panels remain native privileged interface. Đây là chống pedagogical leak trên TV/Preview, không bảo mật trước người có quyền xem source JSON hoặc same-origin DevTools.

## Focus, fallback và validation

Native answer Focus links code/algorithm/instruction/checkpoint; native content Focus emphasizes task. Previous disclosed proof remains visible/dim; current focus strong; future absent. Clear Focus không đổi native answer mode/count/source/layout/scene/zoom/pan/pointer/board/hint. Picking mode toggle semantics nguyên baseline. Dispose xóa own markers/panel/context; CSS selectors scoped Informatics; retained stylesheet/listener cannot alter inactive Legacy/Geometry/Algebra DOM.

Chỉ tự báo diagnostics bounded; malformed optional records fail closed, không crash. Không sửa Core để sửa dữ liệu hoặc đổi historical descriptor. Core need → STOP before patch, báo policy fields và chờ GV.
'''
(r/'INFORMATICS_PROFILE_CONTRACT.md').write_text(contract)
checks='\n'.join(f"{i+1}. PASS — {c['name']}" for i,c in enumerate(target['checks']))
evidence=f'''# INFORMATICS_PHASE6_TEST_EVIDENCE

Current working targeted26checks PASS, browser Chromium {target['browser']}; fresh unpacked candidate repeats toàn bộ26checks PASS. Required sixteen categories đều được exercise bằng native Teacher import/controls/TV popup, không zero-test/run-only syntax. INFORMATICS_TARGETED.json và PACKAGED_SMOKE/INFORMATICS_TARGETED.json chứa raw assertions/evidence.

## Targeted checks

{checks}

126cases =21screens ×hidden/full ×1920x1080/1366x768/1280x720. Thêm3cases với expected/student/checkpoint/sample/comparison/all3practice steps visible. Assertions kiểm scrollHeight/clientHeight và scrollWidth/clientWidth; không cắt hidden text hoặc đổi source để PASS. Native Focus code3, earlier1, task, checkpoint, algorithm có invariants và clear restoration. Sample requires GV confirmation+reveal; full answer alone hidden. Hint hide loại source khỏi DOM, teacher/private note absent. Local video playback verified currentTime>0,320x180 controls/no autoplay; GIF/image/screenshot/diagram aspect-ratio checked.

## Boundary and negative

PROFILE_BOUNDARIES.json:19PASS. Sample-active Informatics→Legacy/missing/unknown/null/Algebra/Geometry so với frozen Algebra snapshot; dispose removes panel/classes/state/metadata. Detached stale button/new-screen cannot reveal; identical re-import new activation sample hidden. Ungated result, bad future gate, masqueraded sensitive block, negative/string checkpoint, remote media, exe, invalid table, future code fail closed. Literal HTML-looking code không execute; invalid future Focus neither reveals later code nor hides supplied first step. Zero page exceptions/external requests.

## Fresh package smoke/assets

PACKAGED_ASSETS.json:58served files byte-identical to fresh unzip:51root JS/CSS/HTML +3MathJax vendor +3Informatics media +1fixture JSON. Native modal close/reopen/close PASS. Fresh separate server8779; full targeted suite26PASS,126+3viewport cases, source memory unchanged, zero runtime exceptions/externalrequests. ZIP manifest/CRC matches tested working1.239files.

## Preserved failure history

I6-F01 P2: shared cognitive-tv.css hides content under answer disclosure; profile activity/sample was mounted but not visible. Root cause confirmed via selector and native isVisible failure. FIXED with Informatics-only display rule; targeted checks now assert previously disclosed activity/sample visible.

I6-F02 P2: stacked labels/media/native proof spacing overflow when all supplied content visible. Probe Demo scroll/client before:1050/945 at1920,759/664 at1366,721/621 at1280. FIXED with scoped inline labels/spacing/bounded media. Final all126+3cases PASS, every revealed source item preserved. ATTEMPT1/2/3 and successful ATTEMPT4 before extra Algorithm Focus preserved in HARNESS_HISTORY.

Regression comparator initially required PNG SHA equality. Four screenshot pairs exactly equal; four had tiny low-amplitude pixel differences despite all20functional/check evidence equal. Observed max channel difference6/255, at most597pixels of1920x1080 (0.0287905%). Exact source/Core/Algebra asset hashes, authored content and layout guards remain asserted; bounded raster comparison <=8/255 and <=0.1% pixels, alongside exact DOM/checks. No engine patch for screenshot differences; underlying rendering/timing cause not independently confirmed. Initial comparator failure retained. A later unsynchronized footer mismatch was confined to the animated bottom progress bar; HARNESS_HISTORY/FINAL_ALGEBRA_CAPTURE_BEFORE_SYNC/PIXEL_DIAGNOSIS.json records12pixels above8/255 at y1078-1079. External capture helper now waits document-wide finite animations/fonts and finishes finite screenshot animations, preserving all functional assertions and engine files. Final measured captures: {raster['exactCaptureCount']}/8exact, max channel difference{raster['observedMaxChannelDifference']}/255, max changed pixel ratio{raster['observedMaxChangedPixelRatio']:.9%}. ALGEBRA_RASTER_COMPARISON.json contains final measured details; do not substitute historical numbers for final results.

## Unrun/limitations

Native Windows, physical classroom TV, back-row readability, audible TTS, full45minute lesson and real SOẠN_TRƯỚC package acceptance UNRUN. Linux browser fixture tests are engine/profile validation. {preserved} No waiver/deferred/pending promoted to PASS.
'''
(r/'INFORMATICS_PHASE6_TEST_EVIDENCE.md').write_text(evidence)
regression=f'''# INFORMATICS_PHASE6_REGRESSION_REPORT

LEGACY_RUNTIME_REGRESSION=PASS; GEOMETRY_PROFILE_REGRESSION=PASS; ALGEBRA_PROFILE_REGRESSION=PASS. Fresh browser runs, explicit runtime roots/ports, output outside all payloads. References immutable Geometry SHA256 `{sha4}` and Algebra SHA256 `{sha5}`.

## Legacy vs frozen Algebra Phase5

Both runtimes:5original packages,171screens342hidden/fullstates;44visual/DOM/layout metrics,15assertions, lesson memory unchanged, zero exceptions/externalrequests/horizontal/vertical overflow. Real results, metrics and assertions strict equal. Includes original native Demo/Math/Tin contexts, navigation, import, Teacher/Preview/TV/TTS presentation hooks and verticalMCQ. ENGINES/results.json and run logs retained. No audible TTS claim.

## Geometry vs frozen Geometry Phase4

14native checks,35screens70states,23visuals each runtime. GT/KL, source figure, analysis, proof/native revelation, related-object highlight, Focus, zoom/annotation,70/60/fullscreen, object types, whole-lesson fit, verticalMCQ and reload PASS. Checks, real states, visual metrics, image hashes, scopes match. Only separately generated lessonActivation IDs normalized cross-run; intra-run Teacher/Preview/TV parity remains exact.

Existing approved auxiliary G4-F01 patched fixture SHA2564488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8 used externally; bundled Geometry fixture remains byte-identical. {preserved}

## Algebra vs frozen Algebra Phase5

20targeted checks each runtime,10screens,30question viewportcases,12full-answer cases each, MathJax3.2.2/fractions/powers/root/polynomial/transformation/equation/inequality/system/error comparison/hint/answer/Focus/noTeachAhead/TeacherPreview pass. Checks/evidence strict equal; unchanged Algebra JS/CSS/local MathJax/test files exact hashes. Final synchronized captures: {raster['exactCaptureCount']}/8PNGs byte-identical; observed max channel difference {raster['observedMaxChannelDifference']}/255 and changed pixel ratio {raster['observedMaxChangedPixelRatio']:.9%}; exact functional/content/layout checks and bounded raster comparison PASS. See test evidence/raster JSON; do not claim allPNG equality.

## Isolation/disposal

14inherited selection/fallback/negative groups +paired native Demo4screens8states PASS. Additional19Informatics boundary/negative cases includes post-sample cleanup to frozen profile outputs, same lesson re-import reset, stale button guards and fail-closed metadata/media/HTML-looking code. SourceScope confirms Geometry/Algebra/nativeCore untouched; original TVComputerEngine538byte prefix exact.

No Production, main/older candidate branches/ZIPs preserved. Regression technical PASS does not change classroom/real-file states.
'''
(r/'INFORMATICS_PHASE6_REGRESSION_REPORT.md').write_text(regression)
risks=f'''# INFORMATICS_PHASE6_RISK_REGISTER

Open Phase6 engine/profile findings:P0=0,P1=0,P2=0,P3=0. Counts exclude accepted frozen Geometry findings and unrun platform/classroom validation. Two discovered Phase6P2 FIXED/retested; full raw failure history retained, no discarded assertions/fixture edits to conceal failures.

| ID | Severity/state | Confirmed finding | Resolution/evidence |
|---|---|---|---|
| I6-F01 | P2 / FIXED | Native answer CSS hides authored activity host. | Profile-only display override; sample/instruction visibility, Focus and fresh-package re-test PASS. |
| I6-F02 | P2 / FIXED | Visible metadata/media +proof spacing overflow representative full reveal. | Source preserved; local inline labels, spacing and bounded media;126+3viewport cases working/package PASS. |

## Accepted baseline statuses — unchanged

{preserved} Algebra Phase5 approvedPASS/FROZEN SHA256 `{sha5}`; Geometry Phase4 FROZEN SHA256 `{sha4}`. No new claim for G4-F02/F04/F05 or real classroom validation.

## Scope and practical limits

- Synthetic21screen fixture is not SGK, not verified curriculum or real SOẠN_TRƯỚC acceptance. No content generation/automatic grading/curriculum rewrite.
- Windows runtime, actualTV/back-row, audibleTTS/full45minute class UNRUN. Linux Chromium functional/layout evidence only.
- Products are supplied text snapshots; no upload/capture/file execution workflow added. Tables and algorithm rows preserve declared content, no auto-generated flowchart.
- Long unavoidable code/table may scroll inside its wrapper instead of clipping/re-writing; representative cases fit. No guarantee all arbitrary huge packages fit every TV.
- Video WebM VP9/local GIF/images tested. Other browser/codecs/remote media/launcher integration not expanded. Native re-render may reset video playback; no new transport state merged into Core. Profile controls require native preview iframe and same-origin storage/BroadcastChannel. Storage failure reports diagnostic; cannot claim sample synchronization works then.
- Gate fields must be authored correctly. afterStep0 deliberately public; renderer cannot recognize semantic answer leakage that an author places in public content. Missing/invalid numeric gates fail closed. sample policy needs valid positive checkpointStep; Teacher confirms it explicitly.
- Core Phase2 REGISTERED_STUB descriptor left unchanged. Registered Informatics adapter/APIIMPLEMENTED is actual implementation evidence; changing descriptor would require Core authorization and STOP policy.
- Algebra final PNGs:{raster['exactCaptureCount']}/8exact; remaining differences bounded. Underlying cause of any residual pixel drift not independently proven. Exact functional/check evidence/source/layout asserted; no engine patch/waiver to fabricate byte equality.
- Inherited docs/checksums inside candidate are historical. Current identity is external Phase6 reports/manifest/checksums/SHA.
- Environment start instructions saved draft only; user review/save/Publish applies them. Fresh-task restoration not verified. Live server processes may need restart.

No Core change required for this implementation. If later necessary:STOP before patch and report required policy fields. STOP after Phase6 candidate/report; no Production/profile merge/next phase without GV approval.
'''
(r/'INFORMATICS_PHASE6_RISK_REGISTER.md').write_text(risks)
# Record provenance and selected additions without changing frozen payloads.
provenance={'sourceCandidate':'WEB_LIVE_ALGEBRA_PHASE5_CANDIDATE','sourceSHA256':sha5,'existingFileChange':'Append Informatics adapter after exact538byte TVComputerEngine prefix','newFiles':scope['addedFiles'],'fixturePurpose':'Synthetic interface data only; not SGK','fixtureScreens':21,'fixtureBytes':(r/'working/WEB_LIVE_INFORMATICS_PHASE6_WORKING_COPY/INFORMATICS_PHASE6_TEST_PACKAGES/INFORMATICS_PROFILE_REPRESENTATIVE_TEST.json').stat().st_size,'testMedia':'Owned generated SVG, ffmpeg testsrc2 320x180@10fps1s WebM VP9,160x90@5fps1s GIF; no external runtime dependencies','sourceTruth':'Source authored metadata only, no generation in runtime','coreChanges':False,'productionChanges':False}
(r/'INFORMATICS_PATCH_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
new=r/'NEW_FILES';new.mkdir(exist_ok=True)
for rel in scope['addedFiles']:
 dest=new/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/'working/WEB_LIVE_INFORMATICS_PHASE6_WORKING_COPY'/rel,dest)
required=['INFORMATICS_PHASE6_IMPLEMENTATION_REPORT.md','INFORMATICS_PROFILE_CONTRACT.md','INFORMATICS_PHASE6_TEST_EVIDENCE.md','INFORMATICS_PHASE6_REGRESSION_REPORT.md','INFORMATICS_PHASE6_RISK_REGISTER.md']
extras=['FINAL_STATUS.txt','SOURCE_SCOPE.json','FROZEN_BASELINES.json','REGRESSION_SUMMARY.json','PREPACKAGE_GATE.json','PACKAGE_IDENTITY.json','PHASE6_PAYLOAD_MANIFEST.json','INFORMATICS_PHASE6_RUNTIME.patch','PACKAGED_ASSETS.json','CLOUD_DRAFT_STATUS.json','FINDINGS.json','INFORMATICS_PATCH_PROVENANCE.json','ALGEBRA_RASTER_COMPARISON.json']
for name in required+extras:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'working/WEB_LIVE_INFORMATICS_PHASE6_WORKING_COPY/INFORMATICS_PHASE6_TEST_PACKAGES/INFORMATICS_PROFILE_REPRESENTATIVE_TEST.json',out/'INFORMATICS_PROFILE_REPRESENTATIVE_TEST.json')
(out/'README.md').write_text(f'''# WEB LIVE Informatics Phase6 candidate

Candidate-only technical PASS; no Production/Core/Geometry/Algebra mutation/profile merge. STOP awaiting GV approval.

- [Candidate ZIP]({package['zip']}), SHA256 `{sha6}`.
- [Implementation report](INFORMATICS_PHASE6_IMPLEMENTATION_REPORT.md), [profile contract](INFORMATICS_PROFILE_CONTRACT.md), [test evidence](INFORMATICS_PHASE6_TEST_EVIDENCE.md), [regression](INFORMATICS_PHASE6_REGRESSION_REPORT.md), [risk register](INFORMATICS_PHASE6_RISK_REGISTER.md).
- [Small synthetic fixture](INFORMATICS_PROFILE_REPRESENTATIVE_TEST.json) only for tests, not SGK. Use bundled copy inside candidate for relative local media.
- [Raw evidence](INFORMATICS_PHASE6_VALIDATION_EVIDENCE.zip), [final status](FINAL_STATUS.txt), [checksums](CHECKSUMS_SHA256.txt), [payload manifest](PHASE6_PAYLOAD_MANIFEST.json).

Unzip and use existing Windows Chrome start handoff scripts. Import bundled Informatics JSON in Teacher, open TV. Native reveal/hint/answer/Focus retained. Practice sample: reveal checkpoint step2, click XÁC NHẬN CHECKPOINT, then HIỆN SẢN PHẨM MẪU. Full Answer alone cannot reveal sample. Native XÓA TẬP TRUNG clears active selection.

Geometry Phase4 `{sha4}` and Algebra Phase5 `{sha5}` FROZEN. {preserved} Windows/physicalTV/back-row/audibleTTS/real45minute class UNRUN. Core REGISTERED_STUB descriptor remains historical metadata; actual WebLiveInformatics.status=IMPLEMENTED. Inherited payload docs/checksums are historical; use external Phase6 files.

Startup instructions saved draft only; review/save then Publish Environment Settings to apply. Fresh-task restoration not verified.
''')
# Evidence ZIP includes external harnesses, native results/captures and failure history.
evidence=out/'INFORMATICS_PHASE6_VALIDATION_EVIDENCE.zip';excluded={'working','packaged-smoke','download-verification'}
with zipfile.ZipFile(evidence,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for file in sorted(r.rglob('*')):
  if file.is_file() and file.relative_to(r).parts[0] not in excluded and file.suffix not in {'.pyc'} and file.name!='DELIVERY_IDENTITY.json':z.write(file,'INFORMATICS_PHASE6_VALIDATION_EVIDENCE/'+str(file.relative_to(r)))
with zipfile.ZipFile(evidence) as z:
 assert z.testzip() is None
 evidencefiles=len(z.namelist())
identity={'candidateSHA256':sha6,'evidenceSHA256':hashlib.sha256(evidence.read_bytes()).hexdigest(),'evidenceBytes':evidence.stat().st_size,'evidenceFiles':evidencefiles,'deliveryFilesBeforeChecksums':len([p for p in out.iterdir() if p.is_file()])}
(r/'DELIVERY_IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n');shutil.copyfile(r/'DELIVERY_IDENTITY.json',out/'DELIVERY_IDENTITY.json')
checksums=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.txt');(out/'CHECKSUMS_SHA256.txt').write_text(checksums)
print(json.dumps(identity,indent=2));print('Five required reports written; delivery files:',len(list(out.iterdir())))
