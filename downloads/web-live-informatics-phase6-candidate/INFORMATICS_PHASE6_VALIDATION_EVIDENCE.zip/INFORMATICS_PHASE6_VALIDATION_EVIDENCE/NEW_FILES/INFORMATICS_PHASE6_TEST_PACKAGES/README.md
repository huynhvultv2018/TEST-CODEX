# Informatics Phase6 test fixture

Synthetic interface data only. Not SGK, not a curriculum or classroom validation. Native import: select JSON in Teacher; local media are packaged under WEB_LIVE/informatics-test-media. Demo media are generated test patterns. Use native next-step/hint/answer/Focus controls. Practice sample requires native checkpoint step 2, XÁC NHẬN CHECKPOINT then HIỆN SẢN PHẨM MẪU. Full Answer alone cannot reveal the sample.
