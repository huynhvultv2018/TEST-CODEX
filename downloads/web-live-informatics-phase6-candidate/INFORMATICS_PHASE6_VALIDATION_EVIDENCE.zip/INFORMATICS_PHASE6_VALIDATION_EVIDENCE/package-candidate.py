from pathlib import Path
import json,hashlib,zipfile
r=Path(__file__).resolve().parent;root=r/'working/WEB_LIVE_INFORMATICS_PHASE6_WORKING_COPY';out=Path('/workspace/output/web-live-informatics-phase6-candidate');out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();manifest={str(p.relative_to(root)):sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
assert manifest==json.loads((r/'TESTED_PAYLOAD_MANIFEST.json').read_text())
assert json.loads((r/'PREPACKAGE_GATE.json').read_text())['result']=='PASS'
path=out/'WEB_LIVE_INFORMATICS_PHASE6_CANDIDATE.zip';assert not path.exists()
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in sorted(manifest):z.write(root/rel,'WEB_LIVE_INFORMATICS_PHASE6_CANDIDATE/'+rel)
with zipfile.ZipFile(path) as z:
 assert z.testzip() is None
 archive={n.split('/',1)[1]:sha(z.read(n)) for n in z.namelist() if not n.endswith('/')};assert archive==manifest
 dest=r/'packaged-smoke';dest.mkdir();z.extractall(dest)
identity={'candidate':'WEB_LIVE_INFORMATICS_PHASE6_CANDIDATE','zip':path.name,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'payloadFiles':len(manifest),'zipCRC':'PASS','testedPayloadMatch':True,'geometryReferenceSHA256':'9974d9fb4d4e4db023846c0ee42258b3fd193acfe37bd63b8fe6c7d2ee5f9b8e','algebraReferenceSHA256':'575b466dc839d54c6ad91327bc5a7454ece42cbacfd69ae916eca4aa1bcaf01d','productionModified':False}
(r/'PACKAGE_IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity,indent=2))
