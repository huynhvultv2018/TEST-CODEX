const fs=require('fs');
const r=JSON.parse(fs.readFileSync(__dirname+'/FULL_PHASE4_REVALIDATION.json','utf8'));
const result={result:r.result,exitCode:r.result==='PASS'?0:1,targeted:r.targetedResult,closureAllowed:r.closureAllowed,failedNativeChecks:r.failedChecks.map(x=>x.name),acceptanceGaps:r.remainingAcceptance};
fs.writeFileSync(__dirname+'/PHASE4_GATE.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));process.exitCode=result.exitCode;
