const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root='/workspace/TEST-CODEX/WEB_LIVE_GEOMETRY_PHASE3_CANDIDATE',out='/workspace/g4-f01-fixture-revalidation/REGRESSION/ISOLATION';
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),runtimes=[],errors=[],cases=[];
 for(const port of [8771,8773]){
  const c=await b.newContext({viewport:{width:1366,height:768}});c.on('page',p=>p.on('pageerror',e=>errors.push({port,message:e.message})));
  const t=await c.newPage();await t.goto('http://127.0.0.1:'+port+'/WEB_LIVE/teacher.html');await t.locator('#closeBtn').click();
  const pop=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await pop;await tv.waitForLoadState();runtimes.push({c,t,tv,port});
 }
 const p3=runtimes[1];await p3.tv.evaluate(()=>{window.profileCalls=[];for(const id of Object.keys(WebLiveProfiles.profiles))WebLiveProfiles.subscribe(id,Object.fromEntries(WebLiveProfiles.hookNames.map(name=>[name,ctx=>profileCalls.push({id,name,activation:ctx.lessonActivation})])));});
 const svg='data:image/svg+xml;base64,'+Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="600" height="400"><rect width="600" height="400" fill="white"/><path d="M100 300L300 60L500 300Z" fill="none" stroke="navy" stroke-width="4"/></svg>').toString('base64');
 const fixture={id:'profile-isolation',subject:'Hình học 8',title:'Runtime presentation fixture',geometry:{figures:[{id:'triangle',sourceScreenId:1,objects:[{id:'A',type:'point',x:.5,y:.15},{id:'B',type:'point',x:1/6,y:.75},{id:'C',type:'point',x:5/6,y:.75},{id:'AB',type:'segment',from:'A',to:'B'}]}]},screens:[
  {id:1,type:'QUESTION',content:'Câu hỏi từ package.',imageData:svg,steps:['AB = AC','Bước tiếp theo từ package.'],geometry:{figureId:'triangle',givens:['GT_METADATA_ONLY'],goals:['KL_METADATA_ONLY'],proofLinks:[['AB'],['A']]},teacherNote:'PRIVATE_NOTE'},
  {id:2,type:'QUESTION',content:'Chuyển bước vẫn giữ hình.',answer:'Đáp án từ package.'}]};
 const get=()=>({mode:screenEl.dataset.subjectMode,stage:screenEl.dataset.pedagogyStage,index:lastState.index,content:content.textContent,answer:answer.textContent,source:pic.getAttribute('src'),
  visible:['content','analysis','answer','hint'].map(id=>{const n=document.getElementById(id);return !n.hidden&&getComputedStyle(n).display!=='none'}),tts:TTSTVPresentation.blocks.map(({region,text})=>({region,text})),stateKeys:Object.keys(lastState).sort()});
 const values=['geometry',undefined,'','unknown','legacy','algebra','geometry','informatics','legacy'];
 for(let n=0;n<values.length;n++){
  const value=values[n],l=JSON.parse(JSON.stringify(fixture));if(value!==undefined)l.subject_engine=value;
  const targets=value==='geometry'?[p3]:runtimes;
  for(const r of targets){await r.t.evaluate(l=>{saveLesson(l);start(l);revealStep()},l);await r.tv.waitForTimeout(220);}
  const expected=['geometry','algebra','informatics'].includes(value)?value:'legacy';
  assert.equal(await p3.tv.evaluate(()=>WebLiveProfiles.getContext().profileId),expected);
  const activation=await p3.tv.evaluate(()=>lastState.lessonActivation),calls=await p3.tv.evaluate(a=>profileCalls.filter(p=>p.activation===a),activation);assert(calls.length>0);assert(calls.every(p=>p.id===expected));
  if(value==='geometry'){
   assert.equal(await p3.tv.locator('#geometryObjectHighlight [data-geometry-object-id]').count(),1);assert((await p3.tv.locator('#content').textContent()).includes('GT_METADATA_ONLY'));
  }else{
   assert.deepEqual(await p3.tv.evaluate(get),await runtimes[0].tv.evaluate(get));
   for(const page of [p3.t,p3.tv,p3.t.frames().find(f=>f.url().includes('preview=1'))]){
    assert.equal(await page.locator('#geometryObjectHighlight').count(),0);assert.equal(await page.locator('#geometryTeacherControls').count(),0);assert.equal(await page.evaluate(()=>WebLiveGeometry.getState()),null);assert(!await page.locator('#screen').evaluate(e=>e.classList.contains('geometryProfile')));
   }
   assert(!(await p3.tv.locator('body').innerText()).includes('GT_METADATA_ONLY'));
  }
  assert(!(await p3.tv.locator('body').innerText()).includes('PRIVATE_NOTE'));cases.push({input:value===undefined?'MISSING':value,profile:expected,comparedWithPhase2:value!=='geometry',geometryActivated:value==='geometry',selectedHooksOnly:true,result:'PASS'});
 }
 // Optional malformed metadata and dangling links must not reveal future proof or crash.
 for(const kind of ['unknown-figure','missing-source','bad-coordinate','unknown-object','future-focus']){
  const l=JSON.parse(JSON.stringify(fixture));l.subject_engine='geometry';
  if(kind==='unknown-figure')l.screens[0].geometry.figureId='not-registered';
  if(kind==='missing-source'){delete l.screens[0].id;delete l.geometry.figures[0].sourceScreenId;}
  if(kind==='bad-coordinate')l.geometry.figures[0].objects[0].x='not-a-number';
  if(kind==='unknown-object')l.screens[0].geometry.proofLinks[0]=['not-an-object'];
  await p3.t.evaluate(({l,kind})=>{saveLesson(l);start(l);revealStep();if(kind==='future-focus'){classroomController.focus={region:'answer',index:1};render();sync()}},{l,kind});await p3.tv.waitForTimeout(220);
  assert(!((await p3.tv.locator('#answer').textContent()).includes('Bước tiếp theo')));
  if(kind!=='future-focus')assert.equal(await p3.tv.locator('#geometryObjectHighlight [data-geometry-object-id]').count(),0);
  cases.push({input:kind,result:'PASS',futureProofAbsent:true,noCrash:true});
 }
 // Demo remains unchanged, and no navigation request launches a native app.
 const demo=[];
 for(const r of runtimes){await r.t.locator('#zipfile').setInputFiles(root+'/WEB_LIVE/DEMO_TRUC_TIEP_SAMPLE_LIVE.zip');await r.t.waitForFunction(()=>lesson?.screens?.length===4);const states=[];
  for(let i=0;i<4;i++){await r.t.evaluate(i=>go(i),i);await r.tv.waitForTimeout(180);states.push(await r.tv.evaluate(get));await r.t.evaluate(()=>toggleAnswer());await r.tv.waitForTimeout(180);states.push(await r.tv.evaluate(get));}demo.push(states);
 }
 assert.deepEqual(demo[0],demo[1]);assert.equal(errors.length,0);
 assert(!await p3.tv.evaluate(()=>WebLiveProfiles.getDiagnostics().some(d=>d.code==='ADAPTER_ERROR'||d.code==='HOOK_ERROR')));
 fs.writeFileSync(out+'/profile-isolation.json',JSON.stringify({browser:b.version(),cases,errors,algebraProfileIsolation:'PASS',informaticsProfileIsolation:'PASS',legacyOptionalMetadata:'PASS',demoScreens:4,demoStates:8,demoMatch:true,nativeWindowsAudio:'UNRUN'},null,2));await b.close();console.log('PASS '+cases.length+' profile isolation/negative cases + paired Demo');
})().catch(e=>{console.error(e);process.exit(1)});
