from pathlib import Path
import json,hashlib,zipfile,shutil,csv,urllib.request
from datetime import datetime,timezone
p=Path(__file__).resolve().parent
read=lambda n:json.loads((p/n).read_text())
write=lambda n,x:(p/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
c=read('CLASSROOM_VALIDATION.json');tv=read('WHOLE_LESSON_TV.json');reg=read('REGRESSION_SUMMARY.json');target=read('TARGETED_G4F01.json');patch=read('FIXTURE_PATCH_VERIFICATION.json');imm=read('SOURCE_IMMUTABILITY.json')
assert len(c['continuousFlow'])==35 and len(c['readability'])==24 and not c['errors'] and not c.get('harnessError')
assert tv['states']==140 and tv['overflowCases']==[] and not tv['errors']
assert target['result']==patch['result']==reg['result']==imm['result']=='PASS'
sha=lambda b:hashlib.sha256(b).hexdigest()
source=Path(c['source']);served=[]
for port,root in [(8773,source),(8771,Path('/workspace/TEST-CODEX/WEB_LIVE_MULTI_CORE_PHASE2_CANDIDATE'))]:
 for rel in ['WEB_LIVE/teacher.html','WEB_LIVE/tv.html','WEB_LIVE/core-profiles.js','WEB_LIVE/common.js']:
  data=urllib.request.urlopen(f'http://127.0.0.1:{port}/{rel}').read();h=sha((root/rel).read_bytes());assert sha(data)==h
  served.append({'port':port,'path':rel,'sha256':h,'servedBytesMatchSource':True})
write('SERVED_RUNTIME_IDENTITY.json',{'result':'PASS','checks':served})
groups=[]
with zipfile.ZipFile(p/patch['patched_fixture']) as z:
 for name,a,b,img in [('VD2',5,10,'VD2_H331.png'),('LT2',11,19,'LT2_H332.png'),('TT2',20,20,'TT2_H333.png'),('VD3',23,25,'VD3_H334.png'),('LT3',26,28,'LT3_Hinh.png'),('VDU',29,32,'VDU_H327.png')]:
  expected=sha(z.read('images/'+img));rows=c['continuousFlow'][a:b+1];snapshots=[s for r in rows for s in [r['hidden'],*r['revealed']]]
  assert all(s['imageSha256']==expected for s in snapshots)
  assert len({s['scope'] for s in snapshots})==1
  groups.append({'name':name,'startIndex':a,'endIndex':b,'expectedImage':img,'expectedSHA256':expected,'screens':len(rows),'checkedStates':len(snapshots),'baseImageAndScopePersist':'PASS'})
write('PERSISTENT_GEOMETRY_FULL_LESSON.json',{'result':'PASS','groups':groups,'scope':'Persistent base and scope within each exercise, including all disclosed analysis/answer states. New exercise boundaries separately tested by TARGETED_G4F01.json. No new missing scene boundary observed.'})
old=Path('/workspace/phase4-geometry-validation');(p/'HISTORY').mkdir(exist_ok=True)
for name in ['FINDINGS.json','PHASE4_FINAL_STATUS.json','RISK_VALIDATION.json','GEOMETRY_PHASE4_FINDINGS.md','PACKAGE_PROVENANCE.json']:
 shutil.copy2(old/name,p/'HISTORY'/name)
history=read('HISTORY/FINDINGS.json')
findings=[]
for f in history:
 r=dict(f);r['historicalEvidence']=r.pop('evidence');r['historicalCause']=r.pop('cause');r['historicalRecommendation']=r.pop('recommendation')
 if f['id']=='G4-F01':
  r.update(classification='P1 (HISTORICAL ORIGINAL FIXTURE)',coreOrGeometryProfile='LESSON_PACKAGE',rootCauseConfirmed=True,rootCause='lesson.json screens[19] lacks the existing sceneEnd contract. Original control reproduces LT2 at all four new exercises; adding only sceneEnd=true clears the timeline and restores all four exact image hashes in unchanged engine.',patchedFixtureReproduces=False,status='TARGETED_PASS_PENDING_FULL_PHASE4_PASS',evidence=['FIXTURE_ONLY_PATCH.diff','FIXTURE_PATCH_VERIFICATION.json','TARGETED_G4F01.json','PERSISTENT_GEOMETRY_FULL_LESSON.json'],activeSeverityOnPatchedFixture=None)
 elif f['id']=='G4-F02':
  r.update(classification='P3',coreOrGeometryProfile='CORE',rootCauseConfirmed=True,rootCause='Existing teacher.js:39 go() invokes resetView(); teacher.js:10 resets zoom and pan for every screen.',reproducible=True,status='OPEN',evidence=['CLASSROOM_VALIDATION.json#/stateTests/5','CLASSROOM_VALIDATION.json#/checks/7'],activeSeverityOnPatchedFixture='P3')
 elif f['id']=='G4-F03':
  r.update(classification='P2',coreOrGeometryProfile='GEOMETRY_PROFILE',rootCauseConfirmed=True,rootCause='Existing geometry-profile.css:7-8 hides previous/nonfocused proof blocks with display:none. Native DOM confirms disclosed step 2 is hidden although answerStep=2.',reproducible=True,status='OPEN',evidence=['CLASSROOM_VALIDATION.json#/focus','CAPTURES/FOCUS_PROOF_1.png','CLASSROOM_VALIDATION.json#/checks/5'],activeSeverityOnPatchedFixture='P2')
 elif f['id']=='G4-F04':
  r.update(classification='P3',coreOrGeometryProfile='UNKNOWN',rootCauseConfirmed=False,rootCause='Physical readability/scaling cause and impact are not confirmed; measured DPR1 viewport typography is 42–52 CSS px at 4K.',status='OPEN_CONTROLLED_RISK',evidence=['CLASSROOM_VALIDATION.json#/readability','CAPTURES/TV_3840x2160_S10_60.png'],activeSeverityOnPatchedFixture='P3')
 else:
  r.update(classification='P2 — VALIDATION_GAP',coreOrGeometryProfile='LESSON_PACKAGE',rootCauseConfirmed=False,rootCause='Full SOẠN_TRƯỚC producer and authoring workflow not demonstrated. Missing metadata on original selects Legacy by contract; it is not evidence of an engine fault.',status='OPEN_PARTIAL_UNRUN',evidence=['CLASSROOM_VALIDATION.json#/originalImport','CLASSROOM_VALIDATION.json#/setup','CLASSROOM_VALIDATION.json#/proofCoverage','HISTORY/PACKAGE_PROVENANCE.json'],activeSeverityOnPatchedFixture='P2')
 findings.append(r)
write('FINDINGS_REVALIDATED.json',findings)
risks=[]
for r in read('HISTORY/RISK_VALIDATION.json'):
 v=dict(r)
 if r['RISK_ID']=='G3-R01':
  v.update(OBSERVATION='Exact approved boundary patch fixes all four images and isolates LT2 context. All six image/scope groups pass. Authored links still cover 4 of 49 answer/proof blocks; full authoring acceptance is partial, without assuming all 49 need links.',VALIDATION_STATUS='CONTROLLED_RISK — G4-F01 targeted PASS; formal closure pending full Phase4 PASS',BLOCKING='NO current P0/P1 runtime blocker on patched fixture',EVIDENCE='TARGETED_G4F01.json; PERSISTENT_GEOMETRY_FULL_LESSON.json; CLASSROOM_VALIDATION.json/proofCoverage; G4-F05')
 else:
  v['EVIDENCE']='Fresh CLASSROOM_VALIDATION.json; WHOLE_LESSON_TV.json; GT_KL_CONTRAST.json. Historical Phase3 evidence remains historical.'
 risks.append(v)
inherited=[('P2-R01','Shared Core globals','UNCHANGED_OPEN'),('P2-R02','Legacy stage divergence','PAIRED_REGRESSION_PASS — broader design risk remains open'),('P2-R03','Windows/physical TV/audible TTS/native classroom','UNRUN_OPEN'),('P2-R04','Real Algebra provenance','OUT_OF_SCOPE_OPEN'),('P2-R05','Malformed board packets','OUT_OF_SCOPE_OPEN — selected profile negative probes do not close whole packet risk'),('P2-R06','Offscreen preview TTS timing','UNRUN_OPEN')]
for rid,trigger,status in inherited:risks.append({'RISK_ID':rid,'TRIGGER':trigger,'VALIDATION_STATUS':status,'BLOCKING':'NO newly demonstrated P0/P1 blocker in this revalidation','EVIDENCE':'Fresh REGRESSION_SUMMARY.json where applicable; historical risk retained, not closed'})
write('RISK_RECLASSIFICATION.json',{'remainingRiskCount':9,'geometryRisks':3,'inheritedRisks':6,'blockingRiskCount':0,'blockingCountScope':'Current reproducible P0/P1 runtime issues on patched fixture, using prior BLOCKING/DISRUPTIVE/MINOR scheme. Zero does not imply every Phase4 acceptance gate is PASS; Focus/zoom failures and incomplete authoring/physical validation prevent full PASS.','risks':risks})
status={
 'PHASE3_CANDIDATE_SHA256_BEFORE':imm['candidateSHA256Before'],
 'PHASE3_CANDIDATE_SHA256_AFTER':imm['candidateSHA256After'],
 'PHASE3_CANDIDATE_MUTATED':'NO',
 'FIXTURE_ORIGINAL_SHA256':patch['original_sha256'],
 'FIXTURE_PATCHED_SHA256':patch['patched_sha256'],
 'G4_F01_PATCH_SCOPE':'FIXTURE_ONLY — /screens/19/sceneEnd=true',
 'G4_F01_TARGETED_TEST':'PASS',
 'G4_F01_STATUS':'TARGETED_PASS_PENDING_FULL_PHASE4_PASS',
 'SCREEN_20_IMAGE':'TT2_H333.png — PASS',
 'SCREEN_23_IMAGE':'VD3_H334.png — PASS',
 'SCREEN_26_IMAGE':'LT3_Hinh.png — PASS',
 'SCREEN_29_IMAGE':'VDU_H327.png — PASS',
 'REAL_LESSON_LOAD':'PASS',
 'PREP_TO_LIVE_FLOW':'PARTIAL — authored ZIP import PASS; SOẠN_TRƯỚC producer UNRUN',
 'PERSISTENT_GEOMETRY_REAL_LESSON':'PASS',
 'PROOF_FIGURE_LINK':'PARTIAL — authored VD2 links PASS; full-lesson authoring not certified',
 'GT_KL_READABILITY':'PASS — tested equivalent viewports/contrast',
 'LAYOUT_70_30':'PASS',
 'LAYOUT_60_40':'PASS',
 'FIGURE_FULLSCREEN':'PASS',
 'GEOMETRY_FOCUS_REAL_LESSON':'FAIL — G4-F03',
 'FIGURE_ZOOM_REAL_LESSON':'FAIL — G4-F02 navigation; zoom/return PASS',
 'ANNOTATION_REAL_LESSON':'PASS',
 'TV_READABILITY':'PARTIAL — viewport fit PASS; physical/last-row acceptance UNRUN',
 'TEACHER_OPERABILITY':'PARTIAL — native controls PASS; G4-F02/F03 remain',
 'CLASSROOM_FLOW':'PARTIAL — 35-screen software flow PASS; actual class UNRUN',
 'P0_COUNT':0,'P1_COUNT':0,'P2_COUNT':2,'P3_COUNT':2,
 'REMAINING_RISK_COUNT':9,'BLOCKING_RISK_COUNT':0,
 'LEGACY_RUNTIME_REGRESSION':'PASS',
 'ALGEBRA_PROFILE_ISOLATION':'PASS',
 'INFORMATICS_PROFILE_ISOLATION':'PASS',
 'SOURCE_SCOPE_VIOLATION':'NO','PRODUCTION_MODIFIED':'NO',
 'PHASE4_STATUS':'NOT_PASS',
 'RECOMMENDED_NEXT_ACTION':'GV review G4-F02–F05 and separately approve any remediation/native acceptance. STOP.'}
write('FINAL_STATUS.json',status)
(p/'FINAL_STATUS.txt').write_text('\n'.join(f'{k} = {v}' for k,v in status.items())+'\n')
write('FULL_PHASE4_REVALIDATION.json',{'result':'NOT_PASS','targetedResult':'PASS','closureAllowed':False,'nativeChecks':{'executed':len(c['checks']),'pass':sum(v['result']=='PASS' for v in c['checks']),'fail':sum(v['result']=='FAIL' for v in c['checks'])},'failedChecks':[r for r in c['checks'] if r['result']=='FAIL'],'all35ScreensWalked':True,'revealedAnswerProofBlocks':len(c['proofCoverage']),'authoredProofLinkBlocks':sum(r['hasAuthoredLink'] for r in c['proofCoverage']),'wholeLessonTVStates':tv['states'],'layoutViewportCases':len(c['readability']),'remainingAcceptance':'SOẠN_TRƯỚC/full authoring, Windows/physical TV/last-row/audible TTS/actual GV class UNRUN or partial.','evaluatedAtUTC':datetime.now(timezone.utc).isoformat(),'gateStatuses':{k:v for k,v in status.items() if k in ['REAL_LESSON_LOAD','PREP_TO_LIVE_FLOW','PERSISTENT_GEOMETRY_REAL_LESSON','PROOF_FIGURE_LINK','GT_KL_READABILITY','LAYOUT_70_30','LAYOUT_60_40','FIGURE_FULLSCREEN','GEOMETRY_FOCUS_REAL_LESSON','FIGURE_ZOOM_REAL_LESSON','ANNOTATION_REAL_LESSON','TV_READABILITY','TEACHER_OPERABILITY','CLASSROOM_FLOW']}})
with (p/'TV_READABILITY_MATRIX.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['width','height','layout','index','font_min_px','font_max_px','text_overflow','horizontal_overflow','student_teacher_controls'])
 for r in c['readability']:w.writerow([*r['size'],r['layout'],r['index'],min(v['fontPx'] for v in r['rows']),max(v['fontPx'] for v in r['rows']),r['snapshot']['overflow'],r['snapshot']['horizontalOverflow'],r['snapshot']['studentControlCount']])
(p/'G4_F01_FIXTURE_PATCH_REPORT.md').write_text(f'''# G4-F01 — fixture-only patch and full revalidation

Targeted correction **PASS**. Full Phase4 **NOT_PASS**, therefore G4-F01 is **TARGETED_PASS_PENDING_FULL_PHASE4_PASS**, not CLOSED. The user explicitly requires full Phase4 PASS for closure. Historical finding is preserved in HISTORY; original fixture remains unchanged.

## Approved change

Only `lesson.json /screens/19/sceneEnd` (screen20, “Chốt ý b”) is added as `true`, using the existing contract. `geometry-profile.js:32` already clears the previous figure on the next screen when the previous screen ends. Original fixture reproduces LT2 at all four targets; changing this one metadata field in a new fixture removes that override with the same runtime. Root cause **CONFIRMED — LESSON_PACKAGE**. No engine, Core, visual resolution, proof or other scene changes.

- Candidate before/after SHA256: `{imm['candidateSHA256After']}`; all 1,227 files equal approved ZIP.
- Original fixture SHA256: `{patch['original_sha256']}`.
- Patched fixture SHA256: `{patch['patched_sha256']}`.
- JSON deep difference: one field. Manifest and all 15 images are byte-identical. CRC PASS. Content/question/answer/hint/proof/GT/KL/text unchanged.

## Image and boundary evidence

| JSON index | UI screen | Exact expected/actual PNG SHA256 |
|---|---|---|
|20|21|TT2_H333.png — b59beaa64e5521a2d5fa46a15c6caf9172e0e52beadd5831f645a4e613cb5cb7|
|23|24|VD3_H334.png — 56f16f50c03069ebf19780f42704eaf216b01f4915f1499eb49aa3193a073c62|
|26|27|LT3_Hinh.png — df741e56c51d49a3055189d4342a97e60cb753baf211a34b52d4f41c89bd5740|
|29|30|VDU_H327.png — 12e1f76365535da45ecebf10ad3306b499b7e008f10b411faafa0d57ecbfd81d|

`TARGETED_G4F01.json` includes original-control actual hash f2dabdd956f7499d913e222756f161243799c295747768188f8bb073076c75b4 and new actual decoded PNG hashes. Nine screenshots compare original/patched and boundary. Index18 BEFORE, index19 AT sceneEnd retain LT2; index20 AFTER clears Geometry figureId/sceneId, restores actual TT2 image and hides/reset proof/analysis; index23 NEXT exercise has correct own image. No annotation/highlight/context leaks. Returning to LT2 restores its own annotation. Teacher preview/actual TV image parity PASS.

Full walk additionally verifies VD2, LT2, TT2, VD3, LT3 and VDU base images/scopes across hidden and all disclosed states. No other missing boundary observed, and no other scene was patched.

## Full Phase4 and fresh regression

Native Linux Chromium {c['browser']}; actual Teacher popup TV and native UI/keyboard/drawing. 35 screens, 49 answer/proof blocks, 4 analysis steps, 140 whole-lesson TV states, 24 layout/viewport cases. 13/15 native assertions PASS; the two failed assertions are retained, not bypassed. The browser helper process completion code 0 means the capture run completed; full acceptance is evaluated separately and fails.

| Gate | Result |
|---|---|
'''+''.join(f"|{k}|{v}|\n" for k,v in status.items() if k in ['REAL_LESSON_LOAD','PREP_TO_LIVE_FLOW','PERSISTENT_GEOMETRY_REAL_LESSON','PROOF_FIGURE_LINK','GT_KL_READABILITY','LAYOUT_70_30','LAYOUT_60_40','FIGURE_FULLSCREEN','GEOMETRY_FOCUS_REAL_LESSON','FIGURE_ZOOM_REAL_LESSON','ANNOTATION_REAL_LESSON','TV_READABILITY','TEACHER_OPERABILITY','CLASSROOM_FLOW'])+'''
Authored proof links pass where supplied: 4 of 49 answer/proof blocks have links. This is coverage evidence; it does not assume every short answer needs highlight. Other real proof authoring has not been accepted. Import/use of the already-authored patched ZIP requires zero runtime data edits; the end-to-end SOẠN_TRƯỚC authoring intervention count remains UNRUN. Original real lesson lacks subject_engine and correctly resolves Legacy.

Legacy regression is a fresh paired Phase2/Phase3 run: 5 real original packages, 171 screens/342 states per runtime; Demo adds 4 screens/8 states. All real states, 44 visual metrics and 15 assertions per runtime match exactly. Zero overflow, runtime exceptions and external requests. 14 isolation/negative groups PASS, including Geometry cleanup when switching to Algebra/Informatics/Legacy. Interface probes are regression fixtures, distinct from real lesson pedagogy evidence. No historical test output is claimed as a new run.

## Remaining findings and acceptance

- G4-F02 **P3/MINOR**: same VD2 figure index9→10 resets zoom 1.15→1; base and annotations persist. Existing teacher.js:39→10 confirms resetView. Zoom/return itself PASS.
- G4-F03 **P2/DISRUPTIVE**: opening two proof steps then focusing step1 hides disclosed step2 (`display:none`, opacity .52), despite answerStep=2. Existing geometry-profile.css:7–8 confirms cause. Focus current objects PASS; proof context FAIL.
- G4-F04 **P3/MINOR, controlled risk**: 4K DPR1 fonts42–52px; viewport fit PASS, physical/scaling/last-row readability not confirmed.
- G4-F05 **P2/DISRUPTIVE validation gap**: full SOẠN_TRƯỚC producer/provenance and whole-lesson link authoring remain unverified. This is not a proven engine bug. No root cause for a producer failure is invented.

P0=0/P1=0 counts current reproduced runtime blockers on **patched fixture**, not the unchanged original control. G4-F01 retains its historical P1 record and remains pending formal closure because full acceptance is NOT_PASS. Existing DISRUPTIVE→P2 and MINOR→P3 mapping yields P2=2/P3=2; counts include the stated validation gap. Remaining risk ledger is 3 Geometry + 6 inherited =9. BlockingRiskCount=0 retains the prior technical P0/P1 scheme; Focus/zoom failures and partial/unrun acceptance still prevent full PASS. These are different measures.

Windows runtime, physical TV, audible TTS, actual GV45-minute class and students at the back are UNRUN. No claim of production/classroom certification. Source scope violation NO, Production modified NO. No Phase3 RC2, new engine candidate or next phase.

STOP. GV reviews G4-F02–F05 and separately authorizes any remediation or native acceptance.
''')
(p/'README.md').write_text('''# G4-F01 fixture revalidation delivery

**Fixture-only patch targeted PASS; full Phase4 NOT_PASS. G4-F01 is not formally CLOSED.**

Import `HINH8_VD2_GEOMETRY_PROFILE_TEST_G4F01_PATCHED.zip` into the **unchanged approved Phase3 runtime**. This ZIP is a lesson test fixture, not an engine/candidate replacement. Original fixture is retained under ORIGINAL_FIXTURE. Only `screens[19].sceneEnd=true` differs.

Read G4_F01_FIXTURE_PATCH_REPORT.md, FINAL_STATUS.txt and FINDINGS_REVALIDATED.json. Audit ZIP contains fresh raw results, native captures, helpers, exact latest approval, source manifests, original/patched lessons/fixtures and immutable previous Phase4 finding history. Source engine files are not repackaged as a new candidate.

Screens in UI are 1-based; JSON indices and final SCREEN_20/23/26/29 keys are 0-based per request. Native tests run Linux Chromium; Windows/physical TV/classroom acceptance remains unrun. Retain source Phase3 candidate SHA256 8817889abb9e98e9e3c60e191be510215e02030d309c2aacaaad1e1f663dd23c.

External scripts require retained source roots and local servers8773 (Phase3) /8771 (Phase2), Python3, Node, /usr/bin/chromium and Playwright with NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules. Do not run inherited scripts with their default evidence paths inside immutable candidate. All outputs must remain external. No worktrees needed.

STOP after report; further changes/phase/Production require a new explicit GV request.
''')
print(json.dumps({'targeted':'PASS','fullPhase4':'NOT_PASS','regression':'PASS','source':'IMMUTABLE','groups':len(groups),'nativePass':13,'nativeFail':2}))
