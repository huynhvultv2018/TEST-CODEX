﻿#requires -Version 5.1
# Synthetic toolkit fixtures only. No R4 import, actual OS queries, identity or license changes.
. (Join-Path $PSScriptRoot 'Common.ps1')
function Assert-CollectionTest([bool]$OK,[string]$Label) {
    if (-not $OK) { throw "FAIL: $Label" }
    Write-Output ('PASS: '+$Label.TrimEnd())
}
function New-Fixture([int]$Index) {
    return [pscustomobject]@{
        IPAddress="192.0.2.$Index"; AddressState='Preferred'; InterfaceAlias='TEST_ONLY'; InterfaceIndex=$Index
        LocalAddress='0.0.0.0'; OwningProcess=0; Name="TEST_ONLY_$Index"; Enabled=$true; Action='Allow'; Profile='Private'
        Protocol='TCP'; LocalPort='5000'; InstanceID="TEST_ONLY_$Index"
    }
}
$one=New-Fixture 21; $two=@((New-Fixture 22),(New-Fixture 23)); $many=@(24..28 | ForEach-Object { New-Fixture $_ })
$cases=@(
    [pscustomobject]@{Name='CASE01_NULL';Value=$null;Count=0;ValidIP=0},
    [pscustomobject]@{Name='CASE02_ZERO';Value=[object[]]@();Count=0;ValidIP=0},
    [pscustomobject]@{Name='CASE03_ONE_OBJECT';Value=[version]'1.2.3.4';Count=1;ValidIP=0},
    [pscustomobject]@{Name='CASE04_TWO';Value=$two;Count=2;ValidIP=2},
    [pscustomobject]@{Name='CASE05_MANY';Value=$many;Count=5;ValidIP=5},
    [pscustomobject]@{Name='CASE06_SCALAR_STRING';Value='TEST_ONLY_STRING';Count=1;ValidIP=0},
    [pscustomobject]@{Name='CASE07_PSCUSTOMOBJECT';Value=$one;Count=1;ValidIP=1},
    [pscustomobject]@{Name='CASE08_PSCUSTOMOBJECT_ARRAY';Value=@((New-Fixture 31),(New-Fixture 32),(New-Fixture 33));Count=3;ValidIP=3}
)
$script:Fixture=$null; $script:FailureMode='NONE'; $script:ContractMode=$false
$script:Calls=New-Object 'System.Collections.Generic.List[string]'
$script:Urls=New-Object 'System.Collections.Generic.List[string]'
function Get-Command([string]$Name,[object]$ErrorAction) {
    if ($script:FailureMode -eq 'MISSING') { return $null }
    return Microsoft.PowerShell.Core\Get-Command -Name $Name -ErrorAction SilentlyContinue
}
function Emit-Fixture([string]$Command) {
    $script:Calls.Add($Command)
    if ($script:FailureMode -eq 'DENIED') { throw (New-Object UnauthorizedAccessException 'TEST_ONLY') }
    if ($script:FailureMode -eq 'UNAVAILABLE') { throw 'TEST_ONLY_QUERY_FAILED' }
    if ($script:FailureMode -eq 'NOT_FOUND') {
        $errorRecord=New-Object System.Management.Automation.ErrorRecord (New-Object Exception 'TEST_ONLY'),'CmdletizationQuery_NotFound',([System.Management.Automation.ErrorCategory]::ObjectNotFound),$null
        throw $errorRecord
    }
    return $script:Fixture
}
function Get-NetIPAddress { Emit-Fixture 'Get-NetIPAddress' }
function Get-NetTCPConnection { Emit-Fixture 'Get-NetTCPConnection' }
function Get-NetFirewallProfile { Emit-Fixture 'Get-NetFirewallProfile' }
function Get-NetFirewallRule { Emit-Fixture 'Get-NetFirewallRule' }
function Get-NetFirewallPortFilter { Emit-Fixture 'Get-NetFirewallPortFilter' }
function Get-NetConnectionProfile { Emit-Fixture 'Get-NetConnectionProfile' }
function Get-CimInstance { Emit-Fixture 'Get-CimInstance' }
function Get-Process { Emit-Fixture 'Get-Process' }
function Test-Connection { Emit-Fixture 'Test-Connection' }
function Test-NetConnection { Emit-Fixture 'Test-NetConnection' }
function Get-HttpResult([string]$Url) {
    $script:Urls.Add($Url)
    if ($script:ContractMode) { $script:Calls.Add('Get-HttpResult'); return 'HTTP_STATUS = 200; HTTP_ACCESS = PASS' }
    Emit-Fixture 'Get-HttpResult'
}
function Get-ChildItem { Emit-Fixture 'Get-ChildItem' }
function Import-Csv { Emit-Fixture 'Import-Csv' }
foreach ($case in $cases) {
    $script:Fixture=$case.Value; $script:Calls.Clear()
    $records=ConvertTo-Records $case.Value
    Assert-CollectionTest ($records -is [object[]] -and $records.Length -eq $case.Count) "$($case.Name) normalized array"
    Assert-CollectionTest ((Get-RecordCount $case.Value) -eq $case.Count) "$($case.Name) count"
    foreach ($command in @('Get-NetIPAddress','Get-NetTCPConnection','Get-NetFirewallRule','Get-NetFirewallPortFilter','Get-NetFirewallProfile','Get-NetConnectionProfile')) {
        $data=Get-ReadOnlyData $command
        Assert-CollectionTest ($data.Items -is [object[]] -and $data.RecordCount -eq $case.Count) "$($case.Name) $command collection"
        $status=if ($case.Count -eq 0) { 'NOT_FOUND' } else { 'FOUND' }
        Assert-CollectionTest ($data.Status -ceq $status) "$($case.Name) $command status"
    }
    $ips=Get-LanDiscovery; $addresses=Get-LanAddresses
    Assert-CollectionTest ($ips.RecordCount -eq $case.ValidIP -and $addresses -is [object[]] -and $addresses.Length -eq $case.ValidIP) "$($case.Name) IP discovery and array return boundary"
    $http=Format-HttpProbeResults 'TEST_ONLY' $case.Value
    $lineCount=[Math]::Max(1,$case.Count)
    Assert-CollectionTest ($http -is [string[]] -and $http.Length -eq $lineCount -and (Get-RecordCount ($http | Where-Object { $_ -match 'UNAVAILABLE' })) -eq $lineCount) "$($case.Name) HTTP unexpected or absent results handled"
    $csv=Read-ResultCsv 'TEST_ONLY.csv'; $files=Get-ResultFiles
    Assert-CollectionTest ($csv -is [object[]] -and $csv.Length -eq $case.Count) "$($case.Name) CSV result collection"
    Assert-CollectionTest ($files -is [object[]] -and $files.Length -eq $case.Count) "$($case.Name) evidence-file collection"
    $report=Get-ServerLanReport 5000
    Assert-CollectionTest ($report -is [string[]] -and $report -contains 'PORT = 5000' -and $report -contains 'R4_LAN_STATUS = NOT_YET_DETERMINED') "$($case.Name) step03 completes without collection exception"
    Assert-CollectionTest (($report -join "`n") -match "LISTENING_PORT = $status; RECORD_COUNT = $($case.Count)") "$($case.Name) step03 listener count semantics"
    Assert-CollectionTest ($script:Calls -contains 'Get-HttpResult') "$($case.Name) loopback probe still performed"
}
$script:Fixture=@($null,$one,$null)
Assert-CollectionTest ((Get-RecordCount $script:Fixture) -eq 1) 'null entries excluded; one real record retained'
$script:Fixture=$false
Assert-CollectionTest ((Get-RecordCount $false) -eq 1 -and -not (Get-BooleanProbe 'Test-Connection' @{}).Succeeded) 'false boolean is a record, not absent data'
$script:Fixture=$true
Assert-CollectionTest ((Get-BooleanProbe 'Test-NetConnection' @{}).Succeeded) 'true quiet TCP result retained'
$badCount=New-Fixture 41; $badCount | Add-Member -NotePropertyName Count -NotePropertyValue 999
Assert-CollectionTest ((Get-RecordCount $badCount) -eq 1) 'object Count property cannot masquerade as record count'
foreach ($mode in @('DENIED','UNAVAILABLE','MISSING','NOT_FOUND')) {
    $script:FailureMode=$mode
    $expectedStatus=switch ($mode) { 'DENIED' {'ACCESS_DENIED'} 'UNAVAILABLE' {'UNAVAILABLE'} 'MISSING' {'NOT_APPLICABLE'} 'NOT_FOUND' {'NOT_FOUND'} }
    foreach ($command in @('Get-NetIPAddress','Get-NetTCPConnection','Get-NetFirewallProfile','Get-NetFirewallRule','Get-NetFirewallPortFilter','Get-NetConnectionProfile','Get-CimInstance','Get-Process')) {
        $data=Get-ReadOnlyData $command
        Assert-CollectionTest ($data.Status -ceq $expectedStatus -and $data.RecordCount -eq 0 -and $data.Items -is [object[]]) "$mode $command degrades to $expectedStatus"
    }
    $report=Get-ServerLanReport 5000
    foreach ($name in @('WINDOWS_INFORMATION','LISTENING_PORT','IPv4_LAN','FIREWALL_STATE','FIREWALL_INBOUND_RULES','FIREWALL_PORT_FILTERS','ACTIVE_NETWORK')) {
        Assert-CollectionTest (($report -join "`n") -match "$name = $expectedStatus; RECORD_COUNT = 0") "$mode step03 $name"
    }
    Assert-CollectionTest ($report -contains 'R4_LAN_STATUS = NOT_YET_DETERMINED') "$mode no invented R4 LAN verdict"
}
$script:FailureMode='NONE'
$script:Fixture=[pscustomobject]@{IPAddress='127.0.0.1';AddressState='Preferred'}
Assert-CollectionTest ((Get-LanDiscovery).RecordCount -eq 0) 'loopback excluded from LAN IP list'
$script:Fixture=[pscustomobject]@{IPAddress='169.254.1.2';AddressState='Preferred'}
Assert-CollectionTest ((Get-LanDiscovery).RecordCount -eq 0) 'link-local excluded from LAN IP list'
$script:Fixture=[pscustomobject]@{IPAddress='not-an-ip';AddressState='Preferred'}
Assert-CollectionTest ((Get-LanDiscovery).Status -ceq 'UNAVAILABLE') 'malformed IP schema unavailable, no HTTP target constructed'
foreach ($ports in @('5000','Any','4990-5010',@('80','5000'),'80,5000')) {
    Assert-CollectionTest (Test-FirewallPort ([pscustomobject]@{Protocol='TCP';LocalPort=$ports}) 5000) 'matching TCP port filter retained'
}
Assert-CollectionTest (-not (Test-FirewallPort ([pscustomobject]@{Protocol='UDP';LocalPort='5000'}) 5000)) 'UDP filter is not TCP'
Assert-CollectionTest (-not (Test-FirewallPort ([pscustomobject]@{Protocol='TCP';LocalPort='80'}) 5000)) 'other port filter is not port 5000'
Assert-CollectionTest (-not (Test-FirewallPort $null 5000)) 'null port filter handled'
Assert-CollectionTest (-not (Test-FirewallPort ([pscustomobject]@{Protocol='TCP';LocalPort='999999999999-9999999999999'}) 5000)) 'malformed range never throws overflow'
$contract=New-Fixture 51
$contract.OwningProcess=1234
$contract | Add-Member -NotePropertyMembers @{ Caption='WINDOWS_TEST_ONLY';Version='10_TEST_ONLY';ProcessName='PROCESS_TEST_ONLY';DefaultInboundAction='Block';NetworkCategory='Private' }
$script:Fixture=$contract; $script:ContractMode=$true; $script:Urls.Clear()
$report=Get-ServerLanReport 5000
$joined=$report -join "`n"
foreach ($text in @('PORT = 5000','WINDOWS = WINDOWS_TEST_ONLY; VERSION = 10_TEST_ONLY','POWERSHELL = ','IPv4_LAN = FOUND; RECORD_COUNT = 1','LISTENING_PORT = FOUND; RECORD_COUNT = 1','LISTENER_PROCESS = FOUND; PID = 1234','PROCESS_NAME = PROCESS_TEST_ONLY','LAN_BINDING = PRESENT; REMOTE_ACCESS_NOT_YET_CONFIRMED','LOOPBACK : HTTP_STATUS = 200; HTTP_ACCESS = PASS','http://192.0.2.51:5000/ : HTTP_STATUS = 200; HTTP_ACCESS = PASS','FIREWALL_STATE = FOUND','FIREWALL_INBOUND_RULES = FOUND','FIREWALL_PORT_FILTERS = FOUND','FIREWALL_PORT_FILTERS_MATCHING = 1','ACTIVE_NETWORK = FOUND','R4_LAN_STATUS = NOT_YET_DETERMINED')) {
    Assert-CollectionTest ($joined.Contains($text)) "step03 synthetic complete contract: $text"
}
Assert-CollectionTest ($script:Urls -contains 'http://127.0.0.1:5000/' -and $script:Urls -contains 'http://192.0.2.51:5000/') 'step03 probes correct local and validated LAN-IP URLs'
$script:ContractMode=$false
$script:Fixture=[pscustomobject]@{LastBootUpTime=[datetime]'2026-01-02T03:04:05'}
Assert-CollectionTest ((Get-LastBootTime) -ceq ([datetime]'2026-01-02T03:04:05').ToString('o')) 'boot timestamp format unchanged for valid data'
$script:Fixture=$null
Assert-CollectionTest ((Get-LastBootTime) -ceq 'NOT_FOUND') 'missing boot timestamp does not crash license observation'
$threw=$false
try { $null=Get-ReadOnlyData 'Set-NetFirewallProfile' } catch { $threw=$_.Exception.Message -like 'Only audited read-only*' }
Assert-CollectionTest $threw 'unapproved write command rejected before invocation'
Write-Output 'COLLECTION_SAFETY_SELF_TEST = PASS; WINDOWS_NATIVE_EXECUTION = NOT_RUN_BY_UNIT_TEST'
