﻿#requires -Version 5.1
param([Parameter(Mandatory=$true)][ValidateRange(1,6)][int]$Task)
. (Join-Path $PSScriptRoot 'Common.ps1')
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Toolkit này cần Windows và Windows PowerShell 5.1.' }
    Initialize-Results
    switch ($Task) {
        1 {
            $os=Get-ReadOnlyData 'Get-CimInstance' @{ClassName='Win32_OperatingSystem'}
            $cpu=Get-ReadOnlyData 'Get-CimInstance' @{ClassName='Win32_Processor'}
            $cs=Get-ReadOnlyData 'Get-CimInstance' @{ClassName='Win32_ComputerSystem'}
            $caption='UNAVAILABLE'; $version='UNAVAILABLE'; $architecture='UNAVAILABLE'; $ram='UNAVAILABLE'
            if ($os.RecordCount -gt 0) { $caption=Get-ObjectField $os.Items[0] 'Caption'; $version=Get-ObjectField $os.Items[0] 'Version'; $architecture=Get-ObjectField $os.Items[0] 'OSArchitecture' }
            [string[]]$cpuNames=@(); foreach ($item in $cpu.Items) { $cpuNames+=Get-ObjectField $item 'Name' }
            if ($cpuNames.Length -eq 0) { $cpuNames=@('UNAVAILABLE') }
            $bytes=0.0
            if ($cs.RecordCount -gt 0 -and [double]::TryParse((Get-ObjectField $cs.Items[0] 'TotalPhysicalMemory'),[ref]$bytes)) { $ram=[string][Math]::Round($bytes/1GB,2) }
            $python='NOT_INSTALLED (không bắt buộc cho toolkit)'
            if (Get-Command py.exe -ErrorAction SilentlyContinue) { $python=(& py.exe -3 --version 2>&1 | Out-String).Trim() }
            elseif (Get-Command python.exe -ErrorAction SilentlyContinue) { $python=(& python.exe --version 2>&1 | Out-String).Trim() }
            $b=Require-Baseline
            if ($b.Match) { & (Join-Path $PSScriptRoot 'SelfTest.ps1') -CandidatePath $b.Path }
            $lines=@('[PASS] Đã nhận diện Windows',"WINDOWS = $caption; VERSION = $version","CPU = $($cpuNames -join '; ')","RAM_GB = $ram","ARCHITECTURE = $architecture","WINDOWS_INFORMATION = $($os.Status); CPU_INFORMATION = $($cpu.Status); COMPUTER_INFORMATION = $($cs.Status)","POWERSHELL = $($PSVersionTable.PSVersion)","PYTHON = $python","CANDIDATE_EXISTS = $($b.Found)","CANDIDATE_SHA256 = $($b.Actual)","R4_EXPECTED_SHA256 = $($b.Expected)","BASELINE_MATCH = $($b.Match.ToString().ToUpperInvariant())")
            foreach ($ip in (Get-LanAddresses)) { $lines+="IPv4 = $($ip.IPAddress); INTERFACE = $($ip.InterfaceAlias)" }
            if ($b.Match) { $lines+='[PASS] SHA-256 đúng R4 Candidate' }
            else { $lines+='[FAIL] SAI R4 CANDIDATE — DỪNG NGHIỆM THU.' }
            Write-Report '01_PRECHECK.txt' $lines
            if (-not $b.Match) { exit 2 }
        }
        2 {
            $b=Require-Baseline
            if (-not $b.Match) { Write-Report '02_BASELINE_FAILURE.txt' @('BASELINE_MATCH = FALSE','SAI R4 CANDIDATE — DỪNG NGHIỆM THU.'); exit 2 }
            Write-Host 'Chỉ nhìn tình trạng license trên ứng dụng. Không nhập mã kích hoạt, mật khẩu hoặc thông tin bí mật.'
            $phase=Read-LicenseObservation
            $observation=Read-Choice 'License còn đúng và hợp lệ? PASS / FAIL / UNKNOWN' @('PASS','FAIL','UNKNOWN')
            $id=Get-Identity
            $boot=Get-LastBootTime
            Save-LicenseRow ([pscustomobject][ordered]@{
                TIMESTAMP=(Get-Date).ToString('o'); WINDOWS_BOOT_TIME=$boot; COMPUTER_NAME=[Environment]::MachineName
                MACHINE_ID_HASH=$id.AppHash; APP_MACHINE_ID_SOURCE=$id.Source; WINDOWS_MACHINEGUID_HASH=$id.GuidHash; UUID_NODE_SOURCE=$id.NodeSource
                LICENSE_OBSERVATION=$observation; NOTE=$phase; BASELINE_MATCH='TRUE'; CANDIDATE_SHA256=$b.Actual
            })
            Write-Host '[PASS] Đã nối thêm một dòng vào RESULTS\02_LICENSE_RESTART.csv.'
            Write-Host "APP_MACHINE_ID_SOURCE = $($id.Source)"
            if ($id.NodeSource -eq 'RANDOM_OR_MULTICAST_NODE') { Write-Host '[CẢNH BÁO] Nguồn uuid.getnode có bit multicast/random. Không kết luận ID ổn định giữa các lần mở; toolkit không sửa nguồn identity.' }
            Write-Host 'Nếu MACHINE_ID_HASH không lấy được, chỉ dùng MachineGuid HASH để đối chiếu Windows; đây không phải ID ứng dụng.'
        }
        3 {
            $b=Require-Baseline
            if (-not $b.Match) { Write-Report '03_BASELINE_FAILURE.txt' @('BASELINE_MATCH = FALSE','SAI R4 CANDIDATE — DỪNG NGHIỆM THU.'); exit 2 }
            $port=Read-Number 'Nhập PORT máy chủ (ví dụ 5000)' 1 65535
            $lines=Get-ServerLanReport $port
            $lines=@("CANDIDATE_SHA256 = $($b.Actual)","R4_EXPECTED_SHA256 = $($b.Expected)")+$lines
            Write-Report '03_LAN_SERVER.txt' $lines
        }
        4 {
            $address=$null
            do { $ip=(Read-Host 'Nhập IPv4 máy chủ (không nhập URL)').Trim(); $ok=[Net.IPAddress]::TryParse($ip,[ref]$address) -and $address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork } until ($ok)
            $port=Read-Number 'Nhập PORT máy chủ' 1 65535
            $ping=Get-BooleanProbe 'Test-Connection' @{ComputerName=$ip;Count=1;Quiet=$true}
            $tcpProbe=Get-BooleanProbe 'Test-NetConnection' @{ComputerName=$ip;Port=$port;InformationLevel='Quiet';WarningAction='SilentlyContinue'}
            $tcp=$tcpProbe.Succeeded
            $lines=@("SERVER_IP = $ip","SERVER_PORT = $port","PING = $($ping.Status) (ICMP có thể bị chặn; không quyết định TCP)","TCP_ACCESS = $($tcpProbe.Status)")
            if ($tcp) { $lines+='[PASS] TÌM THẤY MÁY CHỦ; PORT TRUY CẬP ĐƯỢC' } else { $lines+='[FAIL] PORT KHÔNG TRUY CẬP ĐƯỢC; kiểm tra server, cùng LAN, port và firewall.'; $lines+='FIREWALL_ACTION_REQUIRED = REVIEW (chưa kết luận firewall là nguyên nhân)' }
            $http=Invoke-HttpProbe 'HTTP' "http://${ip}:$port/"
            $httpOK=$http.Length -gt 0 -and (Get-RecordCount ($http | Where-Object { $_ -match 'HTTP_ACCESS = PASS' })) -eq $http.Length
            $lines+=$http
            if ($httpOK) { $lines+='[PASS] WEB SERVER PHẢN HỒI' } else { $lines+='[FAIL] HTTP chưa đạt; xem mã HTTP nếu có.' }
            $lines+='BASELINE_MATCH = NOT_CHECKED_ON_CLIENT; đối chiếu 01_PRECHECK của máy chủ.'
            $safeName=[Environment]::MachineName -replace '[^a-zA-Z0-9_-]','_'
            Write-Report ("CLIENT_TEST_$safeName.txt") $lines
            if (-not $tcp -or -not $httpOK) { exit 3 }
        }
        5 {
            $b=Require-Baseline
            if (-not $b.Match) { Write-Report '05_BASELINE_FAILURE.txt' @('BASELINE_MATCH = FALSE','SAI R4 CANDIDATE — DỪNG NGHIỆM THU.'); exit 2 }
            $n=Read-Number 'SỐ MÁY THAM GIA' 1 100000
            do {
                $lo=Read-Number 'LOGIN THÀNH CÔNG' 0 $n; $lf=Read-Number 'LOGIN THẤT BẠI' 0 $n
                if ($lo+$lf -ne $n) { Write-Host 'Tổng login thành công và thất bại phải bằng số máy.' }
            } until ($lo+$lf -eq $n)
            do {
                $so=Read-Number 'NỘP BÀI THÀNH CÔNG' 0 $n; $sf=Read-Number 'NỘP BÀI THẤT BẠI' 0 $n
                if ($so+$sf -ne $n) { Write-Host 'Tổng nộp thành công và thất bại phải bằng số máy; máy chưa nộp tính thất bại.' }
            } until ($so+$sf -eq $n)
            $lost=Read-Choice 'CÓ MẤT ĐÁP ÁN KHÔNG?' @('Y','N')
            $mixed=Read-Choice 'CÓ NHẦM DỮ LIỆU HỌC SINH KHÔNG?' @('Y','N')
            $http500=Read-Choice 'CÓ HTTP 500 KHÔNG?' @('Y','N')
            $locked=Read-Choice 'CÓ DATABASE LOCK KHÔNG?' @('Y','N')
            $verdict=Get-RoomVerdict $n $lo $lf $so $sf @($lost,$mixed,$http500,$locked)
            Write-Report '05_PHYSICAL_LAN_TEST.txt' @('BASELINE_MATCH = TRUE',"SO_MAY_THAM_GIA = $n","LOGIN_THANH_CONG = $lo","LOGIN_THAT_BAI = $lf","NOP_BAI_THANH_CONG = $so","NOP_BAI_THAT_BAI = $sf","MAT_DAP_AN = $lost","NHAM_DU_LIEU_HS = $mixed","HTTP_500 = $http500","DATABASE_LOCK = $locked","PHYSICAL_50_PC_LAN = $verdict",'Kết quả do người dùng ghi nhận; cần đối chiếu evidence, không tự chứng nhận 50-PC PASS.')
        }
        6 {
            $package=Package-Results
            Write-Host "ĐÃ TẠO GÓI KẾT QUẢ: $($package.Path)"
            Write-Host "SHA256: $($package.Hash)"
            Write-Host "SỐ TỆP EVIDENCE: $($package.Count)"
        }
    }
    exit 0
} catch {
    Write-Host '[FAIL] Không hoàn tất tác vụ. Không tiếp tục nếu precheck chưa PASS.'
    # Exception messages may contain user-entered paths only; never dump environment or license files.
    Write-Host $_.Exception.Message
    exit 1
}
