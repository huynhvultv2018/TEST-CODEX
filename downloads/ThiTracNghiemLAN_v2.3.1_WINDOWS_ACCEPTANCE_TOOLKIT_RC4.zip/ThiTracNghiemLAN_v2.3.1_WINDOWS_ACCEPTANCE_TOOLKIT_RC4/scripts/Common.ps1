﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:Root = Split-Path $PSScriptRoot -Parent
$script:Results = Join-Path $script:Root 'RESULTS'
$script:Expected = '68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2'
function Initialize-Results {
    New-Item -ItemType Directory -Path $script:Results -Force | Out-Null
}
function Read-Choice([string]$Prompt,[string[]]$Choices) {
    do { $v = (Read-Host "$Prompt [$($Choices -join '/')]").Trim().ToUpperInvariant() } until ($Choices -contains $v)
    return $v
}
$script:LicenseObservationLabels = @('BEFORE','SERVER_REOPEN','APP_REOPEN','WINDOWS_REBOOT1')
function Convert-LicenseObservationLabel([string]$Value) {
    if ($null -eq $Value) { return $null }
    $normalized = $Value.Trim().ToUpperInvariant()
    if ($script:LicenseObservationLabels -contains $normalized) { return $normalized }
    return $null
}
function Read-LicenseObservation {
    $choices = $script:LicenseObservationLabels -join ' / '
    for ($attempt = 1; $attempt -le 20; $attempt++) {
        $phase = Convert-LicenseObservationLabel (Read-Host "Lan ghi nhan: $choices")
        if ($null -ne $phase) { return $phase }
        Write-Host "[INVALID] Chi nhap mot trong: $choices. Hay nhap lai ($attempt/20)."
    }
    throw 'Da nhap sai 20 lan. Dung buoc 02; chay lai BAT de thu tiep. Chua ghi them evidence.'
}
function Read-Number([string]$Prompt,[int]$Min=0,[int]$Max=100000) {
    do { $v = Read-Host $Prompt; $n = 0; $ok = [int]::TryParse($v,[ref]$n) -and $n -ge $Min -and $n -le $Max } until ($ok)
    return $n
}
function Get-Baseline([string]$Path) {
    $found = Test-Path -LiteralPath $Path -PathType Leaf
    $actual = 'MISSING'
    if ($found) { $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
    return [pscustomobject]@{ Found=$found; Actual=$actual; Match=($actual -eq $script:Expected); Expected=$script:Expected }
}
function Require-Baseline {
    $default = Join-Path $script:Root 'ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip'
    Write-Host 'Chọn R4 CANDIDATE.zip, không chọn HANDOFF.zip; không giải nén candidate để kiểm SHA.'
    $p = Read-Host 'Kéo tệp candidate ZIP vào đây rồi Enter (Enter để dùng ZIP cạnh toolkit)'
    if ([string]::IsNullOrWhiteSpace($p)) { $p=$default } else { $p=$p.Trim().Trim('"') }
    $b = Get-Baseline $p
    return [pscustomobject]@{ Path=$p; Found=$b.Found; Actual=$b.Actual; Match=$b.Match; Expected=$b.Expected }
}
function Write-Report([string]$Name,[object[]]$Lines) {
    $text = @(('TIMESTAMP = '+(Get-Date).ToString('o')),('COMPUTER_NAME = '+[Environment]::MachineName)) + $Lines
    $text | Set-Content -LiteralPath (Join-Path $script:Results $Name) -Encoding UTF8
    $text | ForEach-Object { Write-Host $_ }
}
function ConvertTo-Records([AllowNull()][object]$Value) {
    [object[]]$records=@($Value | Where-Object { $null -ne $_ })
    # Emit the array as one object: zero/one results must not collapse at the call boundary.
    return ,$records
}
function Get-RecordCount([AllowNull()][object]$Value) {
    $records=ConvertTo-Records $Value
    return $records.Length
}
function Get-ObjectField([AllowNull()][object]$Value,[string]$Name,[string]$Fallback='UNAVAILABLE') {
    if ($null -eq $Value) { return $Fallback }
    try {
        $property=$Value.PSObject.Properties[$Name]
        if ($null -eq $property -or $null -eq $property.Value) { return $Fallback }
        return [string]$property.Value
    } catch { return $Fallback }
}
function Get-ReadOnlyData([string]$Command,[hashtable]$Parameters=@{}) {
    $allowed=@('Get-NetIPAddress','Get-NetTCPConnection','Get-NetFirewallProfile','Get-NetFirewallRule','Get-NetFirewallPortFilter','Get-NetConnectionProfile','Get-CimInstance','Get-Process','Test-Connection','Test-NetConnection')
    if ($allowed -notcontains $Command) { throw 'Only audited read-only discovery commands are allowed.' }
    $status='NOT_APPLICABLE'; [object[]]$items=@()
    try {
        if ($null -ne (Get-Command -Name $Command -ErrorAction SilentlyContinue)) {
            $options=@{}; foreach ($key in $Parameters.Keys) { $options[$key]=$Parameters[$key] }
            $options['ErrorAction']='Stop'
            $items=ConvertTo-Records (& $Command @options)
            $status=if ($items.Length -eq 0) { 'NOT_FOUND' } else { 'FOUND' }
        }
    } catch {
        $status='UNAVAILABLE'
        if ($_.Exception -is [UnauthorizedAccessException] -or $_.CategoryInfo.Category -eq 'PermissionDenied' -or $_.FullyQualifiedErrorId -match 'AccessDenied|UnauthorizedAccess|0x80070005' -or $_.Exception.HResult -eq -2147024891) { $status='ACCESS_DENIED' }
        elseif ($_.CategoryInfo.Category -eq 'ObjectNotFound' -or $_.FullyQualifiedErrorId -match 'CmdletizationQuery_NotFound|NoProcessFound') { $status='NOT_FOUND' }
        $items=@()
    }
    return [pscustomobject]@{ Status=$status; Items=$items; RecordCount=$items.Length }
}
function Get-LanDiscovery {
    $source=Get-ReadOnlyData 'Get-NetIPAddress' @{AddressFamily='IPv4'}
    [object[]]$valid=@(); $malformed=$false
    foreach ($item in $source.Items) {
        $ipText=Get-ObjectField $item 'IPAddress'
        $address=$null
        if (-not [Net.IPAddress]::TryParse($ipText,[ref]$address) -or $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) { $malformed=$true; continue }
        if ([Net.IPAddress]::IsLoopback($address) -or $ipText -like '169.254.*' -or $ipText -eq '0.0.0.0' -or $ipText -eq '255.255.255.255') { continue }
        $state=Get-ObjectField $item 'AddressState'
        if ($state -eq 'UNAVAILABLE') { $malformed=$true; continue }
        if ($state -ne 'Preferred') { continue }
        $valid+= [pscustomobject]@{ IPAddress=$address.ToString(); InterfaceAlias=(Get-ObjectField $item 'InterfaceAlias'); InterfaceIndex=(Get-ObjectField $item 'InterfaceIndex') }
    }
    $status=$source.Status
    if ($status -eq 'FOUND') {
        $status=if ($valid.Length -gt 0) { 'FOUND' } elseif ($malformed) { 'UNAVAILABLE' } else { 'NOT_FOUND' }
    }
    $valid=ConvertTo-Records ($valid | Sort-Object InterfaceIndex,IPAddress)
    return [pscustomobject]@{ Status=$status; Items=$valid; RecordCount=$valid.Length; SourceRecordCount=$source.RecordCount }
}
function Get-LanAddresses {
    $discovery=Get-LanDiscovery
    return ,$discovery.Items
}
function Get-HttpResult([string]$Url) {
    # Read headers only; do not collect response bodies, cookies, credentials or redirects.
    $response=$null
    try {
        $req=[System.Net.HttpWebRequest]::Create($Url)
        $req.Timeout=5000; $req.ReadWriteTimeout=5000; $req.AllowAutoRedirect=$false; $req.Proxy=$null
        $response=$req.GetResponse()
        $status=[int]$response.StatusCode
        return "HTTP_STATUS = $status; HTTP_ACCESS = PASS"
    } catch [System.Net.WebException] {
        $response=$_.Exception.Response
        if ($null -ne $response) {
            $status=[int]$response.StatusCode
            return "HTTP_STATUS = $status; HTTP_ACCESS = FAIL; SERVER_RESPONDED = TRUE"
        }
        return 'HTTP_ACCESS = FAIL; HTTP_STATUS = UNAVAILABLE'
    } finally { if ($null -ne $response) { $response.Close() } }
}
function Get-Identity {
    $appHash='UNAVAILABLE'; $source='UNCONFIRMED'; $guidHash='UNAVAILABLE'; $nodeSource='UNAVAILABLE'
    try {
        $guid=(Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
        $sha=[System.Security.Cryptography.SHA256]::Create()
        try { $guidHash=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($guid)))).Replace('-','').ToLowerInvariant() } finally { $sha.Dispose() }
    } catch { }
    # Do not import app.py, read license files, activate or reset anything.
    $helper=Join-Path $PSScriptRoot 'Identity.py'
    try {
        if (Get-Command py.exe -ErrorAction SilentlyContinue) { $value=& py.exe -3 $helper 2>$null }
        elseif (Get-Command python.exe -ErrorAction SilentlyContinue) { $value=& python.exe $helper 2>$null }
        else { $value='' }
        $parts=@($value)
        if ($LASTEXITCODE -eq 0 -and $parts.Count -eq 2 -and $parts[0] -match '^[a-f0-9]{64}$') {
            $appHash=$parts[0]; $nodeSource=$parts[1]; $source='CONFIRMED_R4_SOURCE_ALGORITHM; RUNTIME_EQUIVALENCE_UNCONFIRMED'
        }
    } catch { }
    return [pscustomobject]@{ AppHash=$appHash; Source=$source; GuidHash=$guidHash; NodeSource=$nodeSource }
}
function Save-LicenseRow([object]$Row) {
    $p=Join-Path $script:Results '02_LICENSE_RESTART.csv'
    if (Test-Path -LiteralPath $p) { $Row | Export-Csv -LiteralPath $p -NoTypeInformation -Encoding UTF8 -Append }
    else { $Row | Export-Csv -LiteralPath $p -NoTypeInformation -Encoding UTF8 }
}
function Get-RoomVerdict([int]$Count,[int]$LoginOK,[int]$LoginFail,[int]$SubmitOK,[int]$SubmitFail,[string[]]$Errors) {
    if ($Count -lt 50) { return 'NOT_TESTED' }
    if ($LoginOK -ne $Count -or $LoginFail -ne 0 -or $SubmitOK -ne $Count -or $SubmitFail -ne 0 -or $Errors -contains 'Y') { return 'FAIL' }
    return 'EVIDENCE_RECORDED_REVIEW_REQUIRED'
}
function Package-Results {
    $files=Get-ResultFiles
    if ($files.Count -eq 0) { throw 'RESULTS chưa có evidence. Hãy chạy các bước kiểm tra trước.' }
    $dest=Join-Path $script:Root ('ThiTracNghiemLAN_v2.3.1_WINDOWS_ACCEPTANCE_RESULTS_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff')+'.zip')
    # ZipFile includes hidden evidence; ZIP stays outside RESULTS to avoid recursion.
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($script:Results,$dest)
    $hash=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $([IO.Path]::GetFileName($dest))" | Set-Content -LiteralPath ($dest+'.sha256') -Encoding ASCII
    return [pscustomobject]@{ Path=$dest; Hash=$hash; Count=$files.Count }
}
function Get-ResultFiles {
    $files=ConvertTo-Records (Get-ChildItem -LiteralPath $script:Results -File -Recurse -Force)
    return ,$files
}
function Read-ResultCsv([string]$Path) {
    $rows=ConvertTo-Records (Import-Csv -LiteralPath $Path)
    return ,$rows
}
. (Join-Path $PSScriptRoot 'NetworkInspection.ps1')
