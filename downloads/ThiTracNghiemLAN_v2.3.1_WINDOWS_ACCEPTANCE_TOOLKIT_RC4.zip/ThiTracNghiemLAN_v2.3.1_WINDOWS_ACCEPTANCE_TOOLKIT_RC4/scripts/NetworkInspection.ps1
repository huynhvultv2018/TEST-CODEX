﻿#requires -Version 5.1
# Definitions only. All OS queries go through the audited read-only command list.
function Format-HttpProbeResults([string]$Name,[AllowNull()][object]$Value) {
    $records=ConvertTo-Records $Value
    [string[]]$lines=@()
    foreach ($record in $records) {
        if ($record -is [string] -and $record -match '^HTTP_(STATUS|ACCESS) = ') { $lines+="$Name : $record" }
        else { $lines+="$Name : HTTP_ACCESS = UNAVAILABLE; HTTP_STATUS = UNAVAILABLE" }
    }
    if ($lines.Length -eq 0) { $lines=@("$Name : HTTP_ACCESS = UNAVAILABLE; HTTP_STATUS = UNAVAILABLE") }
    return ,$lines
}
function Invoke-HttpProbe([string]$Name,[string]$Url) {
    try { $value=Get-HttpResult $Url } catch { $value=$null }
    $lines=Format-HttpProbeResults $Name $value
    return ,$lines
}
function Test-FirewallPort([AllowNull()][object]$Filter,[int]$Port) {
    $protocol=Get-ObjectField $Filter 'Protocol'
    if ($protocol -notin @('TCP','6','Any','256')) { return $false }
    if ($null -eq $Filter) { return $false }
    $property=$Filter.PSObject.Properties['LocalPort']
    if ($null -eq $property) { return $false }
    $values=ConvertTo-Records $property.Value
    foreach ($value in $values) {
        foreach ($text in ([string]$value -split ',')) {
            $text=$text.Trim()
            if ($text -eq 'Any' -or $text -eq [string]$Port) { return $true }
            if ($text -match '^(\d+)-(\d+)$') {
                $minimum=0; $maximum=0
                if ([int]::TryParse($Matches[1],[ref]$minimum) -and [int]::TryParse($Matches[2],[ref]$maximum) -and $Port -ge $minimum -and $Port -le $maximum) { return $true }
            }
        }
    }
    return $false
}
function Get-ServerLanReport([int]$Port) {
    $lines=New-Object 'System.Collections.Generic.List[string]'
    $lines.Add("PORT = $Port")
    $lines.Add('BASELINE_MATCH = TRUE')
    $lines.Add('R4_LAN_STATUS = NOT_YET_DETERMINED')
    $lines.Add('POWERSHELL = '+$PSVersionTable.PSVersion.ToString())
    $lines.Add('OS_PLATFORM = '+[Environment]::OSVersion.Platform.ToString())
    $os=Get-ReadOnlyData 'Get-CimInstance' @{ClassName='Win32_OperatingSystem'}
    $lines.Add("WINDOWS_INFORMATION = $($os.Status); RECORD_COUNT = $($os.RecordCount)")
    foreach ($item in $os.Items) { $lines.Add('WINDOWS = '+(Get-ObjectField $item 'Caption')+'; VERSION = '+(Get-ObjectField $item 'Version')) }
    $listeners=Get-ReadOnlyData 'Get-NetTCPConnection' @{State='Listen';LocalPort=$Port}
    $lines.Add("LISTENING_PORT = $($listeners.Status); RECORD_COUNT = $($listeners.RecordCount)")
    $binding=$listeners.Status; $validListener=$false; $lanListener=$false
    foreach ($listener in $listeners.Items) {
        $local=Get-ObjectField $listener 'LocalAddress'
        $processId=Get-ObjectField $listener 'OwningProcess'
        $lines.Add("LISTEN_ADDRESS = $local; PID = $processId")
        $address=$null
        if ([Net.IPAddress]::TryParse($local,[ref]$address)) {
            $validListener=$true
            if (-not [Net.IPAddress]::IsLoopback($address)) { $lanListener=$true }
        }
        $number=0
        if ([int]::TryParse($processId,[ref]$number) -and $number -gt 0) {
            $process=Get-ReadOnlyData 'Get-Process' @{Id=$number}
            $lines.Add("LISTENER_PROCESS = $($process.Status); PID = $number")
            foreach ($p in $process.Items) { $lines.Add('PROCESS_NAME = '+(Get-ObjectField $p 'ProcessName')) }
        } else { $lines.Add('LISTENER_PROCESS = UNAVAILABLE') }
    }
    if ($listeners.Status -eq 'FOUND') {
        $binding=if ($lanListener) { 'PRESENT; REMOTE_ACCESS_NOT_YET_CONFIRMED' } elseif ($validListener) { 'LOOPBACK_ONLY' } else { 'UNAVAILABLE' }
    }
    $lines.Add("LAN_BINDING = $binding")
    $ips=Get-LanDiscovery
    $lines.Add("IPv4_LAN = $($ips.Status); RECORD_COUNT = $($ips.RecordCount)")
    foreach ($ip in $ips.Items) {
        $url="http://$($ip.IPAddress):$Port/"
        $lines.Add("IP MAY CHU = $($ip.IPAddress); CARD = $($ip.InterfaceAlias)")
        $lines.Add("DIA CHI MAY CON CAN MO = $url")
        foreach ($line in (Invoke-HttpProbe $url $url)) { $lines.Add($line) }
    }
    foreach ($line in (Invoke-HttpProbe 'LOOPBACK' ("http://127.0.0.1:$Port/"))) { $lines.Add($line) }
    $profiles=Get-ReadOnlyData 'Get-NetFirewallProfile'
    $lines.Add("FIREWALL_STATE = $($profiles.Status); RECORD_COUNT = $($profiles.RecordCount)")
    foreach ($p in $profiles.Items) { $lines.Add('FIREWALL_PROFILE = '+(Get-ObjectField $p 'Name')+'; ENABLED = '+(Get-ObjectField $p 'Enabled')+'; INBOUND_DEFAULT = '+(Get-ObjectField $p 'DefaultInboundAction')) }
    $rules=Get-ReadOnlyData 'Get-NetFirewallRule' @{Direction='Inbound'}
    $lines.Add("FIREWALL_INBOUND_RULES = $($rules.Status); RECORD_COUNT = $($rules.RecordCount)")
    foreach ($rule in $rules.Items) { $lines.Add('FIREWALL_RULE = '+(Get-ObjectField $rule 'Name')+'; ENABLED = '+(Get-ObjectField $rule 'Enabled')+'; ACTION = '+(Get-ObjectField $rule 'Action')+'; PROFILE = '+(Get-ObjectField $rule 'Profile')) }
    $filters=Get-ReadOnlyData 'Get-NetFirewallPortFilter'
    $lines.Add("FIREWALL_PORT_FILTERS = $($filters.Status); RECORD_COUNT = $($filters.RecordCount)")
    $matching=0
    foreach ($filter in $filters.Items) {
        if (Test-FirewallPort $filter $Port) {
            $matching++
            $lines.Add('FIREWALL_PORT_FILTER = '+(Get-ObjectField $filter 'InstanceID')+'; PROTOCOL = '+(Get-ObjectField $filter 'Protocol')+'; LOCAL_PORT = '+(Get-ObjectField $filter 'LocalPort'))
        }
    }
    $lines.Add("FIREWALL_PORT_FILTERS_MATCHING = $matching")
    $lines.Add('FIREWALL_RULE_PORT_CORRELATION = UNCONFIRMED; filters and inbound rules are separate read-only inventories, not proof that traffic is allowed or blocked.')
    $networks=Get-ReadOnlyData 'Get-NetConnectionProfile'
    $lines.Add("ACTIVE_NETWORK = $($networks.Status); RECORD_COUNT = $($networks.RecordCount)")
    foreach ($p in $networks.Items) { $lines.Add('NETWORK_INTERFACE = '+(Get-ObjectField $p 'InterfaceAlias')+'; CATEGORY = '+(Get-ObjectField $p 'NetworkCategory')) }
    $lines.Add('FIREWALL_BLOCK_STATUS = UNCONFIRMED; only a real client test establishes LAN access.')
    $lines.Add('FIREWALL_ACTION_REQUIRED = REVIEW_IF_CLIENT_CANNOT_CONNECT; no firewall/network setting is changed.')
    return ,$lines.ToArray()
}
function Get-BooleanProbe([string]$Command,[hashtable]$Parameters) {
    $data=Get-ReadOnlyData $Command $Parameters
    $status=$data.Status; $success=$false
    if ($data.RecordCount -eq 1 -and $data.Items[0] -is [bool]) { $success=$data.Items[0]; $status=[string]$success }
    elseif ($status -eq 'FOUND') { $status='UNAVAILABLE' }
    return [pscustomobject]@{ Status=$status; Succeeded=$success }
}
function Get-LastBootTime {
    $os=Get-ReadOnlyData 'Get-CimInstance' @{ClassName='Win32_OperatingSystem'}
    if ($os.RecordCount -eq 0) { return $os.Status }
    try {
        $property=$os.Items[0].PSObject.Properties['LastBootUpTime']
        if ($null -ne $property -and ($property.Value -is [datetime] -or $property.Value -is [datetimeoffset])) { return $property.Value.ToString('o') }
    } catch { }
    return 'UNAVAILABLE'
}
