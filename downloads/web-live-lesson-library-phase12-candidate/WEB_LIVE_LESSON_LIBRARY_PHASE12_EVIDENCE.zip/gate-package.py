from pathlib import Path
import json, hashlib, zipfile, difflib
p=Path(__file__).parent
root=p/'working/WEB_LIVE_LESSON_LIBRARY_PHASE12_WORKING_COPY'
frozen=Path('/workspace/phase11-subject-loader/packaged-smoke/WEB_LIVE_SUBJECT_LOADER_PHASE11_CANDIDATE')
out=Path('/workspace/output/web-live-lesson-library-phase12-candidate')
read=lambda n:json.loads((p/n).read_text())
write=lambda n,x:(p/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=lambda r:{str(x.relative_to(r)):sha(x.read_bytes()) for x in sorted(r.rglob('*')) if x.is_file()}
before=read('SOURCE_MANIFEST_BEFORE.json');after=manifest(root)
assert manifest(frozen)==before
assert set(before)==set(after) and len(after)==1241
changed=[n for n in before if before[n]!=after[n]]
assert changed==['WEB_LIVE/subject-loader.css','WEB_LIVE/subject-loader.js']
source=read('SOURCE_IDENTITY.json');source['sha256After']=sha(Path(source['sourceZip']).read_bytes())
assert source['sha256Before']==source['sha256After']=='1a04b5e9ae52068e9bf7d194b0767f233e0aecab3a17dd490ff2606178005954'
write('SOURCE_IDENTITY.json',source)
old=(frozen/'WEB_LIVE/subject-loader.js').read_text();new=(root/'WEB_LIVE/subject-loader.js').read_text()
segments=[('quick-access',' const quickKey=', ' const label='),('validation-staging-transaction-quota',' function indicate(){',' renderLibrary=function(){')]
segmentResults={}
for name,start,end in segments:
 a=old[old.index(start):old.index(end)];b=new[new.index(start):new.index(end)]
 assert a==b,name
 segmentResults[name]={'byteExact':True,'sha256':sha(a.encode())}
write('SOURCE_SCOPE.json',{'result':'PASS','fileCount':1241,'changedFiles':changed,'unchangedFiles':1239,'addedFiles':[],'removedFiles':[],'frozenPhase11PayloadUnchanged':True,'coreMutated':False,'profilesMutated':False,'productionModified':False,'unchangedLoaderSegments':segmentResults})
(p/'PATCH_FILES.diff').write_text(''.join(''.join(difflib.unified_diff((frozen/n).read_text().splitlines(True),(root/n).read_text().splitlines(True),fromfile='Phase11/'+n,tofile='Phase12/'+n)) for n in changed))
comparisons={}
files={'GEOMETRY':'GEOMETRY_RUNTIME/geometry-runtime.json','ALGEBRA':'ALGEBRA_TARGETED.json','INFORMATICS':'INFORMATICS/INFORMATICS_TARGETED.json','LEGACY':'ENGINES/results.json'}
def normalize(x,profile):
 if isinstance(x,dict):return {k:normalize(v,profile) for k,v in x.items() if not (profile=='GEOMETRY' and k=='lessonActivation' or profile=='INFORMATICS' and k=='currentTime')}
 if isinstance(x,list):return [normalize(v,profile) for v in x]
 return x
for profile,n in files.items():
 a=json.loads((Path('/workspace/phase11-subject-loader/REGRESSION')/n).read_text());b=read('REGRESSION/'+n)
 assert not b.get('errors') and not b.get('external') and not b.get('externalRequests')
 assert b.get('result','PASS')=='PASS'
 assert normalize(a,profile)==normalize(b,profile),profile
 checks=b.get('checks',b.get('assertions',[]))
 comparisons[profile]={'result':'PASS','checks':len(checks),'reference':'Phase11/REGRESSION/'+n,'phase12':'REGRESSION/'+n,'comparison':'SEMANTIC_JSON_EQUAL','normalization':{'GEOMETRY':'Only per-run lessonActivation UUID; within-run identity assertions remain exact','INFORMATICS':'Only manual video currentTime; playback >0 assertions remain executed'}.get(profile,'NONE')}
write('REGRESSION_COMPARISON.json',comparisons)
gates={}
for name,n,count in [('library','LIBRARY_RESULTS.json',21),('quickAccess','QUICK_ACCESS_REGRESSION/QUICK_ACCESS_RESULTS.json',16),('safeguards','SAFEGUARDS/TARGETED_RESULTS.json',15)]:
 data=read(n);assert data['result']=='PASS' and len(data['checks'])==count and not data['errors'];gates[name]={'result':'PASS','groups':count}
write('PREPACKAGE_GATE.json',{'result':'PASS','workingGates':gates,'profileRegression':comparisons,'sourceScope':'PASS'})
out.mkdir(parents=True,exist_ok=True)
name='WEB_LIVE_LESSON_LIBRARY_PHASE12_CANDIDATE';dest=out/(name+'.zip')
assert not dest.exists(), 'Do not overwrite a candidate'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in after:z.write(root/n,name+'/'+n)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None
 zipped={n[len(name)+1:]:sha(z.read(n)) for n in z.namelist() if not n.endswith('/')}
 assert zipped==after
 z.extractall(p/'packaged-smoke')
assert manifest(p/'packaged-smoke'/name)==after
write('CANDIDATE_PAYLOAD_MANIFEST.json',after)
write('PACKAGE_IDENTITY.json',{'candidate':name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'files':1241,'wrapperRoot':name,'zipCRC':'PASS','freshExtractionManifest':'PASS','phase11SHA256':source['sha256Before'],'historicalDocumentsInsidePayload':'Inherited historical reports/checksums are unchanged; external Phase12 reports and manifest are authoritative for this candidate.'})
print(json.dumps(read('PACKAGE_IDENTITY.json'),indent=2))
