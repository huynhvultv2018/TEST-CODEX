from pathlib import Path
import json, hashlib, shutil, zipfile
p=Path(__file__).parent;out=Path('/workspace/output/web-live-lesson-library-phase12-candidate')
read=lambda n:json.loads((p/n).read_text())
write=lambda n,x:(p/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=read('PACKAGE_IDENTITY.json');scope=read('SOURCE_SCOPE.json');reg=read('REGRESSION_COMPARISON.json');source=read('SOURCE_IDENTITY.json')
groups={}
for key,rel,count in [('workingLibrary','LIBRARY_RESULTS.json',21),('workingQuick','QUICK_ACCESS_REGRESSION/QUICK_ACCESS_RESULTS.json',16),('workingSafeguards','SAFEGUARDS/TARGETED_RESULTS.json',15),('packagedLibrary','PACKAGED_LIBRARY/LIBRARY_RESULTS.json',21),('packagedQuick','PACKAGED_QUICK_ACCESS/QUICK_ACCESS_RESULTS.json',16),('packagedSafeguards','PACKAGED_SAFEGUARDS/TARGETED_RESULTS.json',15)]:
 d=read(rel);assert d['result']=='PASS' and len(d['checks'])==count and not d['errors'];groups[key]={'result':'PASS','groups':count,'evidence':rel}
assets=read('PACKAGED_SMOKE/PACKAGED_ASSETS.json');assert assets['result']=='PASS' and len(assets['assets'])==60
assert read('ENVIRONMENT_SETTINGS_EVIDENCE.json')['unchanged']
assert sha(Path(source['sourceZip']).read_bytes())==source['sha256Before']==source['sha256After']
assert sha((out/(identity['candidate']+'.zip')).read_bytes())==identity['sha256']
write('RELEASE_GATE.json',{'result':'PASS','cloudTechnicalOnly':True,'groups':groups,'profileRegressionGroups':75,'exactHTTPAssets':60,'zipCRC':'PASS','payloadManifest':'PASS','scope':'PASS','sourceFrozen':'PASS','P11_F01':'P2 OPEN_DEFERRED','capacityLimitRemoved':False,'newP0':0,'newP1':0,'newP2':0,'newP3':0,'carriedP2':1,'windowsPhysical':'UNRUN','physicalTV':'UNRUN','realClassroom':'UNRUN'})
library=read('LIBRARY_RESULTS.json');packlibrary=read('PACKAGED_LIBRARY/LIBRARY_RESULTS.json');quick=read('QUICK_ACCESS_REGRESSION/QUICK_ACCESS_RESULTS.json');packquick=read('PACKAGED_QUICK_ACCESS/QUICK_ACCESS_RESULTS.json')
quota=next(c['evidence'] for c in quick['checks'] if c['name']=='ACTUAL_QUOTA_REPRODUCER_PRESERVED_CURRENT_AND_UNKNOWN_DATA');pquota=next(c['evidence'] for c in packquick['checks'] if c['name']=='ACTUAL_QUOTA_REPRODUCER_PRESERVED_CURRENT_AND_UNKNOWN_DATA')
def report(name,text):(p/name).write_text(text.strip()+'\n')
report('LESSON_LIBRARY_PHASE12_IMPLEMENTATION_REPORT.md',f'''
# Phase 12 — Lesson Library Filter

PHASE12_STATUS = PASS (cloud technical candidate, chờ GV phê duyệt).

GV đã phê duyệt/freeze Phase11: SHA256 {source['sha256Before']}. ZIP nguồn và toàn bộ 1.241 file frozen giữ nguyên. Working copy riêng; chỉ sửa WEB_LIVE/subject-loader.js và WEB_LIVE/subject-loader.css. 1.239 file còn lại byte-identical; không thêm/xóa file runtime, không Core/Profile/Production change. PATCH_FILES.diff và SOURCE_SCOPE.json là bằng chứng phạm vi.

Loader hiện có bộ lọc Môn → Lớp → Tuần → Tiết cho bài đã lưu. Grade/week/period lấy trực tiếp từ cached lesson metadata; subject_engine dùng đúng mapping có sẵn Phase9/11. Chỉ tạo lựa chọn có dữ liệu, sắp xếp số và cascade reset. Tên bài và metadata gọn hiển thị trong một modal hiện có. Preview và explicit NẠP BÀI được đặt gần bộ lọc; nút ĐÓNG ở đầu modal. File/ZIP import và Recent vẫn có trong modal đó.

Bài thiếu dữ liệu nằm trong nhóm CHƯA ĐỦ THÔNG TIN, có ghi trường còn thiếu. Không lấy metadata từ nội dung, câu hỏi, tên file hoặc class8A. Bài trùng tên/cùng bộ metadata có Mã bài để phân biệt. Không dùng filename fallback. Chọn bài vẫn stage/validate/route; chỉ nút explicit load mới commit. Đổi bộ lọc hủy pending preview và giữ bài đang dạy. Recent ngoài bộ lọc chỉ reset bộ lọc khám phá, vẫn qua cùng openSaved/stage pipeline.

Không thêm localStorage namespace hay cache index. FilterState chỉ có ba giá trị trong RAM; descriptor giữ scalar bounded metadata và reference, không giữ package/assets clone. Quota/transaction/quick-access đoạn mã giữ byte-exact so với Phase11. Recent tối đa5, metadata ≤8192 ký tự; native essential lesson storage vẫn hiện hữu. P11-F01=P2 OPEN_DEFERRED; capacity limit chưa loại bỏ.

Kiểm chứng: working và fresh-extracted ZIP đều21 library +16 quick-access +15 safeguard groups PASS; bốn profile75 groups PASS với exact semantic JSON comparison Phase11 (chỉ UUID Geometry/currentTime video Informatics được normalization). HTTP60 assets exact bytes, ZIP CRC/full1241file manifest PASS. Không tuyên bố ảnh chụp pixel-identical hay physical PASS.

Common load đạt5 meaningful interactions trong ca nhớ sẵn môn, System đang đóng, chọn Lớp8 và bài đầu: mở System → mở Loader → chọn Lớp → chọn bài → explicit load. Dropdown native được selectOption trong automation; mô hình chuột6click, Windows physical UNRUN. Không cần scroll trong ca đã đo. Chọn cả bốn cấp từ đầu có thể nhiều hơn5; thời gian đọc/tìm bài và cuộn danh sách tùy thư viện không được đo như physical interaction.

Khôi phục phiên bài đã được chấp nhận trên reload là hành vi native frozen pedagogy-teacher.js. Giữ hành vi đó, không tạo auto-load từ remembered subject/Recent. Trong fresh context có lastSubject nhưng không native saved session, lesson vẫn null; G/W/P không persist.

Environment Settings draft revision12 unchanged; không write/Save/Publish, trạng thái DRAFT_PENDING_SAVE_PUBLISH. Python3/Node/Playwright/Chromium sẵn có, static app không cần npm build. Hướng dẫn chạy/kiểm tra trong README_PHASE12.txt; fresh managed-task restoration chưa được kiểm chứng. Windows/TV vật lý/lớp thật đều UNRUN.

Candidate: {identity['candidate']}.zip; SHA256 {identity['sha256']}; {identity['bytes']}bytes,1241files. Reports/checksums cũ trong payload là lịch sử inherited và được giữ nguyên; bộ báo cáo Phase12 bên ngoài ZIP là release authority. STOP; không Production/Phase13.
''')
report('LESSON_LIBRARY_PHASE12_CONTRACT.md','''
# Phase 12 — Loader discovery contract

1. Subject routing dùng engine()/WebLiveProfiles resolver sẵn có: geometry/algebra/informatics/legacy; không có subject_engine → legacy, default → legacy, trim/case normalization giữ nguyên. Engine lạ/không hợp lệ vẫn bị validation block. Không profile inference từ title/subject/content.
2. Grade chỉ lấy lesson.grade; week và period chỉ lấy lesson.week/lesson.period. Catalog title được dùng để hiển thị nếu native lesson không có tên; catalog metadata không được thay thế actual lesson fields. class được hiển thị riêng nếu thiếu grade, không biến 8A thành grade8. Không filename fallback.
3. Chấp nhận scalar number/string cho discovery. Trim, maximum128characters, no data URI/nonfinite. Numeric decimal string được chuẩn hóa số (8 và "8" cùng lựa chọn); số sort trước, text metadata thật sort sau, missing cuối. Unusable field vào incomplete bucket; validation package gốc giữ nguyên. Không viết normalized values vào package.
4. Lựa chọn Grade từ actual subject rows; Week từ rows hợp Grade; Period từ rows hợp Grade+Week. All là wildcard; missing option xuất hiện chỉ khi có field thiếu. Missing field chưa thể xác nhận một known filter nên vẫn xuất hiện trong nhóm riêng nếu các field có sẵn khớp. Known mismatch bị ẩn ở filter đó nhưng truy cập lại được bằng All/giá trị thực. Chọn missing trực tiếp chỉ thu hẹp bài thật sự thiếu field. Không bài thiếu metadata bị loại khỏi thư viện.
5. Subject đổi reset Grade/Week/Period; Grade đổi reset Week/Period; Week đổi reset Period. Filter change clear pending/stale async revision; bài đang dạy/TV/disclosure/Focus/storage giữ nguyên đến load thành công. Không gọi start từ filter change.
6. Sort deterministic: grade/week/period numeric, title vi collator numeric, canonical ID tie-break. UI deduplicates catalog IDs only, không delete storage. Cùng title/profile/grade/week/period hiển thị ID để phân biệt. Cache unreadable/engine invalid vẫn ghi rõ, không nạp bypass.
7. Library và Recent gọi cùng openSaved/stage/validate/assets/profile routing/explicit commit. Recent/reference ngoài strict discovery scope reset G/W/P only, không tự đổi selected subject hay rewrite lesson. Missing reference clear pending/error và giữ current. Mismatch phải bị block, không auto-relabeled.
8. Commit, rollback, essential storage quota guard và optional quick-access writes giữ byte-exact. Native start/reset/sync cùng Core/Profile không thay đổi. Recent limit5; rememberSubject chỉ cập nhật sau successful commit. Không tự nạp từ quick access. Native accepted-session restore trên reload vẫn giữ nguyên, không lọc theo rememberedSubject.
9. RAM filter state3scalar values; transient descriptors bounded scalar metadata + IDs, no payload/assets retained. No new persistent index, no IndexedDB, cache migration, quota expansion or automatic deletion. Inherited explicit user-confirmed XÓA action giữ nguyên, không dùng trong task để giải quyết capacity.
10. Runtime candidate không chứa660lesson test library mới. Synthetic fixture/evidence/helpers là sidecars; không SGK/PPCT/real-file acceptance claim. One existing modal only. ≤5 meaningful interactions là target common scenario, không universal click guarantee. Windows/physicalTV/classroom UNRUN.
''')
rows='\n'.join(f"| {k} | {v['groups']} | PASS | {v['evidence']} |" for k,v in groups.items())
report('LESSON_LIBRARY_PHASE12_TEST_EVIDENCE.md',f'''
# Phase 12 — Test evidence

Chromium {library['browser']}, Linux managed cloud, Playwright. Tests viết/chạy ngoài candidate. Không Windows runtime hay TV vật lý.

| Suite | Groups | Result | Raw evidence |
|---|---:|---|---|
{rows}

660 synthetic lessons:4profiles ×4grades(6–9) ×5weeks(1,2,5,10,11) ×4periods(1,2,9,10) ×2variants =640complete, cộng5missing per profile =20incomplete. Legacy thiếu subject_engine; lesson content/title cố ý có tín hiệu gây nhiễu; clone/catalog metadata lệch không được thay source truth. Bài trùng title+gwp có2IDs. Đây là TEST ONLY, không dữ liệu SGK.

21 library groups kiểm: empty library/no phantom values; numeric grade/week/period sort; four subject groups; cascade narrowing/reset; missing field visibility và no false metadata; missing option narrowing; list stability after reverse catalog; duplicate identification; actual cached metadata priority; subject/filter preserving actual Teacher/TV snapshot; zero filter storage writes; cancel pending; disappeared reference clears stale selection; Recent shared pipeline/reset; common5actions; reload native session behavior; rememberedSubject-only không auto-load; all metadata absent still loadable; zero runtime/external errors. Screenshots1366/1280/1920 + validated preview nằm trong evidence ZIP.

Common scenario actions={json.dumps(library['interactions'][0]['observedAutomationActions'],ensure_ascii=False)}. Working và packaged đều5meaningful /6modeled mouse clicks, một modal, zero file-browser steps. selectOption là native dropdown automation, chưa kiểm chuột Windows. Ca đầu tiên visible trước click và explicitLoad visible sau preview được assert; arbitrary scroll/search/reading không có bảo đảm ≤5.

Performance observational only: working {json.dumps(library['performance'],ensure_ascii=False)}; packaged {json.dumps(packlibrary['performance'],ensure_ascii=False)}. Không benchmark physical/acceptance threshold; mỗi render đọc current metadata, tránh cache stale.

Quota: actual Chromium capacity reached at {quota['storedCharacters']} stored characters working /{pquota['storedCharacters']} packaged trong ca fixture. Essential commit bị block đúng; current Teacher/TV và unknown storage sentinel giữ nguyên, Recent không thêm failed lesson, warning visible. Fault injection lesson/library/snapshot failures preserve current; optional quota/security quick-access failures giữ successful load và warning sau modal close. Capacity limit vẫn tồn tại; test không tăng quota/xóa package.

Inherited safeguards15groups gồm four profile routing/mismatch, invalid metadata/packages/missing assets, preview not commit, rollback lỗi persistence/start/UI preflight, profile reset/TV no stale state, no teach ahead. G4-F01 patched real representative fixture được dùng nguyên byte (SHA2564488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8); không patch lesson package mới.

Fresh extracted artifact được kiểm ZIP CRC/full manifest1241files, target52groups lặp trên root/port riêng và60runtime/vendor/media assets HTTP byte-identical + modal close/reopen/close. Four regressions chạy một lần trên working; allpayloadhashes exact chứng minh fresh artifact cùng implementation, không tuyên bố đã lặp tất cả75groups trên ZIP.

HARNESS_HISTORY giữ run đầu thất bại vì helper giả định lesson=null sau reload. Frozen pedagogy-teacher.js đã có accepted-session restore; helper sửa để assert cùng accepted current ID + hidden disclosure và thêm fresh quick-subject-only context lesson=null. Không runtime change cho lỗi helper, không bỏ safeguard assertion.

WINDOWS_PHYSICAL_RUNTIME=UNRUN; PHYSICAL_TV_VALIDATION=UNRUN; REAL_CLASSROOM_TRIAL=UNRUN. Inherited waived Ti09/Ti10 real-file test không re-run hay convert thành PASS.
''')
profileRows='\n'.join(f"| {k} | {v['checks']} | PASS | {v['normalization']} |" for k,v in reg.items())
report('LESSON_LIBRARY_PHASE12_REGRESSION_REPORT.md',f'''
# Phase 12 — Regression report

| Profile | Groups | Result | Normalization for Phase11 JSON comparison |
|---|---:|---|---|
{profileRows}

75 groups semantic JSON equality với completed frozen Phase11 evidence. Legacy/Algebra no normalization; Geometry only random activationUUID across independent runs (within-run Teacher/TV/preview exact assertions executed); Informatics only manual video.currentTime (playback >0 verified). No screenshot hash/physical equivalence claim. Native no-teach-ahead/hidden steps/hints/sample/teacher-note assertions executed across profiles; Geometry35screens×2states, Informatics21screens×2states×3viewports. MCQ TV vertical full-width, instructions separate remain checked, no adaptive-column restoration.

SourceScope1241files exact path equality: only WEB_LIVE/subject-loader.js/css changed,1239byte-exact. Core, resolver, Geometry, Algebra, Informatics, Teacher/TV, common storage, zip import, assets/packages unchanged. Quick-access namespace/transaction/quota segments exact. Frozen Phase11 ZIP SHA before=after {source['sha256Before']}; frozen unpacked1241file manifest equals baseline.

Storage regression: filter change0setItem/removeItem; no persistent filter keys, asset or package duplication. RAM3filtervalues, metadata bounded per row; ephemeral list scales with library count, no unbounded persistent history/index. Existing Recent5 and8192character bound unchanged. P11-F01=P2 OPEN_DEFERRED; no capacity increase/fix claim. Actual-quota preservation and essential/optional-write faults PASS working+packaged.

Scope/CRC/manifests/new artifact hash + fresh52targetedgroups +60HTTPassets PASS. Inherited Core accepted-session restore unchanged. Invalid metadata/mismatch/transaction/state reset remain PASS. Production/main/old delivery branches are not implementation destinations; only separate Phase12 delivery branch receives artifacts.

Environment config revision12 unchanged/no Save/Publish; DRAFT_PENDING_SAVE_PUBLISH. Runtime/toolchain reuse only. Physical status remains all UNRUN. Historical report/checksum files embedded in payload unchanged; external Phase12 files identify current release.
''')
report('LESSON_LIBRARY_PHASE12_RISK_REGISTER.md','''
# Phase 12 — Risk register

New findings: P0=0,P1=0,P2=0,P3=0 after authorized cloud gates. Open carried P2=1. Phase12 technical PASS does not imply physical/classroom acceptance.

| ID | Class | Status | Evidence / scope |
|---|---|---|---|
| P11-F01 LOCALSTORAGE_STORAGE_CAPACITY | P2 | OPEN_DEFERRED | User canonical ID; prior Phase11 report alias P11-R01. Limit not removed. Guard/current preservation PASS, no crash/Recent payload. No IndexedDB/quota/delete/cache rewrite authorized. |

Storage capacity remains browser/origin dependent. Filter adds no persisted index and0writes, but native saved lesson packages still consume quota. Do not claim resolved; any later storage architecture work needs separate authorization. No package was automatically deleted.

Missing metadata stays accessible and explicitly incomplete. Unknown fields cannot confirm a known filter; incomplete bucket remains in compatible scope. GV must read preview before explicit load; no fabricated labels. Same title/gwp options have canonical ID, not filename inference. Fully fresh four-level selection and arbitrary reading/scroll may exceed5actions; measured common scenario5meaningful/6modeled mouse only.

660lesson library is synthetic TEST ONLY. No PPCT/SGK verification or new teaching data. Native accepted-session restore on reload is inherited and retained; lastSubject/Recent do not cause new auto-load. Unexpected stale/malformed package is still stage/validation-blocked; unreadable cache remains visible disabled.

Inherited Geometry G4-F02 OPEN_DEFERRED P3; G4-F03 FIXED; G4-F04 OPEN_DEFERRED P3; G4-F05 VALIDATION_PENDING. User-waived Ti09/Ti10 real-file validation NOT_RUN_BY_GV_DECISION. These are unchanged historical accepted-scope limitations, not new Phase12 findings and not marked resolved/PASS.

WINDOWS_PHYSICAL_RUNTIME=UNRUN; PHYSICAL_TV_VALIDATION=UNRUN; REAL_CLASSROOM_TRIAL=UNRUN; physical back-row reading/audible TTS UNRUN. Recommend GV review candidate then separately authorize physical acceptance. No Phase13/Production/main merge.

Environment draft revision12 unchanged, DRAFT_PENDING_SAVE_PUBLISH; no Publish/fresh-task restoration validation. Scripts/status in this evidence identify current Phase12 working/package roots without modifying frozen Environment Settings.
''')
final='''PHASE11_SHA256_BEFORE = {source}
PHASE11_SHA256_AFTER = {source}
PHASE11_CANDIDATE_MUTATED = NO

LESSON_LIBRARY_FILTER = PASS

SUBJECT_FILTER = PASS
GRADE_FILTER = PASS
WEEK_FILTER = PASS
PERIOD_FILTER = PASS

LESSON_LIST = PASS
MISSING_METADATA_HANDLING = PASS

GRADE_SORT = PASS
WEEK_NUMERIC_SORT = PASS
PERIOD_NUMERIC_SORT = PASS

RECENT_LESSONS = PASS (LIMIT 5)
REMEMBER_LAST_SUBJECT = PASS

COMMON_LIBRARY_LOAD_INTERACTION_COUNT = 5 meaningful; 6 modeled mouse clicks; remembered subject + one grade filter; Windows UNRUN

SUBJECT_METADATA_VALIDATION = PASS
SUBJECT_MISMATCH_BLOCK = PASS
TRANSACTIONAL_LOAD = PASS
CURRENT_LESSON_PRESERVATION = PASS
PROFILE_STATE_RESET = PASS

LOCALSTORAGE_QUOTA_GUARD = PASS
P11_F01_STATUS = P2 OPEN_DEFERRED (CAPACITY LIMIT NOT REMOVED)
STORAGE_REGRESSION = PASS

GEOMETRY_LOAD = PASS
ALGEBRA_LOAD = PASS
INFORMATICS_LOAD = PASS
LEGACY_LOAD = PASS

LEGACY_RUNTIME_REGRESSION = PASS
GEOMETRY_PROFILE_REGRESSION = PASS
ALGEBRA_PROFILE_REGRESSION = PASS
INFORMATICS_PROFILE_REGRESSION = PASS
NO_TEACH_AHEAD_GLOBAL = PASS

CORE_CHANGE_REQUIRED = NO
WEB_LIVE_CORE_MUTATED = NO
GEOMETRY_PROFILE_MUTATED = NO
ALGEBRA_PROFILE_MUTATED = NO
INFORMATICS_PROFILE_MUTATED = NO

WINDOWS_PHYSICAL_RUNTIME = UNRUN
PHYSICAL_TV_VALIDATION = UNRUN
REAL_CLASSROOM_TRIAL = UNRUN

P0_COUNT = 0
P1_COUNT = 0
P2_COUNT = 1 (P11-F01 carried OPEN_DEFERRED; new Phase12 P2 = 0)
P3_COUNT = 0 (new Phase12 findings; inherited accepted Geometry issues unchanged)

SOURCE_SCOPE_VIOLATION = NO
PRODUCTION_MODIFIED = NO

PHASE12_CANDIDATE = WEB_LIVE_LESSON_LIBRARY_PHASE12_CANDIDATE
PHASE12_CANDIDATE_SHA256 = {candidate}

PHASE12_STATUS = PASS (CLOUD TECHNICAL CANDIDATE ONLY)
RECOMMENDED_NEXT_ACTION = GV review/approve candidate; separately authorize physical acceptance; no next phase/Production

STOP
Chờ GV phê duyệt.
'''.format(source=source['sha256Before'],candidate=identity['sha256'])
(p/'FINAL_STATUS.txt').write_text(final)
report('README_PHASE12.txt',f'''
WEB LIVE LESSON LIBRARY PHASE12 CANDIDATE
Runtime ZIP: {identity['candidate']}.zip
SHA256: {identity['sha256']}
Extract all, keep directory structure. Existing full Windows launch scripts/dependencies remain inherited and unchanged. Windows physical start not executed in this cloud task.
Required5reports are beside ZIP. Evidence ZIP contains tests/results/screenshots/fixtures, not runtime lessons. Embedded older reports/checksums are historical; CANDIDATE_PAYLOAD_MANIFEST.json + external current CHECKSUMS identify Phase12.

Cloud reproduction: Python3 static server on selected root, no build/install:
python3 -B -m http.server 8788 --bind 127.0.0.1 --directory /workspace/phase12-lesson-library/packaged-smoke/WEB_LIVE_LESSON_LIBRARY_PHASE12_CANDIDATE
NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules
P12_ROOT=<extracted candidate> P12_BASE=http://127.0.0.1:8788 P12_LIBRARY_OUT=<external evidence> node library-tests.cjs
Quick regression uses P12_QUICK_OUT; safeguards uses P12_SAFEGUARD_OUT. Scripts need SYNTHETIC_LARGE_LIBRARY.json/NEGATIVE_FIXTURES next to them; existing external G4-F01 ZIP path documented in evidence. Never write test outputs into candidate. Inspect occupied ports before starting; do not stop unrelated servers. These are local reproduction instructions, not remote classroom links.

No Environment Settings write/Save/Publish. Draft revision12 unchanged; DRAFT_PENDING_SAVE_PUBLISH. Current runtime reused; fresh managed-task restore unverified. No secret requirements added. Full download link delivered after Git verification on isolated Phase12 branch; no main/Production.

Common interaction target5meaningful/6modeled clicks, qualified scenario only. P11-F01 P2 OPEN_DEFERRED. Windows/physicalTV/classroom UNRUN. STOP/chờ GV.
''')
# Bundle test-only artifacts and original helpers externally, excluding runtime roots and huge server logs.
bundle=out/'WEB_LIVE_LESSON_LIBRARY_PHASE12_EVIDENCE.zip'
include=['LIBRARY_RESULTS.json','LIBRARY_RUN.log','LIBRARY_FILTERS_1920.png','LIBRARY_FILTERS_1366.png','LIBRARY_FILTERS_1280.png','LIBRARY_VALIDATED_PREVIEW.png','SYNTHETIC_LARGE_LIBRARY.json','library-tests.cjs','quick-access-regression.cjs','safeguards.cjs','packaged-assets.cjs','gate-package.py','reports.py','SOURCE_MANIFEST_BEFORE.json','QUICK_ACCESS_RUN.log','SAFEGUARD_RUN.log','LEGACY_RUN.log','GEOMETRY_RUN.log','ALGEBRA_RUN.log','INFORMATICS_RUN.log','PACKAGED_LIBRARY_RUN.log','PACKAGED_QUICK_ACCESS_RUN.log','PACKAGED_SAFEGUARDS_RUN.log','PACKAGED_ASSETS_RUN.log']
directories=['QUICK_ACCESS_REGRESSION','SAFEGUARDS','REGRESSION','NEGATIVE_FIXTURES','HARNESS_HISTORY','PACKAGED_LIBRARY','PACKAGED_QUICK_ACCESS','PACKAGED_SAFEGUARDS','PACKAGED_SMOKE']
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in include:
  assert (p/n).is_file(),n;z.write(p/n,n)
 for directory in directories:
  for file in sorted((p/directory).rglob('*')):
   if file.is_file():z.write(file,str(file.relative_to(p)))
 fixture=Path('/workspace/g4-f01-fixture-revalidation/HINH8_VD2_GEOMETRY_PROFILE_TEST_G4F01_PATCHED.zip')
 assert sha(fixture.read_bytes())=='4488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8'
 z.write(fixture,'EXTERNAL_TEST_INPUTS/'+fixture.name)
with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
sidecars=['AUTHORIZE_PHASE12.txt','SOURCE_IDENTITY.json','SOURCE_SCOPE.json','CANDIDATE_PAYLOAD_MANIFEST.json','PACKAGE_IDENTITY.json','PATCH_FILES.diff','PREPACKAGE_GATE.json','RELEASE_GATE.json','REGRESSION_COMPARISON.json','ENVIRONMENT_SETTINGS_EVIDENCE.json','FINAL_STATUS.txt','README_PHASE12.txt']+sorted(x.name for x in p.glob('LESSON_LIBRARY_PHASE12_*.md'))
for n in sidecars:shutil.copy2(p/n,out/n)
(out/'CHECKSUMS_SHA256.txt').write_text(''.join(sha(f.read_bytes())+'  '+f.name+'\n' for f in sorted(out.iterdir()) if f.is_file() and f.name!='CHECKSUMS_SHA256.txt'))
print(json.dumps({'result':'PASS','files':len(list(out.iterdir())),'candidateSHA256':identity['sha256'],'evidenceBytes':bundle.stat().st_size,'groups':104+75+1,'assets':60},indent=2))
