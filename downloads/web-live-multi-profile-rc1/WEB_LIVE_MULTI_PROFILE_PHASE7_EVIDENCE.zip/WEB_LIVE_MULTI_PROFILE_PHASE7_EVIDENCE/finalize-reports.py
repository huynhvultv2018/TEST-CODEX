import json,pathlib,hashlib,zipfile,shutil
P=pathlib.Path(__file__).parent;O=pathlib.Path('/workspace/output/web-live-multi-profile-rc1')
def read(n):return json.loads((P/n).read_text())
def write(n,s):(P/n).write_text(s.strip()+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
integration=read('INTEGRATION_RESULTS.json');rc=read('RC_VALIDATION/INTEGRATION_RESULTS.json');assets=read('RC_VALIDATION/PACKAGED_ASSETS.json');identity=read('PACKAGE_IDENTITY.json')
assert integration['result']==rc['result']==assets['result']=='PASS';assert len(assets['assets'])==58
refs=read('SOURCE_INTEGRITY.json')
for name,r in refs.items():assert sha(pathlib.Path(r['zip']))==r['sha256Before']==r['sha256After']
manifest=read('RC1_PAYLOAD_MANIFEST.json')
for root in [P/'working/WEB_LIVE_MULTI_PROFILE_PHASE7_VALIDATION_COPY',P/'packaged-smoke/WEB_LIVE_MULTI_PROFILE_RC1']:
 actual={str(f.relative_to(root)):sha(f) for f in sorted(root.rglob('*')) if f.is_file()};assert actual==manifest
write('RELEASE_GATE.json',json.dumps({'result':'PASS','prepackageGate':'PASS','packagedIntegration':'PASS','packagedAssets':'PASS','assets':58,'files':1239,'runtimeErrors':0,'externalRuntimeRequests':0,'frozenReferencesMutated':False,'productionModified':False,'newPhase7OpenFindings':{'P0':0,'P1':0,'P2':0,'P3':0}},indent=2))
frozen='\n'.join(f"{n} Phase{r['phase']}: BEFORE = AFTER = {r['sha256Before']}; MUTATED = NO; {r['files']} files unchanged." for n,r in refs.items())
write('MULTI_PROFILE_PHASE7_INTEGRATION_REPORT.md',f'''# WEB LIVE Multi-Profile — Phase 7

PHASE7_STATUS = PASS (cloud technical integration only).
RC1_CREATED = YES. RELEASE CANDIDATE; no Production.

## Scope and integrity

Authority: AUTHORIZE_PHASE7.txt, resumed by GV instruction “tiep tuc tien trinh Phase 7”. Existing checkouts reused; no worktrees. Cloud environment onboarding skill used for temporary static servers/readiness/testing. Environment Settings were read only: revision 12 unchanged; ENVIRONMENT_STARTUP_INSTRUCTIONS = DRAFT_PENDING_SAVE_PUBLISH.

No application files added, changed or removed relative to frozen Phase6. Entire 1239-file payload byte-identical. Core, HTML/importer, state schema, navigation/sync, shared CSS, pedagogy and all profiles unchanged. External validation helpers/reports only. No feature/refactor/UI/schema redesign/performance rewrite/automatic patch. Frozen references never edited.

{frozen}

## Integration result

ONE CORE/MULTIPLE PROFILES: existing WEB_LIVE/core-profiles.js resolver and adapter/lifecycle boundaries select Legacy/Geometry/Algebra/Informatics. Existing profile presentation modules supply subject behavior; no duplicate Core or independent engine created. Core Phase2 REGISTERED_STUB descriptor for Algebra/Informatics is retained historical metadata; actual adapter APIs are IMPLEMENTED and dispatch tested.

PROFILE_RESOLVER = PASS: 12 inputs checked on Teacher, embedded Preview and native TV popup. Explicit geometry/algebra/informatics, absent/unknown/null/number/object/array/empty/whitespace engines and normalized Algebra string route without runtime crash.

PROFILE_SWITCHING, STATE_ISOLATION, CSS_ISOLATION, REVEAL_ISOLATION = PASS: required four sequences, 14 entries on continuously open pages. Each profile is dirtied before switching. Geometry figure/annotation/proof/Focus/layout/zoom; Algebra reveal/highlight/Focus/hint/answer; Informatics activity/code/highlight/checkpoint/Focus/answer/sample; Legacy hint/reveal exercised. Fresh next-profile context resets correctly and contains no old profile controls or foreign annotations/reveal. Authored lesson memory remains exact. Own Geometry persisted annotations may restore in their own scene; no cross-profile leakage.

INVALID_DATA_SAFETY = PASS: 10 malformed/missing/empty-screen-object/optional-data cases after dirty Informatics. Unknown profiles additionally covered by resolver cases. Empty screen means a present screen object with no fields; arbitrary corrupt JSON and a completely empty lesson are outside this finite suite. Optional missing media and malformed blocks/code/Algebra/Geometry metadata do not crash or cross-reveal.

LEGACY_COMPATIBILITY = PASS: absent subject_engine runs without migration; fresh frozen-reference regression also passes.

NO_TEACH_AHEAD_GLOBAL = PASS for tested fixtures: authored content unchanged; future proof/math/code/comparison, hidden hints, unapproved sample and private notes protected. Native answer-priority still hides hint while answer is active. Sample requires checkpoint + GV confirmation + explicit reveal. No generation/solver/code execution introduced.

TV_LAYOUT_INTEGRATION = PASS: 12 dirty-profile cases at 1920×1080, 1366×768, 1280×720; additional inherited figure/math/code/table/media/MCQ suites. MCQ remains vertical full-width independent rows with separate instructions. Screenshots reviewed for representative Algebra and Informatics dirty Focus states. Physical/back-row acceptance remains UNRUN.

CROSS_PROFILE_STRESS_TEST = PASS within recorded 8-cycle/48-switch diagnostics. See test evidence and risk register for resource measurements and retained per-activation sample booleans; no production-grade benchmark claim.

## Packaged release validation

Fresh RC1 extraction CRC and all 1239 file hashes match frozen Phase6. RC integration repeated all six groups, 14 requested entries, 10 invalid probes, 48 stress switches and 12 viewport cases. Served 58 runtime/profile/MathJax/media/fixture assets match local package bytes; native importer closes/reopens/closes. Zero collected page runtime errors and external runtime requests in integration runs. RELEASE_GATE.json = PASS.

RC1 SHA256: {identity['sha256']}

Known accepted G4-F02/F04 deferred, G4-F03 fixed and G4-F05 pending remain unchanged. Real-file validation waived by GV; Windows/physical TV/classroom unrun. New Phase7 open findings P0/P1/P2/P3 = 0/0/0/0, excluding inherited accepted Geometry items.

STOP. Wait GV approval; no automatic patch, next phase, merge or Production.
''')
s=integration['stress'];b=s[0];a=s[-1]
write('MULTI_PROFILE_PHASE7_TEST_EVIDENCE.md',f'''# Phase 7 — Evidence

## Raw evidence and targets

INTEGRATION_RESULTS.json + INTEGRATION_RUN.log: PASS; 6 groups, 12 resolver inputs, 14 sequence entries, 10 invalid cases, 8 cycles/48 stress switches, 12 TV layout cases, 4 captures. Linux Chromium {integration['browser']} via Playwright; static Python HTTP. All evidence/helpers outside frozen/runtime payload.

Final source/ports: Geometry Phase4 8775, Algebra Phase5 8777, frozen Informatics Phase6 8781, Phase7 byte-copy 8780, fresh extracted RC1 8782. These loopback endpoints are internal tests, not public previews. No npm build/install needed for the existing static application. Existing Chromium/Node/Playwright reused.

Commands from /workspace (NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules):
- node /workspace/phase7-multi-profile-integration/integration.cjs
- node /workspace/phase7-multi-profile-integration/REGRESSION/FROZEN_GEOMETRY/geometry-runtime.cjs and corresponding PHASE7 helper
- node /workspace/phase7-multi-profile-integration/REGRESSION/FROZEN_ALGEBRA/targeted-algebra.cjs and corresponding PHASE7 helper
- Informatics helper with INFORMATICS_ROOT/INFORMATICS_BASE/INFORMATICS_EVIDENCE selecting explicit frozen root:8781 or Phase7 root:8780
- Frozen GEOMETRY_PHASE3_TESTS/engines.cjs with WEB_LIVE_TEST_ROOT/WEB_LIVE_BROWSER_BASE/PHASE2_EVIDENCE selecting those same roots and external evidence
- python3 /workspace/phase7-multi-profile-integration/gate-and-package.py (one-shot; refuses existing RC1 overwrite)
- node /workspace/phase7-multi-profile-integration/rc-integration.cjs
- node /workspace/phase7-multi-profile-integration/rc-assets.cjs

All final processes exit 0 with populated fresh result files. Native Teacher popup plus embedded Preview and TV stay open during switching/stress; no page reload resets each transition.

## Stress measurements

Warmed baseline and final CDP process/renderer counters (Teacher/TV sessions may share one renderer; these are not independent page-owned leak totals):
{json.dumps({'before':b,'after':a},indent=2)}

Event listeners: 797 → 797; nodes 2065 → 2064; measured heap 16,296,556 → 16,930,096 bytes (~3.9%). Two profile style links and one MathJax script remain; inactive Teacher panels absent. Guards: listeners baseline+30, nodes baseline+500, final GC heap ≤ baseline×1.5+4MiB. All rounds recorded. These finite diagnostics do not prove indefinite runtime flatness.

Informatics persistence keys 15→23 and chars 1845→2829: eight distinct activation-scoped sample/checkpoint boolean entries retained. Re-import starts with hidden/unconfirmed sample; no active state collision. This deliberate persistence growth is reported, not described as zero growth. No engine patch or expiration feature added.

## Harness/setup failures preserved

HARNESS_HISTORY/ATTEMPT1: wrong external selector .geometryProofStep; frozen rendered proof class is .proofStep. Selector corrected only in external helper; expected two proof steps then verified.

HARNESS_HISTORY/ATTEMPT2: wrong expectation that hint stays visible after answer reveal. Existing cognitive-tv.css native answer-priority hides hint; profile removes concealed hint source. Corrected helper asserts dirty showHint flag=true and hint invisible, then flag resets on next profile. No product patch.

HARNESS_HISTORY/REFERENCE_SERVER_8779: stale reference server returned ERR_EMPTY_RESPONSE before app load. Preserved logs, started fresh read-only frozen-reference server 8781 with redirected output and verified GET readiness. Both affected reference suites reran and passed. Not an engine/profile defect; no speculative product root cause.

## Package, scope and evidence

RC_VALIDATION/INTEGRATION_RESULTS.json: full fresh packaged integration PASS; RC_VALIDATION/PACKAGED_ASSETS.json: 58 assets + modal lifecycle PASS.
SOURCE_INTEGRITY.json and before/after manifests: all three frozen ZIPs/directories unchanged.
SOURCE_SCOPE.json: 0 changed/added/removed payload files.
REGRESSION_COMPARISON.json: all four fresh reference comparisons PASS.
PREPACKAGE_GATE.json and RELEASE_GATE.json: PASS.
ENVIRONMENT_SETTINGS_EVIDENCE.json: full draft unchanged, revision12, no write/publish.
RC1_PAYLOAD_MANIFEST.json and PACKAGE_IDENTITY.json: all1239files, CRC/hash identity.

REAL_FILE_VALIDATION = NOT_RUN_BY_GV_DECISION. WINDOWS_PHYSICAL_RUNTIME = UNRUN. PHYSICAL_TV_VALIDATION = UNRUN. REAL_CLASSROOM_TRIAL = UNRUN. Audible native Windows TTS and classroom back-row readability unrun. Test fixtures are not certified real lesson/package acceptance.
''')
write('MULTI_PROFILE_PHASE7_REGRESSION_REPORT.md','''# Phase 7 — Frozen profile regression

Fresh frozen-reference and Phase7 byte-copy runs all passed; external helpers adapt only root/port/evidence paths and capture settling. Frozen helpers/application/test payload never modified.

| Profile | Reference | Fresh checks per target | Result |
|---|---|---|---|
| Geometry | Frozen Phase4 | 14 checks; 35 screens/70 states; 23 visuals | PASS |
| Algebra | Frozen Phase5 | 20 checks; 10 fixture screens; 30 question/12 disclosed viewport cases; 8 captures | PASS |
| Informatics | Frozen Phase6 | 26 checks; 21 screens×hidden/full×3 sizes=126 cases; 3 sample/comparison cases; 6 captures | PASS |
| Legacy/default | Frozen Phase6 inherited Legacy behavior | 5 lesson packages; 171 screens/342 states; 44 visual metrics; 15 assertions | PASS |

Comparison: REGRESSION_COMPARISON.json. Geometry JSON exact after removing only per-import lessonActivation UUIDs (23 records); all native intra-run Teacher/Preview/TV parity remains asserted. Algebra JSON exact with no normalization. Informatics JSON exact except video currentTime (reference0.030376s versus Phase7 0.016790s), both independent manual playback checks >0; controls/aspect ratio/autoplay and all semantic/layout assertions exact. Legacy JSON fully exact with no normalization. Screenshot raster hashes are not asserted identical; screenshots accompany exact functional/DOM/layout evidence.

All test-owned errors/request/overflow collections clean; no test case disabled to obtain PASS. Expected fallback behavior for intentionally malformed data retained. G4-F01 auxiliary corrected test fixture is test-only and imported unchanged; original bundled fixture/frozen packages untouched. Geometry own-scene annotation persistence and native Algebra answer-priority are inherited contracts.

Local MathJax/offline behavior, future-step protection, Focus emphasis, vertical MCQ options, table/code/media fit and old package no-migration all exercised. NO_TEACH_AHEAD_GLOBAL PASS for the finite tested fixtures. No new feature/pedagogy output introduced.

Packaged RC1 reruns integrated sequences/isolation/invalid/stress/layout against fresh extracted payload and verifies 58 served asset hashes/modal lifecycle. Full inherited regression evidence applies to byte-identical1239file payload; no claim of Windows/physicalTV/classroom acceptance.
''')
write('MULTI_PROFILE_PHASE7_RISK_REGISTER.md','''# Phase 7 — Risk register

New reproduced application findings: none. Open Phase7 P0=0, P1=0, P2=0, P3=0. Counts exclude already accepted Geometry deferred/pending items. No automatic patch/defer; frozen code unchanged.

| Item | Status | Owner / action |
|---|---|---|
| G4-F02 | OPEN_DEFERRED (inherited P3) | Retain GV accepted disposition; no Phase7 patch |
| G4-F03 | FIXED | Retain frozen approved fix |
| G4-F04 | OPEN_DEFERRED (inherited P3) | Retain GV accepted disposition; no Phase7 patch |
| G4-F05 | VALIDATION_PENDING | Pending original real-package validation; not PASS |
| Real-file lesson validation | NOT_RUN_BY_GV_DECISION | Preserve explicit waiver |
| Windows physical runtime | UNRUN | GV future physical acceptance |
| Physical TV / back-row readability | UNRUN | GV future physical acceptance |
| Real classroom trial | UNRUN | GV future classroom acceptance |
| Environment startup draft | DRAFT_PENDING_SAVE_PUBLISH | Revision12 unchanged; separate approval required before Settings edits |

Finite stress diagnostics: 48 switches only; garbage-collected process/renderer counters are not a long-duration production benchmark. Heap rises ~3.9%, listeners stable, small per-activation sample boolean persistence increases8keys/984chars. Scope-key separation and default-hidden re-import pass. Unbounded-session storage lifetime/cleanup policy is outside this validation; no reproduced classroom failure or speculative root-cause assignment, and no expiration feature implemented.

Invalid-data suite covers named malformed/missing optional fields and a present empty screen object; not every arbitrary corrupt binary/JSON or zero-screen lesson. Synthetic profile metadata and media fixtures do not certify actual SGK/SOẠN_TRƯỚC packages.

Harness incidents recorded separately, not P0–P3 application findings: wrong Geometry selector, wrong Algebra hint-vs-answer expectation, stale reference8779server startup failure. Proven helper/setup diagnoses, corrected externally and affected steps rerun PASS; originals preserved under HARNESS_HISTORY. No engine change used to conceal fixture/harness issues.

This release is RC1 only. STOP after report/download delivery; wait GV review/approval. No Production, next phase or automatic patch.
''')
write('MULTI_PROFILE_RC1_MANIFEST.md',f'''# WEB_LIVE_MULTI_PROFILE_RC1 — Manifest

Kind: RELEASE CANDIDATE; Production = NO.
ZIP: WEB_LIVE_MULTI_PROFILE_RC1.zip
SHA256: {identity['sha256']}
Bytes: {identity['bytes']}
Root: WEB_LIVE_MULTI_PROFILE_RC1/
Files: 1239; no directory-only entries.

Payload lineage: frozen Phase6 complete package; all1239relative paths and bytes unchanged. New root name/ZIP identity only. No source patch/addition/removal. Includes existing Core + Legacy/Geometry/Algebra/Informatics, existing launcher/static runtime/assets and inherited tests/history. Inherited Phase3/4/5 docs/checksums inside ZIP are historical and do not identify RC1; this external manifest, RC1_PAYLOAD_MANIFEST.json and CHECKSUMS_SHA256.txt identify RC1.

{frozen}

CRC = PASS; fresh extraction manifest exact; packaged integration = PASS; 58 served assets/modal lifecycle = PASS; RELEASE_GATE = PASS. Runtime folder WEB_LIVE contains teacher.html/tv.html and existing local dependencies. No new build/install required. Existing Windows launchers were carried byte-for-byte, not physically executed/accepted in Phase7.

Required five reports delivered beside ZIP, not injected into frozen-derived runtime payload. Plain FINAL_STATUS.txt and CHECKSUMS_SHA256.txt also provided; WEB_LIVE_MULTI_PROFILE_PHASE7_EVIDENCE.zip contains external raw tests/results/logs/captures/source manifests/harness failure history (no duplicated application payload).

Known inherited G4-F02/F04 OPEN_DEFERRED, G4-F03 FIXED, G4-F05 VALIDATION_PENDING. REAL_FILE_VALIDATION NOT_RUN_BY_GV_DECISION; WINDOWS_PHYSICAL_RUNTIME/PHYSICAL_TV_VALIDATION/REAL_CLASSROOM_TRIAL UNRUN. Environment draft unchanged/unpublished. No main/Production merge.

STOP / WAIT_FOR_GV_APPROVAL.
''')
lines=[]
for n,r in refs.items():
 lines += [f"{n}_PHASE{r['phase']}_SHA256_BEFORE = {r['sha256Before']}",f"{n}_PHASE{r['phase']}_SHA256_AFTER = {r['sha256After']}",f"{n}_PHASE{r['phase']}_MUTATED = NO",'']
for n in ['PROFILE_RESOLVER','PROFILE_SWITCHING','STATE_ISOLATION','CSS_ISOLATION','REVEAL_ISOLATION','LEGACY_COMPATIBILITY','INVALID_DATA_SAFETY','GEOMETRY_PROFILE_REGRESSION','ALGEBRA_PROFILE_REGRESSION','INFORMATICS_PROFILE_REGRESSION','LEGACY_RUNTIME_REGRESSION','NO_TEACH_AHEAD_GLOBAL','TV_LAYOUT_INTEGRATION','CROSS_PROFILE_STRESS_TEST']:lines.append(n+' = PASS')
lines += ['', 'G4_F02_STATUS = OPEN_DEFERRED','G4_F03_STATUS = FIXED','G4_F04_STATUS = OPEN_DEFERRED','G4_F05_STATUS = VALIDATION_PENDING','','REAL_FILE_VALIDATION = NOT_RUN_BY_GV_DECISION','WINDOWS_PHYSICAL_RUNTIME = UNRUN','PHYSICAL_TV_VALIDATION = UNRUN','REAL_CLASSROOM_TRIAL = UNRUN','','ENVIRONMENT_STARTUP_INSTRUCTIONS = DRAFT_PENDING_SAVE_PUBLISH','','P0_COUNT = 0','P1_COUNT = 0','P2_COUNT = 0','P3_COUNT = 0','','SOURCE_SCOPE_VIOLATION = NO','PRODUCTION_MODIFIED = NO','','RC1_CREATED = YES','RC1_NAME = WEB_LIVE_MULTI_PROFILE_RC1','RC1_SHA256 = '+identity['sha256'],'','PHASE7_STATUS = PASS','RECOMMENDED_NEXT_ACTION = WAIT_FOR_GV_APPROVAL','','STOP']
write('FINAL_STATUS.txt','\n'.join(lines))
targets=read('REGRESSION_TARGETS.json');targets['FROZEN_INFORMATICS'][1]=8781;write('REGRESSION_TARGETS_FINAL.json',json.dumps(targets,indent=2))
selected=['AUTHORIZE_PHASE7.txt','FINAL_STATUS.txt','MULTI_PROFILE_PHASE7_INTEGRATION_REPORT.md','MULTI_PROFILE_PHASE7_TEST_EVIDENCE.md','MULTI_PROFILE_PHASE7_REGRESSION_REPORT.md','MULTI_PROFILE_PHASE7_RISK_REGISTER.md','MULTI_PROFILE_RC1_MANIFEST.md','RC1_PAYLOAD_MANIFEST.json','PACKAGE_IDENTITY.json','SOURCE_INTEGRITY.json','SOURCE_SCOPE.json','REGRESSION_COMPARISON.json','PREPACKAGE_GATE.json','RELEASE_GATE.json','ENVIRONMENT_SETTINGS_EVIDENCE.json']
for n in selected:shutil.copy2(P/n,O/n)
z=O/'WEB_LIVE_MULTI_PROFILE_PHASE7_EVIDENCE.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for p in sorted(P.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  relative=p.relative_to(P)
  if relative.parts[0] in ['working','packaged-smoke'] or p.name.endswith('SERVER.log') or p.name.startswith('remote-refs'):continue
  f.write(p,'WEB_LIVE_MULTI_PROFILE_PHASE7_EVIDENCE/'+str(relative))
with zipfile.ZipFile(z) as f:assert f.testzip() is None
(O/'CHECKSUMS_SHA256.txt').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(O.iterdir()) if p.is_file() and p.name!='CHECKSUMS_SHA256.txt'))
print('Five required reports + plain status + full external evidence delivered')
print('RC1 SHA256 = '+identity['sha256'])
