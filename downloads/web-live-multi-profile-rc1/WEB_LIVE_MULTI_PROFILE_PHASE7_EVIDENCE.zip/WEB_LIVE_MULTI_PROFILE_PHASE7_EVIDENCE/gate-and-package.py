import hashlib,json,pathlib,zipfile
P=pathlib.Path(__file__).parent
def read(p):return json.loads(p.read_text())
def save(n,d):(P/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest(root):return {str(f.relative_to(root)):sha(f) for f in sorted(root.rglob('*')) if f.is_file()}
refs=read(P/'FROZEN_REFERENCES.json')
for name,r in refs.items():
 m=manifest(pathlib.Path(r['root']));assert m==read(P/(name+'_MANIFEST_BEFORE.json'))
 r['sha256After']=sha(pathlib.Path(r['zip']));assert r['sha256After']==r['sha256Before'];r['mutated']=False
 save(name+'_MANIFEST_AFTER.json',m)
save('SOURCE_INTEGRITY.json',refs)
work=P/'working/WEB_LIVE_MULTI_PROFILE_PHASE7_VALIDATION_COPY';payload=manifest(work)
assert payload==read(P/'INFORMATICS_MANIFEST_BEFORE.json')
save('SOURCE_SCOPE.json',{'result':'PASS','files':len(payload),'changed':[],'added':[],'removed':[],'applicationPatched':False,'frozenReferencesMutated':False,'productionModified':False})
pairs=[('GEOMETRY','FROZEN_GEOMETRY/GEOMETRY_RUNTIME/geometry-runtime.json','PHASE7/GEOMETRY_RUNTIME/geometry-runtime.json'),('ALGEBRA','FROZEN_ALGEBRA/ALGEBRA_TARGETED.json','PHASE7/ALGEBRA_TARGETED.json'),('INFORMATICS','FROZEN_INFORMATICS/INFORMATICS_TARGETED.json','PHASE7/INFORMATICS/INFORMATICS_TARGETED.json'),('LEGACY','FROZEN_INFORMATICS/ENGINES/results.json','PHASE7/ENGINES/results.json')]
def normalize(d,profile):
 if isinstance(d,dict):return {k:normalize(v,profile) for k,v in d.items() if not (profile=='GEOMETRY' and k=='lessonActivation') and not(profile=='INFORMATICS' and k=='currentTime')}
 if isinstance(d,list):return [normalize(v,profile) for v in d]
 return d
comparison={}
for name,a,b in pairs:
 left=read(P/'REGRESSION'/a);right=read(P/'REGRESSION'/b)
 assert not left['errors'] and not right['errors']
 if 'checks' in right:assert all(c['result']=='PASS' for c in right['checks']) and all(c['result']=='PASS' for c in left['checks'])
 assert normalize(left,name)==normalize(right,name),name+' regression mismatch'
 comparison[name]={'result':'PASS','reference':a,'phase7':b,'normalization':{'GEOMETRY':'Per-import lessonActivation UUID only (all 23 records); native intra-run parity still asserted.','INFORMATICS':'Video currentTime only; both runs independently asserted manual playback >0. All dimensions, controls and autoplay constraints remain exact.'}.get(name,'NONE'),'checks':len(right.get('checks',right.get('assertions',[])))}
save('REGRESSION_COMPARISON.json',comparison)
integration=read(P/'INTEGRATION_RESULTS.json');assert integration['result']=='PASS' and len(integration['checks'])==6
env=read(P/'ENVIRONMENT_SETTINGS_EVIDENCE.json');assert env['fullDraftUnchanged'] and not env['configurationWritten']
save('PREPACKAGE_GATE.json',{'result':'PASS','integration':'PASS','regression':{n:'PASS' for n in comparison},'scope':'PASS','frozenIntegrity':'PASS','environmentSettingsUnchanged':True,'phase7OpenFindings':{'P0':0,'P1':0,'P2':0,'P3':0},'knownAcceptedGeometryItemsExcludedFromNewFindingCounts':True})
output=pathlib.Path('/workspace/output/web-live-multi-profile-rc1');output.mkdir(exist_ok=True)
z=output/'WEB_LIVE_MULTI_PROFILE_RC1.zip';assert not z.exists(),'Do not overwrite existing RC1'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as f:
 for relative in payload:f.write(work/relative,'WEB_LIVE_MULTI_PROFILE_RC1/'+relative)
unpack=P/'packaged-smoke';unpack.mkdir(exist_ok=True)
with zipfile.ZipFile(z) as f:
 assert f.testzip() is None
 assert len(f.namelist())==len(payload)
 f.extractall(unpack)
assert manifest(unpack/'WEB_LIVE_MULTI_PROFILE_RC1')==payload
save('RC1_PAYLOAD_MANIFEST.json',payload)
save('PACKAGE_IDENTITY.json',{'name':'WEB_LIVE_MULTI_PROFILE_RC1','kind':'RELEASE_CANDIDATE','zip':str(z),'sha256':sha(z),'bytes':z.stat().st_size,'files':len(payload),'crc':'PASS','freshExtractionByteEquality':'PASS','applicationChangesFromPhase6':0,'production':False})
print('PREPACKAGE_GATE = PASS; RC1 packaged and extracted; all 1239 payload files equal frozen Phase6')
print(sha(z))
