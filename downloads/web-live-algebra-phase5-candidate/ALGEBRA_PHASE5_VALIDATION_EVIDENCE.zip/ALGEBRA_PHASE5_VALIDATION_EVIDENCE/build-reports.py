from pathlib import Path
import json
import shutil

p = Path(__file__).resolve().parent
out = Path('/workspace/output/web-live-algebra-phase5-candidate')
read = lambda name: json.loads((p / name).read_text())
package = read('PACKAGE_IDENTITY.json')
targeted = read('ALGEBRA_TARGETED.json')
regression = read('REGRESSION_SUMMARY.json')
smoke = read('PACKAGED_ALGEBRA_SMOKE.json')
scope = read('SOURCE_SCOPE.json')
assert targeted['result'] == regression['result'] == smoke['result'] == scope['result'] == 'PASS'
assert len(smoke['assets']) == 53 and len(smoke['checks']) == 8
sha4 = package['geometryReferenceSHA256']
sha5 = package['sha256']
status = f'''GEOMETRY_PHASE4_CANDIDATE = WEB_LIVE_GEOMETRY_PHASE4_CANDIDATE (FROZEN)
GEOMETRY_PHASE4_SHA256 = {sha4}
GEOMETRY_PHASE4_MUTATED = NO

ALGEBRA_PROFILE = IMPLEMENTED

MATHJAX_RENDERING = PASS
FRACTION_RENDERING = PASS
EXPRESSION_RENDERING = PASS
EQUATION_RENDERING = PASS
SYSTEM_RENDERING = PASS

STEP_REVEAL = PASS
STEP_HIGHLIGHT = PASS
ALGEBRA_FOCUS = PASS
ERROR_COMPARISON = PASS
HINT_CONTROL = PASS
ANSWER_CONTROL = PASS
NO_TEACH_AHEAD = PASS

CORE_CHANGE_REQUIRED = NO
WEB_LIVE_CORE_MUTATED = NO

LEGACY_RUNTIME_REGRESSION = PASS
GEOMETRY_PROFILE_REGRESSION = PASS
INFORMATICS_PROFILE_ISOLATION = PASS

P0_COUNT = 0
P1_COUNT = 0
P2_COUNT = 0
P3_COUNT = 0

SOURCE_SCOPE_VIOLATION = NO
PRODUCTION_MODIFIED = NO

PHASE5_CANDIDATE = WEB_LIVE_ALGEBRA_PHASE5_CANDIDATE
PHASE5_CANDIDATE_SHA256 = {sha5}

PHASE5_STATUS = PASS
RECOMMENDED_NEXT_PHASE = WAIT_FOR_GV_APPROVAL
'''
(p / 'FINAL_STATUS.txt').write_text(status + '\nSTOP\n')

implementation = f'''# ALGEBRA_PHASE5_IMPLEMENTATION_REPORT

Algebra Profile đã được triển khai và qua targeted/global regression theo phê duyệt `AUTHORIZE_PHASE5.txt`. Không cần thay Core. Geometry Phase4 đã được đóng băng và không sửa. Candidate mới được tạo sau gate PASS; fresh ZIP smoke cũng PASS.

## Geometry freeze và trạng thái giữ nguyên

`WEB_LIVE_GEOMETRY_PHASE4_CANDIDATE`, SHA256 `{sha4}`, technical PASS, status FROZEN. 1.227 file nguồn trùng ZIP và manifest trước/sau. Không Production.

G4-F01 TARGETED_PASS; G4-F02 OPEN_DEFERRED P3; G4-F03 FIXED/targeted PASS; G4-F04 OPEN_DEFERRED P3; G4-F05 VALIDATION_PENDING. REAL_FILE_VALIDATION=NOT_RUN_BY_GV_DECISION; REAL_CLASSROOM_TRIAL=UNRUN. Không chuyển waiver/pending/deferred thành PASS, không yêu cầu transfer các real files được waive.

## Kiến trúc/phạm vi

Sử dụng Core/Profile hiện tại. `WEB_LIVE/tv-layout-algebra.js` giữ nguyên byte phần `TVAlgebraEngine` cũ rồi thêm adapter `WebLiveProfiles.registerAdapter('algebra', {{presentation}})` và lifecycle cleanup. Không dựng engine độc lập/solver/state controller; không sửa HTML để nối script. Native Teacher controls và iframe preview vẫn là giao diện điều khiển.

Working copy riêng: `working/WEB_LIVE_ALGEBRA_PHASE5_WORKING_COPY`. Payload mới 1.233 file: khác đúng một file Algebra-owned; 1.226 file cũ nguyên byte; thêm đúng sáu file được liệt kê trong SOURCE_SCOPE.json. Core registry, importer, state/sync/navigation/disclosure, shared CSS/math, Geometry JS/CSS/contract/fixtures, Informatics stub, launcher không sửa. Existing Legacy layout code trong file Algebra giữ nguyên prefix và behavior được kiểm bằng paired regression.

Thêm Algebra CSS scoped `.algebraProfile`, local MathJax 3.2.2 `tex-svg-full.js`/Apache-2.0 LICENSE/package metadata, test-only JSON và README. MathJax npm tarball integrity SHA512 được xác minh trước khi lấy selected files; provenance trong ALGEBRA_PATCH_PROVENANCE.json/MATHJAX_PACKAGE_METADATA.json. Không thay dependency/lockfile cũ, không CDN hoặc remote font.

Actual runtime implementation status là `WebLiveAlgebra.status=IMPLEMENTED`. Core descriptor Phase2 vẫn có `REGISTERED_STUB`; đó là scaffold metadata cố định, không gate dispatch. Không sửa Core chỉ để đổi label này; contract giải thích rõ cách xác định implementation.

## Behavior

- MathJax SVG dựng phân số tử/bar/mẫu, lũy thừa, căn, đa thức/biểu thức, phương trình, bất phương trình và hệ hai hàng có ngoặc. Chỉ convert authored TeX delimited; không suy luận công thức/phương pháp từ prose.
- Native steps quyết định reveal. Read-only state phân biệt UNREVEALED/REVEALED, CURRENT/COMPLETED. Future proof và supporting metadata không mount vào DOM. Native Previous Step/Hide Answer tiếp tục hoạt động.
- Current/selected step được nhấn mạnh; các bước đã mở vẫn nhìn thấy và giảm nhấn mạnh. Focus không đổi reveal/source/hint/answer/navigation/board/figure state. XÓA TẬP TRUNG phục hồi presentation theo reveal state.
- Optional metadata `original/reason/result` đi cùng native step đã mở. Equation và reason có thể đặt cạnh nhau trong cùng full-width step row; không mất source text. Arrows không lấy thêm chiều cao mỗi row. MCQ vẫn bốn hàng độc lập full-width và instruction riêng.
- Student/correct comparison chỉ từ dữ liệu được cung cấp và chỉ hiện sau reveal step liên quan. Không tự tạo lỗi học sinh. Hint/answer obey native control và native priority; hint bị che không có trong TV DOM.
- Tám stage labels là optional authored metadata; không ép mọi lesson đủ chuỗi và không tạo màn hình/nội dung.
- Async MathJax jobs được guard theo profile/activation/source/index/version/epoch/connected nodes. Switching profile dọn owned context/markers; stale jobs không chèn nội dung vào màn hình mới.

## Validation và candidate

Targeted 20 checks PASS; 30 question viewport cases + 12 full-answer cases ở 1920×1080/1366×768/1280×720; eight captured states. Eight lifecycle/race cases PASS. Global Legacy/Geometry/Informatics PASS against frozen Phase4. Fresh ZIP: 53 served assets byte-identical, eight smoke checks PASS, four-step full answer fits 1280×720.

Hai lỗi P2 trong quá trình phát triển (visible duplicate assistive MathML; Algebra layout overflow) đã FIXED và retest PASS; failure evidence giữ trong HARNESS_HISTORY. Xem risk register để phân biệt finding đã đóng, Geometry findings kế thừa và coverage chưa chạy. Các bộ đếm P0–P3 trong final block đếm **finding Phase5 còn mở**: đều 0.

Candidate `WEB_LIVE_ALGEBRA_PHASE5_CANDIDATE.zip`: {package['bytes']:,} bytes, 1.233 files, CRC PASS, payload bằng working manifest. SHA256 `{sha5}`. Không overwrite Geometry/Phase3 candidate.

Các báo cáo/checksums Phase3/4 kế thừa **trong payload** là lịch sử. Release Phase5 dùng các báo cáo, PHASE5_PAYLOAD_MANIFEST.json, PACKAGE_IDENTITY.json và CHECKSUMS_SHA256.txt **ngoài ZIP**. Fixture mới chỉ 5.503 bytes/10 screens, không phải SGK/source sư phạm; chưa xác nhận lesson/classroom thật hoặc native Windows/physical TV/audible TTS.

Cloud startup draft đã lưu, chỉ cập nhật instructions; install/network/secrets/repositories giữ nguyên. Review/save trong Environment Settings rồi Publish để áp dụng. Fresh-task restoration chưa được kiểm chứng.

## Final block

```text
{status.rstrip()}
```

STOP — chờ GV review. Không Production, không bắt đầu Informatics Profile.
'''
(p / 'ALGEBRA_PHASE5_IMPLEMENTATION_REPORT.md').write_text(implementation)

test_rows = '\n'.join(f'| {n+1} | {c["name"]} | {c["result"]} |' for n, c in enumerate(targeted['checks']))
transition_rows = '\n'.join(f'| {c["name"]} | {c["result"]} |' for c in read('PROFILE_TRANSITIONS.json')['cases'])
evidence = f'''# ALGEBRA_PHASE5_TEST_EVIDENCE

Browser native Chromium {targeted['browser']} trên Linux. Không mock MathJax/Core/disclosure. Native Teacher importer/buttons/Focus drives real TV popup và native preview. Tests/helpers/evidence ở ngoài source/candidate; runtime assets served và verified từ selected roots.

## Targeted — PASS

Fixture: ALGEBRA_PHASE5_TEST_PACKAGES/ALGEBRA_PROFILE_REPRESENTATIVE_TEST.json, 10 screens, 5.503 bytes, TEST_ONLY_NOT_SGK. Có expression/fraction/root/power, bốn transformation steps, equation/inequality/system, authored comparison, hint/answer, optional stages và vertical MCQ. Fixture không chứng minh SGK alignment hoặc lớp thật.

| # | Check | Result |
|---|---|---|
{test_rows}

Raw: ALGEBRA_TARGETED.json, TARGETED_ALGEBRA_RUN.log, targeted-algebra.cjs. Fraction test kiểm SVG mfrac, numerator y < denominator y và fraction bar; system test kiểm brace, hai mtr rows và hai equals glyph. Step/Focus tests kiểm native states, absence của future/correction/conclusion/hint trong DOM và state invariants. 30 question viewport cases và 12 full-answer viewport cases đều không overflow ngang/dọc. Assertions không bị bỏ hoặc nới để có PASS.

## Lifecycle/async transitions — PASS

| Case | Result |
|---|---|
{transition_rows}

Raw PROFILE_TRANSITIONS.json, profile-transitions.cjs. Hai race cases delay local MathJax bundle 600ms ở test harness; runtime không thêm delay. Actual MathJax-active Algebra chuyển Geometry/Legacy/Informatics phải bằng frozen snapshot; không chỉ so profile label.

## Fresh ZIP — PASS

PACKAGED_ALGEBRA_SMOKE.json: 53 assets (50 root runtime + three MathJax files) match exact bytes, eight checks; modal close/reopen, bundled JSON import, fraction, reveal/Focus/clear, full four-step answer/conclusion at1280×720, system rows, authored error disclosure, vertical MCQ/one formula per option, unchanged lesson memory. Errors/external runtime requests = 0.

PACKAGE_IDENTITY.json/PHASE5_PAYLOAD_MANIFEST.json: ZIP CRC PASS, 1.233 files equal tested working copy. SHA256 `{sha5}`. PACKAGED_FULL_TRANSFORM_1280.png được kiểm tra trực quan: đủ bốn bước, quy tắc, original/result/conclusion; không clip. Target screenshots Focus3, stacked fraction, system và MCQ cũng được kiểm tra.

## Failure history giữ nguyên

ATTEMPT1/2: native MCQ720p overflow; screenshots và MathJax display probe cho thấy visible SVG + visible assistive MathML. Initialization flag không đổi actual MathJax document action; explicit document flag false loại duplicate output, supplied aria-label giữ accessibility source. MCQ scoped padding được giảm, giữ native readable floor.

ATTEMPT3/4: full transformation with supporting fields overflow. FULL_TRANSFORM_BEFORE_METRICS ghi pane/scroll 945/1031 tại1920, 664/747 tại1366 và 621/725 tại1280; MathML duplicate đã 0. Fix local row grid, inline supporting fields, stage label dùng native badge, connectors ra khỏi flow; giữ toàn bộ text và reveal state. Final target/full ZIP smoke PASS. Không sửa Geometry hoặc Core.

COMPARE_ATTEMPT1.cjs có external reader assertion nhầm `realStates` array là scalar70. Sửa reader thành `.length===70` và thêm strict array equality/overflow assertions. Browser runs không đổi, không rerun/patch engine để che lỗi reader.

Native Windows launcher/physical TV/scaling/back-row/audible TTS/actual classroom trial = UNRUN. REAL_FILE_VALIDATION=NOT_RUN_BY_GV_DECISION. Những trạng thái này không phải PASS.
'''
(p / 'ALGEBRA_PHASE5_TEST_EVIDENCE.md').write_text(evidence)

legacy_rows = '\n'.join(f'| {x["package"]} | {x["screens"]} | {x["states"]} | PASS |' for x in regression['pairedRealPackages'])
regression_report = f'''# ALGEBRA_PHASE5_REGRESSION_REPORT

LEGACY_RUNTIME_REGRESSION=PASS; GEOMETRY_PROFILE_REGRESSION=PASS; INFORMATICS_PROFILE_ISOLATION=PASS.

Reference thực sự là frozen Geometry Phase4 ZIP SHA256 `{sha4}` và 1.227-file manifest đã verify; baseline runtime port8775. Phase5 working copy port8776. Không dùng Phase2 thay cho frozen Geometry reference. Raw paths REGRESSION/FROZEN_GEOMETRY và REGRESSION/PHASE5 phản ánh đúng selected roots.

## Legacy paired regression

| Original package | Screens mỗi runtime | Hidden/full states mỗi runtime | Result |
|---|---|---|---|
{legacy_rows}

171 screens/342 states, 44 captured DOM/layout metrics và 15 assertions mỗi runtime, strict equality của real/visual/assertions. Demo 4 screens/8 states strict equality. Zero overflow/exceptions/external requests; lesson memory unchanged. Các package không explicit Algebra vẫn giữ behavior cũ; đây là runtime regression, không phải một lớp thật.

## Geometry paired regression

Frozen reference và Phase5 đều 14/14 native checks PASS, 35 screens/70 hidden/full states, 23 visual metrics mỗi runtime. Checks/realStates/visuals/persistentImageHashes/persistentScopes bằng nhau. Chỉ lessonActivation UUID được normalize trong cross-run visuals vì activation khác nhau theo import; parity Teacher/Preview/TV trong mỗi run đã được kiểm không normalize.

Bao gồm persistent authored figure, GT/KL contrast, progressive analysis/proof/future hidden, links/highlights, Focus, native zoom/return/reset, annotations undo/redo/clear, 70/30,60/40,figure fullscreen, object coordinate types, full lesson fit, Geometry vertical MCQ ở four sizes, refresh và zero teacher controls trên TV. G4-F03 Focus sửa trong frozen reference được giữ nguyên.

Approved G4-F01 auxiliary fixture SHA2564488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8 dùng nguyên byte; không patch/import replacement vào candidate Geometry fixtures. G4-F02 zoom reset vẫn OPEN_DEFERRED P3; không tuyên bố được sửa. G4-F04 OPEN_DEFERRED P3 và G4-F05 VALIDATION_PENDING giữ nguyên. Core/Geometry byte comparison bảo đảm không patch những findings này.

## Isolation và transitions

14 native selection/fallback/negative groups + paired Demo PASS; Geometry ngay trong isolation cũng paired frozen reference. Missing/empty/unknown engine giữ Legacy; Informatics stub không sửa; selected lifecycle hooks đúng profile. Eight transition/race cases PASS, including actual MathJax-active Algebra → Geometry comparison, → Legacy/Informatics comparison, optional metadata, invalid future Focus and delayed work disposal/new-screen.

## Source scope

SOURCE_SCOPE.json PASS: frozen Geometry ZIP/files unchanged; one changed Algebra-owned module (original Legacy prefix byte-identical); six additions; 1.226 old files unchanged; no removal. WEB_LIVE_CORE_MUTATED=NO; GEOMETRY_PROFILE_MUTATED=NO; INFORMATICS_PROFILE_MUTATED=NO; LEGACY_BEHAVIOR_MUTATED=NO; SOURCE_SCOPE_VIOLATION=NO; PRODUCTION_MODIFIED=NO.

Raw REGRESSION_SUMMARY.json, source manifests, compare-regression.cjs and all runtime JSON/screenshots are delivered in evidence ZIP. New candidate was created only after PREPACKAGE_GATE PASS; fresh ZIP assets and smoke also PASS. No force push/main merge or Production action is part of this phase.

REAL_FILE_VALIDATION=NOT_RUN_BY_GV_DECISION; REAL_CLASSROOM_TRIAL=UNRUN. Không chuyển geometry/physical-classroom coverage chưa chạy thành PASS.
'''
(p / 'ALGEBRA_PHASE5_REGRESSION_REPORT.md').write_text(regression_report)

risk = '''# ALGEBRA_PHASE5_RISK_REGISTER

P0_COUNT/P1_COUNT/P2_COUNT/P3_COUNT trong final block đếm finding **Phase5 còn mở**; cả bốn = 0. Hai P2 được tìm trong development đã FIXED và retest PASS. Geometry findings kế thừa được ghi riêng, không xóa/đóng hoặc tính lại thành lỗi Phase5.

## Confirmed Phase5 findings — closed

| ID | Severity | Component | Confirmed issue/root cause | Fix/verification | Status |
|---|---|---|---|---|---|
| A5-F01 | P2 | ALGEBRA_PROFILE / MathJax conversion | Converter returned visible SVG and visible assistive MathML. Actual document enableAssistiveMml remained true despite initial config flag; output was duplicated. DOM/screenshot evidence confirms both representations. | Disable actual document action after startup; source aria-label/role=math retained. Final native tests assert zero assistive MML and one SVG per MCQ option; screenshots reviewed. | FIXED |
| A5-F02 | P2 | ALGEBRA_PROFILE CSS/UI | Native-height expression/supporting-field rows and in-flow connectors overflowed the full-answer panel; stacked fraction MCQ also exceeded720p with large row padding. Measured scroll/client heights and failing assertions retained. | Local expression/reason grid inside each full-width proof row; compact supporting fields; connectors out of flow; authored stage uses existing badge; scoped MCQ row padding. All text/reveal retained; 30 question +12 full viewport cases and fresh ZIP1280 smoke PASS. | FIXED |

Không sửa Core hoặc Geometry để xử lý các findings này. External comparator array/scalar mistake là harness defect, không engine finding; reader được sửa và historical source được giữ.

## Frozen Geometry accepted status

| Finding | Accepted status | Phase5 action |
|---|---|---|
| G4-F01 | TARGETED_PASS | No fixture patch |
| G4-F02 | OPEN_DEFERRED, P3, WEB_LIVE_CORE | Record unchanged; no patch |
| G4-F03 | FIXED, targeted PASS | Keep frozen CSS/behavior |
| G4-F04 | OPEN_DEFERRED, P3 | No typography patch |
| G4-F05 | VALIDATION_PENDING; root cause unconfirmed/owner UNKNOWN | No diagnosis by assumption or patch |

REAL_FILE_VALIDATION=NOT_RUN_BY_GV_DECISION; REAL_CLASSROOM_TRIAL=UNRUN. Frozen Phase4 technical PASS does not certify real-file/classroom validation.

## Coverage and contract limits

| Item | Proven scope / remaining limit | Review action |
|---|---|---|
| Lesson pedagogy/source | New fixture is synthetic10screens/5.503bytes, not SGK; profile never generates a solution or student error. Real Algebra lesson/SGK alignment not run. | GV reviews candidate/contract; a later authorized phase may validate actual lessons. |
| Mathematical input | Proven authored delimited TeX forms include fractions, powers/root, polynomial, equation/inequality and two-row cases system. Unmarked prose math stays text; arbitrary TeX/extensions/macros beyond tested fixture are not certified. | Follow documented format and test additional authored forms when needed. |
| Accessibility/TTS | role=math/author TeX aria-label provided; duplicate visual assistive MathML disabled. Native audible TTS/screen-reader classroom acceptance not run. | Review with actual classroom devices in a later authorized validation. |
| Registry descriptor | Core's immutable Phase2 REGISTERED_STUB descriptor is historical scaffold metadata. Actual registered adapter/getState/API are IMPLEMENTED and dispatch works. | Use actual implementation API/contract. Any requested Core metadata update requires separate GV approval. |
| Very long content/physical readability | Measured three TV viewport sizes, native source-preserving layouts and Core overflow diagnostics. Physical TV, scaling, back-row trial and long arbitrary lessons unrun. | Validate actual lesson/device after review; no silent text removal. |
| Runtime restoration | Current static servers/assets and package tested; cloud startup draft saved, requires Publish. Fresh-task restoration not verified. | Review/save settings then Publish if desired. |

No Production; Informatics stays frozen/stub. STOP and await GV approval; no automatic next phase.
'''
(p / 'ALGEBRA_PHASE5_RISK_REGISTER.md').write_text(risk)

names = ['ALGEBRA_PHASE5_IMPLEMENTATION_REPORT.md', 'ALGEBRA_PROFILE_CONTRACT.md', 'ALGEBRA_PHASE5_TEST_EVIDENCE.md', 'ALGEBRA_PHASE5_REGRESSION_REPORT.md', 'ALGEBRA_PHASE5_RISK_REGISTER.md', 'FINAL_STATUS.txt', 'SOURCE_SCOPE.json', 'FREEZE_GEOMETRY_PHASE4.json', 'REGRESSION_SUMMARY.json', 'PREPACKAGE_GATE.json', 'PACKAGE_IDENTITY.json', 'PHASE5_PAYLOAD_MANIFEST.json', 'ALGEBRA_PHASE5_RUNTIME.patch', 'PACKAGED_ALGEBRA_SMOKE.json', 'CLOUD_DRAFT_STATUS.json']
for name in names:
    shutil.copyfile(p / name, out / name)
working = p / 'working/WEB_LIVE_ALGEBRA_PHASE5_WORKING_COPY'
shutil.copyfile(working / 'ALGEBRA_PHASE5_TEST_PACKAGES/ALGEBRA_PROFILE_REPRESENTATIVE_TEST.json', out / 'ALGEBRA_PROFILE_REPRESENTATIVE_TEST.json')
new = p / 'NEW_FILES'
new.mkdir()
for name in scope['addedFiles']:
    dest = new / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(working / name, dest)
readme = f'''# WEB LIVE — ALGEBRA PHASE5 CANDIDATE

Algebra Profile đã triển khai qua Core/Profile hiện có; MathJax SVG local, transformations/reveal/Focus, authored comparison và hint/answer control. Targeted20checks/global regression PASS. Core/Geometry/Informatics/Legacy behavior giữ nguyên; Geometry Phase4 frozen.

- [Candidate ZIP](WEB_LIVE_ALGEBRA_PHASE5_CANDIDATE.zip) — SHA256 `{sha5}`.
- [Implementation report](ALGEBRA_PHASE5_IMPLEMENTATION_REPORT.md), [contract](ALGEBRA_PROFILE_CONTRACT.md), [test evidence](ALGEBRA_PHASE5_TEST_EVIDENCE.md), [regression](ALGEBRA_PHASE5_REGRESSION_REPORT.md), [risk register](ALGEBRA_PHASE5_RISK_REGISTER.md).
- [Small representative JSON](ALGEBRA_PROFILE_REPRESENTATIVE_TEST.json) — 5.503bytes, TEST_ONLY_NOT_SGK. Không dùng như source sư phạm.
- [Raw evidence ZIP](ALGEBRA_PHASE5_VALIDATION_EVIDENCE.zip), [final status](FINAL_STATUS.txt), [checksums](CHECKSUMS_SHA256.txt), [payload manifest](PHASE5_PAYLOAD_MANIFEST.json).

Giải nén vào thư mục riêng; giữ Geometry Phase4 nguyên vẹn. Native START_WEB_LIVE.bat/launcher giữ nguyên; native Windows/audio/physical classroom acceptance UNRUN. Mở JSON fixture bằng Teacher importer, MỞ TV, native Reveal/Focus/XÓA TẬP TRUNG; MathJax asset nằm trong candidate, không cần CDN. Contract chỉ định authored TeX format và optional metadata.

Core registry descriptor REGISTERED_STUB là metadata Phase2 giữ nguyên; actual WebLiveAlgebra.status=IMPLEMENTED. Inherited Phase3/4 reports/checksums bên trong ZIP là lịch sử, dùng các file Phase5 bên ngoài cho release này.

Geometry reference SHA256 `{sha4}`: G4-F01 TARGETED_PASS; F02/F04 OPEN_DEFERRED P3; F03 FIXED; F05 VALIDATION_PENDING. REAL_FILE_VALIDATION=NOT_RUN_BY_GV_DECISION; REAL_CLASSROOM_TRIAL=UNRUN. Waiver/pending không phải PASS. Các bộ đếm severity chỉ đếm finding Phase5 còn mở (0); hai Phase5 P2 trong development đã FIXED và giữ evidence.

Cloud startup draft saved; review/save trong Environment Settings rồi Publish để áp dụng. Fresh-task restoration chưa kiểm chứng.

STOP — chờ GV review. Không Production, không bắt đầu Informatics.
'''
(out / 'README.md').write_text(readme)
print(json.dumps({'reports':5,'requiredFinalFields':len([line for line in status.splitlines() if ' = ' in line]),'candidateSHA256':sha5,'packageSmoke':'PASS','openPhase5Findings':0}))
