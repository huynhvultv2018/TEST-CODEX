Fixture nhỏ chỉ kiểm tra Algebra Profile và các trạng thái UI. Không phải SGK/source sư phạm, không xác nhận bài thật hoặc lớp thật. Dùng subject_engine=algebra và native Teacher controls.
