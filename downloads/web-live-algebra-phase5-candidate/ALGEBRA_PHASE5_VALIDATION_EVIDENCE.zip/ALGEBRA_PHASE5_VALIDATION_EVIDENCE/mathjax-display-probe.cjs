const {chromium}=require('playwright'),fs=require('fs');
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),results=[];
 for(const assistive of [true,false]){
  const c=await b.newContext({viewport:{width:1366,height:768}});
  if(assistive)await c.route('**/vendor/mathjax-3.2.2/tex-svg-full.js',async route=>{await route.request().frame().evaluate(()=>MathJax.options.enableAssistiveMml=true);await route.continue();});
  const t=await c.newPage();await t.goto('http://127.0.0.1:8776/WEB_LIVE/teacher.html');await t.locator('#jsonfile').setInputFiles('/workspace/phase5-algebra-profile/working/WEB_LIVE_ALGEBRA_PHASE5_WORKING_COPY/ALGEBRA_PHASE5_TEST_PACKAGES/ALGEBRA_PROFILE_REPRESENTATIVE_TEST.json');await t.waitForFunction(()=>lesson?.screens?.length===10);await t.evaluate(()=>go(9));
  const pending=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await pending;await tv.waitForLoadState();await tv.waitForFunction(()=>lastState?.index===9&&document.getElementById('screen').dataset.algebraMathReady==='true'&&document.getElementById('algebraProfileStyle').sheet);await tv.locator('#screen').waitFor({state:'visible'});
  for(const size of [{width:1920,height:1080},{width:1366,height:768},{width:1280,height:720}]){
   await tv.setViewportSize(size);await tv.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
   const data=await tv.evaluate(()=>({mathjaxVersion:MathJax.version,assistiveEnabled:MathJax.startup.document.options.enableAssistiveMml,pane:{height:document.querySelector('.textPane').clientHeight,scroll:document.querySelector('.textPane').scrollHeight},contentFont:getComputedStyle(document.getElementById('content')).fontSize,components:[...document.querySelectorAll('.algebraMath')].map(n=>({width:n.getBoundingClientRect().width,height:n.getBoundingClientRect().height,svg:[...n.querySelectorAll('svg')].map(m=>({width:m.getBoundingClientRect().width,height:m.getBoundingClientRect().height})),assistiveMml:[...n.querySelectorAll('mjx-assistive-mml')].map(m=>({display:getComputedStyle(m).display,width:m.getBoundingClientRect().width,height:m.getBoundingClientRect().height})),sourceWidth:n.querySelector('.algebraMathSource').getBoundingClientRect().width}))}));results.push({assistive,size,...data});await tv.screenshot({path:__dirname+'/HARNESS_HISTORY/MML_'+assistive+'_'+size.width+'.png'});
  }
  await c.close();
 }
 fs.writeFileSync(__dirname+'/HARNESS_HISTORY/MATHJAX_DISPLAY_COMPARISON.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results));await b.close();
})().catch(e=>{console.error(e);process.exitCode=1});
