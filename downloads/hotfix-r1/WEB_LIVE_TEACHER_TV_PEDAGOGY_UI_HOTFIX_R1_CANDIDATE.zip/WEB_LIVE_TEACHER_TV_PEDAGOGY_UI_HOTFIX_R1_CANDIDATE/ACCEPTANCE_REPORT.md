# ACCEPTANCE REPORT — RC2 CANDIDATE

Ngày: 2026-10-04T12:41:37+07:00. **UI/cloud acceptance: PASS. Full production gate: FAIL — giữ Candidate.**

```text
BASELINE LOCK = PASS
TEACHER COCKPIT = PASS
TV COGNITIVE WORKSPACE = PASS
PEDAGOGY LOCKS = PASS
GEOMETRY ENGINE = PASS
ALGEBRA ENGINE = PASS
TIN ENGINE = PASS
PROGRESSIVE DISCLOSURE = PASS
TEACHER-TV SYNC = PASS
TTS REGRESSION = FAIL
DEMO REGRESSION = FAIL
LAUNCHER REGRESSION = FAIL
VISUAL ACCEPTANCE = PASS
PACKAGE = PASS
```

PASS giao diện/engine/sync/locks là kết luận từ các check cloud đã thực thi. ALGEBRA ENGINE PASS chỉ cho presentation fixtures, chưa cho lesson Đại số thực tế. VISUAL ACCEPTANCE PASS chỉ cho desktop/browser ở kích thước kiểm, chưa đánh giá từ cuối lớp/TV vật lý.

TTS REGRESSION, DEMO REGRESSION, LAUNCHER REGRESSION dùng cổng đầy đủ yêu cầu máy thật. FAIL ở đây là **chưa đủ bằng chứng nghiệm thu toàn phần**, không phải chứng minh source đang hỏng: 30 TTS integration mock và 7 edge cases PASS, Demo fail-safe/mock PASS, 18 Chrome Start dispatch và 16 API checks PASS; source nền của các thành phần này không đổi. Cloud không có giọng Việt, Windows desktop hay app Word/GeoGebra.

## Tiêu chí UI

| Tiêu chí | Kết luận | Chứng cứ |
|---|---|---|
| Preview là trung tâm, 72–78% desktop | PASS | Teacher 1920/1366 + cockpit metric |
| Teaching controls ưu tiên, 4 nhóm, một Next Action | PASS | Teacher screenshots; action checks |
| WYSIWYG Teacher preview | PASS ở cùng viewport | Dùng tv.html; parity DOM/state/image/labels |
| Không teacher-only data trên TV | PASS | Private sentinels và TV button check |
| ONE SCREEN ONE PRIMARY TASK | PASS với source model4/quick mapping | Focus đổi câu hỏi, không đổi source |
| NO EARLY ANSWER/progressive disclosure | PASS | Real Hint 1/2, Answer, close, proof future nodes |
| ACTIVE STUDENT | PASS UI | Nhiệm vụ/câu hỏi và hint chờ GV; không auto answer |
| TRACEABILITY | PASS | Không sửa lesson, source ref giữ nguyên, integrity hash |
| Geometry hình + reasoning, scene xuyên suốt | PASS | 6 màn cùng image SHA và overlays thực |
| Algebra workspace/atomic expressions | PASS fixtures | Steps, long formula, table/system/router |
| Tin Mẫu 4/resource + task | PASS | Tin packages + resource evidence |
| Demo near-full workspace/fail-safe | PASS UI/cloud | Demo ratio, explicit calls; không auto launch |
| Không scroll trong flow chuẩn | PASS | 342 states và 44 ảnh không overflow |
| Long content/formula, large figure, no/with resource | PASS tested cases | EVIDENCE và engine snapshots |
| Fullscreen/zoom mặc định | PASS browser | Actual Fullscreen API + snapshots |
| Nghe TTS Việt thật | UNVERIFIED | Native voices = 0 |
| Chrome Start và handoff Windows/TV thật | UNVERIFIED | Không có Windows desktop |

Nội dung vượt xa độ dài kiểm thử vẫn có fallback scroll của baseline để không cắt mất chữ; không cam kết mọi văn bản tùy ý sẽ vừa một màn hình. Editor công cụ được ghi nhãn riêng, không thay thế preview thật. TV độc lập có viewport khác với preview chuẩn cần kiểm display thực.

## Evidence mới

EVIDENCE có Teacher 1920×1080, Teacher 1366×768, Teacher fullscreen, TV fullscreen, TV Geometry, TV Algebra fixture, TV Tin fixture và Tin SGK resource thật, Hint 1, Hint 2 dữ liệu thật, Answer, Knowledge Close, Demo fixture, long formula và long content. Ảnh là browser screenshot từ candidate, không là thiết kế mockup; fixture dữ liệu được ghi rõ, không là chứng nhận SGK.

## Các bước đóng gate còn thiếu

1. Giải nén toàn bộ candidate ở Windows; chạy START_WEB_LIVE.bat, Chrome, display Extend và TV/loa thật. Import các gói Tin/Hình học và một LIVE.zip Đại số thật.
2. Đối chiếu preview/TV ở 1920×1080, 1366×768 và fullscreen theo DPI/zoom thực; lặp Next/Back, hints, answer/close, refresh/reconnect, các bước hình học và công cụ.
3. Chọn giọng Việt thật, nghe read/pause/resume/stop/replay, thử Next/import khi đang đọc; kiểm output loa/HDMI và không có speech trùng từ TV.
4. Demo Word và GeoGebra qua explicit confirmation: launch, đưa sang TV, retry/return; TV không tự mở app. Kiểm Chrome Start không đổi fallback/reuse khi mở lần hai.
5. Ghi OS/browser/voice URI/device/DPI/date/SHA, ảnh/video/audio và PASS/FAIL. Chỉ khi các gate critical có bằng chứng PASS mới cân nhắc Production.

**KHÔNG NÂNG PRODUCTION ở lượt bàn giao này.**
