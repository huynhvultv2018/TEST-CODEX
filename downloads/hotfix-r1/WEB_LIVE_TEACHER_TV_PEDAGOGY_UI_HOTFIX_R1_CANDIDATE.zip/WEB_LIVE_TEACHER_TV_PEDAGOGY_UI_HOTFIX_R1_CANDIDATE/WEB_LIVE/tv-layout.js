/* TV-only presentation. No lesson mutation, geometry cache writes or disclosure commands. */
const TVLayout=(()=>{
 const el=id=>document.getElementById(id);
 function kind(l,s){
  if(!livePedagogyEnabled(l))return 'legacy';
  if(livePedagogyIsClose(l,s))return 'knowledge';
  const stage=livePedagogyStage(l,s),type=String(s.type||'').toUpperCase();
  if(type==='QUICK_CHECK'||stage==='CHECK_UNDERSTANDING'||l.pedagogyPolicy?.quick_check_task_ids?.includes(s.id))return 'quick';
  return ['OBSERVE','DISCOVER','QUESTION','PREDICT'].includes(type)?'model4':'legacy';
 }
 function contextResource(l,s,index){
  if(!s.resourceRequired||!s.sgkTrace?.unitId)return null;
  const ref=s.sgkTrace.sourceRef;
  if(!ref?.path||!ref.sha256||ref.book_page==null)return null;
  for(let n=index-1;n>=0;n--){
   const prior=l.screens[n],r=prior.sgkTrace?.sourceRef;
   if(prior.sgkTrace?.unitId!==s.sgkTrace.unitId)break;
   if(r?.path!==ref.path||r.sha256!==ref.sha256||r.book_page!==ref.book_page)continue;
   if(isAnalysisScreen(prior))continue;
   const image=resolveScreenVisuals(l,n)?.geometry;
   if(image)return {...image,contextIndex:n};
  }
  return null;
 }
 function plan(l,s,d,visuals){
  const type=kind(l,s),paths=Array.isArray(s.sgkTrace?.path)?s.sgkTrace.path:[];
  const parts=paths.length?paths:String(s.title||'').split(' / ');
  const resource=visuals?.geometry|| (type==='model4'?contextResource(l,s,d.index):null) || (resolveSubjectLayout(s,l)!=='GEOMETRY'&&!isAnalysisScreen(s)?visualSource(s,'image','imageData'):null);
  const focus=typeof s.resourceFocus==='string'?s.resourceFocus:'';
  const q=livePedagogyContent(l,s,d.pedagogy?.knowledgeCloseVisible);
  let situation='',situationBlocks=0;
  if(type==='model4'&&!resource){const pieces=Classroom.parts(normalizeLiveText(q,'prose'));const first=pieces.findIndex(x=>x.type==='block'&&x.text.includes('?'));if(first>0){situation=pieces.slice(0,first).map(x=>x.text).join('');situationBlocks=pieces.slice(0,first).filter(x=>x.type==='block').length;}}
  return {type,situation,situationBlocks,section:parts[0]||s.title||'',activity:parts.slice(1).join(' / '),resource,
   contextual:!!resource&&!visuals?.geometry,secondary:type==='model4'&&!!visuals?.analysis&&!liveAnalysisSteps(s).length,
   ratio:d.classroom?.layoutPinned&&['60','70'].includes(d.classroom.layout)?d.classroom.layout:q.length>135?'55':'60',
   caption:resource?[s.sgkTrace?.sourceRef?.book_page!=null?'SGK trang '+s.sgkTrace.sourceRef.book_page:'',focus&&focus.trim()!==q.trim()?focus:''].filter(Boolean).join(' · '):''};
 }
 function primaryTask(node,d,p){
  node.classList.remove('primaryFocus');el('taskPart').textContent='';
  const nodes=Array.from(node.children||[]),blocks=nodes.filter(x=>x.classList?.contains('focusBlock'));
  nodes.forEach(x=>{x.hidden=false});
  if(p.situationBlocks)blocks.forEach((x,i)=>{x.hidden=i<p.situationBlocks});
  const questions=blocks.map((x,i)=>x.textContent.includes('?')?i:-1).filter(i=>i>=0);
  if(questions.length<2){if(p.situationBlocks)node.classList.add('primaryFocus');return;}
  const requested=d.classroom?.focus?.region==='content'?d.classroom.focus.index:questions[0];
  const selected=Math.max(0,questions.findLastIndex(i=>i<=requested));
  const from=selected===0?p.situationBlocks:questions[selected],to=questions[selected+1]??blocks.length;
  blocks.forEach((x,i)=>{x.hidden=i<from||i>=to});
  node.classList.add('primaryFocus');el('taskPart').textContent=(selected+1)+' / '+questions.length;
 }
 // Labels and emphasis are presentation mappings, never new lesson instructions.
 function activityLabel(s){
  const type=String(s.type||'').toUpperCase();
  if(s.demo||type==='DEMO')return 'DEMO TRỰC TIẾP';
  return ({OLD_LESSON_CHECK:'KIỂM TRA BÀI CŨ',REVIEW:'KIỂM TRA BÀI CŨ',LESSON_TRANSITION:'DẪN VÀO BÀI',INTRO:'DẪN VÀO BÀI',WARMUP:'DẪN VÀO BÀI',OBSERVE:'KHÁM PHÁ',DISCOVER:'KHÁM PHÁ',QUESTION:'KHÁM PHÁ',PREDICT:'KHÁM PHÁ',KNOWLEDGE:'HÌNH THÀNH KIẾN THỨC',KNOWLEDGE_CLOSE:'CỦNG CỐ',CLOSE:'CỦNG CỐ',CONSOLIDATION:'CỦNG CỐ',PRACTICAL:'THỰC HÀNH',PRACTICE:'LUYỆN TẬP',APPLICATION:'VẬN DỤNG',QUICK_CHECK:'CỦNG CỐ'})[type]||'';
 }
 function infoContext(l,s){
  const lesson=String(l.title||'').match(/\bBài\s+\d+/iu)?.[0];
  const path=Array.isArray(s.sgkTrace?.path)?s.sgkTrace.path:[];
  const section=path[0]?.match(/^\s*(\d+)\./u)?.[1];
  // Use only explicit current-screen context; never infer a section from a prior task.
  const explicit=String(s.title||'').match(/\bMục\s+\d+/iu)?.[0];
  return [l.subject,lesson,section?'Mục '+section:explicit].filter(x=>typeof x==='string'&&x.trim()).join(' • ');
 }
 function textProfile(values,image=false,steps=0){
  const text=values.filter(Boolean).join('\n'),lines=text.split('\n').length;
  const formulas=(text.match(/[=><≥≤≠≈∥⊥≅∼⇔⇒]/gu)||[]).length;
  const score=text.length+Math.max(0,lines-1)*28+formulas*12+steps*22+(image?70:0);
  return score<=150?'SHORT':score<=300?'MEDIUM':score<=600?'LONG':'EXTRA_LONG';
 }
 function hierarchy(node,s){
  const blocks=Array.from(node.children||[]).filter(x=>x.classList?.contains('focusBlock'));
  const intro=['LESSON_TRANSITION','INTRO','WARMUP'].includes(String(s.type||'').toUpperCase());
  const question=intro?blocks.findIndex(x=>x.textContent.includes('?')):-1;
  blocks.forEach((block,index)=>{
   if(question>=0)block.classList.add(index<question?'tvContext':index===question?'tvMainTask':'tvInstruction');
   // Retain the complete source prefix as a smaller subtitle, including punctuation/spaces.
   const source=block.textContent,prefix=source.match(/^((?:Luyện tập|Vận dụng|Thực hành)\s*\d+\s*:\s*)/iu)?.[0];
   if(prefix&&document.createElement&&block.replaceChildren){
    const label=document.createElement('span'),task=document.createElement('span');
    label.className='tvSourceSubtitle';task.className='tvSourceTask';label.textContent=prefix;
    if(typeof renderMathAtomic==='function')renderMathAtomic(task,source.slice(prefix.length));else task.textContent=source.slice(prefix.length);
    block.replaceChildren(label,task);
   }
  });
 }
 function studentUi(screen,l,s,d,p){
  screen.dataset.studentUi='rc4';
  const badge=activityLabel(s),node=el('activityBadge');node.textContent=badge;node.hidden=!badge;
  el('tvInfoContext').textContent=infoContext(l,s);
  el('tvInfoProgress').textContent=Number.isInteger(d.index)&&d.total>0?(d.index+1)+' / '+d.total:'';
  screen.dataset.activity=String(s.type||'').toUpperCase();
  const duplicate=String(s.title||'').trim().toLocaleUpperCase('vi')===badge;
  screen.classList.toggle('duplicateActivityTitle',!!badge&&duplicate);
  hierarchy(el('content'),s);
  const visible=node=>node.hidden?'':Array.from(node.children||[]).length?Array.from(node.children).filter(x=>!x.hidden).map(x=>x.textContent).join(''):node.textContent;
  const exclusive=screen.dataset.disclosure==='answer'&&p.type!=='legacy';
  const items=[p.type==='legacy'&&!duplicate?s.title:'',exclusive?'':visible(el('content')),exclusive?'':visible(el('hint')),visible(el('answer')),visible(el('analysis'))];
  const steps=el('answer').classList.contains('hasSteps')?(d.answerStep||0):d.analysisStep||0;
  screen.dataset.textLength=textProfile(items,!!p.resource,steps);
 }
 function apply(screen,l,s,d,p){
  screen.dataset.presentation=p.type;screen.dataset.contextResource=String(p.contextual);
  screen.dataset.panelRatio=p.ratio;
  const close=livePedagogyIsClose(l,s),answered=!!liveAnswerText(s,d.answerMode,d.answerStep||0);
  screen.dataset.pedagogyStage=liveUIStage(l,s,d);
  el('tvStage').textContent=screen.dataset.pedagogyStage.replace('_',' ');
  screen.dataset.disclosure=close?(d.pedagogy?.knowledgeCloseVisible?'knowledge':'waiting'):answered?'answer':d.showHint?'hint':d.analysisStep>0?'analysis':'question';
  screen.classList.toggle('resourceFocused',p.type==='model4'&&!!s.resourceFocus);
  screen.classList.toggle('model4',p.type==='model4');screen.classList.toggle('hasSituation',!!p.situation);screen.classList.toggle('hasSecondary',p.secondary);
  el('taskHeader').hidden=p.type==='legacy';el('taskLabel').hidden=p.type!=='model4'&&p.type!=='quick';
  el('sectionTitle').textContent=p.section;el('activityTitle').textContent=p.activity;el('activityTitle').hidden=!p.activity;
  el('taskLabelText').textContent=answered?'Đáp án':p.type==='quick'?'Kiểm tra nhanh':'Câu hỏi trọng tâm';
  el('situationPane').hidden=!p.situation;Classroom.focusText(el('situationText'),p.situation,'content',d.classroom?.focus);
  el('pic').alt=p.type==='model4'?'Tài nguyên quan sát của nhiệm vụ':'Hình học của bài toán';
  el('resourceCaption').textContent=p.caption;el('resourceCaption').hidden=p.type!=='model4'||!p.caption;
  const fig=el('figurePane'),analysis=el('analysisFigure'),pane=screen.querySelector?.('.textPane');
  if(p.secondary&&analysis.parentElement!==fig)fig.appendChild?.(analysis);
  else if(!p.secondary&&pane&&analysis.parentElement===fig)pane.insertBefore?.(analysis,el('answer'));
  if(p.type==='model4'||p.type==='quick')primaryTask(el('content'),d,p);
  else {el('content').classList.remove('primaryFocus');el('taskPart').textContent='';}
  studentUi(screen,l,s,d,p);
  TVMultiEngine.apply(screen,l,s,d,p);
  // The subject renderer rebuilds content; reapply the existing single-task focus afterwards.
  if(p.type==='model4'||p.type==='quick')primaryTask(el('content'),d,p);
  if(screen.dataset.disclosure==='answer'){el('hint').hidden=true;el('analysis').hidden=true;el('analysisFigure').hidden=true;}
  if(screen.dataset.disclosure==='analysis'){el('hint').hidden=true;}
  if(close&&d.pedagogy?.knowledgeCloseVisible){el('hint').hidden=true;el('answer').hidden=true;el('analysis').hidden=true;}
  screen.classList.toggle('demoWorkspace',screen.dataset.pedagogyStage==='DEMO');
 }
 function fit(screen,pane){
  pane.classList.remove('tight');pane.dataset.tvOverflow='false';
  el('analysis').classList.remove('tvAnalysisGrid');
  for(const id of ['content','hint','answer','analysis'])el(id).style.fontSize='';
  const tooTall=()=>pane.scrollHeight>pane.clientHeight+2;
  if(!tooTall())return;
  pane.classList.add('tight');
  // A fully disclosed geometry analysis can use numbered rows in two columns.
  if(tooTall()&&screen.dataset.subjectMode==='GEOMETRY'&&!el('analysis').classList.contains('tvDependencyTree')&&el('analysis').querySelectorAll('.analysisStep').length>=3)el('analysis').classList.add('tvAnalysisGrid');
  // Re-measure after spacing changes, then bound the reduction to a readable floor.
  if(tooTall()&&typeof getComputedStyle==='function'){
   const nodes=['content','hint','answer','analysis'].map(el),base=nodes.map(n=>parseFloat(getComputedStyle(n).fontSize)||34);
   for(const factor of [.96,.92,.88]){
    nodes.forEach((n,i)=>{n.style.fontSize=Math.max(i===0?30:26,base[i]*factor)+'px'});
    if(!tooTall())break;
   }
  }
  // Unusually long source remains fully available; no horizontal clipping or silent deletion.
  pane.dataset.tvOverflow=String(tooTall());
 }
 return {kind,contextResource,plan,apply,fit,activityLabel,infoContext,textProfile,hierarchy};
})();
