/* RC3 contract mapping. Read fields only; never rewrite lesson content or order. */
function livePedagogyEnabled(l){return l?.preparedContract==='TIN_SGK_PREP_3'||l?.pedagogyLocks?.knowledgeFormation===true||l?.screens?.some(s=>s.pedagogyStage||s.hintLevel1||s.hintLevel2||s.pedagogyGuidance||['KNOWLEDGE','KNOWLEDGE_CLOSE','CLOSE'].includes(String(s.type||'').toUpperCase()))}
function livePedagogyText(v){return typeof v==='string'?v:Array.isArray(v)&&v.every(x=>typeof x==='string')?v.join('\n'):''}
function livePedagogyGuidance(s,key){return livePedagogyText(s?.[key]??s?.pedagogyGuidance?.[key])}
function livePedagogyHint(s,level){
 const first=livePedagogyGuidance(s,'hintLevel1')||livePedagogyText(s?.hint),second=livePedagogyGuidance(s,'hintLevel2');
 return level===2?(second||first):level===1?first:'';
}
function livePedagogyStage(l,s){return s?.pedagogyStage||Object.entries(l?.pedagogyFlow||{}).find(([,id])=>id===s?.id)?.[0]||''}
function livePedagogyIsClose(l,s){return livePedagogyEnabled(l)&&(livePedagogyStage(l,s)==='STANDARDIZE'||['KNOWLEDGE','CLOSE','KNOWLEDGE_CLOSE'].includes(String(s?.type||'').toUpperCase()))}
function livePedagogyContent(l,s,revealed=false){return livePedagogyIsClose(l,s)&&!revealed?'':livePedagogyText(s?.content||s?.question)}
function livePedagogyCore(s){return typeof s?.coreStatus==='string'?s.coreStatus:typeof s?.CORE_STATUS==='string'?s.CORE_STATUS:''}
function livePedagogyState(l,level,closed){return livePedagogyEnabled(l)?{hintLevel:[1,2].includes(level)?level:0,knowledgeCloseVisible:closed===true}:null}

/* RC2 display stage: reads metadata and disclosure state; never moves the lesson. */
function liveUIStage(l,s,d={}){
 if(livePedagogyIsClose(l,s))return d.pedagogy?.knowledgeCloseVisible?'KNOWLEDGE_CLOSE':'THINK';
 const mode=typeof resolveSubjectLayout==='function'?resolveSubjectLayout(s,l):/hình học/iu.test(l?.subject||'')?'GEOMETRY':'';
 if(d.answerMode==='full'||d.answerMode==='steps'&&d.answerStep>0)return mode==='GEOMETRY'?'PROOF':'ANSWER';
 if(d.showHint)return 'HINT';
 if(d.analysisStep>0)return mode==='GEOMETRY'?'PROOF':'THINK';
 if(s?.demo||String(s?.type||'').toUpperCase()==='DEMO')return 'DEMO';
 const raw=String(livePedagogyStage(l,s)||s?.type||'QUESTION').toUpperCase();
 const map={STANDARDIZE:'KNOWLEDGE_CLOSE',CHECK_UNDERSTANDING:'QUICK_CHECK',KNOWLEDGE:'KNOWLEDGE_CLOSE',CLOSE:'KNOWLEDGE_CLOSE',DISCOVER:'OBSERVE',PREDICT:'THINK',ANALYSIS:'THINK',GEOMETRY_ANALYSIS:'THINK',PROOFANALYSIS:'THINK',ANALYSISDIAGRAM:'THINK',DISCUSS:'THINK',PROOF_DEPENDENCY_TREE:'THINK',GEOMETRY_PROOF:'PROOF',CONCLUSION:'KNOWLEDGE_CLOSE',PRACTICAL:'QUESTION',PRACTICE:'QUESTION',APPLICATION:'QUESTION',REVIEW:'QUICK_CHECK',OLD_LESSON_CHECK:'QUICK_CHECK',INTRO:'OBSERVE',LESSON_TRANSITION:'OBSERVE','QUAN SÁT':'OBSERVE','PHÂN TÍCH':'THINK','CHỨNG MINH':'PROOF'};
 return ['OBSERVE','QUESTION','THINK','HINT','EXPLAIN','PROOF','ANSWER','KNOWLEDGE_CLOSE','QUICK_CHECK','DEMO'].includes(raw)?raw:map[raw]||'QUESTION';
}
