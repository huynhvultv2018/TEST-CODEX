/* RC2 cockpit: presentation and explicit teacher decisions only. */
(() => {
 const el=id=>document.getElementById(id), frame=el('studentPreview');
 const side=el('sideBody')||document.querySelector('.sideBody');
 const tools=el('displayToolsGroup'), notes=document.querySelector('.teacherNotes');
 notes.querySelector('#pedagogySection details').open=true;
 const classroom=document.createElement('details');classroom.className='controlGroup';classroom.id='classroomGroup';
 classroom.innerHTML='<summary>03 · CÔNG CỤ LỚP HỌC</summary>';
 side.append(classroom);classroom.append(el('demoSection'),el('ttsGroup'),tools);
 tools.querySelector('summary').textContent='Chỉ điểm · Focus · Vẽ · Che · Zoom';
 el('ttsGroup').open=false;
 const system=document.createElement('details');system.className='controlGroup';system.id='systemGroup';
 system.innerHTML='<summary>04 · HỆ THỐNG</summary>';side.append(system);
 for(const id of ['ttsVoice','ttsRate','ttsGenderPreference','ttsKnownGender','ttsHighlight','ttsVolume']){
  const input=el(id),label=input.closest('label');if(label)system.append(label);
 }
 system.append(document.querySelector('.ttsOutputNote'),document.querySelector('.classroomClockControls'));
 const library=[...document.querySelectorAll('button')].find(b=>b.getAttribute('onclick')==='showImporter()');system.prepend(library);
 const steps=document.querySelector('.lessonSteps');el('jump').after(steps);
 document.querySelector('.sideHeader span').textContent='01 · ĐIỀU KHIỂN DẠY HỌC';
 el('hintBtn').setAttribute('aria-label','Gợi ý mức 1');el('hint2Btn').setAttribute('aria-label','Gợi ý mức 2');
 let nextDecision=null, tvSeen=0, previewSize={width:1920,height:1080};
 function decision(){
  if(!lesson)return null;
  const s=lesson.screens[i],enabled=livePedagogyEnabled(lesson);
  if(livePedagogyIsClose(lesson,s)&&!knowledgeCloseVisible)return {label:'📌 CHỐT KIẾN THỨC',action:toggleKnowledgeClose,reason:'Hiện nội dung chốt khi lớp đã sẵn sàng.'};
  if(!knowledgeCloseVisible&&answerMode==='hidden'){
   const first=enabled?livePedagogyHint(s,1):livePedagogyText(s.hint);
   if(first&&!showHint&&!analysisStep)return {label:'💡 GỢI Ý MỨC 1',action:()=>enabled?setPedagogyHintLevel(1):toggleHint(),reason:'Gợi mở để học sinh tiếp tục tự giải quyết.'};
   if(enabled&&showHint&&hintLevel<2&&livePedagogyGuidance(s,'hintLevel2'))return {label:'💡 GỢI Ý MỨC 2',action:()=>setPedagogyHintLevel(2),reason:'Thêm trợ giúp khi gợi ý đầu chưa đủ.'};
   if(liveAnalysisSteps(s).length>analysisStep)return {label:'↳ BƯỚC PHÂN TÍCH TIẾP',action:revealAnalysis,reason:'Chỉ hiện thêm một bước phân tích.'};
  }
  if(!knowledgeCloseVisible&&liveSteps(s).length&&answerMode!=='full'&&answerStep<liveSteps(s).length)return {label:'✓ BƯỚC GIẢI TIẾP THEO',action:revealStep,reason:'GV chọn hiện từng bước; bước sau vẫn ẩn.'};
  if(!knowledgeCloseVisible&&answerMode==='hidden'&&liveAnswerText(s,'full'))return {label:'✓ HIỆN ĐÁP ÁN',action:toggleAnswer,reason:'Chỉ hiện sau khi GV bấm nút này.'};
  if(i<lesson.screens.length-1)return {label:livePedagogyIsClose(lesson,lesson.screens[i+1])?'📌 SANG MÀN CHỐT':'TIẾP · NHIỆM VỤ MỚI →',action:next,reason:'Màn mới bắt đầu với gợi ý và đáp án ẩn.'};
  return {label:'ĐÃ ĐẾN CUỐI BÀI',action:null,reason:'Có thể quay lại để kiểm tra mức độ hiểu.'};
 }
 function fit(){
  const box=el('livePreview'),view=el('previewViewport'),k=Math.min(box.clientWidth/previewSize.width,box.clientHeight/previewSize.height);
  frame.style.width=previewSize.width+'px';frame.style.height=previewSize.height+'px';frame.style.transform='scale('+Math.max(.01,k)+')';
  view.style.width=previewSize.width*k+'px';view.style.height=previewSize.height*k+'px';
 }
 function refresh(){
  nextDecision=decision();const btn=el('nextActionBtn');btn.textContent=nextDecision?.label||'CHỌN BÀI HỌC';btn.disabled=!nextDecision?.action;
  el('nextActionReason').textContent=nextDecision?.reason||'Nhập LIVE.zip hoặc mở bài đã lưu.';
  if(lesson){const s=lesson.screens[i];el('cockpitStage').textContent=liveUIStage(lesson,s,{answerMode,answerStep,analysisStep,showHint,pedagogy:{knowledgeCloseVisible}}).replace('_',' ');
   el('progress').textContent=lesson.subject||'';el('demoBadge').hidden=!s.demo;
   const note=[s.teacherNote,s.note,livePedagogyText(s.notes)].filter(Boolean).join('\n');el('note').textContent=note||'—';
   const meta=[livePedagogyCore(s),Number.isFinite(s.timeBudgetMin)?s.timeBudgetMin+' phút':''].filter(Boolean).join(' · ');if(!livePedagogyEnabled(lesson))el('pedagogyMeta').textContent=meta;
  }
  el('tvConnection').textContent=Date.now()-tvSeen<5000?'TV ● Đã kết nối':'TV ○ Chưa kết nối';el('tvConnection').classList.toggle('connected',Date.now()-tvSeen<5000);
  const edit=boardController?.open||coverController?.open||smartController?.open||classroomController?.tool||classroomController?.focusMode;
  if(edit){if(!el('annotationEditor').open)el('annotationEditor').open=true;if(!classroom.open)classroom.open=true;if(!tools.open)tools.open=true;}
  fit();
 }
 window.runNextAction=()=>{const choice=decision();choice?.action?.()};
 window.cockpit={refresh,decision,fit};
 frame.addEventListener('load',()=>{fit();if(lesson)sync()});
 function presence(d){
  if(d?.type!=='tvPresence')return;
  if(d.preview)return;
  if(d.lessonActivation!==lessonActivation||d.lessonId!==currentLessonId||d.index!==i)return;
  tvSeen=d.closed?0:Date.now();
  try{const doc=tvWindow?.document;if(doc){previewSize={width:tvWindow.innerWidth,height:tvWindow.innerHeight};}}catch(_){}
  refresh();
 }
 bc?.addEventListener('message',e=>presence(e.data));
 window.addEventListener('message',e=>{if(e.origin===location.origin)presence(e.data)});
 new ResizeObserver(fit).observe(el('livePreview'));
 new MutationObserver(refresh).observe(el('annotationEditor'),{attributes:true,attributeFilter:['open']});
 for(const id of ['drawControls','coverControls','smartControls'])new MutationObserver(refresh).observe(el(id),{attributes:true,attributeFilter:['hidden']});
 setInterval(refresh,1500);refresh();
})();
