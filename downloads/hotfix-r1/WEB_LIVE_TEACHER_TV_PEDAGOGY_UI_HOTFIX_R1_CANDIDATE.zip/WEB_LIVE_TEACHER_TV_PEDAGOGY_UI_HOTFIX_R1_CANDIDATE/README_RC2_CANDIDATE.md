# WEB LIVE — Teacher/TV Pedagogy UI RC2 CANDIDATE

Đọc UPGRADE_REPORT.md, REGRESSION_REPORT.md và ACCEPTANCE_REPORT.md trước khi nghiệm thu. UI/cloud regression đạt; giọng Việt thật và Windows/TV/Demo handoff chưa được kiểm chứng. Giữ Candidate.

Windows: giải nén toàn bộ, chạy START_WEB_LIVE.bat như baseline. Import LIVE.zip, mở TV. Teacher preview dùng trang TV chung; “Chú thích / Focus” là ngăn thao tác tool riêng. Trong panel, Next Action là gợi ý thao tác, GV luôn bấm để thực hiện. Guidance và System chỉ dành GV.

CHECKSUMS_SHA256.txt ở root là manifest hiện hành; không bao gồm chính nó. Từ root có thể xác minh bằng sha256sum -c CHECKSUMS_SHA256.txt. Các báo cáo/checksum đời trước được giữ làm lịch sử baseline, không phải nghiệm thu RC2.

Tái lập cloud checks: RC2_TESTS/README.md. Không tạo worktree. Không thay lesson hay nâng Production từ kết quả mock.
