# Audit và design map RC2

Baseline là ZIP CHROME_START_HANDOFF người dùng cung cấp. Không sửa baseline. Candidate là bản sao riêng.

## Audit
- teacher.js: state/disclosure, lớp scene chung, BroadcastChannel + localStorage + postMessage.
- tv.js + TVLayout + TVMultiEngine: renderer TV, geometry overlays, atomic math, Tin Mẫu 4.
- PedagogyTeacher: hướng dẫn dành riêng cho GV; fallback cũ giới hạn vào contract Tin.
- TTSController: một owner, registry nội dung đã reveal, Web Speech API; không có engine TTS ngoài Web Speech trong source.
- DemoTeacher: /status và /pair khi chuyển màn; /launch chỉ khi GV xác nhận.
- LAUNCHER: Python loopback, Chrome Start và Windows handoff. Giữ byte-identical.

## Mapping (không sửa dữ liệu)
| Stage | Geometry | Algebra | Tin | Resource |
|---|---|---|---|---|
| OBSERVE / QUESTION / THINK | Hình 62% + nhiệm vụ 38% | Biểu thức / bảng / nhiệm vụ | Mẫu 4 / resource 60% + nhiệm vụ 40% | Không resource: workspace chữ |
| HINT | Giữ hình + chỉ gợi ý mức hiện tại và nhiệm vụ | Nhiệm vụ + mức gợi ý hiện tại | Resource + gợi ý hiện tại | Không lộ đáp án |
| PROOF / EXPLAIN | Hình + analysis/proof đã reveal | Chuỗi biến đổi đã reveal | Phần giải thích đã reveal | Không thay scene bằng analysis |
| ANSWER | Hình + đáp án, ẩn gợi ý và analysis | Chuỗi biến đổi | Resource + đáp án | GV click rõ ràng |
| KNOWLEDGE_CLOSE | Giữ scene khi contract scene có | Kết luận/chốt | Chốt đúng stage | Trước reveal: màn chờ |
| QUICK_CHECK | Một nhiệm vụ | Một nhiệm vụ | MCQ hiện có | Không tự chọn đáp án |
| DEMO | Workspace gần toàn màn | Workspace gần toàn màn | Workspace gần toàn màn | Chỉ GV launch, TV chỉ hướng dẫn |

Teacher preview dùng tv.html trong iframe cùng origin, render ở viewport chuẩn 1920×1080 và scale để giữ typography/layout. Iframe không launch app, không phát âm. Các công cụ vẽ hiện có dùng một ngăn chỉnh hình riêng có nhãn; preview thật vẫn ở trung tâm và cập nhật đồng bộ. Không tạo worktree.

## File dự kiến
teacher.html, teacher.js, pedagogy.js, pedagogy-teacher.js, tv.html, tv.js, tv-layout.js, tts-teacher.js; thêm cockpit.css/cockpit.js và cognitive-tv.css. Không sửa lesson ZIP, scene resolver, engine routing, TTSController, DemoTeacher, Launcher, Chrome Start.

## Kiểm tra
Bắt buộc: import năm lesson ZIP, Next/Back/sync/reload/reconnect, hints/answer/close, geometry scenes/overlays, algebra fixtures, Tin Mẫu 4, TTS integration, Demo fail-safe, HTTP/Chrome Start regression và ảnh 1920/1366.
Máy thật Windows/TV/Word/GeoGebra và nghe giọng Việt cần xác minh riêng nếu cloud không cung cấp phần cứng/giọng. Không tuyên bố PASS vật lý từ mock.
