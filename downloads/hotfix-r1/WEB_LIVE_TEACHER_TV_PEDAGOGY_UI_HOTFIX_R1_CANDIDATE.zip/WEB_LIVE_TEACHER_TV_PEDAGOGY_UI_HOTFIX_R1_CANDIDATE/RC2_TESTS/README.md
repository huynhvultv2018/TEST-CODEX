# RC2 regression

Runtime dependencies: Python 3.12, Node 24, Playwright và Chromium. Các dependency test không thuộc runtime của ứng dụng. Sử dụng thư mục hiện có, không tạo worktree.

Từ root candidate, chạy static server trong terminal riêng:

```sh
python -m http.server 8765 --bind 127.0.0.1 --directory .
```

Trong terminal khác, cũng từ root candidate:

```sh
node RC2_TESTS/cockpit.cjs
node TV_MULTI_ENGINE_TESTS/run.cjs
node TV_MULTI_ENGINE_TESTS/extra.cjs
WEB_LIVE_TEST_ROOT="$PWD" node RC2_TESTS/tts-runtime.cjs
WEB_LIVE_TEST_ROOT="$PWD" node RC2_TESTS/tts-edge.cjs
WEB_LIVE_TEST_ROOT="$PWD" node RC2_TESTS/native-probe.cjs
node TTS_UI_TESTS/math-speech.cjs
node TTS_UI_TESTS/regression.cjs
node TTS_UI_TESTS/regression-extra.cjs
PYTHONDONTWRITEBYTECODE=1 python CHROME_START_TESTS/test_browser_start.py
WEB_LIVE_HTTP_PATCH_ROOT="$PWD" PYTHONDONTWRITEBYTECODE=1 python RC2_TESTS/chrome-http/run_http.py
```

Các test dùng browser context riêng; dữ liệu kiểm thử không ghi vào lesson ZIP. Default Chromium /usr/bin/chromium, override CHROMIUM_PATH cho Node harness hỗ trợ biến đó. Adapter RC2 sao chép test TTS/HTTP gốc và chỉ thêm thao tác mở parent group mới, hoặc mở System để tới voice settings. Giữ assertion cũ; không vô hiệu hóa lỗi hoặc force click nút ẩn. Test gốc vẫn có trong gói, một số locator của chúng không phù hợp bố cục RC2 nếu chạy trực tiếp.

33 kiểm tra mới trong cockpit.cjs xác minh popup thật, parity iframe/TV, disclosure, primary action, 2 hints thật, knowledge gate, refresh/reconnect, source bất biến, geometry scenes, thao tác vẽ thật, Focus, fullscreen, privacy, algebra fixture, Tin resource và Demo workspace, TTS mock.

TTS test double không tạo âm thanh. Native probe báo 0 voices ở cloud này. Demo /launch & /return mock không mở app OS. HTTP suite thực thi handler và pairing production trên loopback, nhưng không kiểm Win32 handoff. Máy thật vẫn cần nghiệm thu riêng.

Khi chạy lại test, các file evidence được cập nhật; cần tạo lại CHECKSUMS_SHA256.txt nếu muốn đóng gói lại.
