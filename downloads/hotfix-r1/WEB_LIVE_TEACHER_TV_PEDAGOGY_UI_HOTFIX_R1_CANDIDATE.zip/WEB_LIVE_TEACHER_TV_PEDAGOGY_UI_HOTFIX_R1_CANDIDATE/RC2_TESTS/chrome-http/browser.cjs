const {chromium}=require('playwright'),fs=require('fs'),assert=require('assert');
const root=process.env.WEB_LIVE_HTTP_PATCH_ROOT;
const out=root+'/CHROME_START_EVIDENCE/HTTP_RUNTIME';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 try{
  const originResults=[];
  for(const host of ['127.0.0.1','localhost']){
   const origin='http://'+host+':47382';
   const context=await browser.newContext({viewport:{width:1920,height:1080}});
   const teacher=await context.newPage(),errors=[],consoleErrors=[],requests=[];
   teacher.on('pageerror',e=>errors.push(e.message));
   teacher.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text())});
   teacher.on('request',r=>requests.push({url:r.url(),method:r.method()}));
   const response=await teacher.goto(origin+'/WEB_LIVE/teacher.html');assert.equal(response.status(),200);
   assert(await teacher.evaluate(()=>isSecureContext&&!!crypto.subtle));
   await teacher.locator('#zipfile').setInputFiles(root+'/WEB_LIVE/DEMO_TRUC_TIEP_SAMPLE_LIVE.zip');
   await teacher.waitForFunction(()=>lesson?.screens?.some(s=>s.demo));
   await teacher.evaluate(()=>go(1));
   await teacher.waitForFunction(()=>demoController.ready&&demoController.state==='ready');
   const state=await teacher.evaluate(()=>({origin:location.origin,protocol:location.protocol,isSecureContext,webCrypto:!!crypto.subtle,launcherEndpoint:demoController.endpoint,ready:demoController.ready,launcherState:demoController.state,tokenPresent:!!demoController.token,statusLabel:document.getElementById('launcherStatus').textContent}));
   assert(state.tokenPresent);assert.equal(state.launcherEndpoint,'http://127.0.0.1:47381');
   const statusResponse=teacher.waitForResponse(r=>r.url().endsWith(':47381/status')&&!!r.request().headers()['x-weblive-token']);
   const status=await teacher.evaluate(async()=>{const r=await fetch(demoController.endpoint+'/status',{headers:{'X-WebLive-Token':demoController.token}});const data=await r.json();return{http:r.status,status:data.status,monitorCount:data.monitorCount}});
   status.allowedOrigin=await (await statusResponse).headerValue('Access-Control-Allow-Origin');
   assert.equal(status.http,200);assert.equal(status.allowedOrigin,origin);assert.equal(status.status,'READY');
   const popup=teacher.waitForEvent('popup');await teacher.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await popup;tv.on('pageerror',e=>errors.push(e.message));await tv.waitForLoadState();
   await tv.waitForFunction(()=>lastState?.index===1);
   assert.equal(new URL(tv.url()).origin,origin);
   await teacher.getByRole('button',{name:'TIẾP ▶',exact:true}).click();await tv.waitForFunction(()=>lastState?.index===2);
   await teacher.getByRole('button',{name:'◀ TRƯỚC',exact:true}).click();await tv.waitForFunction(()=>lastState?.index===1);
   await teacher.evaluate(()=>document.getElementById('classroomGroup').open=true);await teacher.locator('#compactBtn').click();if(!await teacher.locator('#displayToolsGroup').getAttribute('open'))await teacher.locator('#displayToolsGroup>summary').click();
   await teacher.screenshot({path:out+'/TEACHER_HTTP_'+host+'.png',fullPage:true});await tv.screenshot({path:out+'/TV_HTTP_'+host+'.png'});
   assert.equal(errors.length,0);
   assert(!requests.some(r=>r.url.startsWith('file:')));
   assert(!requests.some(r=>r.url.endsWith('/launch')),'Startup/import must not launch a native application');
   assert(requests.some(r=>r.url.endsWith(':47381/pair')));
   assert.equal(consoleErrors.length,0,JSON.stringify(consoleErrors));
   originResults.push({origin,url:teacher.url(),http:response.status(),state,authenticatedStatus:status,tvURL:tv.url(),teacherTVSync:'PASS next/previous actual popup',errors,consoleErrors,fileRequests:0,nativeLaunchCalls:0,requests:requests.filter(r=>!r.url.endsWith('runtime-config.js'))});
   await context.close();
  }
  const result={environment:'LINUX CLOUD CHROMIUM; actual static HTTP and production Launcher API handlers, no fetch mock; Windows desktop/.bat not executed',browser:browser.version(),origins:originResults,statuses:{WEB_LIVE_HTTP:'PASS',LAUNCHER_RUNNING:'PASS',ORIGIN_ALLOWED:'PASS',WEB_LIVE_TO_LAUNCHER:'PASS',file_dependency:'NONE',CORS_wildcard:'NONE'}};
  fs.writeFileSync(out+'/browser-runtime.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({statuses:result.statuses,origins:originResults.map(r=>({origin:r.origin,state:r.state,authenticatedStatus:r.authenticatedStatus,errors:r.errors,consoleErrors:r.consoleErrors}))},null,2));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exit(1)});
