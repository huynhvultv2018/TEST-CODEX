# Evidence R1

RUN_INDEX.json xác định các lần chạy R1 mới. PRE_PATCH_AUDIT ghi lỗi 5→1 của RC2 trước sửa; native-tts.json ghi 5→5 sau sửa. Native registry/UI/context không chứng nhận âm thanh. TTS_PLAY/TTS_STOP logs ghi giới hạn thật, không mock PASS.

Demo/Launcher screenshots ghi connected/autopair/metadata qua handlers thật. DEMO_CONFIRM UNRUN; DEMO_LAUNCH là negative response APP_NOT_FOUND; START_WEB_LIVE quan sát Windows-only blocker trên Linux. launcher-native relocation là thư mục Linux thật, không phải ổ D: Windows. FULL_REGRESSION chứa các kết quả/captures mới chạy R1. Các evidence kế thừa ngoài thư mục này không dùng để nghiệm thu vật lý.
