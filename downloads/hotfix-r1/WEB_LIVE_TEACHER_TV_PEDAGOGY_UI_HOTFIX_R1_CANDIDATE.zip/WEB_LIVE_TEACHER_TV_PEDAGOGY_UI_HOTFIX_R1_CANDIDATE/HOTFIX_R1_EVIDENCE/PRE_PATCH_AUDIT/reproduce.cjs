const {chromium}=require('playwright'),fs=require('fs');
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const result={browser:b.version(),speechProvider:'NATIVE WEB SPEECH API; no mock or injected voice',runs:[]};
 for(const transport of ['default','without-BroadcastChannel']){
  const c=await b.newContext({viewport:{width:1920,height:1080}});if(transport!=='default')await c.addInitScript(()=>{window.BroadcastChannel=undefined});
  const t=await c.newPage(),errors=[];t.on('pageerror',e=>errors.push(e.message));
  await t.goto('http://127.0.0.1:8765/WEB_LIVE/teacher.html');await t.locator('#zipfile').setInputFiles('/workspace/TEST-CODEX/WEB_LIVE_TEACHER_TV_PEDAGOGY_UI_RC2_CANDIDATE/RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip');await t.waitForFunction(()=>lesson?.screens.length);await t.evaluate(()=>go(14));await t.waitForTimeout(350);
  const get=()=>({allVoices:speechSynthesis.getVoices().map(v=>({name:v.name,lang:v.lang,localService:v.localService})),state:ttsUI.controller.state,error:ttsUI.controller.errorCode,blocks:ttsUI.blocks.map(b=>({id:b.id,text:b.text})),previewVisible:document.getElementById('studentPreview').getBoundingClientRect().width>0,editorOpen:document.getElementById('annotationEditor').open,mainDisabled:document.getElementById('ttsMain').disabled,binding:typeof document.getElementById('ttsMain').onclick,source:document.getElementById('ttsSource').textContent});
  const beforeTV=await t.evaluate(get);const pop=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await pop;await tv.waitForLoadState();await t.waitForTimeout(500);const withTV=await t.evaluate(get);
  await tv.close();await t.waitForTimeout(300);await t.evaluate(()=>sync());await t.waitForTimeout(300);const afterClosedAndSync=await t.evaluate(get);
  const record={transport,beforeTV,withTV,afterClosedAndSync,errors};result.runs.push(record);console.log(JSON.stringify({transport,before:beforeTV.blocks.length,withTV:withTV.blocks.length,afterClosedAndSync:afterClosedAndSync.blocks.length,voices:beforeTV.allVoices.length,error:beforeTV.error,errors}));
  await t.screenshot({path:'/workspace/hotfix-r1-audit/RC2_'+transport+'.png'});await c.close();
 }
 await b.close();fs.writeFileSync('/workspace/hotfix-r1-audit/reproduction.json',JSON.stringify(result,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
