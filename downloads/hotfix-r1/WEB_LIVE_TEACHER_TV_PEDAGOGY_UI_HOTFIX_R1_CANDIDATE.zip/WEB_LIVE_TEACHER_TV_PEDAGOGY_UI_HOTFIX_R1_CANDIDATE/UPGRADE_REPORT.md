# UPGRADE REPORT — RC2 CANDIDATE

Ngày báo cáo: 2026-10-04T12:41:37+07:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud. **Không nâng Production.**

Teacher có preview làm trung tâm và panel sư phạm riêng. Preview nhúng chính tv.html, cùng renderer và state TV, không có ghi chú GV hay speech controller. Desktop 1920×1080 và 1366×768 có tỷ lệ vùng preview nằm trong 72–78% chiều rộng; header giữ bài/môn/stage/số màn/trạng thái kết nối. Presence riêng phân biệt preview với cửa sổ TV.

Panel có bốn nhóm: điều khiển dạy học, hướng dẫn GV, công cụ lớp học, hệ thống. Chỉ Hành động tiếp theo được nhấn mạnh chính; quyết định gợi ý, giải từng bước, đáp án, chốt và chuyển nhiệm vụ luôn cần GV bấm. Field sư phạm cũ và mới được đọc với fallback; không sửa thứ tự hoặc nội dung lesson.

TV có stage nhận thức chuẩn, Geometry giữ hình và overlays, Algebra có mathematical workspace và bước biến đổi, Tin giữ Mẫu 4 và resource/task. Hint 2 hiện đúng mức đang yêu cầu. Answer thay thế content/hint/analysis, Knowledge Close có gate riêng. Các source có nhiều câu hỏi trong Mẫu 4/quick check dùng Focus hiện có để chỉ hiện một câu hỏi chính tại một thời điểm. Nguồn vẫn giữ trong DOM/data; không sửa lesson.

Demo có resource sử dụng workspace gần toàn màn và hướng dẫn nhỏ bên dưới. Demo không có resource dùng workspace chữ. Import/Next/refresh không gọi /launch; chỉ GV có quyền launch qua flow cũ.

## Baseline và phạm vi

- Baseline: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CHROME_START_HANDOFF.zip`.
- SHA-256: `80f1d254ab722b574d5808fca1d117e4e7dde1e47d48a9a7830f6800842b43d4`.
- Toàn bộ 284 tệp baseline giải nén không đổi. Bản ZIP input không bị ghi đè.
- Launcher, Chrome Start, DemoTeacher, runtime pairing config, TTSController, MathSpeech, scene resolver, ba subject engine và các lesson ZIP byte-identical. Bằng chứng: EVIDENCE/baseline-integrity.json.
- Thay đổi runtime chỉ ở 9 tệp WEB_LIVE liệt kê trong manifest; thêm cockpit.css, cockpit.js, cognitive-tv.css. Xem DESIGN_MAP.md và CHANGELOG.md.

## Điểm đánh đổi

Các công cụ Drawing/Cover/Smart Geometry/Focus giữ listener và DOM gốc trong ngăn “Chú thích / Focus”. Ngăn này được mở khi dùng công cụ, có nhãn riêng chỉ GV. Preview TV thật luôn ở phía trên và cập nhật theo thao tác; bề mặt chỉnh công cụ không được gọi là WYSIWYG. Preview mặc định 1920×1080, tự dùng kích thước TV popup mở bởi Teacher khi truy cập được; TV độc lập có kích thước khác cần kiểm theo display thật.

Không có backend/package runtime mới. Test harness dùng Playwright đã có trong cloud; WEB LIVE vẫn dùng tài nguyên local. Browser test không chứng nhận âm thanh hay Win32.

## Kết quả

- 33 kiểm tra cockpit/disclosure/sync/tools/privacy PASS; 15 ảnh từ harness mới và 1 ảnh Tin SGK thật.
- 171 màn × 2 trạng thái, 44 ảnh đa engine, 15 contract assertions: PASS; 0 overflow trong 342 trạng thái và 44 ảnh kiểm.
- 13 kiểm tra engine bổ sung; TTS 30 kiểm tra tích hợp mock + 7 edge cases + 21 ca MathSpeech: PASS trong phạm vi cloud.
- Chrome Start 18 unit/dispatch checks và 16 API/HTTP checks trên handler thực; popup sync/CORS/pairing ở hai origin loopback: PASS cloud.

Cổng nghiệm thu đầy đủ còn thiếu giọng Việt/âm thanh thật và Windows/TV/Word/GeoGebra thực. `FAIL` tại ba cổng TTS/Demo/Launcher trong ACCEPTANCE_REPORT.md nghĩa là chưa đủ bằng chứng để PASS toàn phần, không phải phát hiện source regression. Gói Đại số có sẵn chỉ là fixture; cần thử thêm LIVE.zip Đại số thực tế.

## Chạy candidate

Giải nén toàn bộ vào thư mục riêng. Trên Windows chạy START_WEB_LIVE.bat như baseline. Import lesson và mở TV; dùng Chrome theo Chrome Start hiện có. Không lấy rời WEB_LIVE khỏi LAUNCHER vì pairing config thuộc cùng gói.

Trong cloud, từ root candidate có thể dùng `python -m http.server 8765 --bind 127.0.0.1 --directory .` cho kiểm thử UI nội bộ; không hỗ trợ mở ứng dụng Windows từ cloud. Không tạo worktree. Hướng dẫn tái lập: RC2_TESTS/README.md.

Các báo cáo/checksum RC1, RC3, RC4, TTS_UI và CHROME_START được giữ như lịch sử baseline. **Báo cáo RC2 ở root và CHECKSUMS_SHA256.txt mới là kết luận/checksum của candidate này.**
