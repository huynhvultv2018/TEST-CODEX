# CHANGELOG — RC2 CANDIDATE

## Teacher
- teacher.html: thêm shared TV iframe, ngăn chú thích, stage/presence header và Next Action; giữ các DOM ID cần cho tool cũ.
- cockpit.js/cockpit.css: grid 75/25, bốn nhóm controls, explicit primary decision, resize preview, phân biệt TV popup với embedded preview, mở editor theo tool. Không reset pedagogy/lesson từ bộ đếm hoặc timer.
- teacher.js: render cockpit và gửi state tới preview cùng sync hiện có. Session state/transport cũ vẫn hoạt động.
- pedagogy-teacher.js: guidance fallback cho lesson metadata hiện có; restore lesson hợp lệ ở index cũ, không khôi phục reveal hay native app.

## Student TV
- tv.html/tv.js: stage nhỏ trong header, preview marker và presence heartbeat. Embedded preview không báo TV đã kết nối, không có fullscreen button.
- tv-layout.js: stage/disclosure, chế độ Demo, hint/analysis/answer/close chỉ theo state; áp dụng lại single-task focus sau subject renderer.
- cognitive-tv.css: hình học 60–65%, Tin resource 60/40, Algebra workspace, semantic hint/conclusion, Demo gần toàn màn, preset 70/30 vẫn thắng các selector phân tích cũ.
- pedagogy.js: display stage mapping tương thích metadata; Hint 2 giữ mức hiện tại, không cộng mọi reveal.

## TTS
- tts-tv.js: registry phân biệt preview/TV.
- tts-teacher.js: đọc registry của shared renderer; ưu tiên registry TV thật cùng state để phản ánh đúng display; giữ single owner và highlight sync.
- Không sửa TTSController/MathSpeech, không thêm dịch vụ TTS ngoài Web Speech API.

## Kiểm thử và bàn giao
- Thêm RC2_TESTS, DESIGN_MAP.md, bốn báo cáo bắt buộc, evidence và checksum.
- Test adapters mở nhóm cha mới trước thao tác locator cũ; assertions được giữ nguyên. Test gốc vẫn nguyên byte.
- Giữ nguyên source Launcher, Chrome Start, DemoTeacher, scene index và lesson ZIP.
- Chỉ Candidate; còn gate máy thật chưa được đóng.
