# HOTFIX R1 Candidate

**PRODUCTION READY = NO.** Đọc HOTFIX_R1_ACCEPTANCE_REPORT.md trước khi dùng. R1 chỉ sửa adapter TTS sau khi TV popup đóng; UI/content/engines/Demo/Launcher giữ nguyên RC2. Giữ bản này độc lập với RC2.

Windows: giải nén toàn bộ gói, dùng START_WEB_LIVE.bat như baseline; Teacher phải mở qua http://127.0.0.1:47382/WEB_LIVE/teacher.html. Python, Chrome, giọng Việt và ứng dụng Demo là prerequisite bên ngoài package. Không đưa path của bản ZIP vào code. Cấu hình exe Word/GeoGebra theo máy trong LAUNCHER/launcher_apps.json; file demo tương đối nằm dưới LAUNCHER/demos/.

Cloud đã kiểm UI, registry, HTTP/API/pairing và relocation thật; âm thanh/Windows còn UNRUN. Báo cáo HOTFIX_R1_* và evidence cùng tên có hiệu lực cho R1; các file RC cũ kế thừa chỉ là lịch sử. Manifest mới thay checksum cũ. Quy trình nghiệm thu máy thật: WINDOWS_RUNTIME_CHECKLIST.md.
