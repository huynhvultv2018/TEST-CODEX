from pathlib import Path
import sys,os,json,subprocess,threading,tempfile,shutil,time,http.client
from http.server import ThreadingHTTPServer
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent.parent
out=root/'HOTFIX_R1_EVIDENCE'
sys.path.insert(0,str(root/'LAUNCHER'))
import WebLiveLauncher as launcher
import web_live_http as web
import start_web_live as startup

def request(path,port=47382):
 c=http.client.HTTPConnection('127.0.0.1',port,timeout=3)
 try:
  c.request('GET',path,headers={'Origin':'http://127.0.0.1:47382'})
  r=c.getresponse();return r.status,r.read()
 finally:c.close()

api=None;api_thread=None

def start_api(base):
 global api,api_thread
 installation,key=launcher.load_installation(base/'LAUNCHER/launcher-config.json')
 api=ThreadingHTTPServer((launcher.HOST,launcher.PORT),launcher.LauncherHandler);api.daemon_threads=True
 api.service=launcher.LauncherService(base/'LAUNCHER',launcher.load_registry(base/'LAUNCHER/launcher_apps.json'))
 api.pairing=launcher.Pairing(installation,key)
 api_thread=threading.Thread(target=api.serve_forever,daemon=True);api_thread.start()

def stop_api():
 global api,api_thread
 if api:
  api.shutdown();api.server_close();api_thread.join(timeout=3);api=None

checks=[];web_process=None
try:
 # Actual CLI startup stops at the intended Windows guard, before any service/browser launch.
 cli=subprocess.run([sys.executable,'-B',str(root/'LAUNCHER/start_web_live.py')],cwd='/tmp',text=True,capture_output=True,timeout=20)
 (out/'START_WEB_LIVE.log').write_text(cli.stdout+cli.stderr+f'\nexit_code={cli.returncode}\nNative Windows .bat/Chrome startup UNRUN on Linux.\n')
 assert cli.returncode!=0 and 'Windows' in cli.stdout
 checks.append({'check':'Actual Python bootstrap with unrelated cwd stops at Windows-only guard before services/browser launch','result':'OBSERVED_BLOCKER','exitCode':cli.returncode,'WindowsBat':'UNRUN'})
 start_api(root)
 web_process=subprocess.Popen([sys.executable,'-B',str(root/'LAUNCHER/web_live_http.py')],cwd='/tmp',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 deadline=time.monotonic()+5
 while startup.probe('http://127.0.0.1:47382/__web_live_health__') is None:
  assert time.monotonic()<deadline;time.sleep(.05)
 assert startup.start_services(root)==[] and startup.start_services(root)==[]
 checks.append({'check':'Real production HTTP process + native production API components reuse twice with no extra processes','result':'PASS'})
 driver=subprocess.Popen(['node',str(root/'HOTFIX_R1_TESTS/demo-native.cjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 log=[]
 for line in driver.stdout:
  log.append(line)
  if line.strip()=='CONTROL STOP_API':stop_api();driver.stdin.write('OK\n');driver.stdin.flush()
  elif line.strip()=='CONTROL START_API':start_api(root);driver.stdin.write('OK\n');driver.stdin.flush()
 status=driver.wait(timeout=10);(out/'demo-native.log').write_text(''.join(log));assert status==0,''.join(log)[-2000:]
 web_process.terminate();web_process.wait(timeout=5);web_process=None;stop_api()
 # Move/rename the real package directories with spaces/Unicode and serve from an unrelated cwd.
 with tempfile.TemporaryDirectory(prefix='weblive-r1-relocation-',dir='/tmp') as temp:
  first=Path(temp)/'Desktop giả lập Linux'/'WEB LIVE R1 đổi tên';first.mkdir(parents=True)
  for directory in ['WEB_LIVE','LAUNCHER']:shutil.copytree(root/directory,first/directory)
  shutil.copyfile(root/'START_WEB_LIVE.bat',first/'START_WEB_LIVE.bat')
  targets=[first,Path(temp)/'D_drive giả lập Linux'/'Thư mục khác'/'Moved R1']
  for n,target in enumerate(targets):
   if n:target.parent.mkdir(parents=True);first.rename(target)
   start_api(target)
   web_process=subprocess.Popen([sys.executable,'-B',str(target/'LAUNCHER/web_live_http.py')],cwd='/tmp',stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   deadline=time.monotonic()+5
   while startup.probe('http://127.0.0.1:47382/__web_live_health__') is None:
    assert time.monotonic()<deadline;time.sleep(.05)
   status,data=request('/WEB_LIVE/teacher.html');assert status==200 and data==(target/'WEB_LIVE/teacher.html').read_bytes()
   health=startup.probe('http://127.0.0.1:47382/__web_live_health__');assert startup.web_ready(health,target)
   assert startup.start_services(target)==[] and startup.start_services(target)==[]
   checks.append({'check':'Rename/relocation runtime, spaces/Unicode, unrelated cwd, Teacher HTTP and duplicate service reuse','result':'PASS','case':n+1,'nativeWindowsDesktopOrDriveD':'UNRUN — Linux directory simulation only'})
   web_process.terminate();web_process.wait(timeout=5);web_process=None;stop_api()
 (out/'launcher-native.json').write_text(json.dumps({'platform':sys.platform,'scope':'Actual CLI/static HTTP and production API components; no executable path, process or app success mocked','checks':checks,'WindowsChromeClosedOpen':'UNRUN','WordGeoGebraHandoff':'UNRUN'},indent=2,ensure_ascii=False))
 print(json.dumps({'checks':len(checks),'productionComponents':'PASS','WindowsStartup':'UNRUN'},indent=2))
finally:
 if web_process and web_process.poll() is None:web_process.terminate();web_process.wait(timeout=5)
 stop_api()
 if (root/'LAUNCHER/launcher.log').exists():
  shutil.move(root/'LAUNCHER/launcher.log',out/'launcher-native-app-errors.log')
