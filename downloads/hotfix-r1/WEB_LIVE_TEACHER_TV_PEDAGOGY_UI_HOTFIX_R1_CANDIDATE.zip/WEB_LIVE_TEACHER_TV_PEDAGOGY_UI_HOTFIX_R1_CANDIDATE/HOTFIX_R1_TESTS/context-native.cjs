const {chromium}=require('playwright'),assert=require('assert'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']}),checks=[];
 for(const fallback of [false,true]){
  const c=await b.newContext();if(fallback)await c.addInitScript(()=>window.BroadcastChannel=undefined);
  const t=await c.newPage();await t.goto('http://127.0.0.1:8766/WEB_LIVE/teacher.html');await t.locator('#zipfile').setInputFiles(root+'/RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip');await t.waitForFunction(()=>lesson?.screens?.length);await t.evaluate(()=>go(14));await t.waitForFunction(()=>ttsUI.blocks.length===5);
  const pop=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await pop;await tv.waitForLoadState();
  const second=await c.newPage();await second.goto('http://127.0.0.1:8766/WEB_LIVE/teacher.html');await second.waitForFunction(()=>lesson?.screens?.length);await second.frames().find(f=>f.url().includes('preview=1')).waitForFunction(()=>lastState?.lessonId);await second.evaluate(()=>loadSample());
  // Let both startup ready handshakes settle before the second Teacher explicitly synchronizes.
  await second.waitForTimeout(300);await second.evaluate(()=>sync());await tv.waitForFunction(()=>lastState?.lessonId==='HINH8_V04_MAU');await second.waitForFunction(()=>ttsUI.blocks.length>0);await t.waitForFunction(()=>ttsUI.blocks.length===0&&document.getElementById('ttsSource').textContent.includes('màn khác'));
  console.log('STATE',JSON.stringify({fallback,first:await t.evaluate(()=>({source:document.getElementById('ttsSource').textContent,lessonId:currentLessonId,index:i,blocks:ttsUI.blocks.length})),second:await second.evaluate(()=>({source:document.getElementById('ttsSource').textContent,lessonId:currentLessonId,index:i,blocks:ttsUI.blocks.length})),tv:await tv.evaluate(()=>({lessonId:lastState.lessonId,index:lastState.index}))}));
  assert((await t.locator('#ttsSource').textContent()).includes('màn khác'));const active=await tv.evaluate(()=>({lessonId:lastState.lessonId,index:lastState.index,lessonActivation:lastState.lessonActivation}));
  for(let n=0;n<5;n++)await t.evaluate(()=>ttsUI.refresh());assert.equal(await t.evaluate(()=>ttsUI.blocks.length),0);assert.deepEqual(await tv.evaluate(()=>({lessonId:lastState.lessonId,index:lastState.index,lessonActivation:lastState.lessonActivation})),active);
  checks.push({transport:fallback?'without-BroadcastChannel':'default',name:'Foreign Teacher context remains blocked and repeated refresh does not steal the active TV',result:'PASS'});
  await second.close();await t.evaluate(()=>sync());await t.waitForFunction(()=>ttsUI.blocks.length===5);await tv.waitForFunction(()=>lastState.index===14);await tv.close();await t.waitForFunction(()=>tvWindow===null&&ttsUI.blocks.length===5);
  checks.push({transport:fallback?'without-BroadcastChannel':'default',name:'Explicit sync restores own registry; subsequent popup close retains it',result:'PASS'});await c.close();
 }
 await b.close();fs.writeFileSync(root+'/HOTFIX_R1_EVIDENCE/context-native.json',JSON.stringify({scope:'Native renderer/context; no speech mock; foreign speech cancellation audio UNRUN',checks},null,2));console.log(JSON.stringify(checks,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
