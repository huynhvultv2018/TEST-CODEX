const {chromium}=require('playwright'),assert=require('assert'),fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..'),out=root+'/HOTFIX_R1_EVIDENCE',base=process.env.R1_BROWSER_BASE||'http://127.0.0.1:8766/WEB_LIVE/';
(async()=>{
 const b=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 const result={browser:b.version(),provider:'NATIVE speechSynthesis; no injected voice or speech mock',checks:[],blocked:[],runs:[]};
 const check=(name,details={})=>{result.checks.push({name,result:'PASS',...details});console.log(name)};
 for(const transport of ['default','without-BroadcastChannel']){
  const c=await b.newContext({viewport:{width:1920,height:1080}});if(transport!=='default')await c.addInitScript(()=>window.BroadcastChannel=undefined);
  const errors=[],requests=[];c.on('page',p=>{p.on('pageerror',e=>errors.push(e.message));p.on('request',r=>{if(r.url().includes(':47381/'))requests.push({method:r.method(),url:r.url()})})});
  const t=await c.newPage();await t.goto(base+'teacher.html');
  await t.locator('#zipfile').setInputFiles(root+'/RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip');await t.waitForFunction(()=>lesson?.screens?.length);await t.evaluate(()=>go(14));await t.waitForFunction(()=>ttsUI.blocks.length===5);
  await t.evaluate(()=>{window.initialTTS=ttsUI.controller;window.initialMain=document.getElementById('ttsMain').onclick});
  const snap=()=>t.evaluate(()=>({index:i,blocks:ttsUI.blocks.map(b=>({id:b.id,region:b.region,text:b.text})),voices:speechSynthesis.getVoices().map(v=>({name:v.name,lang:v.lang,localService:v.localService})),state:ttsUI.controller.state,error:ttsUI.controller.errorCode,source:document.getElementById('ttsSource').textContent,tvReferenceCleared:tvWindow===null,queue:ttsUI.controller.queue.length}));
  let before=await snap();const pop=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();let tv=await pop;await tv.waitForLoadState();await t.waitForFunction(()=>document.getElementById('ttsSource').textContent.includes('trên TV'));const withTV=await snap();
  assert.deepEqual(withTV.blocks,before.blocks);check(transport+': preview and popup TTS use the same five disclosed MCQ blocks');
  await tv.close();await t.waitForFunction(()=>tvWindow===null&&ttsUI.blocks.length===5);await t.evaluate(()=>sync());await t.waitForTimeout(120);const closed=await snap();assert.deepEqual(closed.blocks,before.blocks);assert(closed.source.includes('TV Preview'));check(transport+': closing popup preserves shared preview registry, including a later sync');
  for(let n=0;n<10;n++)await t.evaluate(()=>ttsUI.refresh());assert.deepEqual((await snap()).blocks,before.blocks);assert(await t.evaluate(()=>initialTTS===ttsUI.controller&&initialMain===document.getElementById('ttsMain').onclick));check(transport+': repeated refresh does not discard blocks or duplicate controller/binding');
  await t.evaluate(()=>go(13));await t.waitForFunction(()=>ttsUI.blocks.some(b=>b.region==='content'));await t.locator('#hintBtn').click();await t.waitForFunction(()=>ttsUI.blocks.some(b=>b.region==='hint'));await t.locator('#hint2Btn').click();await t.waitForFunction(()=>hintLevel===2&&ttsUI.blocks.some(b=>b.region==='hint'));
  await t.locator('#ansBtn').click();await t.waitForFunction(()=>ttsUI.blocks.length&&ttsUI.blocks.every(b=>b.region==='answer'));const answer=await snap();assert(!answer.blocks.some(b=>b.region==='content'||b.region==='hint'));check(transport+': after TV close, Hint1/Hint2/Answer read only shared renderer disclosures');
  await t.evaluate(()=>go(5));await t.waitForFunction(()=>ttsUI.blocks.length===0);await t.locator('#closeKnowledgeBtn').click();await t.waitForFunction(()=>ttsUI.blocks.length>0);check(transport+': Knowledge Close remains unreadable before explicit reveal');
  await t.locator('#systemGroup>summary').click();await t.locator('#ttsRate').selectOption('1.1');await t.locator('#ttsGenderPreference').selectOption('female');const oldLesson=await t.evaluate(()=>JSON.stringify(lesson));await t.reload();await t.waitForFunction(()=>lesson?.screens?.length&&ttsUI.blocks.length===0);assert.equal(await t.evaluate(()=>JSON.stringify(lesson)),oldLesson);assert.equal(await t.evaluate(()=>ttsUI.controller.settings.rate),1.1);assert.equal(await t.evaluate(()=>ttsUI.controller.settings.preferredGender),'female');check(transport+': refresh retains settings and source, hides reveals, and keeps Teacher initialization');
  await t.evaluate(()=>go(14));await t.waitForFunction(()=>ttsUI.blocks.length===5);
  const pop2=t.waitForEvent('popup');await t.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();tv=await pop2;await tv.waitForLoadState();await t.waitForFunction(()=>document.getElementById('ttsSource').textContent.includes('trên TV'));await t.getByRole('button',{name:'TIẾP ▶',exact:true}).click();await tv.waitForFunction(()=>lastState.index===15);await t.getByRole('button',{name:'◀ TRƯỚC',exact:true}).click();await tv.waitForFunction(()=>lastState.index===14);await tv.reload();await tv.waitForFunction(()=>lastState?.index===14);check(transport+': popup reconnect, Next/Back and TV refresh still sync');
  const live=await snap();if(live.voices.filter(v=>/^vi(?:-|$)/i.test(v.lang)).length===0){
   assert.equal(live.error,'NO_VOICE');assert(await t.locator('#ttsMain').isDisabled());assert.equal(await t.evaluate(()=>ttsUI.controller.read(ttsUI.blocks)),false);assert.equal(await t.evaluate(()=>ttsUI.controller.queue.length),0);
   result.blocked.push({transport,tests:['TTS_START_AUDIO','TTS_STOP_AUDIO','TTS_REPLAY_AUDIO','NEXT_WHILE_SPEAKING','BACK_WHILE_SPEAKING','VOICE_SELECT','NATIVE_PAUSE_RESUME','NATIVE_VOICE_FALLBACK'],outcome:'UNRUN',reason:'Native speechSynthesis has zero Vietnamese voices (all voices count '+live.voices.length+')'});
   check(transport+': native missing-voice error is explicit; no speech queue or false success');
  }else{throw Error('Native Vietnamese voice now exists; run full audio checks instead of the no-voice plan')}
  if(transport==='default'){
   await t.screenshot({path:out+'/TTS_ENGINE.png'});await tv.screenshot({path:out+'/TTS_NEXT_SCREEN.png'});await t.evaluate(()=>{ttsUI.controller.stop();});await t.screenshot({path:out+'/TTS_STOP.png'});
   await t.setViewportSize({width:1366,height:768});await t.screenshot({path:out+'/TEACHER_1366x768.png'});await t.setViewportSize({width:1920,height:1080});await t.screenshot({path:out+'/TEACHER_1920x1080.png'});
  }
  assert.equal(errors.length,0);assert(!requests.some(r=>r.url.endsWith('/launch')));check(transport+': no page errors or native launch requests in teaching/TTS navigation');
  result.runs.push({transport,before,withTV,closed,answer,native:live,errors});await c.close();
 }
 // Multi-subject routes use the same unchanged TTS controller and disclosed registry.
 const c=await b.newContext({viewport:{width:1920,height:1080}}),t=await c.newPage();await t.goto(base+'teacher.html');
 await t.locator('#zipfile').setInputFiles(root+'/WEB_LIVE/HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST.zip');await t.waitForFunction(()=>lesson?.subject==='Hình học 8');await t.evaluate(()=>{go(9);revealStep()});await t.waitForFunction(()=>ttsUI.blocks.some(b=>b.region==='answer'));assert(await t.evaluate(()=>ttsUI.blocks.every(b=>b.region==='answer')));check('Geometry reads only disclosed proof through the unchanged TTS provider');
 await t.evaluate(()=>{const l={id:'r1-algebra-test',subject:'Đại số 8',title:'Presentation fixture',screens:[{type:'EQUATION',content:'2x + 6 = 14',steps:['2x = 8','x = 4']}]};saveLesson(l);start(l);revealStep()});await t.waitForFunction(()=>ttsUI.blocks.some(b=>b.region==='answer'));assert(await t.evaluate(()=>ttsUI.blocks.every(b=>!b.text.includes('x = 4'))));check('Algebra fixture keeps future solution out of the TTS registry');
 await c.close();await b.close();
 fs.writeFileSync(out+'/native-tts.json',JSON.stringify(result,null,2));fs.writeFileSync(out+'/TTS_PLAY.log','UNRUN audio: native speechSynthesis returned zero Vietnamese voices. TTSController.read returned false with NO_VOICE. No mock or audio success claimed.\n');fs.writeFileSync(out+'/TTS_STOP.log','Controller stop/empty queue observed in native API context; stopping audible Vietnamese speech is UNRUN because no voice is present.\n');
})().catch(e=>{console.error(e);process.exit(1)});
