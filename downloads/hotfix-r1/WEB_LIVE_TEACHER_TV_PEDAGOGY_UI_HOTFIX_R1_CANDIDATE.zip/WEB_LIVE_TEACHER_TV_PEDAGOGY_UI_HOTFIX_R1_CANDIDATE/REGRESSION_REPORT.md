# REGRESSION REPORT — RC2

Ngày: 2026-10-04T12:41:37+07:00. Browser: Chromium 151.0.7922.173, Linux. Mọi PASS sau đây có phạm vi ghi rõ; không suy thành PASS phần cứng.

| Suite / thao tác | Kết quả hiện tại | Evidence |
|---|---|---|
| RC2 cockpit | 33/33 PASS, 0 runtime errors | EVIDENCE/cockpit-results.json |
| Multi-engine gốc | 171 màn, 342 states, 15 assertions, 44 ảnh PASS; không overflow | TV_MULTI_ENGINE_EVIDENCE/results.json |
| Engine extra | 13/13 PASS | TV_MULTI_ENGINE_EVIDENCE/extra-results.json |
| TTS presentation regression | 171 màn/342 states, 44 ảnh; 0 runtime errors/overflow | TTS_UI_EVIDENCE/regression/results.json |
| TTS integration RC2 adapter | 30/30 PASS_TEST_DOUBLE, không tạo audio | TTS_UI_EVIDENCE/runtime.json |
| TTS edge RC2 adapter | 7/7 PASS_TEST_DOUBLE | TTS_UI_EVIDENCE/edge-cases.json |
| MathSpeech | 21 ca PASS, không tạo audio | TTS_UI_EVIDENCE/math-speech.json |
| Native voice probe | API có; 0 voices; thiếu giọng Việt được báo và navigation vẫn hoạt động | TTS_UI_EVIDENCE/native-probe.json |
| Chrome Start | 18 tests, 0 failures/errors; process dispatch Windows được kiểm soát | CHROME_START_EVIDENCE/browser-dispatch-tests.json |
| Production HTTP/Launcher API | 16 checks PASS, handler thật, CORS/HMAC/token, static root và reuse | CHROME_START_EVIDENCE/HTTP_RUNTIME/http-api-checks.json |
| Popup Teacher-TV ở localhost/127.0.0.1 | PASS với production server, không /launch | CHROME_START_EVIDENCE/HTTP_RUNTIME/browser-runtime.json |
| Windows Chrome .bat / Word / GeoGebra / monitor handoff | UNRUN trên cloud | Chờ máy thật |
| Nghe audio Việt, pause/resume native, output HDMI/loa | UNRUN; native 0 voices | Chờ máy thật |
| Gói Đại số curriculum thực | UNRUN; engine được kiểm bằng fixture | Chờ LIVE.zip thực |

## Coverage hành vi

Import năm ZIP gốc, Next/Back, jump, thao tác nhanh 14 vòng Next/Back, popup thật, heartbeat, refresh TV, đóng/mở TV, reload Teacher và source/index restore. Tất cả reveal ẩn lại khi Teacher refresh. Embedded preview và TV được đối chiếu engine/stage/disclosure/nội dung visible/figure/labels.

Hai hints dùng dữ liệu Tin thật, Answer không lộ sớm, Knowledge Close chờ GV. Guidance private được kiểm bằng sentinel ở teacherProbe/expectedResponse/commonError/notes/pedagogyGuidance và không xuất hiện trong TV body; TV không có teacher buttons.

Geometry qua sáu screen cùng scene có cùng image SHA; analysis future node không vào DOM; proof steps, overlay order, Drawing/Label qua mouse và dialog thật, Mask/Smart/Pointer/Zoom, timer, Whiteboard, layout 70/30, double-click round-trip và Focus đều kiểm. Source lesson vẫn bằng JSON trước thao tác.

Algebra được kiểm 8 loại workspace và các route bổ sung bằng fixture: expression/equation/system/word problem/identity/table/graph/practice; no-early-step, atomic long formula, quan hệ/bước biến đổi. Không tuyên bố curriculum Đại số đã kiểm.

Tin kiểm 3 lesson ZIP thật; MCQ, review, intro, observe/resource, knowledge, practice, application, Mẫu 4; có/không resource và primary question Focus. Demo fixture có figure ~80% + task, kiểm screen Demo thật; không import/Next/refresh nào gọi /launch. /launch và /return chỉ được mô phỏng để không gọi OS app trong cloud.

TTS mock kiểm speak Việt/rate, gender metadata/fallback, thiếu voice, pause/resume, stop/replay, auto-cancel Next/Back/jump/import, highlight không thay geometry/focus, đọc đúng visible registry, settings reload, natural completion, error callback, single owner, storage denial, two Teachers và không BroadcastChannel. TV không có TTSController và không phát speech.

## Chẩn đoán các lần chạy đầu

Test gốc tìm controls ở panel cũ bị timeout do parent group mới đóng; adapter thêm thao tác mở nhóm/Settings, giữ assertions. Selector CSS 70/30 trên màn analysis và observer mở editor lặp đã được sửa trong candidate; các ca tương ứng chạy lại PASS. Một check guidance trước khi mở nhóm bị timeout/không có innerText; harness mở group bằng thao tác UI rồi kiểm. Không bỏ assertion, không force-click nút ẩn, không thay bài học để làm test pass.

## Reproduce

Xem RC2_TESTS/README.md. Log run mới được chép vào EVIDENCE/logs; các JSON/ảnh ở đường dẫn trên được tạo từ những lượt chạy hiện tại. Các báo cáo/evidence khác được mang từ baseline là lịch sử, không dùng để khẳng định RC2 đạt máy thật.
