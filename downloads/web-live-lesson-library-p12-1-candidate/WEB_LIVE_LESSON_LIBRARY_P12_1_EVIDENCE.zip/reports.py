from pathlib import Path
import json,hashlib,shutil,zipfile
p=Path(__file__).parent;out=Path('/workspace/output/web-live-lesson-library-p12-1-candidate');read=lambda n:json.loads((p/n).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda n,d:(p/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
identity=read('PACKAGE_IDENTITY.json');source=read('SOURCE_IDENTITY.json');scope=read('SOURCE_SCOPE.json');reg=read('REGRESSION_COMPARISON.json');before=read('BEFORE_REPRODUCTION.json');assert before['rootCauseConfirmed']
groups={}
for key,rel,count in [('workingTargeted','TARGETED/TARGETED_RESULTS.json',28),('workingLibrary','LIBRARY/LIBRARY_RESULTS.json',21),('workingQuick','QUICK/QUICK_ACCESS_RESULTS.json',16),('workingSafeguards','SAFEGUARDS/TARGETED_RESULTS.json',15),('packagedTargeted','PACKAGED_TARGETED/TARGETED_RESULTS.json',28),('packagedLibrary','PACKAGED_LIBRARY/LIBRARY_RESULTS.json',21),('packagedQuick','PACKAGED_QUICK/QUICK_ACCESS_RESULTS.json',16),('packagedSafeguards','PACKAGED_SAFEGUARDS/TARGETED_RESULTS.json',15)]:
 d=read(rel);assert d['result']=='PASS' and len(d['checks'])==count and not d['errors'];groups[key]={'result':'PASS','groups':count,'evidence':rel}
assets=read('PACKAGED_SMOKE/PACKAGED_ASSETS.json');assert assets['result']=='PASS' and len(assets['assets'])==60
assert read('ENVIRONMENT_SETTINGS_EVIDENCE.json')['unchanged'];assert sha(Path(source['sourceZip']).read_bytes())==source['sha256Before']==source['sha256After'];assert sha((out/(identity['candidate']+'.zip')).read_bytes())==identity['sha256']
write('RELEASE_GATE.json',{'result':'PASS','cloudTechnicalOnly':True,'beforeReproduced':'YES','rootCauseConfirmed':'YES','groups':groups,'profileRegressionGroups':75,'exactHTTPAssets':60,'zipCRC':'PASS','payloadManifest':'PASS','sourceScope':'PASS','P12_F01':'TECHNICAL_FIX_VERIFIED_WINDOWS_RETEST_PENDING','P11_F01':'P2 OPEN_DEFERRED','capacityLimitRemoved':False,'newP0':0,'newP1':0,'newP2':0,'newP3':0,'carriedOpenP2':1,'P12_F01_windowsFinding':'YES (GV_REPORTED)','windowsRetest':'UNRUN','physicalTV':'UNRUN','realClassroom':'UNRUN'})
working=read('TARGETED/TARGETED_RESULTS.json');library=read('LIBRARY/LIBRARY_RESULTS.json');quick=read('QUICK/QUICK_ACCESS_RESULTS.json');packquick=read('PACKAGED_QUICK/QUICK_ACCESS_RESULTS.json');quota=next(c['evidence'] for c in quick['checks'] if c['name']=='ACTUAL_QUOTA_REPRODUCER_PRESERVED_CURRENT_AND_UNKNOWN_DATA');pquota=next(c['evidence'] for c in packquick['checks'] if c['name']=='ACTUAL_QUOTA_REPRODUCER_PRESERVED_CURRENT_AND_UNKNOWN_DATA')
def report(n,text):(p/n).write_text(text.strip()+'\n')
report('P12_1_ROOT_CAUSE_REPORT.md',f'''
# P12.1 — Root cause and minimal compatibility fix

P12-F01 = P2, owner SUBJECT LOADER COMPATIBILITY LAYER. ROOT_CAUSE_CONFIRMED = YES. Core/Profile/package content failure = NO for the reproduced finding.

Authoritative source: frozen WEB_LIVE_LESSON_LIBRARY_PHASE12_CANDIDATE, SHA256 {source['sha256Before']}. Original ZIP CRC and1241file manifest verified before making a separate working copy. SHA after={source['sha256After']}; original unpacked payload remains exact. No source lesson ZIP, PPCT/SGK/SBT, Core/Profile or Production patch.

Before patch reproduced on actual frozen Phase12 HTTP runtime, served loader SHA256 {before['sourceLoaderSHA256']}. Case1: synthetic equivalent subject=Tin học6, grade6/week5/period5, title=Bài3.THÔNG TIN TRONG MÁY TÍNH, subject_engine absent. Case2: unchanged existing RC3_PED1_TEST_PACKAGES/TIN6_W05_LIVE_RC3_PED1.zip, actual same metadata, ID TIN6_T05_P05_SGK_RC3_PED1. Both select informatics → resolve runtime legacy → BLOCK, preview metadata readable, current lesson null. BEFORE_REPRODUCTION.json + BEFORE_1.png/BEFORE_2.png show exact error “Môn của bài: Legacy”. Windows reproduction YES is GV-reported in authorization, not independently performed by this cloud run.

Confirmed source path: engine(x) returns legacy when subject_engine is absent; validate(x) returns that runtime engine; refresh compares selected subject directly to validate result and labels engine as “Môn của bài”. renderLibrary used row.profile for subject filtering and rememberSuccess used recentEntry.subjectEngine for lastSubject. This conflates discovery/selection subject with runtime profile. Source and two before-runtime cases support this cause; no speculative engine fix.

Only WEB_LIVE/subject-loader.js changed; subject-loader.css and1240other files exact. Added Loader-local subjectIdentity/mappedSubject: recognized top-level official subject metadata identifies subject; runtime engine always uses unchanged engine()/frozen Profile Resolver. Tin học6 with engine absent now subject=informatics and runtime=legacy. Conflicting recognized subject with nonlegacy explicit engine blocks with warning. Unknown subject stays unknown in compatibility bucket. Modern explicit engine with generic/unrecognized subject text keeps existing explicit-engine discovery compatibility.

Minimal integrations: refresh checks subject identity; library uses subjectId while retaining engine separately; preview/cards/Recent/indicator label Chế độ chạy; successful quick access remembers resolved subject while its existing subjectEngine reference stores actual engine. No new persistent namespace/schema/payload or migration. Reopening Recent uses same openSaved/stage pipeline; never assigns subject_engine to Legacy packages.

After patch working and fresh ZIP28targeted groups each PASS including unchanged real existing W05 ZIP and15cross-subject Legacy variants. Package engine missing/legacy/default stays exactly so; runtime always legacy. True mismatches, sixcontradiction pairs, invalid engines/packages preserve Teacher/TV/storage. Filters/Recent/quota safeguards PASS. Four-profile75groups match frozen Phase12 semantic JSON with documented UUID/video-time normalization.

P12_F01_STATUS = TECHNICAL_FIX_VERIFIED_WINDOWS_RETEST_PENDING. P12_1_WINDOWS_RETEST=UNRUN; PHYSICAL_TV_VALIDATION=UNRUN; REAL_CLASSROOM_TRIAL=UNRUN. Do not convert cloud success to physical acceptance. Candidate {identity['candidate']}.zip SHA256 {identity['sha256']}. STOP, chờ GV kiểm thử lại trên Windows.
''')
report('P12_1_LEGACY_SUBJECT_COMPATIBILITY_CONTRACT.md','''
# P12.1 — Loader-local subject / engine contract

Discovery subject and runtime engine are separate. resolveSubject returns {id,engine,known,source}; id is a filter category, not a package write or Core profile. known=false with id=legacy means compatibility bucket, not assigned lesson subject “Legacy”. engine() and frozen WebLiveProfiles resolver unchanged.

| Existing official metadata | Discovery selection | Runtime |
|---|---|---|
| subject Tin học / Tin học6 / Tin học8, engine absent/legacy/default | informatics | legacy |
| subject Hình học8, engine absent/legacy/default | geometry | legacy |
| subject Đại số8, engine absent/legacy/default | algebra | legacy |
| explicit recognized subject and matching modern explicit engine | that subject | exact supplied modern engine |
| generic/unrecognized subject, valid explicit modern engine | existing engine compatibility category | supplied modern engine |
| unknown/missing subject, absent/legacy/default engine | unknown Legacy compatibility bucket | legacy |
| recognized subject different from nonlegacy explicit engine | BLOCK / clear metadata-conflict warning | no commit |
| true subject mismatch with selected subject | BLOCK | no commit |
| invalid/empty/unsupported explicit engine | BLOCK | no fallback bypass |

Actual source inventory found top-level subject and subject_engine; no other existing subject-related structured fields. Use those fields only, do not invent nested metadata keys/contracts. Mapping priority: recognized official subject; if unknown, retain existing explicit-modern-engine compatibility; else unknown Legacy bucket. The safe Legacy mapping interprets official subject labels only, never pedagogy.

Safe map is anchored full-string: Hình học/Đại số/Tin học, optionally grade6–9 or “lớp6–9”, plus canonical geometry/algebra/informatics tokens. Unicode NFKC, case/whitespace normalization only, max160characters. Additional unknown suffixes/mixed labels/Toán8/misleading title or filename are not substring-matched. Unknown packages remain accessible in Legacy bucket with “Môn chưa xác định”/“Chưa đủ thông tin: MÔN”, not guessed. No filename/content/question/PPCT/SGK/SBT heuristic. Subject numeral never writes grade or engine.

Recognized subject with engine absent remains property-absent after load/save; explicit legacy/default raw value stays unchanged. No engine inference, new profile, Core resolver edit, package source rewrite, pedagogy generation or subject metadata insertion. Standard native sourceKey/ZIP image preparation behavior unchanged.

Preview shows actual raw subject if supplied, present grade/week/period/title and separate Chế độ chạy including absent-engine Legacy status. Mismatch labels subject independently of engine; never “Môn của bài: Legacy” for a known Tin/Hình/Đại subject. Library and Recent show source metadata plus runtime mode. Indicator labels resolved subject or unknown, plus actual runtime mode.

Library Môn → Lớp → Tuần → Tiết uses subjectId and native grade/week/period fields. Numeric sort/cascade/clear-pending unchanged. Missing grade/week/period remains incomplete; unknown-subject packages use Legacy compatibility bucket, with an unknown note even if G/W/P are present. Invalid contradictory cache rows remain visibly invalid and stage-blocked, not relabeled or repaired. All/unknown options use actual data only. No grade inferred from Tin học6.

Recent keeps original namespace/version, fields and max5/8192character bound. subjectEngine remains actual engine; lastSubject is discovery subject after successful commit. Cached lesson is revalidated on every reopen; original existing optional entries read unchanged. Old lastSubject values are not automatically migrated/reinterpreted; next successful explicit load updates correctly. No read-time writes, duplicated package/assets, storage architecture migration or IndexedDB/quota changes.

Transaction stage/validation/assets/profile routing/explicit commit/current rollback unchanged in code except subject validation and compatibility conflict gate. Essential quota guard exact; optional quick-access failure remains nonfatal to successful load. Grade/week/period change cancels pending preview without changing current Teacher/TV. Native accepted-session restore on reload retained, quick subject memory does not initiate new load.

Scope only subject-loader.js plus external tests/reports. subject-loader.css unchanged. Physical Windows retest/TV/classroom UNRUN. P11-F01 P2 OPEN_DEFERRED, capacity limit not removed. No Phase13/Production.
''')
suiteRows='\n'.join(f"| {k} | {v['groups']} | PASS | {v['evidence']} |" for k,v in groups.items())
report('P12_1_TEST_EVIDENCE.md',f'''
# P12.1 — Evidence

Chromium {working['browser']}, Linux managed cloud, Playwright. Synthetic fixtures are TEST ONLY, not SGK/PPCT acceptance. Real existing source W05 ZIP used unchanged; this does not validate its textbook content or physical classroom behavior.

Before2cases reproduced on frozen Phase12, before patch only: finding-equivalent JSON and actual TIN6W05ZIP. HTTP loader bytes match frozen manifest; selected informatics/resolved engine legacy/old mismatch blocked. Windows original finding is GV-reported YES.

| Suite | Groups | Result | Raw evidence |
|---|---:|---|---|
{suiteRows}

28targeted groups include: independent subject/engine identity; exact Tin6 resolution; explicit stage no auto-commit; corrected preview labels; Legacy load/property absence/content exact; Recent actual-engine reference and subject memory; hidden future/Teacher notes on actual TV; subject+Grade6/Week5/Period5 visibility; filter changes preserving Teacher/TV/storage; true modern mismatch; sixLegacy mismatches; sixmetadata/modern-engine contradictions; invalid explicit engine5variants and invalidscreens;15Legacy cases (Tin/Tin6/Tin8/Hình8/Đại8 × missing/legacy/default); modern3profile routing; conservative unknown cases/title/content/filename non-inference; knownTin6 with missingG/W/P still accessible/no fabricated grade; unchanged actual W05ZIP allowed with Legacy; Recent5dedup/reload/shared validation; no optional-cache migration/read writes; zero errors/external requests. Exact engine-source preservation assertions executed, not inferred from labels.

Phase12 large library21groups repeated working+fresh artifact:660lessons,4groups,grades6–9,weeks1/2/5/10/11,periods1/2/9/10,2normalvariants each +20missing. List stability/duplicates/source truth/zero filter writes/current preservation/no fake fields/numeric sort PASS. Common qualified scenario5meaningful/6modeledmouse clicks retained; native dropdown automation and arbitrary search/scroll are not Windows click measurements.

Quick16groups and safeguards15groups repeated working+fresh artifact. Actual Chromium quota reached with {quota['storedCharacters']}storedcharacters working /{pquota['storedCharacters']} packaged fixture; blocked essential commit preserves current Teacher/TV/unknown sentinel and failed lesson absent from Recent. Fivefault categories (lesson/library/snapshot writes/optional quota/security) tested; partial rollback/nonfatal optional warnings intact. No capacity removal, migration or package eviction.

All4runtime regressions75groups PASS against completed Phase12 semantic evidence; regression report gives normalization. Fresh ZIP1241file SHA manifest equality, CRC PASS; HTTP60assets served exact bytes and modal close/reopen/close PASS. Fourprofile detailed75groups run on working once, identical fresh payload hash verified; do not claim all75were re-run from ZIP.

External harness changes reflect authorized contract only: preview always has Chế độ chạy; exact source package selectors use subject from official metadata (TIN6/TIN8→informatics,HINH8→geometry), while assertions still require Legacy engine/output. HARNESS_ADAPTATIONS.txt documents changes; no disabled safety/overflow/no-teach-ahead assertions. Source lesson packages and old Phase12 helpers untouched. HARNESS_HISTORY retains initial27groupsPASS before adding missing-grade case; no runtime defect concealed.

Evidence ZIP includes raw JSON/logs/screens/helpers/fixtures and original G4-F01 representative test input SHA4488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8. Finding-equivalent fixture contains authored stub question/steps, not reconstructed SGK lesson. W05source ZIP checksum is in fullpayloadmanifest. Root cause screenshots show before/after readable metadata and actual mismatch/allow button.

P12_F01_REPRODUCED_ON_WINDOWS=YES(GV_REPORTED). P12_1_WINDOWS_RETEST=UNRUN; PHYSICAL_TV_VALIDATION=UNRUN; REAL_CLASSROOM_TRIAL=UNRUN. No independently measured Windows launcher/audio/back-row readability claim.
''')
profileRows='\n'.join(f"| {k} | {v['checks']} | PASS | {v['normalization']} |" for k,v in reg.items())
report('P12_1_REGRESSION_REPORT.md',f'''
# P12.1 — Regression and source integrity

| Runtime | Groups | Result | Phase12 semantic JSON normalization |
|---|---:|---|---|
{profileRows}

75regression groups compare exact semantic output to completed frozen Phase12 baseline. Legacy/Algebra no normalization; Geometry only across-run random activationUUID (within-run Teacher/TV/preview identity asserted), Informatics only manual video currentTime (playback>0 assertions still run). No pixel-hash or physical-equivalence claim. Existing question/hint/answer/proof/sample/checkpoint/Teacher-note gates remain checked; no-teach-ahead PASS. Vertical full-width MCQ and separate instructions retained; no adaptive columns.

Source files1241 unchanged path set. Only WEB_LIVE/subject-loader.js changed;1240files including css, Core, Profile Resolver, Geometry/Algebra/Informatics, teacher.js/tv.js/common.js/zip.js, assets and lesson packages byte-exact. No added/removed runtime file. Original Phase12 frozen unpacked1241file baseline and ZIP SHA before=after {source['sha256Before']}. SOURCE_SCOPE.json records exact unchanged engine/essential asset-stage-transaction-quota segment and relevant filter/quick functions.

Engine validation/frozen resolver unchanged: missing subject_engine/default/legacy runtime still Legacy; unknown/empty/nonstring engine blocked; matching modernexplicit routes unchanged. Newsubject conflict/mismatch gate preserves current. Grade/week/period numeric/cascade behavior unchanged. Recent originalnamespace/version/max5/fields/8192bound remain; only lastSubject successful-write value now resolvedsubject. Old optional records not rewritten on read.

Storage: filter0writes, no new persistent key/index/cache, no payload/assets duplicated, no automatic user-package deletion/quota increase/IndexedDB. P11-F01=P2 OPEN_DEFERRED. Current preservation, rollback, warnings and optional write failures PASS. Original essential transaction code exact.

Native accepted-session restore retained on reload; remembered subject alone does not trigger new load. Reset explicit activation/Focus/hint/answer/zoom/oldprofile overlays remains PASS across Geometry→Algebra→Informatics→Legacy→Geometry. Source lesson JSON property/content preservation and absent-engine assertion demonstrate no inferred profile.

Fresh extracted candidate same1241hashes;80targeted/filter/quick/safeguardgroups repeated plus60HTTPassets exact +modal check. All reports/fixtures/helpers external to runtime ZIP. Embedded prior reports/checksums are historical unchanged records; external P12.1 manifest/checksums are release authority.

Environment draft revision12 unchanged/no write/Save/Publish; DRAFT_PENDING_SAVE_PUBLISH. ExistingPython3/Node/Playwright/Chromium reused, no npm build/install. Windows afterpatch/TVphysical/classroom UNRUN. Production/main/old branches preserved; artifact delivery only new isolated P12.1 branch, no PR/merge.
''')
report('P12_1_RISK_REGISTER.md','''
# P12.1 — Risk register

New open findings after authorized cloud gates: P0=0,P1=0,P2=0,P3=0. Carried open P2=1 (P11-F01). P12-F01 technical fix verified; Windows reacceptance pending, do not report physical FIXED/PASS.

| ID | Class | Status | Evidence / decision |
|---|---|---|---|
| P12-F01 Legacy subject/engine mismatch | P2 | TECHNICAL_FIX_VERIFIED_WINDOWS_RETEST_PENDING | Reproduced on frozen runtime with synthetic+unchangedW05 package; postpatch28targetedgroups working/freshPASS, actual Legacy engine preserved. Windows finding GV-reportedYES; retestUNRUN. |
| P11-F01 localStorage capacity | P2 | OPEN_DEFERRED | Guard/currentpreservation PASS; capacity not removed. No storage architecture changes authorized. |

Safe alias list is deliberately bounded to explicit official subject labels/canonicalIDs and THCS6–9. Unknown/composite/generic/additional suffix strings are not auto-assigned; Legacy bucket remains accessible with unknown warning. Any later alias expansion needs actual metadata evidence and separate scoped change; do not use pedagogy/title/filename. No nestedsubject fields invented because existing source inventory has only top-levelsubject/subject_engine.

Recognized subject different from modern explicit engine is BLOCK, no repair. KnownLegacy subject appears in its actual subject group, so selecting genericLegacybucket does not bypass a real subject mismatch. Existing rememberedLegacy values are not migrated on read; a successful explicitload updates true subject. Recent always revalidates cached lesson, never trusts stale summary/engine to commit.

P12.1 capacity unchanged; native package storage still browser-limited. Optionalquick metadata remains small/guarded; no automatic package eviction. Required6–9/GWP sorting and missing metadata remain tested. Common5meaningfulaction scenario is qualified and not a universal/Windows click guarantee.

Historical Geometry findings unchanged: G4-F02OPEN_DEFERRED P3,G4-F03FIXED,G4-F04OPEN_DEFERRED P3,G4-F05VALIDATION_PENDING. Ti09/Ti10 realfilevalidationNOT_RUN_BY_GV_DECISION; not reopened or declaredPASS. Excluded from newhotfix counts without marking them resolved.

P12_F01_REPRODUCED_ON_WINDOWS=YES (GV_REPORTED). P12_1_WINDOWS_RETEST=UNRUN; PHYSICAL_TV_VALIDATION=UNRUN; REAL_CLASSROOM_TRIAL=UNRUN; audibleTTS/back-rowreadingUNRUN. Candidate technicalPASS requires GV Windows retest before any later acceptance decision. No Phase13/Production.

Environment configuration revision12 unchanged; DRAFT_PENDING_SAVE_PUBLISH, no Publish/freshmanaged-task restoration test. Local existing launchers preserved byte-exact; cloud does not assert Windows launch acceptance.
''')
final='''PHASE12_SHA256_BEFORE = {source}
PHASE12_SHA256_AFTER = {source}
PHASE12_CANDIDATE_MUTATED = NO

P12_F01_REPRODUCED = YES (frozen source/runtime; original Windows finding GV-reported)
P12_F01_ROOT_CAUSE = CONFIRMED: Loader compared selected subject to runtime engine; subject Tin học6 with absent engine resolved Legacy and was incorrectly blocked

LESSON_SUBJECT_SEPARATED_FROM_ENGINE = PASS

LEGACY_INFORMATICS_SUBJECT_RESOLUTION = PASS
LEGACY_INFORMATICS_FILTER_VISIBILITY = PASS
LEGACY_INFORMATICS_LOAD = PASS
LEGACY_ENGINE_PRESERVED = PASS
NO_ENGINE_INFERENCE = PASS

TRUE_SUBJECT_MISMATCH_BLOCK = PASS
AMBIGUOUS_METADATA_BLOCK = PASS
CURRENT_LESSON_PRESERVATION = PASS

SUBJECT_FILTER = PASS
GRADE_FILTER = PASS
WEEK_FILTER = PASS
PERIOD_FILTER = PASS

RECENT_LESSONS = PASS (LIMIT5; DEDUPLICATION PASS)
REMEMBER_LAST_SUBJECT = PASS
LOCALSTORAGE_QUOTA_GUARD = PASS
P11_F01_STATUS = P2 OPEN_DEFERRED (CAPACITY LIMIT NOT REMOVED)

GEOMETRY_LOAD = PASS
ALGEBRA_LOAD = PASS
INFORMATICS_LOAD = PASS
LEGACY_LOAD = PASS

LEGACY_RUNTIME_REGRESSION = PASS
GEOMETRY_PROFILE_REGRESSION = PASS
ALGEBRA_PROFILE_REGRESSION = PASS
INFORMATICS_PROFILE_REGRESSION = PASS
NO_TEACH_AHEAD_GLOBAL = PASS

CORE_CHANGE_REQUIRED = NO
WEB_LIVE_CORE_MUTATED = NO
GEOMETRY_PROFILE_MUTATED = NO
ALGEBRA_PROFILE_MUTATED = NO
INFORMATICS_PROFILE_MUTATED = NO

P12_1_WINDOWS_RETEST = UNRUN
PHYSICAL_TV_VALIDATION = UNRUN
REAL_CLASSROOM_TRIAL = UNRUN

P0_COUNT = 0
P1_COUNT = 0
P2_COUNT = 1 (carried P11-F01; P12-F01 technical fix verified, Windows retest pending)
P3_COUNT = 0 (new hotfix findings; inherited accepted Geometry issues unchanged)

SOURCE_SCOPE_VIOLATION = NO
PRODUCTION_MODIFIED = NO

P12_1_CANDIDATE = WEB_LIVE_LESSON_LIBRARY_P12_1_CANDIDATE
P12_1_CANDIDATE_SHA256 = {candidate}

P12_1_STATUS = PASS (CLOUD TECHNICAL GATES ONLY)
RECOMMENDED_NEXT_ACTION = GV Windows retest on P12.1; no Phase13/Production

STOP
Chờ GV kiểm thử lại trên Windows.
'''.format(source=source['sha256Before'],candidate=identity['sha256'])
(p/'FINAL_STATUS.txt').write_text(final)
report('README_P12_1.txt',f'''
WEB_LIVE_LESSON_LIBRARY_P12_1_CANDIDATE.zip
SHA256 {identity['sha256']}
Full runtime1241files, extract all and retain structure. ExistingWindows launch scripts preserved unchanged; cloud has not re-tested them on Windows. Phase12 original candidate is not overwritten. Onlysubject-loader.js changed, no Core/Profile/package-source edits.

GV Windows retest: use full extracted P12.1. Select TIN HỌC, import original TIN6W05 package / provided originalfinding package; preview subjectTin học6 and runtimeLegacy; explicitNẠP BÀI should be enabled. Confirm subject/Grade6/Week5/Period5 libraryvisibility aftersave. Test mismatched Đại sốpackage underTin học must block; contradictory subjectTin học+enginealgebra must block and preservecurrent. Do not rewrite source lesson engine to make testpass. Windows/physicalTV/classroom status staysUNRUN until actual GVresults; STOP/no Production.

Required5reports/FINAL_STATUS/manifest/checksums besideZIP are currentreleaseauthority. Embeddedolder documents/checksums historical unchanged. EvidenceZIP is test-only helpers/fixtures/rawresults/screens, not teachingcontent. P11-F01P2OPEN_DEFERRED, capacity limit remains.

Cloud reproduction no npm build/install: Python3staticserver on selected working/candidate root, Node+Playwright /usr/bin/chromium.
python3 -B -m http.server 8790 --bind 127.0.0.1 --directory /workspace/p12-1-legacy-subject/packaged-smoke/WEB_LIVE_LESSON_LIBRARY_P12_1_CANDIDATE
NODE_PATH=/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules
P121_ROOT=<extractedcandidate> P121_BASE=http://127.0.0.1:8790 P121_OUT=<outsideevidence> node targeted.cjs
Inheritedhelpers use P12_ROOT/P12_BASE with P12_LIBRARY_OUT/P12_QUICK_OUT/P12_SAFEGUARD_OUT. Keep FINDING_EQUIVALENT.json/SYNTHETIC_LARGE_LIBRARY.json/NEGATIVE_FIXTURES beside scripts. ExistingG4F01 externalfixture path inhelpers is preserved; evidenceincludes original testZIP forreproduction. Beforehelper needs frozenPhase12server8788, notpatchedruntime. Never writeevidence into frozen/candidate roots. Inspectoccupiedports; do notstop unrelatedservers.

Environmentdraftrevision12 unchanged; DRAFT_PENDING_SAVE_PUBLISH; no configurationSave/Publish, freshmanaged-task restoration unverified. OnlyisolatedGitHubdeliverybranch, no main/PR/merge.
''')
bundle=out/'WEB_LIVE_LESSON_LIBRARY_P12_1_EVIDENCE.zip';include=['AUTHORIZE_P12_1.txt','BEFORE_REPRODUCTION.json','BEFORE_RUN.log','BEFORE_1.png','BEFORE_2.png','FINDING_EQUIVALENT.json','SYNTHETIC_LARGE_LIBRARY.json','HARNESS_ADAPTATIONS.txt','SOURCE_MANIFEST_BEFORE.json','reproduce-before.cjs','targeted.cjs','library-tests.cjs','quick-access-regression.cjs','safeguards.cjs','packaged-assets.cjs','gate-package.py','reports.py']+[x.name for x in sorted(p.glob('*RUN.log')) if x.name!='BEFORE_RUN.log'];directories=['TARGETED','LIBRARY','QUICK','SAFEGUARDS','REGRESSION','NEGATIVE_FIXTURES','HARNESS_HISTORY','PACKAGED_TARGETED','PACKAGED_LIBRARY','PACKAGED_QUICK','PACKAGED_SAFEGUARDS','PACKAGED_SMOKE']
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in include:assert (p/n).is_file(),n;z.write(p/n,n)
 for directory in directories:
  for f in sorted((p/directory).rglob('*')):
   if f.is_file():z.write(f,str(f.relative_to(p)))
 fixture=Path('/workspace/g4-f01-fixture-revalidation/HINH8_VD2_GEOMETRY_PROFILE_TEST_G4F01_PATCHED.zip');assert sha(fixture.read_bytes())=='4488b1997e416fa634a577900af76fff1dbf17de1eb4bd62eee3a772df7bcab8';z.write(fixture,'EXTERNAL_TEST_INPUTS/'+fixture.name)
with zipfile.ZipFile(bundle) as z:assert z.testzip() is None
sidecars=['AUTHORIZE_P12_1.txt','BEFORE_REPRODUCTION.json','SOURCE_IDENTITY.json','SOURCE_SCOPE.json','CANDIDATE_PAYLOAD_MANIFEST.json','PACKAGE_IDENTITY.json','PATCH_FILES.diff','PREPACKAGE_GATE.json','RELEASE_GATE.json','REGRESSION_COMPARISON.json','ENVIRONMENT_SETTINGS_EVIDENCE.json','FINAL_STATUS.txt','README_P12_1.txt']+sorted(x.name for x in p.glob('P12_1_*.md'))
for n in sidecars:shutil.copy2(p/n,out/n)
(out/'CHECKSUMS_SHA256.txt').write_text(''.join(sha(f.read_bytes())+'  '+f.name+'\n' for f in sorted(out.iterdir()) if f.is_file() and f.name!='CHECKSUMS_SHA256.txt'))
print(json.dumps({'result':'PASS','files':len(list(out.iterdir())),'candidateSHA256':identity['sha256'],'evidenceBytes':bundle.stat().st_size,'checkGroups':236,'HTTPAssets':60},indent=2))
