from pathlib import Path
import json,hashlib,zipfile,difflib
p=Path(__file__).parent;root=p/'working/WEB_LIVE_LESSON_LIBRARY_P12_1_WORKING_COPY';frozen=Path('/workspace/phase12-lesson-library/packaged-smoke/WEB_LIVE_LESSON_LIBRARY_PHASE12_CANDIDATE');out=Path('/workspace/output/web-live-lesson-library-p12-1-candidate')
read=lambda n:json.loads((p/n).read_text());write=lambda n,d:(p/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest();manifest=lambda r:{str(f.relative_to(r)):sha(f.read_bytes()) for f in sorted(r.rglob('*')) if f.is_file()}
before=read('SOURCE_MANIFEST_BEFORE.json');after=manifest(root);assert manifest(frozen)==before;assert set(before)==set(after) and len(after)==1241
changed=[n for n in before if before[n]!=after[n]];assert changed==['WEB_LIVE/subject-loader.js']
source=read('SOURCE_IDENTITY.json');source['sha256After']=sha(Path(source['sourceZip']).read_bytes());assert source['sha256Before']==source['sha256After']=='329dca2256104ef5d9ccca18a2dad2e9c921324260f31249b165683128a2d5e9';write('SOURCE_IDENTITY.json',source)
old=(frozen/'WEB_LIVE/subject-loader.js').read_text();new=(root/'WEB_LIVE/subject-loader.js').read_text()
def function(text,name):
 start=text.index(' function '+name+'(');return text[start:text.index('\n }',start)+3]
unchanged={}
for name in ['engine','recentEntry','readQuick','libraryValue','compareValues','matchField','matches','populateFilter','compareLessons','clear','cloneControllers','runtime','restore','commit']:
 a=function(old,name);b=function(new,name);assert a==b,name;unchanged[name]={'byteExact':True,'sha256':sha(a.encode())}
start=' const imagePairs=';end=' const nativeStart=';a=old[old.index(start):old.index(end)];b=new[new.index(start):new.index(end)];assert a==b;unchanged['assets-stage-runtime-essential-transaction-quota']={'byteExact':True,'sha256':sha(a.encode())}
write('SOURCE_SCOPE.json',{'result':'PASS','fileCount':1241,'changedFiles':changed,'unchangedFiles':1240,'addedFiles':[],'removedFiles':[],'frozenPhase12PayloadUnchanged':True,'cssUnchanged':True,'coreMutated':False,'profilesMutated':False,'productionModified':False,'unchangedLoaderFunctions':unchanged})
(p/'PATCH_FILES.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='Phase12/WEB_LIVE/subject-loader.js',tofile='P12.1/WEB_LIVE/subject-loader.js')))
assert read('BEFORE_REPRODUCTION.json')['result']=='REPRODUCED'
comparisons={};files={'GEOMETRY':'GEOMETRY_RUNTIME/geometry-runtime.json','ALGEBRA':'ALGEBRA_TARGETED.json','INFORMATICS':'INFORMATICS/INFORMATICS_TARGETED.json','LEGACY':'ENGINES/results.json'}
def normalize(x,profile):
 if isinstance(x,dict):return {k:normalize(v,profile) for k,v in x.items() if not(profile=='GEOMETRY' and k=='lessonActivation' or profile=='INFORMATICS' and k=='currentTime')}
 if isinstance(x,list):return [normalize(v,profile) for v in x]
 return x
for profile,n in files.items():
 a=json.loads((Path('/workspace/phase12-lesson-library/REGRESSION')/n).read_text());b=read('REGRESSION/'+n);assert not b.get('errors') and not b.get('external') and not b.get('externalRequests');assert b.get('result','PASS')=='PASS';assert normalize(a,profile)==normalize(b,profile),profile
 comparisons[profile]={'result':'PASS','checks':len(b.get('checks',b.get('assertions',[]))),'reference':'Phase12/REGRESSION/'+n,'p12_1':'REGRESSION/'+n,'comparison':'SEMANTIC_JSON_EQUAL','normalization':{'GEOMETRY':'Only random per-run lessonActivation UUID; within-run identity exact','INFORMATICS':'Only manual video currentTime; playback >0 assertions executed'}.get(profile,'NONE')}
write('REGRESSION_COMPARISON.json',comparisons)
gates={}
for name,n,count in [('targeted','TARGETED/TARGETED_RESULTS.json',28),('library','LIBRARY/LIBRARY_RESULTS.json',21),('quickAccess','QUICK/QUICK_ACCESS_RESULTS.json',16),('safeguards','SAFEGUARDS/TARGETED_RESULTS.json',15)]:
 d=read(n);assert d['result']=='PASS' and len(d['checks'])==count and not d['errors'];gates[name]={'result':'PASS','groups':count}
write('PREPACKAGE_GATE.json',{'result':'PASS','workingGates':gates,'profileRegression':comparisons,'sourceScope':'PASS','beforeRootCause':'CONFIRMED'})
out.mkdir(parents=True,exist_ok=True);name='WEB_LIVE_LESSON_LIBRARY_P12_1_CANDIDATE';dest=out/(name+'.zip');assert not dest.exists()
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n in after:z.write(root/n,name+'/'+n)
with zipfile.ZipFile(dest) as z:
 assert z.testzip() is None;assert {n[len(name)+1:]:sha(z.read(n)) for n in z.namelist() if not n.endswith('/')}==after;z.extractall(p/'packaged-smoke')
assert manifest(p/'packaged-smoke'/name)==after
write('CANDIDATE_PAYLOAD_MANIFEST.json',after);write('PACKAGE_IDENTITY.json',{'candidate':name,'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size,'files':1241,'wrapperRoot':name,'zipCRC':'PASS','freshExtractionManifest':'PASS','phase12SHA256':source['sha256Before'],'historicalDocumentsInsidePayload':'Inherited documents/checksums unchanged; external P12.1 reports/manifest identify this candidate.'})
print(json.dumps(read('PACKAGE_IDENTITY.json'),indent=2))
