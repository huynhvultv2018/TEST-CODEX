"""Real HTTP clients against the unchanged candidate entry point, on its own IP.

The admin fixture credential is read from a command-local environment binding.
No passwords, session cookies, CSRF nonces or client tokens enter evidence files.
Only explicitly created test database rows are edited for corruption/deadline
fixtures. Application files, schema and clocks are never patched.
"""
import ast,base64,copy,hashlib,http.client,json,math,os,re,signal,socket,sqlite3,statistics,subprocess,sys,threading,time,traceback,urllib.parse,zipfile,zlib
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timedelta,timezone
from http.cookies import SimpleCookie
from io import BytesIO
from pathlib import Path
import psutil
from openpyxl import Workbook,load_workbook
from independent_scoring import answers_for,choice,complete,correct_value,submit_form,wrong_value
from v23_float_oracle import score_v23 as score

ROOT=Path('/workspace/ui-v2-4-rc1/lan-runtime')
E=Path(os.environ.get('FINAL_LAN_OUTPUT','/workspace/ui-v2-4-rc1/evidence/lan'))
APP=ROOT/os.environ.get('FINAL_LAN_RUNTIME','clean-release')/'PHAN_MEM'
DATABASE=APP/'thi_trac_nghiem.db'
IP=socket.gethostbyname_ex(socket.gethostname())[2][0]
PORT=5000
REQUESTS=[];LOCK=threading.Lock();IN_FLIGHT=0;PEAK=0

def digest(value):return hashlib.sha256(value if isinstance(value,bytes) else str(value).encode()).hexdigest()
def save(name,value):
    path=E/name;path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def rows(query,params=(),write=False):
    c=sqlite3.connect(DATABASE,timeout=30);c.row_factory=sqlite3.Row
    try:
        result=[dict(r) for r in c.execute(query,params).fetchall()]
        if write:c.commit()
        return result
    finally:c.close()
def db_hash():
    c=sqlite3.connect(DATABASE)
    try:return digest('\n'.join(c.iterdump()))
    finally:c.close()
def session_payload(cookie):
    parts=cookie.split('.');compressed=parts[0]=='';text=parts[1] if compressed else parts[0]
    data=base64.urlsafe_b64decode(text+'='*(-len(text)%4))
    return json.loads(zlib.decompress(data) if compressed else data)
def multipart(fields,files):
    boundary='FINAL_VALIDATION_'+os.urandom(16).hex();output=[]
    for name,value in fields:
        output.extend([f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),str(value).encode(),b'\r\n'])
    for name,filename,data in files:
        output.extend([f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode(),data,b'\r\n'])
    output.append(f'--{boundary}--\r\n'.encode());return b''.join(output),'multipart/form-data; boundary='+boundary

class Client:
    def __init__(self,code,scope='setup'):
        self.code=code;self.scope=scope;self.cookies={};self.nonce=None;self.attempt=None;self.items=None
    def clone(self,code=None):
        other=Client(code or self.code,self.scope);other.cookies=self.cookies.copy();other.nonce=self.nonce;other.attempt=self.attempt;other.items=self.items
        return other
    def identity(self):
        cookie=self.cookies.get('session','');payload=session_payload(cookie)
        return dict(client=self.code,attempt_id=payload.get('attempt_id'),cookie_sha256=digest(cookie),csrf_sha256=digest(payload.get('_csrf_token','')),client_token_sha256=digest(payload.get('client_token','')),expected_student=self.code)
    def request(self,path,method='GET',form=None,payload=None,files=None,expected=(200,),group='OTHER',token=True,headers=None,timeout=30,planned_timeout=False):
        global IN_FLIGHT,PEAK
        h=dict(headers or {});body=None
        if self.cookies:h['Cookie']='; '.join(k+'='+v for k,v in self.cookies.items())
        if method in ('POST','PUT','PATCH','DELETE') and token and 'X-CSRF-Token' not in h:
            assert self.nonce,'Obtain the real HTML nonce before POST'
            h['X-CSRF-Token']=self.nonce
        if isinstance(form,dict):form=list(form.items())
        if files:body,h['Content-Type']=multipart(form or [],files)
        elif payload is not None:body=json.dumps(payload,ensure_ascii=False).encode();h['Content-Type']='application/json'
        elif form is not None:body=urllib.parse.urlencode(form,doseq=True).encode();h['Content-Type']='application/x-www-form-urlencoded'
        start=time.perf_counter();started=time.time();status=None;error=None;data=b'';response_headers={}
        with LOCK:IN_FLIGHT+=1;PEAK=max(PEAK,IN_FLIGHT);active=IN_FLIGHT
        connection=http.client.HTTPConnection(IP,PORT,timeout=timeout)
        try:
            connection.request(method,path,body=body,headers=h);response=connection.getresponse();status=response.status
            for name,value in response.getheaders():
                response_headers[name.lower()]=value
                if name.lower()=='set-cookie':
                    jar=SimpleCookie();jar.load(value)
                    for k,v in jar.items():
                        if v.value:self.cookies[k]=v.value
                        else:self.cookies.pop(k,None)
            data=response.read()
            if 'text/html' in response_headers.get('content-type',''):
                match=re.search(rb'<meta name="csrf-token" content="([^"]+)"',data)
                if match:self.nonce=match.group(1).decode()
        except Exception as exc:error=type(exc).__name__
        finally:
            connection.close();elapsed=time.perf_counter()-start
            with LOCK:
                IN_FLIGHT-=1
                REQUESTS.append(dict(client=self.code,scope=self.scope,group=group,method=method,path=path,status=status,expected_statuses=list(expected),expected_rejection=status is not None and status>=400 and status in expected,error=error,planned_timeout=planned_timeout,success=(error is None and status in expected) or (planned_timeout and error in ('TimeoutError','socket.timeout')),started_epoch=started,latency_ms=elapsed*1000,in_flight_at_start=active))
        if error and planned_timeout:return status,data,response_headers
        assert error is None,(self.code,path,error)
        assert status in expected,(self.code,path,status,data[:160])
        return status,data,response_headers
    def html(self,path,group='LOAD EXAM'):
        return self.request(path,group=group)[1].decode()
    def post(self,path,**kw):return self.request(path,method='POST',expected=kw.pop('expected',(302,)),**kw)

class Server:
    def __init__(self):self.p=None;self.stop_event=threading.Event();self.samples=[];self.measurement_error=None;self.starts=[]
    def start(self):
        env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['LOCALAPPDATA']=str(ROOT/'runtime-local');env.pop('TNLAN_R4_VALID_CLIENT',None);env.pop('PYTHONPATH',None);env.pop('FINAL_TEST_PASSWORD',None)
        logfile=ROOT/f'server-start-{len(self.starts)+1}.log';self.log_handle=logfile.open('wb')
        self.p=subprocess.Popen([sys.executable,'-u','app.py'],cwd=APP,env=env,stdout=self.log_handle,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            if self.p.poll() is not None:raise AssertionError('Candidate entry point failed to start')
            try:
                c=http.client.HTTPConnection(IP,PORT,timeout=1);c.request('GET','/health');r=c.getresponse();body=r.read();c.close()
                if r.status==200:break
            except OSError:time.sleep(.1)
        else:raise AssertionError('Candidate did not become healthy')
        process=psutil.Process(self.p.pid)
        listeners=[dict(ip=c.laddr.ip,port=c.laddr.port) for c in process.net_connections(kind='inet') if c.status=='LISTEN']
        assert dict(ip='0.0.0.0',port=PORT) in listeners
        self.starts.append(dict(pid=self.p.pid,port=PORT,bind=listeners,LAN_URL=f'http://{IP}:{PORT}',health=json.loads(body),cwd=str(APP),entry_point='candidate PHAN_MEM/app.py',readiness='HTTP 200 from non-loopback IP'))
        self.stop_event.clear();self.sampler=threading.Thread(target=self.sample,args=(process,),daemon=True);self.sampler.start()
    def sample(self,process):
        try:
            process.cpu_percent(None)
            while not self.stop_event.wait(.1):
                self.samples.append(dict(epoch=time.time(),cpu_percent=process.cpu_percent(None),rss_bytes=process.memory_info().rss,threads=process.num_threads()))
        except Exception as exc:self.measurement_error=type(exc).__name__
    def stop(self):
        self.stop_event.set()
        if self.p and self.p.poll() is None:
            self.p.terminate()
            try:self.p.wait(timeout=8)
            except subprocess.TimeoutExpired:self.p.kill();self.p.wait(timeout=5)
        self.log_handle.close()
        if hasattr(self,'sampler'):self.sampler.join(timeout=1)

def teacher_login():
    teacher=Client('TEACHER');teacher.html('/teacher/login','TEACHER LOGIN')
    teacher.post('/teacher/login',form={'username':'admin','password':os.environ['FINAL_TEST_PASSWORD']},group='TEACHER LOGIN')
    teacher.html('/teacher','TEACHER LOGIN');return teacher
def native_question(teacher,kind,level,number,subject='FINAL_LAN',text=None):
    spec={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
    items,answer=spec[kind];code=f'{subject}_{kind}_{level}_{number}'
    fields=dict(ma_cau=code,khoi_lop='8',mon=subject,chu_de='Chủ đề, có dấu phẩy',muc_do=level,question_type=kind,noi_dung=text or code,items=items,answers=answer,points=str(2+number),scoring_mode='all' if level in ('NB','VD') else 'partial',weights='1,3' if kind in ('TF','MATCH','FILL') else '')
    teacher.post('/teacher/multi/new',form=fields,group='QUESTION CRUD');return fields,rows('SELECT * FROM cau_hoi WHERE ma_cau=?',(code,))[0]
def create_exam(teacher,name,counts=None,subject='FINAL_LAN',minutes=15):
    f=dict(ten=name,mon=subject,thoi_gian=str(minutes),hien_diem='on')
    f.update(counts or {k+'_'+lv:'2' for k in ('SINGLE','MULTI','TF','MATCH','FILL') for lv in ('NB','TH','VD','VDC')})
    f['chu_de']='Chủ đề, có dấu phẩy'
    teacher.post('/teacher/create-exam',form=f,group='CREATE EXAM')
    return rows('SELECT id FROM ky_thi WHERE ten=? ORDER BY id DESC',(name,))[0]['id']
def import_students(teacher,codes):
    wb=Workbook();ws=wb.active;ws.append(['Mã HS','Họ tên','Lớp'])
    for code in codes:ws.append([code,'Student '+code,'8A'])
    stream=BytesIO();wb.save(stream)
    _,page,_=teacher.post('/teacher/students/import-preview',files=[('file','test-students.xlsx',stream.getvalue())],expected=(200,),group='IMPORT')
    match=re.search(rb'name="token" value="([^"]+)"',page);assert match
    teacher.post('/teacher/students/import-confirm',form={'token':match.group(1).decode(),'mode':'skip'},group='IMPORT')
    assert len(rows('SELECT ma_hs FROM hoc_sinh WHERE ma_hs IN ('+','.join('?'*len(codes))+')',codes))==len(codes)
def login_student(code,eid,scope):
    client=Client(code,scope);client.html('/','LOGIN')
    _,_,h=client.post('/',form={'ma_hs':code,'ky_thi_id':str(eid)},group='LOGIN')
    assert h.get('location')=='/exam'
    page=client.html('/exam','LOAD EXAM');assert 'id="form"' in page and 'Student '+code in page
    attempt=rows('SELECT * FROM bai_thi WHERE ky_thi_id=? AND ma_hs=?',(eid,code));assert len(attempt)==1
    client.attempt=attempt[0]['id'];client.items=json.loads(attempt[0]['de_json'])
    assert client.identity()['attempt_id']==client.attempt
    return client
def burst(clients,fn):
    barrier=threading.Barrier(len(clients));out=[]
    def run(pair):
        i,c=pair;barrier.wait(timeout=20);return fn(c,i)
    with ThreadPoolExecutor(max_workers=len(clients)) as pool:out=list(pool.map(run,enumerate(clients)))
    return out
def saved_answers(client):
    return {r['vi_tri_cau']:choice(r['lua_chon']) for r in rows('SELECT vi_tri_cau,lua_chon FROM cau_tra_loi WHERE bai_thi_id=?',(client.attempt,))}
def save_answer(client,index,value,expected=(200,),group='AUTOSAVE'):
    status,data,_=client.post('/api/save-answer',payload={'index':index,'choice':value},expected=expected,group=group)
    payload=json.loads(data)
    assert payload['ok']==(status==200);return payload
def compare_client(client,expected_values,finalized=False):
    row=rows('SELECT * FROM bai_thi WHERE id=?',(client.attempt,))[0]
    actual=saved_answers(client)
    mismatch=[i for i in set(actual)|set(expected_values) if actual.get(i)!=expected_values.get(i) or (i in actual)!=(i in expected_values)]
    original_snapshot=json.dumps(client.items,ensure_ascii=False)
    assert json.loads(row['de_json'])==client.items
    recalculated=score(client.items,actual)
    stored=row['diem'];score_mismatch=int(finalized and stored!=recalculated)
    record=dict(client=client.code,attempt_id=client.attempt,student_id=row['ma_hs'],submitted_at=row['submitted_at'],stored_score=stored,recalculated_score=recalculated,score_mismatch=score_mismatch,answer_mismatch_positions=mismatch,expected_answers=expected_values,stored_answers=actual,snapshot_sha256=digest(row['de_json']),snapshot=client.items,stored_correct=row['so_cau_dung'],independent_correct=sum(complete(q,actual.get(i)) for i,q in enumerate(client.items)),question_count=len(client.items))
    assert row['ma_hs']==client.code and not mismatch,(client.code,mismatch)
    if finalized:
        assert row['submitted_at'] is not None and stored is not None and math.isfinite(stored) and 0<=stored<=10
        assert not score_mismatch,(client.code,stored,recalculated)
        assert row['so_cau_dung']==record['independent_correct'] and row['tong_so_cau']==len(client.items)
    return record
def workbook_values(data):return {s.title:[list(r) for r in s.iter_rows(values_only=True)] for s in load_workbook(BytesIO(data),data_only=False)}

def security_restore_history(teacher):
    output={}
    route_set=set()
    for filename in ('app.py','multi_routes.py'):
        tree=ast.parse((APP/filename).read_text())
        for node in ast.walk(tree):
            if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
            for deco in node.decorator_list:
                if not isinstance(deco,ast.Call) or not isinstance(deco.func,ast.Attribute) or not isinstance(deco.func.value,ast.Name) or deco.func.value.id!='app' or not deco.args:continue
                if not isinstance(deco.args[0],ast.Constant):continue
                methods=[deco.func.attr.upper()] if deco.func.attr in ('post','put','patch','delete') else next((ast.literal_eval(k.value) for k in deco.keywords if k.arg=='methods'),[])
                for method in methods:
                    if method in ('POST','PUT','PATCH','DELETE'):route_set.add((deco.args[0].value,method))
    assert len(route_set)==35,len(route_set)
    negative=[]
    before=db_hash()
    for route,method in sorted(route_set):
        path=re.sub(r'<(?:int:)?[^>]+>','999999',route);path=path.replace('<path:name>','missing.db')
        for variant,kw in [('missing',{'token':False}),('wrong',{'headers':{'X-CSRF-Token':'wrong'}}),('Unicode_wrong',{'token':False,'form':{'csrf_token':'sai-đ-token'}}),('foreign_Origin_valid_nonce',{'headers':{'Origin':'http://foreign.invalid'}}),('foreign_Referer_valid_nonce',{'headers':{'Referer':'http://foreign.invalid/'}})]:
            teacher.request(path,method=method,expected=(403,),group='CSRF ROUTE INVENTORY',**kw);assert db_hash()==before
            negative.append(dict(route=route,path=path,method=method,variant=variant,status=403,DB_unchanged=True))
    teacher.request('/teacher/logout',expected=(405,),group='CSRF GET LOGOUT');teacher.html('/teacher','TEACHER LOGIN')
    save('csrf-route-inventory.json',dict(route_count=35,negative_requests=175,results=negative,source='AST of exact candidate source; no route exemptions'))
    output['CSRF_route_guard']=dict(routes=35,negative_requests=175,missing_wrong_Unicode_Origin_Referer_rejected=True,GET_logout_405=True)
    # Actual HTML-field token transport and admin actions, including a valid import.
    original=teacher.nonce;before=db_hash()
    for path,kw in [('/teacher/settings',{'token':False}),('/teacher/accounts/add',{'headers':{'X-CSRF-Token':'wrong'}}),('/teacher/restore',{'token':False}),('/teacher/students/import-preview',{'headers':{'Origin':'http://foreign.invalid'}})]:
        teacher.post(path,expected=(403,),group='SECURITY',**kw);assert db_hash()==before
    teacher.post('/teacher/settings',token=False,form={'csrf_token':original,'school_name':'FINAL TEST ONLY','server_port':str(PORT),'support_text':''},group='ADMIN VALID')
    teacher.post('/teacher/accounts/add',form={'username':'FINAL_TEST_TEACHER','ho_ten':'Test teacher','vai_tro':'GIAOVIEN','password':os.environ['FINAL_TEST_PASSWORD']+'!FINAL'},group='ADMIN VALID')
    uid=rows('SELECT id FROM tai_khoan_gv WHERE username=?',('FINAL_TEST_TEACHER',))[0]['id']
    teacher.post(f'/teacher/accounts/{uid}/toggle',group='ADMIN VALID');assert rows('SELECT active FROM tai_khoan_gv WHERE id=?',(uid,))[0]['active']==0
    teacher.post(f'/teacher/accounts/{uid}/toggle',group='ADMIN VALID')
    output['positive_admin_HTML_field_and_import']=True

    # Native backup, then corrupt/legacy/valid uploaded restores; no altered source.
    _,_,created=teacher.post('/teacher/backup',group='BACKUP')
    assert created.get('location')=='/teacher/backups'
    manager=teacher.html('/teacher/backups','BACKUP')
    backup_name=re.search(r'/teacher/backup/download/(backup_[^"<>]+\.db)',manager)
    assert backup_name,'Created backup must appear as a downloadable file'
    _,backup,_=teacher.request('/teacher/backup/download/'+backup_name.group(1),group='BACKUP DOWNLOAD')
    private=ROOT/'test-databases';private.mkdir(exist_ok=True);base=private/'valid.db';base.write_bytes(backup)
    corrupt=b'not a SQLite database';invalid=private/'semantic-invalid.db';invalid.write_bytes(backup)
    c=sqlite3.connect(invalid);qid,payload=c.execute('SELECT id,payload FROM cau_hoi WHERE payload<>\'\' LIMIT 1').fetchone();item=json.loads(payload);item['scoring']['points']=0;c.execute('UPDATE cau_hoi SET payload=? WHERE id=?',(json.dumps(item),qid));c.commit();assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close()
    restore_tests=[]
    for name,data in [('physical-corrupt.db',corrupt),('semantic-invalid.db',invalid.read_bytes())]:
        before=db_hash();source_sha=digest(data)
        teacher.post('/teacher/restore',files=[('file',name,data)],group='RESTORE')
        page=teacher.html('/teacher/backups','RESTORE')
        assert db_hash()==before and ('Không khôi phục' in page or 'Khôi phục thất bại' in page)
        restore_tests.append(dict(case=name,rejected=True,active_database_unchanged=True,source_sha256=source_sha,SQLite_integrity='ok' if name.startswith('semantic') else 'not a database'))
    legacy=private/'legacy.db';legacy.write_bytes(backup);c=sqlite3.connect(legacy)
    for qid,payload in c.execute('SELECT id,payload FROM cau_hoi WHERE payload<>\'\'').fetchall():
        item=json.loads(payload);item.pop('scoring',None);c.execute('UPDATE cau_hoi SET payload=? WHERE id=?',(json.dumps(item),qid))
    c.commit();c.close();legacy_data=legacy.read_bytes()
    teacher.post('/teacher/restore',files=[('file','legacy.db',legacy_data)],group='RESTORE');page=teacher.html('/teacher/backups','RESTORE')
    assert 'Đã khôi phục dữ liệu' in page and digest(legacy.read_bytes())==digest(legacy_data)
    assert all('scoring' not in json.loads(r['payload']) for r in rows('SELECT payload FROM cau_hoi WHERE payload<>\'\''))
    # Exercise legacy build/scoring before returning to the valid backup.
    legacy_eid=create_exam(teacher,'FINAL_LEGACY',{'MULTI_NB':'1'});legacy_client=login_student('FINAL_SMOKE',legacy_eid,'smoke');values={0:correct_value(legacy_client.items[0])}
    legacy_client.post('/exam',form=submit_form(legacy_client.items,values),group='SUBMIT');assert compare_client(legacy_client,values,True)['stored_score']==10
    teacher.post('/teacher/restore',files=[('file','valid.db',backup)],group='RESTORE');page=teacher.html('/teacher/backups','RESTORE');assert 'Đã khôi phục dữ liệu' in page
    assert digest(base.read_bytes())==digest(backup)
    output['backup_restore']=restore_tests+[dict(case='legacy',accepted=True,legacy_score=10,source_unchanged=True),dict(case='valid',accepted=True,source_unchanged=True)]

    f,q=native_question(teacher,'SINGLE','NB',1,'FINAL_HISTORY','BEFORE_NB');eid=create_exam(teacher,'FINAL_HISTORY',{'SINGLE_NB':'1'},'FINAL_HISTORY')
    student=login_student('FINAL_SMOKE',eid,'smoke');v={0:correct_value(student.items[0])}
    save_answer(student,0,v[0]);student.post('/exam',form=submit_form(student.items,v),group='SUBMIT');original_row=rows('SELECT * FROM bai_thi WHERE id=?',(student.attempt,))[0]
    teacher.html('/teacher','HISTORY');before_html=teacher.html(f'/teacher/report/{eid}','REPORT');before_xlsx=teacher.request(f'/teacher/report/{eid}/export',group='EXPORT')[1]
    f.update(noi_dung='AFTER_VD',muc_do='VD',ma_cau='CHANGED_HISTORY',points='9')
    teacher.post('/teacher/multi/edit/'+str(q['id']),form=f,group='QUESTION CRUD');teacher.html('/teacher/multi','HISTORY')
    after_html=teacher.html(f'/teacher/report/{eid}','REPORT');after_xlsx=teacher.request(f'/teacher/report/{eid}/export',group='EXPORT')[1]
    assert 'BEFORE_NB' in before_html and 'BEFORE_NB' in after_html and 'AFTER_VD' not in after_html
    assert workbook_values(before_xlsx)==workbook_values(after_xlsx)
    assert rows('SELECT * FROM bai_thi WHERE id=?',(student.attempt,))[0]==original_row
    for name,data in [('history-before.html',before_html.encode()),('history-after.html',after_html.encode()),('history-before.xlsx',before_xlsx),('history-after.xlsx',after_xlsx)]:
        # Rendered HTML contains the session nonce; redact only this credential.
        if name.endswith('.html'):data=re.sub(rb'(name="csrf-token" content=")[^"]+',rb'\1[REDACTED]',data);data=re.sub(rb'(name="csrf_token" value=")[^"]+',rb'\1[REDACTED]',data)
        (E/name).write_bytes(data)
    legacy_items=copy.deepcopy(student.items)
    for item in legacy_items:item.pop('history')
    legacy_json=json.dumps(legacy_items,ensure_ascii=False);rows('UPDATE bai_thi SET de_json=? WHERE id=?',(legacy_json,student.attempt),True)
    legacy_page=teacher.html(f'/teacher/report/{eid}','REPORT');legacy_export=teacher.request(f'/teacher/report/{eid}/export',group='EXPORT')[1]
    assert 'Không rõ (legacy)' in legacy_page and 'BEFORE_NB' in legacy_page
    assert rows('SELECT de_json,diem FROM bai_thi WHERE id=?',(student.attempt,))[0]=={'de_json':legacy_json,'diem':10.0}
    (E/'history-legacy.xlsx').write_bytes(legacy_export);rows('UPDATE bai_thi SET de_json=? WHERE id=?',(original_row['de_json'],student.attempt),True)
    output['historical_report']=dict(contract='snapshot at exam time',UI_before_after=True,Excel_values_before_after_equal=True,stored_attempt_unchanged=True,score=10,legacy_marked_unknown=True,no_legacy_backfill=True)

    # Direct runtime corruption fixture, always restoring the original bytes/state.
    invalid_cases=[('missing_answer',lambda x:x.pop('answer')),('zero_points',lambda x:x['scoring'].update(points=0)),('NaN_points',lambda x:x['scoring'].update(points=float('nan'))),('invalid_history',lambda x:x.update(history=[])),('id_overflow',lambda x:x.update(id=2**64)),('wrong_shape',None)]
    runtime=[]
    for name,change in invalid_cases:
        data=copy.deepcopy(student.items)
        if change:change(data[0]);text=json.dumps(data)
        else:text='{"wrong":"not a snapshot list"}'
        rows('UPDATE bai_thi SET de_json=?,submitted_at=NULL,diem=NULL WHERE id=?',(text,student.attempt),True);before=db_hash()
        student.request('/exam',expected=(400,),group='F010 CORRUPTION')
        student.post('/api/save-answer',payload={'index':0,'choice':0},expected=(400,),group='F010 CORRUPTION')
        student.post('/exam',form=[('q_0','0')],expected=(400,),group='F010 CORRUPTION')
        assert db_hash()==before
        rows('UPDATE bai_thi SET submitted_at=?,diem=? WHERE id=?',(original_row['submitted_at'],10,student.attempt),True)
        teacher.request(f'/teacher/report/{eid}',expected=(400,),group='F010 CORRUPTION')
        teacher.request(f'/teacher/report/{eid}/export',expected=(400,),group='F010 CORRUPTION')
        runtime.append(dict(case=name,GET_autosave_submit_report_export=[400]*5,no_writes=True))
        rows('UPDATE bai_thi SET de_json=?,submitted_at=?,diem=? WHERE id=?',(original_row['de_json'],original_row['submitted_at'],10,student.attempt),True)
    output['F010_runtime']=runtime

    # Use an exam whose bank still meets its quota for unlock/retake validation.
    unlock_eid=create_exam(teacher,'FINAL_UNLOCK',{'SINGLE_NB':'1'})
    active=login_student('FINAL_SMOKE',unlock_eid,'smoke');save_answer(active,0,correct_value(active.items[0]))
    stored=saved_answers(active);teacher.post('/teacher/unlock/'+str(active.attempt),group='UNLOCK')
    resumed=login_student('FINAL_SMOKE',unlock_eid,'smoke');assert resumed.attempt==active.attempt and saved_answers(resumed)==stored
    active.post('/api/save-answer',payload={'index':0,'choice':0},expected=(409,),group='SESSION NEGATIVE')
    resumed.post('/exam',form=submit_form(resumed.items,{0:correct_value(resumed.items[0])}),group='SUBMIT')
    stale=resumed.clone();teacher.post('/teacher/unlock/'+str(resumed.attempt),group='UNLOCK')
    replacement=login_student('FINAL_SMOKE',unlock_eid,'smoke');assert replacement.attempt==resumed.attempt
    assert saved_answers(replacement)=={}
    stale.post('/api/save-answer',payload={'index':0,'choice':0},expected=(409,),group='SESSION NEGATIVE')
    replacement.post('/exam',form=submit_form(replacement.items,{0:correct_value(replacement.items[0])}),group='SUBMIT')
    replacement.html('/result','RESULT');output['unlock_relogin_retake']=True
    save('smoke-security-database-history.json',output);return output

def integrity(scope,clients):
    c=sqlite3.connect(DATABASE)
    try:
        check=c.execute('PRAGMA integrity_check').fetchall();fk=c.execute('PRAGMA foreign_key_check').fetchall()
        orphan_answers=c.execute('SELECT COUNT(*) FROM cau_tra_loi a LEFT JOIN bai_thi b ON b.id=a.bai_thi_id WHERE b.id IS NULL').fetchone()[0]
        orphan_questions=c.execute('SELECT COUNT(*) FROM cau_tra_loi a LEFT JOIN cau_hoi q ON q.id=a.cau_hoi_id WHERE q.id IS NULL').fetchone()[0]
        duplicates=c.execute('SELECT ky_thi_id,ma_hs,COUNT(*) FROM bai_thi GROUP BY ky_thi_id,ma_hs HAVING COUNT(*)>1').fetchall()
        duplicate_answers=c.execute('SELECT bai_thi_id,vi_tri_cau,COUNT(*) FROM cau_tra_loi GROUP BY bai_thi_id,vi_tri_cau HAVING COUNT(*)>1').fetchall()
        invalid_final=c.execute('SELECT COUNT(*) FROM bai_thi WHERE submitted_at IS NOT NULL AND (diem IS NULL OR so_cau_dung IS NULL OR tong_so_cau IS NULL)').fetchone()[0]
    finally:c.close()
    result=dict(scope=scope,integrity_check=check,foreign_key_check=fk,foreign_keys_applicable_note='Schema has no declared foreign keys; explicit orphan/duplicate checks supplement PRAGMA.',orphan_answers=orphan_answers,orphan_question_references=orphan_questions,duplicate_attempts=duplicates,duplicate_answers=duplicate_answers,invalid_finalized_rows=invalid_final,clients_checked=len(clients))
    assert check==[('ok',)] and not fk and orphan_answers==0 and orphan_questions==0 and not duplicates and not duplicate_answers and invalid_final==0
    save(scope+'-database-integrity.json',result);return result

def monitor(teacher,eid,stop):
    while not stop.is_set():
        teacher.request(f'/teacher/api/monitor/{eid}',group='TEACHER MONITOR')
        teacher.request(f'/teacher/report/{eid}',group='TEACHER MONITOR')
        stop.wait(.25)

def primary50(teacher,codes):
    eid=create_exam(teacher,'FINAL_50_PRIMARY');clients=burst([Client(code,'50-main') for code in codes],lambda c,i:login_student(c.code,eid,'50-main'))
    assert len({c.attempt for c in clients})==50 and all(len(c.items)==40 and {q['type'] for q in c.items}=={'SINGLE','MULTI','TF','MATCH','FILL'} for c in clients)
    identities=[c.identity() for c in clients]
    for key in ('cookie_sha256','csrf_sha256','client_token_sha256'):assert len({x[key] for x in identities})==50
    save('50-identities-initial.json',identities)
    expected=[answers_for(c.items,i,0) for i,c in enumerate(clients)]
    def autosaves(c,i):
        for index in range(40):save_answer(c,index,expected[i][index]);time.sleep(((i*17+index*7)%9)/1000)
    stop=threading.Event();observer=threading.Thread(target=monitor,args=(teacher.clone('TEACHER_MONITOR'),eid,stop),daemon=True);observer.start()
    try:
        burst(clients,autosaves)
        burst(clients,lambda c,i:save_answer(c,0,answers_for(c.items,i,1)[0]))
        for i,c in enumerate(clients):expected[i][0]=answers_for(c.items,i,1)[0]
        comparison=[compare_client(c,expected[i]) for i,c in enumerate(clients)];save('50-answers-after-autosave.json',comparison)

        # Cross-client nonce and forged signed-cookie token substitution.
        before=db_hash();clients[1].post('/api/save-answer',payload={'index':0,'choice':0},headers={'X-CSRF-Token':clients[0].nonce},expected=(403,),group='SESSION NEGATIVE');assert db_hash()==before
        forged=clients[1].clone('FORGED_CLIENT_TOKEN');cookie=forged.cookies['session'];parts=cookie.split('.');payload=session_payload(cookie);payload['client_token']=session_payload(clients[0].cookies['session'])['client_token']
        raw=json.dumps(payload,separators=(',',':')).encode();compressed=parts[0]==''
        encoded=base64.urlsafe_b64encode(zlib.compress(raw) if compressed else raw).decode().rstrip('=')
        parts[1 if compressed else 0]=encoded;forged.cookies['session']='.'.join(parts)
        forged.post('/api/save-answer',payload={'index':0,'choice':0},expected=(403,),group='SESSION NEGATIVE');assert db_hash()==before
        save('50-token-negative-probes.json',dict(cross_client_csrf=403,forged_cross_client_token_signed_cookie=403,DB_unchanged=True,client_token_transport='Bound inside authenticated signed session, not a request parameter.'))

        # Genuine short disconnect: no traffic from ten clients for >20 seconds.
        disconnected=list(range(10));old=[c.clone() for c in clients[:10]]
        last_seen=[rows('SELECT last_seen_at FROM bai_thi WHERE id=?',(c.attempt,))[0]['last_seen_at'] for c in old]
        end=time.monotonic()+22
        def staying_online(pair):
            i,c=pair;j=0
            while time.monotonic()<end:
                index=(j+i)%40;value=answers_for(c.items,i,2)[index];save_answer(c,index,value);expected[i][index]=value;j+=1;time.sleep(.22+((i+j)%5)*.01)
        with ThreadPoolExecutor(max_workers=40) as pool:list(pool.map(staying_online,list(enumerate(clients))[10:]))
        reconnect=[]
        for i in disconnected:
            before_values=saved_answers(old[i]);fresh=login_student(old[i].code,eid,'50-main')
            assert fresh.attempt==old[i].attempt and fresh.items==old[i].items and saved_answers(fresh)==before_values
            old[i].post('/api/save-answer',payload={'index':0,'choice':0},expected=(409,),group='SESSION NEGATIVE')
            assert saved_answers(fresh)==before_values
            reconnect.append(dict(client=fresh.code,same_attempt=True,snapshot_preserved=True,answers_preserved=True,old_token_rejected=409,old_identity=old[i].identity(),new_identity=fresh.identity(),last_seen_before_disconnect=last_seen[i]))
            clients[i]=fresh
        save('50-disconnect-reconnect.json',dict(offline_seconds_at_least=22,clients=10,results=reconnect))
        # Canonical final workload, all clients differ and all question types used.
        expected=[answers_for(c.items,i,3) for i,c in enumerate(clients)]
        burst(clients,lambda c,i:[save_answer(c,j,expected[i][j]) for j in range(40)])
        save('50-answers-before-submit.json',[compare_client(c,expected[i]) for i,c in enumerate(clients)])
        assert all(rows('SELECT submitted_at FROM bai_thi WHERE id=?',(c.attempt,))[0]['submitted_at'] is None for c in clients)
        start=len(REQUESTS)
        burst(clients,lambda c,i:c.post('/exam',form=submit_form(c.items,expected[i]),group='SUBMIT'))
        submit_events=[x for x in REQUESTS[start:] if x['scope']=='50-main' and x['group']=='SUBMIT']
        assert len(submit_events)==50
        save('50-submit-burst.json',dict(client_count=50,dispatch_span_ms=(max(x['started_epoch'] for x in submit_events)-min(x['started_epoch'] for x in submit_events))*1000,peak_in_flight=max(x['in_flight_at_start'] for x in submit_events),responses=Counter(str(x['status']) for x in submit_events)))
        final=[compare_client(c,expected[i],True) for i,c in enumerate(clients)];save('50-final-answer-score-comparison.json',final)
        # Wrong duplicate submit, duplicated autosave after finalization cannot overwrite.
        finalized=[rows('SELECT * FROM bai_thi WHERE id=?',(c.attempt,))[0] for c in clients]
        def duplicate(c,i):
            c.post('/exam',form=submit_form(c.items,{j:wrong_value(q,'late_wrong') for j,q in enumerate(c.items)}),group='DUPLICATE SUBMIT')
            save_answer(c,0,wrong_value(c.items[0]),expected=(409,),group='DUPLICATE AUTOSAVE')
            page=c.html('/result','RESULT');assert 'Student '+c.code in page and str(final[i]['stored_score']) in page
        burst(clients,duplicate)
        assert all(rows('SELECT * FROM bai_thi WHERE id=?',(c.attempt,))[0]==finalized[i] for i,c in enumerate(clients))
        save('50-final-identities.json',[c.identity() for c in clients]);integrity('50-main',clients)
        return clients,dict(status='PASS',clients=50,exam_id=eid,questions=40,unique_attempts=50,score_mismatch_count=0,cross_student_contamination=0,lost_submissions=0,duplicate_finalizations=0,reconnect_clients=10,token_isolation='PASS')
    finally:stop.set();observer.join(timeout=15)

def mixed50(teacher,codes):
    eid=create_exam(teacher,'FINAL_50_MIXED');clients=burst([Client(code,'50-mixed') for code in codes],lambda c,i:login_student(c.code,eid,'50-mixed'));expected=[{} for _ in clients]
    def run(c,i):
        if i<10:c.html('/exam','LOAD EXAM')
        elif i<30:
            value=correct_value(c.items[0]);save_answer(c,0,value);expected[i][0]=value
        elif i<40:c.html('/exam','RELOAD')
        else:
            expected[i]={j:correct_value(q) for j,q in enumerate(c.items)};c.post('/exam',form=submit_form(c.items,expected[i]),group='SUBMIT')
    burst(clients,run)
    comparisons=[compare_client(c,expected[i],i>=40) for i,c in enumerate(clients)]
    save('50-mixed-comparison.json',comparisons);integrity('50-mixed',clients)
    return dict(status='PASS',exam_id=eid,concurrent_workload={'load':10,'autosave':20,'reload':10,'submit':10},contamination=0)

def deadline50(teacher,codes):
    eid=create_exam(teacher,'FINAL_50_DEADLINE');clients=burst([Client(code,'50-deadline') for code in codes],lambda c,i:login_student(c.code,eid,'50-deadline'))
    # Shortened deadlines exist only as fixture rows; real server/client clock remains unchanged.
    burst(clients,lambda c,i:save_answer(c,0,wrong_value(c.items[0],c.code)))
    target=int(time.time())+4;deadline=datetime.fromtimestamp(target).strftime('%Y-%m-%d %H:%M:%S')
    for c in clients:rows('UPDATE bai_thi SET deadline_at=? WHERE id=?',(deadline,c.attempt),True)
    def at_deadline(c,i):
        planned=target-2 if i<15 else target-.15 if i<30 else target+.25
        delay=planned-time.time()
        if delay>0:time.sleep(delay)
        sent=time.time();status,data,_=c.post('/api/save-answer',payload={'index':0,'choice':correct_value(c.items[0])},expected=(200,409),group='DEADLINE AUTOSAVE')
        c.post('/exam',form=submit_form(c.items,{j:correct_value(q) for j,q in enumerate(c.items)}),group='DEADLINE SUBMIT')
        bt=rows('SELECT * FROM bai_thi WHERE id=?',(c.attempt,))[0];actual=saved_answers(c)
        if i>=30:
            assert status==409 and actual.get(0)==wrong_value(c.items[0],c.code)
            assert all(actual.get(j) is None for j in range(1,40)) and bt['diem']==0
        elif i<15:assert status==200 and bt['diem']==10
        # Boundary requests may wait across the deadline; saved state must match score.
        assert bt['diem']==score(c.items,actual) and bt['submitted_at'] is not None
        return dict(client=c.code,group='before' if i<15 else 'near' if i<30 else 'after',request_started_epoch=sent,deadline_epoch=target,autosave_status=status,autosave_reason=json.loads(data).get('reason'),stored_score=bt['diem'],independent_score=score(c.items,actual),late_post_did_not_replace_saved_answers=True if i>=30 else None,stored_answers=actual,snapshot=c.items)
    result=burst(clients,at_deadline);save('50-deadline.json',dict(status='PASS',fixture_deadline=deadline,clock_monkeypatch=False,results=result));integrity('50-deadline',clients)
    return dict(status='PASS',before=15,near=15,after=20,late_post_overwrites=0)

def headroom60(teacher,codes):
    eid=create_exam(teacher,'FINAL_60_HEADROOM');clients=burst([Client(code,'60-headroom') for code in codes],lambda c,i:login_student(c.code,eid,'60-headroom'));expected=[answers_for(c.items,i,4) for i,c in enumerate(clients)]
    burst(clients,lambda c,i:[save_answer(c,j,expected[i][j]) for j in range(40)])
    burst(clients,lambda c,i:save_answer(c,0,expected[i][0]))
    burst(clients,lambda c,i:c.post('/exam',form=submit_form(c.items,expected[i]),group='SUBMIT'))
    final=[compare_client(c,expected[i],True) for i,c in enumerate(clients)];save('60-final-answer-score-comparison.json',final)
    burst(clients,lambda c,i:c.html('/result','RESULT'));integrity('60-headroom',clients)
    return dict(status='PASS',clients=60,exam_id=eid,score_mismatch_count=0,cross_student_contamination=0)

def retry_race(teacher,codes):
    eid=create_exam(teacher,'FINAL_RETRY_RACE');client=login_student(codes[0],eid,'50-retry');correct={i:correct_value(q) for i,q in enumerate(client.items)}
    racers=[client.clone('RACE_'+str(i)) for i in range(8)];wrong={i:wrong_value(q,'race') for i,q in enumerate(client.items)}
    burst(racers,lambda c,i:c.post('/exam',form=submit_form(c.items,correct if i%2==0 else wrong),group='RACE SUBMIT'))
    actual=saved_answers(client);assert actual in (correct,wrong)
    bt=rows('SELECT * FROM bai_thi WHERE id=?',(client.attempt,))[0];assert bt['diem']==score(client.items,actual)
    save('HTTP-race.json',dict(status='PASS',parallel_requests=8,stored_score=bt['diem'],independent_score=score(client.items,actual),one_consistent_winner=True,stored_answers=actual,snapshot=client.items))
    retry=login_student(codes[1],eid,'50-retry');correct={i:correct_value(q) for i,q in enumerate(retry.items)}
    status,_,_=retry.post('/exam',form=submit_form(retry.items,correct),timeout=.0005,planned_timeout=True,group='PLANNED TIMEOUT SUBMIT')
    retry.post('/exam',form=submit_form(retry.items,correct),group='RETRY SUBMIT');record=compare_client(retry,correct,True)
    save('HTTP-timeout-retry.json',dict(status='PASS',first_response_status=status,client_read_timeout_s=.0005,final_submission_single_consistent=True,comparison=record))
    return dict(status='PASS',race_parallel_requests=8,retry_after_short_timeout=True)

def metrics(scope):
    events=[e for e in REQUESTS if e['scope'].startswith(scope)];groups={}
    for group in sorted({e['group'] for e in events}):
        selected=[e for e in events if e['group']==group];lat=sorted(e['latency_ms'] for e in selected)
        groups[group]=dict(count=len(selected),success=sum(e['success'] for e in selected),failed=sum(not e['success'] for e in selected),status_distribution=Counter(str(e['status']) for e in selected),latency_ms=dict(min=min(lat),median=statistics.median(lat),p95=lat[math.ceil(.95*len(lat))-1],max=max(lat)))
    return dict(scope=scope,request_count=len(events),success_count=sum(e['success'] for e in events),failed_count=sum(not e['success'] for e in events),HTTP_4xx=sum(e['status'] is not None and 400<=e['status']<500 for e in events),expected_rejections=sum(e['expected_rejection'] for e in events),HTTP_500_count=sum(e['status']==500 for e in events),HTTP_5xx=sum(e['status'] is not None and e['status']>=500 for e in events),timeouts=sum(e['error'] in ('TimeoutError','socket.timeout') for e in events),planned_timeouts=sum(bool(e['planned_timeout'] and e['error']) for e in events),groups=groups)

def main():
    global PORT
    E.mkdir(parents=True,exist_ok=True);server=Server();results=[]
    def check(name,fn):
        try:value=fn();results.append(dict(name=name,status='PASS',detail=value[1] if isinstance(value,tuple) else value));print(name,'PASS',flush=True);return value
        except Exception:results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()));print(name,'FAIL',flush=True);return None
    try:
        server.start();teacher=teacher_login()
        for kind in ('SINGLE','MULTI','TF','MATCH','FILL'):
            for level in ('NB','TH','VD','VDC'):
                for number in (0,1):native_question(teacher,kind,level,number)
        codes=[f'FINAL_50_{i:02d}' for i in range(1,51)];extra=[f'FINAL_60_{i:02d}' for i in range(51,61)]
        import_students(teacher,codes+extra+['FINAL_SMOKE'])
        teacher.html('/teacher/questions','QUESTION BANK');teacher.html('/teacher/multi','QUESTION BANK');teacher.request('/teacher/api/question-availability?mon=FINAL_LAN',group='EXAM MATRIX')
        check('native_smoke_F010_F011_F012_backup_restore_unlock',lambda:security_restore_history(teacher))
        result=check('50_client_primary',lambda:primary50(teacher,codes))
        check('50_client_mixed',lambda:mixed50(teacher,codes))
        check('50_client_deadline_under_load',lambda:deadline50(teacher,codes))
        check('HTTP_retry_and_atomic_race',lambda:retry_race(teacher,codes))
        if result is not None:check('60_client_optional_headroom',lambda:headroom60(teacher,codes+extra))
    except Exception:results.append(dict(name='setup_or_execution',status='FAIL',traceback=traceback.format_exc()));print('SETUP_OR_EXECUTION FAIL',flush=True)
    finally:
        server.stop()
        # Evidence logs redact credential-bearing banner only; preserve all errors.
        for logfile in ROOT.glob('server-start-*.log'):
            lines=logfile.read_text(errors='replace').splitlines();safe=['[DEFAULT ACCOUNT BANNER REDACTED]' if 'Tai khoan khoi tao:' in line else line for line in lines]
            (E/logfile.name).write_text('\n'.join(safe)+'\n')
        (E/'route-error.log').write_bytes((APP/'logs/app.log').read_bytes())
        save('requests.json',REQUESTS);save('metrics-50.json',metrics('50'));save('metrics-60.json',metrics('60'));save('results.json',dict(results=results,peak_client_requests_in_flight=PEAK,server_starts=server.starts))
        save('server-resource-samples.json',dict(measurement_error=server.measurement_error,samples=server.samples,CPU='MEASURED' if server.samples else 'NOT MEASURED',MEMORY='MEASURED' if server.samples else 'NOT MEASURED'))
    return int(any(r['status']=='FAIL' for r in results))

if __name__=='__main__':raise SystemExit(main())
