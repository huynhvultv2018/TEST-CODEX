"""Package the frozen UI RC1 source and honest validation evidence; never import app."""
import hashlib,json,shutil,zipfile
from pathlib import Path
R=Path('/workspace/ui-v2-4-rc1'); B=R/'baseline';C=R/'candidate';E=R/'evidence';O=R/'artifacts';O.mkdir(exist_ok=True)
BASE='68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2'
INPUT=Path('/workspace/attachments/2f51db05-fe0d-4268-aa62-20cb74239406/ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(INPUT)==BASE
def read(p):return json.loads(p.read_text())
ui=read(E/'ui/results.json');assert len(ui['results'])==28 and all(r['status']=='PASS' for r in ui['results'])
native=read(E/'native-final/results.json');r4=read(E/'r4-final/results.json');lan=read(E/'lan/results.json')
assert all(r['status']=='PASS' for r in r4['results']) and all(r['status']=='PASS' for r in lan['results'])
assert sum(r['status']=='PASS' for r in native if r['mode'].endswith('compatibility'))==6
assert sum(r['status']=='FAIL' for r in native if r['mode']=='UI_RC1_original')==4
changed=[];unchanged=[];added=[];hashes={}
for p in sorted(C.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(C).as_posix();hashes[rel]=sha(p);old=B/rel
 if old.exists():
  record=dict(file=rel,before=sha(old),after=sha(p),bytes=p.stat().st_size)
  (unchanged if record['before']==record['after'] else changed).append(record)
 else:added.append(dict(file=rel,after=sha(p),bytes=p.stat().st_size))
assert len(changed)==9 and len(unchanged)==50 and len(added)==5
assert all(x['file'].startswith('PHAN_MEM/templates/') for x in changed)
assert all(x['file'].startswith('PHAN_MEM/static/') for x in added)
for rel in hashes:
 assert not any(part in ('__pycache__','.pytest_cache','node_modules','logs','backups') for part in Path(rel).parts)
 assert Path(rel).suffix.lower() not in ('.db','.pyc','.zip','.exe','.tmp')
K='ThiTracNghiemLAN_v2.4_UI_RC1_CANDIDATE.zip'; H='ThiTracNghiemLAN_v2.4_UI_RC1_HANDOFF.zip'
with zipfile.ZipFile(O/K,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in sorted(hashes):z.write(C/rel,rel)
with zipfile.ZipFile(O/K) as z:
 assert z.testzip() is None and len(z.namelist())==64
 assert all(hashlib.sha256(z.read(rel)).hexdigest()==s for rel,s in hashes.items())
CAND=sha(O/K)
manifest=['UI V2.4 RC1 FILE MANIFEST','BASELINE_ZIP_SHA256 = '+BASE,'CANDIDATE_ZIP_SHA256 = '+CAND,'SOURCE FILES = 64','CHANGED = 9; UNCHANGED = 50; ADDED = 5','No deleted baseline files; no backend/core/build/test edits.','', 'CHANGED (before -> after)']
for x in changed:manifest += [x['file'],x['before']+' -> '+x['after']]
manifest+=['','ADDED']
for x in added:manifest+=[x['after']+'  '+x['file']]
manifest+=['','UNCHANGED']
for x in unchanged:manifest+=[x['after']+'  '+x['file']]
(O/'UI_V2_4_FILE_MANIFEST.txt').write_text('\n'.join(manifest)+'\n')
(E/'source-integrity.json').write_text(json.dumps(dict(baseline_zip_sha256=BASE,candidate_zip_sha256=CAND,changed=changed,unchanged=unchanged,added=added,deleted=[],backend_core_unchanged=True),ensure_ascii=False,indent=2)+'\n')
ui_map={
 'UI01':'UI01_UI02_SIDEBAR_ACTIVE','UI02':'UI01_UI02_SIDEBAR_ACTIVE','UI03':'UI03_TEACHER_1366','UI04':'UI04_TEACHER_1920','UI05':'UI05_STUDENT_1366','UI06':'UI06_STUDENT_1920',
 'UI07':'UI07_UI09_UI10_UI11_UI12_NAVIGATOR','UI08':'UI08_UI19_ANSWERED_AND_AUTOSAVE','UI09':'UI07_UI09_UI10_UI11_UI12_NAVIGATOR','UI10':'UI07_UI09_UI10_UI11_UI12_NAVIGATOR','UI11':'UI07_UI09_UI10_UI11_UI12_NAVIGATOR','UI12':'UI07_UI09_UI10_UI11_UI12_NAVIGATOR',
 'UI13':'UI13_SINGLE','UI14':'UI14_MULTI','UI15':'UI15_TF','UI16':'UI16_MATCH','UI17':'UI17_FILL','UI18':'UI18_MATHJAX','UI19':'UI08_UI19_ANSWERED_AND_AUTOSAVE','UI20':'UI20_UI21_SUBMIT_MODAL_WARNING','UI21':'UI20_UI21_SUBMIT_MODAL_WARNING','UI22':'UI22_SUCCESSFUL_SUBMIT','UI23':'UI23_MONITOR_50_ROWS','UI24':'UI24_REPORT_TABS','UI25':'UI07_UI25_10_TO_60_QUESTIONS','UI26':'UI26_KEYBOARD_FOCUS','UI27':'UI27_CSRF_NEW_UI','UI28':'UI28_REFRESH_RESUME'}
by_id={r['id']:r for r in ui['results']};mapped=[dict(id=k,status=by_id[v]['status'],browser_check=v,detail=by_id[v].get('detail')) for k,v in ui_map.items()]
(E/'UI01_UI28_TRACEABILITY.json').write_text(json.dumps(mapped,ensure_ascii=False,indent=2)+'\n')
diff='\n'.join('- `'+x['file']+'`' for x in changed+added)
implementation=f'''# UI V2.4 RC1 — Implementation report

UI_IMPLEMENTATION = PASS (internal Chromium validation)
UI_RC1_CANDIDATE = BLOCKED
PRODUCTION = NO

## Baseline và phạm vi

Input duy nhất: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
SHA-256: `{BASE}` — MATCH với expected value của GV.
Candidate mới: `{K}`; SHA-256: `{CAND}`.
Không ghi đè R4. 59 file baseline được giữ đầy đủ; 9 template đổi presentation,
5 file CSS/JS mới; 50 file baseline giữ nguyên byte. Toàn bộ 30 file ngoài
templates/static giữ nguyên, gồm Python backend, scoring, question types,
snapshot, license, công cụ cấp mã, build_exe.bat, requirements và 6 native tests.
Không migration/schema change; không tạo database/license state trong candidate.

## Giao diện đã triển khai

- Shell sidebar cố định 212 px, 8 mục, active state, keyboard focus; Segoe UI/system-ui/Arial.
- Tổng quan: health thật, IP/cổng từ trang system-status R4, chọn kỳ thi và số đếm theo lớp từ monitor API. Form thêm câu hỏi, nhập học sinh, sao lưu, license nằm ở module riêng.
- Giám sát: 6 chỉ số từ API, 8 cột, tìm mã/tên, 5 bộ lọc, sticky header, 50 dòng trong vùng cuộn. Dòng DOM được tái sử dụng; polling 3 giây, không chồng request, bỏ qua lúc tab ẩn. Lỗi đọc API giữ dữ liệu cuối và báo chưa cập nhật.
- Bài thi: giữ toàn bộ input/question DOM, tên field và các hàm `choice`, `save`, `tick`, `ping` nguyên byte. JS chỉ đổi câu visible, đánh dấu xem lại trong sessionStorage theo attempt, cập nhật navigator/ARIA và quan sát trạng thái lưu thực tế. Không tự lưu hoặc sửa giá trị đáp án khi chuyển câu.
- SINGLE radio; MULTI checkbox + hướng dẫn; TF/MATCH hai cột; FILL input rộng. MathJax offline và các helper R4 nguyên byte, kiểm tra đủ 5 loại.
- Modal nộp hiển thị số câu đã trả lời/chưa trả lời và danh sách số câu còn thiếu. Xác nhận gọi native form POST kèm CSRF hiện hành. Timer tự nộp và deadline server không đổi. Thông báo thành công chỉ nằm trên result do server xác nhận.
- Tạo kỳ thi: wizard 4 bước trên `/teacher?view=exams`; giữ availability API, repeated topic fields, ma trận 20 ô và validation R4. Route mixed-exam cũ cũng có 4 bước presentation, server vẫn kiểm tra đủ câu.
- Báo cáo từng kỳ thi: 5 tab, giữ nguyên dữ liệu/công thức/thang điểm/ngưỡng có sẵn; export R4 giữ nguyên. Báo cáo tổng hợp vẫn dùng analytics hiện có và liên kết tới report từng kỳ thi.
- Hệ thống giữ các liên kết đổi mật khẩu, backup, thiết lập/tài khoản/nhật ký theo quyền R4.

## UI_DATA_GAP — không tự tạo dữ liệu

| ID | Dữ liệu thiếu / giới hạn R4 | Presentation an toàn |
|---|---|---|
| G01 | API không đếm session hiện đang đăng nhập | Dùng nhãn “Đã vào thi” = số có attempt; nêu rõ không phải số phiên đăng nhập |
| G02 | Monitor API không trả started_at/submitted_at | Hai cột thời gian ghi “Chưa có dữ liệu”; không suy từ last_seen |
| G03 | Không có trạng thái lỗi máy con ngoài trạng thái monitor hiện có | Hiển thị đúng R4; mất kết nối có text/⚠, lỗi API có banner; không giả lập lỗi từng máy |
| G04 | MO là mở nhận bài, không phải lịch start/end thực tế | Dashboard ghi “Kỳ thi đang mở”, không tuyên bố kỳ thi đang diễn ra theo lịch |
| G05 | R4 không có route clone exam | NOT_SUPPORTED_IN_R4; không thêm chức năng. Clone question hiện có đã được kiểm |
| G06 | Không có phân loại Giỏi/Khá/TB/Yếu mới | Giữ ngưỡng >=5/>=8 và bands của R4, không phát minh rule |

BACKEND_CHANGE_REQUEST = NONE_IMPLEMENTED. Các gap được để an toàn theo chỉ thị;
không sửa backend để bổ sung dữ liệu. Không đổi license, machine identity hoặc quyền truy cập.

## Evidence và giới hạn

Chromium thật `/usr/bin/chromium`, Playwright, Linux, runtime sao chép vào thư mục
tạm. 28 nhóm kiểm tra cuối PASS; mapping UI01–UI28 và 5 screenshot nằm trong
`UI_V2_4_TEST_EVIDENCE/ui/`. Đã kiểm teacher dashboard/exams/monitor/report/mixed-exam
ở 1366x768 và 1920x1080; student với 10/20/30/40/50/60 câu; không horizontal overflow
ở fixture bình thường. Nút Nộp bài và timer thấy được ở 1366x768.
Ảnh dùng học sinh/câu hỏi fixture, không phải lớp học thực tế.

HOST_WINDOWS_RUNTIME = NOT_RUN; PHYSICAL_50_PC = NOT_RUN.
Không build EXE, không Production. Release gate BLOCKED vì các test legacy nguyên bản
chưa PASS; xem regression/defect report. Không tạo RC2.

## File thay đổi/thêm

{diff}
'''
(O/'UI_V2_4_IMPLEMENTATION_REPORT.md').write_text(implementation)
native_table='\n'.join('| '+n+' | '+next(x['status'] for x in native if x['script']==n and x['mode']=='UI_RC1_original')+' | '+next(x['status'] for x in native if x['script']==n and x['mode'].endswith('compatibility'))+' |' for n in ['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_mathjax.py','kiem_tra_v222.py','kiem_tra_v23.py','kiem_tra_v23_integration.py'])
ui_table='\n'.join('| '+x['id']+' | '+x['status']+' | `'+x['browser_check']+'` |' for x in mapped)
regression=f'''# UI V2.4 RC1 — Regression report

REGRESSION = BLOCKED (literal all-existing-tests-PASS gate not satisfied)
R4_FUNCTIONAL_LOCK = PASS (internal tests and exact source integrity)
UI_IMPLEMENTATION = PASS
50_CLIENT_SIMULATION = PASS
60_CLIENT_HEADROOM = PASS
WINDOWS_RUNTIME = NOT_RUN
PHYSICAL_50_PC = NOT_RUN
PRODUCTION = NO
UI_RC1_CANDIDATE = BLOCKED

## Native tests: đúng thứ tự build_exe.bat, standalone

| Script | Nguyên bản trong candidate | Bản sao validation + test-only patch đã duyệt |
|---|---|---|
{native_table}

4 FAIL nguyên bản tái hiện cả trên ZIP R4 không sửa: các POST legacy thiếu nonce CSRF.
`TEST_SETUP_INCOMPLETE`, không chứng minh regression runtime UI. Không đổi source test
trong candidate. Validation bổ sung chỉ overlay 4 script test-only đã được GV duyệt
trước đây trong một bản sao tạm: cả 6 chạy độc lập bằng `python script.py`, không
sitecustomize, không transport adapter bên ngoài, không disable/exempt CSRF.
Thử nghiệm bổ sung không được dùng để đổi trạng thái 4 FAIL gốc thành PASS.
Log trước/sau ở native/ và native-final/; các file test trong ZIP vẫn hash giống R4.

## R1–R4 và kiểm tra dữ liệu

| Suite | Kết quả | Evidence / giới hạn |
|---|---|---|
| R1 | 18/18 PASS | Deadline POST/GET; boundary; wait-under-lock; 8-submit race; autosave/submitted; rollback; ALL/PARTIAL/weights; comma-topic 20 ô; backward compatibility |
| R2 | 15/15 PASS | availability type/level fallback; token/result isolation; unlock/retake; queued requests; legacy editor validation |
| R3 | 12 PASS / 3 FAIL | Tất cả 15 trạng thái giống R4 baseline; xem r3-baseline-comparison.json |
| R4 final | 7/7 PASS | 344 scoring cases; malformed rules/snapshot controlled rejection; restore semantics; all 35 CSRF routes; historical HTML/Excel |
| Browser UI | 28/28 nhóm PASS | Genuine form/header CSRF, login rotation, autosave/reload/submit/result, offline failed state, 5 types/MathJax, wizard comma roundtrip |
| Native HTTP security smoke | PASS | 35 route × 5 CSRF-negative variants = 175 rejections; DB unchanged; Excel/import, backup/restore, history, unlock |
| 50 primary/mixed/deadline | PASS | 40 câu × 5 types × 4 levels; no answer/score mismatch, lost submission or contamination |
| HTTP race/retry | PASS | 8 parallel submits, single consistent winner; timeout retry; late save/submit rejected correctly |
| 60 headroom | PASS | 60 independent cookie sessions, 40 câu mỗi bài, 0 score mismatch |

R1–R3 harness có trước F011. Bản harness sao chép độc lập thương lượng nonce thật từ
application/session cho positive POST; không monkeypatch CSRF, không đổi assertion.
AST của toàn bộ assertion giống nguyên bản (provenance ghi hash/count). Instrumentation
lock/clock/rollback có sẵn trong harness R1/R2 chỉ chạy trên runtime/database fixture.
CSRF negative cases dùng raw clients riêng, không được thêm nonce giúp PASS.

3 FAIL R3 không được bỏ qua: hai case kỳ vọng flash còn trong session sau khi template
đã tiêu thụ flash (`mixed-exam`); một case kỳ vọng dữ liệu câu hỏi hiện tại trong Excel
trái contract snapshot lịch sử F012. Cả ba FAIL giống baseline R4; không sửa expected
test. R4 harness kiểm độc lập rằng report/Excel giữ đúng snapshot và text/numeric.
Yêu cầu regression “clone exam” = NOT_SUPPORTED_IN_R4; clone question 4 lớp × 5 types
× 2 modes PASS. Không thêm chức năng clone exam.

## Load evidence

50-scope: 8.408 HTTP requests, 0 failed unexpected, 0 HTTP 500; 82 rejection dự kiến.
1 read timeout được chủ động đặt 0,0005 giây để kiểm retry; ghi riêng là planned timeout.
60-scope: 2.760 HTTP requests, 0 failed, 0 HTTP 500, 0 timeout.
Peak = 60 request đồng thời. CPU/RSS được đo; đây là HTTP simulation trên cloud Linux,
không thay cho Windows native hoặc phòng máy 50 PC vật lý. Xem requests/metrics,
submit burst, final-answer-score-comparison, deadline, reconnect và resource samples.

LAN harness dùng entry point app.py/Waitress nguyên bản trong clone riêng, không UI
adapter. Oracle độc lập giữ thứ tự binary-float/Decimal của scoring v2.3; không đổi
scoring để khớp oracle rational khác. Hàm/tệp oracle có provenance trong HARNESS.

## UI01–UI28

| Case | Status | Browser check |
|---|---|---|
{ui_table}

## Lịch sử validation giữ nguyên

- UI first run phát hiện nút submit quá thấp ở 1366 và selector checkbox chưa scoped;
  sửa presentation CSS và stimulus test tương ứng. Log/ảnh first run vẫn giữ.
- Offline probe trước đó giả định câu 0 là SINGLE hoặc check lại radio đã checked;
  R4 shuffle khiến probe không phát sinh change. Final harness tìm SINGLE theo snapshot,
  chọn radio khác, giữ nguyên assertion failed/saved và cleanup offline bằng finally.
- LAN first run hoàn tất mọi functional assertion nhưng lỗi ghi summary chứa Client
  object; chỉnh serializer harness, giữ raw first-run evidence và chạy lại full suite.
- Không sửa assertion chức năng cũ; không bỏ case FAIL; không dựng screenshot hoặc số liệu.

## Release gate

Không phát hiện regression mới của UI/core trong scope đã chạy. Tuy nhiên điều kiện
“toàn bộ test hiện có PASS” không đạt ở 4 native tests và 3 stale R3 assertions.
Không được gọi UI_RC1_CANDIDATE = PASS. Giữ BLOCKED và dừng ở candidate, chờ GV quyết định.
'''
(O/'UI_V2_4_REGRESSION_REPORT.md').write_text(regression)
changelog=f'''# UI V2.4 RC1 — Changelog

Kế thừa trực tiếp R4 input `{BASE}`. Candidate SHA-256 `{CAND}`.

- Thêm teacher sidebar/shell, Tổng quan tách module và các liên kết hệ thống.
- Thêm monitor filters/search/metrics, DOM update từng dòng với chu kỳ R4 3 giây.
- Thêm focused-question UI, navigator, flag, previous/next, modal submit và CSS trạng thái lưu.
- Tổ chức create-exam/mixed-exam thành 4 bước presentation; report thành 5 tab.
- Giữ MathJax offline, toàn bộ field names/CSRF, hàm autosave/timer/ping và backend R4.
- Bổ sung kiểm thử/evidence bên ngoài source candidate; không sửa 6 native tests.

9 template changed, 5 static files added, 50 original files unchanged, 0 deleted.
Xem UI_V2_4_FILE_MANIFEST.txt cho mọi hash before/after và file unchanged.
Không migration, reset license/MID, build EXE, Production hoặc RC2.

UI_IMPLEMENTATION = PASS; REGRESSION = BLOCKED; UI_RC1_CANDIDATE = BLOCKED.
'''
(O/'UI_V2_4_CHANGELOG.md').write_text(changelog)
defects='''# UI V2.4 RC1 — Defect / release-gate report

UI_RC1_CANDIDATE = BLOCKED. Không có patch backend, không tạo RC2.

## D001 — Baseline native tests chưa tương thích CSRF F011

4 file kiem_tra_v22/v221/v222/v23_integration trong input R4 thiếu nonce thật cho POST.
Expected: các positive POST functional assertions chạy sau negotiation nonce hiện hành.
Actual: raw scripts FAIL trên R4 baseline và UI RC1 trước các assertion DB/scoring tiếp theo.
Evidence: native/* và native-final/*; approved-test compatibility copy = 6/6 PASS.
Classification kế thừa audit đã duyệt: TEST_SETUP_INCOMPLETE / LEGACY_TEST_DEFECT,
PATCH_REQUIRED = TEST_ONLY. Không đổi severity hoặc sửa test trong candidate này.
Đây là blocker release gate all-tests-PASS và build_exe.bat nguyên bản; không phải defect
UI runtime đã chứng minh. GV quyết định cách áp dụng test-only patch ở vòng được duyệt riêng.

## D002 — R3 harness expectations không khớp contract R4 đã khóa

F006 mixed-exam invalid-time/invalid-counts yêu cầu flash còn trong session; template
consume flash khi render. F008 report Excel yêu cầu code/nội dung từ bank sửa sau khi thi;
F012 yêu cầu snapshot lịch sử. 3 FAIL xuất hiện giống nhau trên baseline R4 và UI RC1.
Evidence: r3/results.json, r3-baseline/results.json, r3-baseline-comparison.json,
R4 final historical snapshot/Excel PASS. Không sửa expected result để tạo PASS.
Blocker là test-contract reconciliation cần GV duyệt; không sửa backend/UI cho expectation cũ.

## UI defect đã xử lý trong cùng RC1

Nút submit vượt viewport 1366x768 ở UI first run: thu gọn vùng cuộn navigator. Final
UI05 và UI25 PASS; 5 screenshot thật. Không có unresolved HIGH/CRITICAL UI defect
được phát hiện trong các case đã chạy; không khẳng định mọi dữ liệu thực tế đã nghiệm thu.

## Data/evidence gaps

UI_DATA_GAP G01–G06 trong implementation report để an toàn, không bổ sung backend.
WINDOWS_RUNTIME = NOT_RUN; PHYSICAL_50_PC = NOT_RUN; PRODUCTION = NO.
No new runtime patch or release claimed. STOP after artifact handoff.
'''
(O/'UI_V2_4_DEFECT_REPORT.md').write_text(defects)
# Shareable evidence includes failed attempts; preserve existing logs rather than relabeling them.
share=O/'UI_V2_4_TEST_EVIDENCE';shutil.copytree(E,share)
shutil.copy2(R/'baseline-manifest.json',share/'baseline-manifest.json')
harness=share/'HARNESS';shutil.copytree(R/'harness',harness,ignore=shutil.ignore_patterns('__pycache__'))
approved=harness/'APPROVED_TEST_COMPATIBILITY';approved.mkdir()
for n in ['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_v222.py','kiem_tra_v23_integration.py']:
 shutil.copy2(Path('/workspace/r4-windows-build-test-patch/candidate/PHAN_MEM')/n,approved/n)
# Package-building script is evidence, not app code. Record original/adapted load harness hashes.
(share/'load-harness-provenance.json').write_text(json.dumps(dict(original='/workspace/final-release-validation-r4/harness/lan_validation.py',original_sha256=sha(Path('/workspace/final-release-validation-r4/harness/lan_validation.py')),adapted_sha256=sha(R/'harness/lan_validation.py'),changes=['runtime/output paths point to disposable UI fixture','independent binary-float v2.3 oracle','omit host-port/restart scenario outside UI scope','serialize only primary50 detail dictionary'],application_modified=False),indent=2)+'\n')
members={'CANDIDATE/'+K:O/K}
for p in O.glob('*.md'):members['REPORTS/'+p.name]=p
members['UI_V2_4_FILE_MANIFEST.txt']=O/'UI_V2_4_FILE_MANIFEST.txt'
for p in share.rglob('*'):
 if p.is_file():members['UI_V2_4_TEST_EVIDENCE/'+p.relative_to(share).as_posix()]=p
inner=''.join(sha(p)+'  '+name+'\n' for name,p in sorted(members.items()))
(O/'HANDOFF_CONTENT_SHA256SUMS.txt').write_text(inner)
members['SHA256SUMS.txt']=O/'HANDOFF_CONTENT_SHA256SUMS.txt'
with zipfile.ZipFile(O/H,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):z.write(p,name)
with zipfile.ZipFile(O/H) as z:
 assert z.testzip() is None and z.read('CANDIDATE/'+K)==(O/K).read_bytes()
 for name,p in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(p)
outer=sha(O/K)+'  '+K+'\n'+sha(O/H)+'  '+H+'\n';(O/'SHA256SUMS_UI_V2_4_ARTIFACTS.txt').write_text(outer)
validation=dict(baseline_sha256=BASE,candidate=dict(file=K,bytes=(O/K).stat().st_size,files=64,sha256=CAND,zip_integrity='PASS',backend_core_unchanged=True),handoff=dict(file=H,bytes=(O/H).stat().st_size,files=len(members),sha256=sha(O/H),zip_integrity='PASS',all_member_checksums_match=True),UI_IMPLEMENTATION='PASS',REGRESSION='BLOCKED',R4_FUNCTIONAL_LOCK='PASS',UI_RC1_CANDIDATE='BLOCKED',WINDOWS_RUNTIME='NOT_RUN',PHYSICAL_50_PC='NOT_RUN',PRODUCTION='NO')
(O/'UI_V2_4_PACKAGE_VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(validation,indent=2))
