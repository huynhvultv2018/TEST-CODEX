"""Identical server-side regressions against verified R1 and R2, on temporary copies."""
import argparse,hashlib,json,logging,os,shutil,sys,tempfile,threading,traceback
from collections import Counter
from datetime import datetime,timedelta
from pathlib import Path


# Standalone CSRF negotiation for this older harness; all original assertions retained.
import re as csrf_re
class CurrentNonceClient:
    def __init__(self,raw):self.raw=raw
    def __getattr__(self,name):return getattr(self.raw,name)
    def post(self,path,**kwargs):
        page=self.raw.get('/teacher/login').get_data(as_text=True)
        match=csrf_re.search(r'<meta name="csrf-token" content="([^"]+)"',page)
        if not match:raise AssertionError('Real CSRF nonce absent')
        headers=dict(kwargs.pop('headers',{}) or {})
        if 'X-CSRF-Token' not in headers:headers['X-CSRF-Token']=match.group(1)
        return self.raw.post(path,headers=headers,**kwargs)

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True);results=[]
    def check(name,fn):
        try: results.append(dict(name=name,status='PASS',detail=fn()))
        except Exception: results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()))
        print(name,results[-1]['status'],flush=True)
    with tempfile.TemporaryDirectory(prefix='tnlan_r2_') as tmp:
        root=Path(tmp);shutil.copytree(args.source,root/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(root/'localappdata');sys.path.insert(0,str(root/'app'))
        import app as m
        from question_types import decode,correct
        from scoring import total_score
        m.init_db();teacher=CurrentNonceClient(m.app.test_client())
        assert teacher.post('/teacher/login',data=dict(username='admin',password='123456')).status_code==302
        def sql(q,a=()):
            c=m.db()
            try:r=c.execute(q,a).fetchall();c.commit();return r
            finally:c.close()
        definitions={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
        levels=('NB','TH','VD','VDC');topic='Chủ đề, có dấu phẩy'
        serial=0
        def seed(subject,variants):
            for kind,(items,answers) in definitions.items():
                for lv in levels:
                    assert teacher.post('/teacher/multi/new',data=dict(ma_cau=subject+kind+lv,khoi_lop='8',mon=subject,chu_de=topic,muc_do=lv,question_type=kind,noi_dung='R2 '+kind,items=items,answers=answers,points='4',scoring_mode='partial',weights='1,3' if kind in ('TF','MATCH','FILL') else '')).status_code==302
                    sql('UPDATE cau_hoi SET muc_do=?,question_type=? WHERE ma_cau=?',(variants(lv),variants(kind),subject+kind+lv))
        def matrix(variant):
            subject='R2_'+variant
            transform={'canonical':lambda s:s,'lowercase':str.lower,'space':lambda s:'  '+s.lower()+'  ','unicode_whitespace':lambda s:'\t\u00a0'+s.lower()+'\n\u2003'}[variant]
            seed(subject,transform)
            before=[dict(r) for r in sql('SELECT * FROM cau_hoi WHERE mon=? ORDER BY id',(subject,))]
            response=teacher.get('/teacher/api/question-availability',query_string={'mon':subject,'chu_de':topic})
            assert response.status_code==200
            av=response.get_json();assert av['counts']['TOTAL']==20
            assert all(av['by_type'][k][lv]==1 for k in definitions for lv in levels)
            details=[]
            for endpoint in ['/teacher/create-exam','/teacher/mixed-exam']:
                fields=dict(ten='R2 matrix '+variant+endpoint,mon=subject,lop='8A',chu_de=topic,thoi_gian='15',minutes='15',hien_diem='on')
                fields.update({k+'_'+lv:'1' for k in definitions for lv in levels})
                assert teacher.post(endpoint,data=fields).status_code==302
                exams=sql('SELECT * FROM ky_thi WHERE ten=?',(fields['ten'],));assert len(exams)==1
                kt=exams[0];assert kt['so_cau']==20
                for _ in range(3):
                    data=m.build_exam(kt)
                    assert len(data)==20 and len({q['id'] for q in data})==20
                    assert Counter(q['type'] for q in data)=={k:4 for k in definitions}
                    choices={i:q['answer'] if q['type']!='FILL' else [a[0] for a in q['answer']] for i,q in enumerate(data)}
                    assert all(correct(q,choices[i]) for i,q in enumerate(data))
                    assert total_score(data,choices)==10
                details.append(dict(endpoint=endpoint,questions=20,draws=3,score=10))
            legacy=dict(mon=subject,chu_de='',muc_do='NB,TH,VD,VDC',nb_count=5,th_count=5,vd_count=5,vdc_count=5,so_cau=20,type_quotas='')
            data=m.build_exam(legacy);assert len(data)==20 and Counter(q['type'] for q in data)=={k:4 for k in definitions}
            assert [dict(r) for r in sql('SELECT * FROM cau_hoi WHERE mon=? ORDER BY id',(subject,))]==before
            return dict(variant=variant,matrix_cells=20,workflows=details,legacy_sampler=20,bank_unchanged=True)
        for variant in ['canonical','lowercase','space','unicode_whitespace']:
            check('F004_matrix_'+variant,lambda variant=variant:matrix(variant))
        def fallback():
            for kind in ['', 'UNKNOWN']:
                subject='R2_fallback_'+kind
                sql("INSERT INTO cau_hoi(ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,question_type) VALUES(?,?,'A',' nb ','Legacy','A','B','C','D','B',?)",(subject,subject,kind))
                _,av=m.question_availability(subject);assert av['SINGLE']['NB']==1
                kt=dict(mon=subject,chu_de='A',type_quotas=json.dumps({'SINGLE':{'NB':1}}))
                data=m.build_exam(kt);assert len(data)==1 and data[0]['type']=='SINGLE'
                assert correct(data[0],data[0]['answer'])
            return 'Existing availability fallback to SINGLE is used by sampling and snapshots; DB preserved.'
        check('F004_legacy_blank_unknown_type_fallback',fallback)
        seed('R2_sessions',lambda s:s)
        def new_attempt():
            nonlocal serial
            serial+=1;name='R2_HS'+str(serial)
            fields=dict(ten='R2 session '+str(serial),mon='R2_sessions',lop='8A',thoi_gian='15',hien_diem='on')
            fields.update({k+'_NB':'1' for k in definitions})
            assert teacher.post('/teacher/create-exam',data=fields).status_code==302
            eid=sql('SELECT MAX(id) FROM ky_thi')[0][0]
            assert teacher.post('/teacher/student/add',data=dict(ma_hs=name,ho_ten='R2 PRIVATE '+name,lop='8A')).status_code==302
            client=CurrentNonceClient(m.app.test_client());assert client.post('/',data=dict(ma_hs=name,ky_thi_id=eid)).location.endswith('/exam')
            with client.session_transaction() as s:session=dict(s)
            aid=session['attempt_id'];data=json.loads(sql('SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0])
            return client,aid,data,session,name,eid
        def state(aid):
            return dict(sql('SELECT * FROM bai_thi WHERE id=?',(aid,))[0]),[dict(r) for r in sql('SELECT * FROM cau_tra_loi WHERE bai_thi_id=? ORDER BY vi_tri_cau',(aid,))]
        def clone(session):
            c=CurrentNonceClient(m.app.test_client())
            with c.session_transaction() as s:s.update(session)
            return c
        def full(data):return {i:q['answer'] if q['type']!='FILL' else [a[0] for a in q['answer']] for i,q in enumerate(data)}
        def form(data):
            f={}
            for i,q in enumerate(data):
                v=full(data)[i]
                if q['type']=='SINGLE':f['q_'+str(i)]=str(v)
                elif q['type']=='MULTI':f['q_'+str(i)]=[str(x) for x in v]
                else:
                    for j,x in enumerate(v):f[f'q_{i}_{j}']=str(x)
            return f
        def submit(c,aid,data):
            assert c.post('/exam',data=form(data)).status_code==302
            bt,rows=state(aid);assert bt['submitted_at'] and bt['diem']==10
            assert total_score(data,{r['vi_tri_cau']:r['lua_chon'] for r in rows})==10
        def result_tokens(submitted):
            c,aid,data,s,name,_=new_attempt()
            if submitted:submit(c,aid,data)
            before=state(aid)
            good=c.get('/result');assert good.status_code==200 and 'R2 PRIVATE '+name in good.get_data(as_text=True)
            if submitted:assert '10.0/10' in good.get_data(as_text=True)
            outcomes=[]
            for token in ['WRONG',None,'']:
                bad=dict(s)
                if token is None:bad.pop('client_token',None)
                else:bad['client_token']=token
                badclient=clone(bad);response=badclient.get('/result');html=response.get_data(as_text=True)
                assert 'R2 PRIVATE '+name not in html and 'Điểm:' not in html and '10.0/10' not in html
                with badclient.session_transaction() as cleared:assert 'attempt_id' not in cleared and 'client_token' not in cleared
                outcomes.append(dict(token=token,status=response.status_code,discloses_result=False))
            assert state(aid)==before
            return dict(submitted=submitted,valid_status=good.status_code,invalid_tokens=outcomes)
        check('F007_result_in_progress_tokens',lambda:result_tokens(False))
        check('F007_result_submitted_tokens',lambda:result_tokens(True))
        def unlocked(submitted=False,legacy=False):
            c,aid,data,s,name,eid=new_attempt()
            if submitted:submit(c,aid,data)
            if legacy:
                sql('UPDATE bai_thi SET client_token=NULL WHERE id=?',(aid,))
                s.pop('client_token',None);c=clone(s)
            assert teacher.post('/teacher/unlock/'+str(aid)).status_code==302
            row,answers=state(aid);assert row['force_relogin']==1 and row['client_token'] is None
            old=dict(s);before=state(aid)
            bad=clone(old);response=bad.post('/api/save-answer',json=dict(index=0,choice=full(data)[0]))
            assert response.status_code==409 and response.get_json()['reason']=='session_conflict'
            bad=clone(old);assert bad.post('/exam',data=form(data)).status_code==200
            html=clone(old).get('/result').get_data(as_text=True)
            assert 'R2 PRIVATE '+name not in html and 'Điểm:' not in html
            assert state(aid)==before
            fresh=CurrentNonceClient(m.app.test_client());r=fresh.post('/',data=dict(ma_hs=name,ky_thi_id=eid));assert r.location.endswith('/exam')
            with fresh.session_transaction() as ns:newtoken=ns['client_token']
            assert newtoken and newtoken!=old.get('client_token')
            bt,_=state(aid);assert bt['client_token']==newtoken and bt['force_relogin']==0
            if submitted:assert bt['submitted_at'] is None and state(aid)[1]==[]
            nowdata=json.loads(bt['de_json'])
            assert fresh.post('/api/save-answer',json=dict(index=0,choice=full(nowdata)[0])).status_code==200
            assert clone(old).post('/api/save-answer',json=dict(index=0,choice=None)).status_code==409
            before=state(aid);assert 'R2 PRIVATE '+name not in clone(old).post('/exam',data=form(nowdata)).get_data(as_text=True);assert state(aid)==before
            submit(fresh,aid,nowdata);assert '10.0/10' in fresh.get('/result').get_data(as_text=True)
            assert '10.0/10' not in clone(old).get('/result').get_data(as_text=True)
            again=CurrentNonceClient(m.app.test_client());assert again.post('/',data=dict(ma_hs=name,ky_thi_id=eid)).location.endswith('/result')
            assert '10.0/10' in again.get('/result').get_data(as_text=True)
            return dict(submitted_before_unlock=submitted,legacy_token=legacy,old_save=409,old_submit_rejected=True,result_not_disclosed=True,new_login_save_submit_result=10)
        check('F017_F007_unlock_active_relogin',unlocked)
        check('F017_F007_unlock_submitted_retake',lambda:unlocked(True))
        check('F017_legacy_NULL_unlock_relogin',lambda:unlocked(legacy=True))
        def legacy_compatible():
            observations=[]
            for submitted in [False,True]:
                for token in [None,'']:
                    c,aid,data,s,name,_=new_attempt()
                    if submitted:submit(c,aid,data)
                    sql('UPDATE bai_thi SET client_token=?,force_relogin=0 WHERE id=?',(token,aid))
                    s.pop('client_token',None);c=clone(s)
                    assert 'R2 PRIVATE '+name in c.get('/result').get_data(as_text=True)
                    if not submitted:
                        assert c.post('/api/save-answer',json=dict(index=0,choice=full(data)[0])).status_code==200
                        submit(c,aid,data)
                    assert '10.0/10' in c.get('/result').get_data(as_text=True)
                    observations.append(dict(submitted=submitted,db_token=token,compatible=True))
            return observations
        check('F007_F017_unrevoked_legacy_NULL_empty_tokens',legacy_compatible)
        def queued_unlock(submit_request):
            _,aid,data,s,name,_=new_attempt();before_answers=state(aid)[1]
            original=m.db;updated=threading.Event();writer_waiting=threading.Event();allow_commit=threading.Event();out={}
            class Connection:
                def __init__(self):self.c=original()
                def execute(self,q,a=()):
                    if threading.current_thread().name=='old_client' and q=='BEGIN IMMEDIATE':writer_waiting.set()
                    result=self.c.execute(q,a)
                    if threading.current_thread().name=='unlock_teacher' and 'SET force_relogin=1,client_token=NULL' in q:updated.set()
                    return result
                def commit(self):
                    if threading.current_thread().name=='unlock_teacher':
                        assert allow_commit.wait(10),'Unlock commit gate timed out'
                    return self.c.commit()
                def __getattr__(self,n):return getattr(self.c,n)
            with teacher.session_transaction() as ts:teachersession=dict(ts)
            def unlock_request():
                try:out['unlock_status']=clone(teachersession).post('/teacher/unlock/'+str(aid)).status_code
                except Exception:out['unlock_error']=traceback.format_exc()
            def old_request():
                try:
                    c=clone(s);r=c.post('/exam',data=form(data)) if submit_request else c.post('/api/save-answer',json=dict(index=0,choice=full(data)[0]))
                    out['old_status']=r.status_code;out['old_json']=r.get_json(silent=True);out['old_html']=r.get_data(as_text=True) if submit_request else None
                except Exception:out['old_error']=traceback.format_exc()
            m.db=Connection;tu=threading.Thread(target=unlock_request,name='unlock_teacher');to=threading.Thread(target=old_request,name='old_client')
            try:
                tu.start();assert updated.wait(10),'Teacher did not update under lock'
                to.start();assert writer_waiting.wait(10),'Old request did not reach contested writer lock'
                allow_commit.set();tu.join(10);to.join(10)
                assert not tu.is_alive() and not to.is_alive() and 'old_error' not in out and 'unlock_error' not in out,out
            finally:
                allow_commit.set();tu.join(10)
                if to.ident is not None:to.join(10)
                m.db=original
            bt,rows=state(aid);assert bt['force_relogin']==1 and bt['client_token'] is None and bt['submitted_at'] is None and rows==before_answers
            assert out['unlock_status']==302
            if submit_request:assert out['old_status']==200 and 'R2 PRIVATE '+name not in out.pop('old_html')
            else:assert out['old_status']==409 and out['old_json']['reason']=='session_conflict'
            return out
        check('F017_queued_autosave_rechecks_unlock_under_lock',lambda:queued_unlock(False))
        check('F017_queued_submit_rechecks_unlock_under_lock',lambda:queued_unlock(True))
        def legacy_question():
            sql("INSERT INTO cau_hoi(ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung) VALUES('R2_legacy','R2_legacy','A','NB','Legacy','Hai','Ba','Bốn','Năm','B')")
            return sql('SELECT MAX(id) FROM cau_hoi')[0][0]
        def legacy_form(answer):
            f=dict(ma_cau='R2_legacy',mon='R2_legacy',chu_de='A',muc_do='NB',noi_dung='Legacy',a='Hai',b='Ba',c='Bốn',d='Năm')
            if answer is not None:f['dap_an_dung']=answer
            return f
        def invalid_editor():
            qid=legacy_question();before=dict(sql('SELECT * FROM cau_hoi WHERE id=?',(qid,))[0]);out=[]
            for answer in ['INVALID','', '  ','AB','1',None]:
                response=teacher.post('/teacher/question/edit/'+str(qid),data=legacy_form(answer))
                assert dict(sql('SELECT * FROM cau_hoi WHERE id=?',(qid,))[0])==before
                assert response.status_code==400
                out.append(dict(input=answer,status=response.status_code,DB_unchanged=True))
            return out
        check('F009_invalid_editor_rejects_before_commit',invalid_editor)
        def valid_editor():
            qid=legacy_question();observations=[]
            for answer in ['A','B','C','D',' a ',' b ',' c ',' d ']:
                r=teacher.post('/teacher/question/edit/'+str(qid),data=legacy_form(answer));assert r.status_code==302
                row=dict(sql('SELECT * FROM cau_hoi WHERE id=?',(qid,))[0]);assert row['dap_an_dung']==answer.strip().upper() and row['payload']==''
                data=m.build_exam(dict(mon='R2_legacy',chu_de='A',muc_do='NB',nb_count=2,th_count=0,vd_count=0,vdc_count=0,so_cau=2,type_quotas=''))
                q=next(q for q in data if q['id']==qid)
                assert q['options'][q['answer']]==row[answer.strip().lower()]
                assert correct(q,q['answer']) and total_score([q],{0:q['answer']})==10
                assert all(not correct(q,i) for i in range(4) if i!=q['answer'])
                observations.append(dict(input=answer,stored=row['dap_an_dung'],correct_score=10))
            return observations
        check('F009_valid_ABCD_editor_scoring',valid_editor)
        schema=[dict(r) for r in sql("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name")]
        (args.output/'schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
        logging.shutdown();shutil.copyfile(root/'app/logs/app.log',args.output/'runtime.log')
    record=dict(source=str(args.source.resolve()),harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),results=results)
    (args.output/'results.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    return 0 if all(r['status']=='PASS' for r in results) else 1
if __name__=='__main__':raise SystemExit(main())
