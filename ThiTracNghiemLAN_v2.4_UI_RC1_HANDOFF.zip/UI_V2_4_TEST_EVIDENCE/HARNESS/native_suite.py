import json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path('/workspace/ui-v2-4-rc1')
TESTS=['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_mathjax.py','kiem_tra_v222.py','kiem_tra_v23.py','kiem_tra_v23_integration.py']
results=[]
for mode,source in [('R4_original',ROOT/'baseline/PHAN_MEM'),('UI_RC1_original',ROOT/'candidate/PHAN_MEM'),('UI_RC1_approved_test_compatibility',ROOT/'candidate/PHAN_MEM')]:
  for test in TESTS:
    with tempfile.TemporaryDirectory(prefix='ui_native_') as tmp:
      app=Path(tmp)/'app';shutil.copytree(source,app)
      if mode.endswith('compatibility'):
        for n in ['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_v222.py','kiem_tra_v23_integration.py']:
          shutil.copy2(Path('/workspace/r4-windows-build-test-patch/candidate/PHAN_MEM')/n,app/n)
      env=os.environ.copy();env.pop('PYTHONPATH',None);env.pop('TNLAN_R4_VALID_CLIENT',None);env['PYTHONDONTWRITEBYTECODE']='1';env['LOCALAPPDATA']=str(Path(tmp)/'localappdata')
      started=time.monotonic();p=subprocess.run([sys.executable,test],cwd=app,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
      out=ROOT/'evidence/native'/mode;out.mkdir(parents=True,exist_ok=True);(out/(test+'.log')).write_bytes(p.stdout)
      row=dict(mode=mode,script=test,status='PASS' if p.returncode==0 else 'FAIL',exit_code=p.returncode,elapsed_s=round(time.monotonic()-started,3),standalone=True,external_adapter=False)
      results.append(row);print(mode,test,row['status'],flush=True)
(ROOT/'evidence/native/results.json').write_text(json.dumps(results,indent=2)+'\n')
