# HOTFIX ROUND 1 — CHANGELOG

**HOTFIX_R1 = PASS**

Ngày báo cáo: 2026-10-02T08:43:46+07:00 (Asia/Bangkok). Baseline duy nhất: v2.3.1 đã audit, ZIP SHA-256 `0a65c964413c9485e973dd91c8d9263d07fa541bb1a08f54603e3390f18738f2`.

## Phạm vi và candidate

Candidate: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R1_CANDIDATE.zip` (862,605 bytes, 62 tệp). SHA-256: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202`. Source mở tại `hotfix-r1-candidate/`, kế thừa trực tiếp bản baseline nguyên trạng. Chỉ 2 file application thay đổi: `PHAN_MEM/app.py` và `PHAN_MEM/multi_routes.py`; 60 file còn lại giống byte.

Không refactor tổng quát, không sửa UI/template/static, scoring.py/question_types.py, dependency/test gốc, license, schema/init/migration, version/banners hoặc findings MEDIUM/LOW/INFO. Không v2.4, commit/push/production. Harness mới nằm ngoài candidate, phục vụ đúng F001–F003 và regression liên quan.

## F001 — deadline server-side — PASS

Sau khi giành khóa ghi, submit đọc lại deadline và quyết định có được đọc request.form hay không. Tại hoặc sau deadline, chỉ dùng đáp án hợp lệ đã lưu theo chính sách hiện tại; form POST muộn bị bỏ qua. GET timeout dùng cùng đường chốt. Điều kiện hết giờ dùng thời gian còn lại thực tế, không dùng số giây đã làm tròn xuống, để cùng ranh giới với autosave.

Autosave cũng kiểm deadline sau khi lấy khóa ghi. Request tới trước giờ nhưng chờ khóa qua hạn không được nhận đáp án mới. Đây là cưỡng chế server-side; không thay timer/UI/scoring.

Evidence: expired POST rỗng →0/10; saved ALL→2/10, PARTIAL với weights→4.5/10, không tăng thành10 từ POST muộn; đúng deadline reject autosave409; lock-wait deadline checks; expired submit reload được autosave hợp lệ của request thắng trước đó và chấm2/10.

## F002 — atomic submission — PASS

Submit dùng `BEGIN IMMEDIATE` để giành quyền ghi SQLite trước authoritative session/submitted/snapshot/saved-answer checks. Fast path cũ chỉ tối ưu request đã submitted; không quyết định quyền chốt. Chỉ request thấy submitted_at=NULL dưới khóa được ghi đáp án. Conditional UPDATE `WHERE submitted_at IS NULL` phải ảnh hưởng1 row mới commit; nếu0 row thì rollback cả đáp án. Exception luôn đóng connection và rollback transaction chưa hoàn tất.

Autosave dùng cùng kiểu khóa, đọc trạng thái hiện tại dưới khóa rồi mới ghi; request đến sau commit submission trả409 và không ghi đè. Transaction chỉ bao quanh đoạn read/check/write cần bảo vệ; không có sleep/delay, global Python lock hoặc workaround riêng để làm test PASS.

Evidence: race probe audit cũ nguyên trạng chuyển FAIL→PASS; stored score10 = regrade10. 8 submit đồng thời trên mỗi mode ALL/PARTIAL, mỗi attempt chỉ một writer ghi5 đáp án. Queued autosave sau chốt trả409. Fault sau write đầu rollback toàn bộ và retry được; SQLite conditional finalization rowcount0 không commit đáp án.

## F003 — chủ đề có dấu phẩy — PASS

Không đổi schema. Với danh sách có ít nhất một tên chứa dấu phẩy, create_exam ghi JSON list vào cột chu_de hiện có và thêm metadata `_topics_format: {"version":1}` vào JSON type_quotas. Toàn bộ 5×4 số lượng và tổng theo mức độ giữ nguyên; sampler bỏ qua metadata khi lấy quota.

Decoder chỉ đọc JSON list khi có metadata đúng phiên bản. Khi metadata vắng, vẫn dùng hợp đồng CSV cũ; không suy đoán format từ tên chủ đề. Do đó tên legacy nhìn như JSON hoặc marker vẫn được giữ theo format cũ. Kỳ thi mới không chứa tên có dấu phẩy vẫn ghi CSV/type_quotas như baseline. Cả reader quota và compatibility sampler cũ dùng decoder tương ứng.

Evidence: “Chủ đề, có dấu phẩy” được lưu/load/build như1 chủ đề; toàn ma trận 20 ô sinh20 câu, kết hợp một chủ đề khác sinh40; chọn đúng môn/chủ đề, không trùng ID. Browser chọn checkbox thật→availability20→create/persist/reload→HS làm đủ5 dạng→score10 = regrade10. 14 case legacy qua hai sampler và hai row persisted qua init_db hai lần không bị sửa; SQLite schema giống baseline.

Tương thích được chứng minh là candidate đọc dữ liệu cũ. Không khẳng định source cũ đọc được representation JSON mới. Những kỳ thi đã lưu CSV mơ hồ từ trước (một tên chứa dấu phẩy và nhiều tên có cùng chuỗi ghép) không thể tự phân biệt bằng dữ liệu cũ; giữ nguyên row, không tự migration/suy đoán lại chủ đề. Khi cần tạo kỳ thi từ tên có dấu phẩy, candidate mới round-trip không mơ hồ.

## Kết quả và điểm dừng

18/18 focused checks PASS. 6/6 script gốc PASS. Race/browser cũ PASS; comma browser PASS. Original audit/legacy còn7 FAIL MEDIUM đã biết, không có PASS cũ thành FAIL. Không hạ severity hoặc tắt assertion để đạt kết luận.

**F001 = PASS; F002 = PASS; F003 = PASS. HOTFIX_R1 = PASS.**

Đây là candidate chờ người dùng duyệt HOTFIX ROUND 1; baseline ZIP/source và báo cáo audit cũ không bị ghi đè. Không đổi BASELINE_LOCK cũ hoặc tự xác lập baseline mới. Đã dừng; không triển khai hay tiếp tục sửa findings khác.
