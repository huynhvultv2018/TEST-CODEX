# HOTFIX ROUND 1 — TEST REPORT

**HOTFIX_R1 = PASS**

Ngày báo cáo: 2026-10-02T08:43:46+07:00 (Asia/Bangkok). Baseline duy nhất: v2.3.1 đã audit, ZIP SHA-256 `0a65c964413c9485e973dd91c8d9263d07fa541bb1a08f54603e3390f18738f2`.

## Môi trường và thực thi

Linux x86_64, Python3.12.14, venv `/workspace/tnlan-audit-venv`, dependency giữ nguyên environment audit (không sửa requirements). System Chromium151.0.7922.173, local Waitress. TLS/package verification không bị tắt. Mọi DB/license/trial/session/log sinh trong copy tạm; không chạy app trực tiếp trong baseline hoặc candidate source.

Harness dùng event/barrier để điều phối transaction hoặc clock test để vượt deadline; **application không có sleep/delay/workaround**. Trả exit code trực tiếp của subprocess, không mất status qua pipeline. Các FAIL hiện hữu giữ assertion và status FAIL, không XFAIL/skip/disable.

## Focused regression — cùng test, baseline và candidate

Chạy từ `/workspace/TEST-CODEX`:

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source baseline-v2.3.1/PHAN_MEM --output HOTFIX_R1_EVIDENCE/focused-baseline
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source hotfix-r1-candidate/PHAN_MEM --output HOTFIX_R1_EVIDENCE/focused-candidate
```

Baseline: 7 PASS, 11 FAIL, exit1. Candidate: **18 PASS, 0 FAIL, exit0**. Không thay test giữa hai input source. Output JSON/runtime.log và stdout/stderr tại hai thư mục tương ứng.

| Check | Baseline audit source | Candidate |
|---|---|---|
| `F001_expired_POST_empty_five_types` | FAIL | PASS |
| `F001_expired_POST_saved_ALL_PARTIAL_weights` | FAIL | PASS |
| `F001_expired_GET_saved_ALL_PARTIAL_weights` | PASS | PASS |
| `F001_exact_deadline_boundary` | FAIL | PASS |
| `F001_submit_lock_wait_rechecks_deadline` | FAIL | PASS |
| `F001_autosave_lock_wait_rechecks_deadline` | FAIL | PASS |
| `REGRESSION_live_ALL_PARTIAL_weights_five_types` | PASS | PASS |
| `REGRESSION_snapshot_scoring_frozen` | PASS | PASS |
| `F002_sequential_duplicate_submit_and_autosave` | PASS | PASS |
| `F002_eight_parallel_submits_single_writer` | FAIL | PASS |
| `F002_queued_autosave_cannot_overwrite_submitted` | FAIL | PASS |
| `F001_F002_timeout_reloads_winning_autosave_under_lock` | FAIL | PASS |
| `F002_transaction_failure_rollback_and_retry` | FAIL | PASS |
| `F002_failed_submission_claim_rolls_back_answers` | FAIL | PASS |
| `F003_comma_single_multi_topic_full_20_cell_roundtrip` | FAIL | PASS |
| `F003_backward_compatibility_14_legacy_sampler_cases` | PASS | PASS |
| `F003_persisted_legacy_rows_unchanged_no_schema_migration` | PASS | PASS |
| `F003_new_literal_tagged_topic_roundtrip` | PASS | PASS |

Mỗi row là một check group, có thể chứa nhiều mode/type/subcase. Không đếm lặp các subcase như test độc lập. Concurrent baseline không buộc lúc nào cũng FAIL: lỗi race phụ thuộc lịch; run cuối thể hiện kết quả trong bảng, probe audit cũ dùng lịch deterministic đã chứng minh lỗi riêng.

F001 covered: 5 types × ALL/PARTIAL late POST rỗng/saved; GET timeout; exact boundary; submit và autosave chờ writer qua deadline; saved-valid autosave commit trước request timeout chốt. Expected độc lập0/2/4.5 và giữ choices đã lưu, không tăng lên10 từ form muộn.

F002 covered: sequential duplicate; 8 requests đồng thời mỗi ALL/PARTIAL (16 submissions tổng), đúng1 writer/5 answer upserts mỗi attempt; queued autosave after submit409; regrade equality/dung counts; fault sau answer write đầu rollback và retry; test-only SQLite trigger làm conditional UPDATE trả rowcount0, cả score/answers không commit. Expected500 trong fault injection là bước kiểm rollback, không lỗi vận hành không giải thích.

F003 covered: ma trận20 ô với một comma-topic (20 câu), hai chủ đề gồm comma-topic (40 câu), mỗi cấu hình10 draws, IDs unique/type-level quota/subject-topic filters; 14 legacy sampler cases;2 persisted rows read/init twice unchanged; JSON/marker-looking legacy names không bị nhận nhầm; source schema snapshot equality.

## Test gốc và audit harness cũ nguyên trạng

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r1-candidate --output HOTFIX_R1_EVIDENCE/original-candidate
```

Runner copy toàn bộ candidate vào staging và đặt tên thư mục `baseline-v2.3.1` chỉ để đáp ứng path hard-code của harness audit cũ. Nội dung là candidate, không dùng source khác; source path và hash script được ghi trong runner-results.json. Harness/test được copy nguyên byte, không sửa assertion. Mỗi script process riêng. Source v2.2.x/v2.3.0 khác không được lấy làm baseline.

| Script/harness | Exit | Kết quả |
|---|---:|---|
| `kiem_tra_v23.py` | 0 | PASS |
| `kiem_tra_v23_integration.py` | 0 | PASS |
| `kiem_tra_v22.py` | 0 | PASS |
| `kiem_tra_v221.py` | 0 | PASS |
| `kiem_tra_v222.py` | 0 | PASS |
| `kiem_tra_mathjax.py` | 0 | PASS |
| `audit_checks.py` | 1 | FAIL — xem phân loại bên dưới |
| `legacy_checks.py` | 1 | FAIL — xem phân loại bên dưới |
| `race_probe.py` | 0 | PASS |
| `browser_checks.py` | 0 | PASS |

6/6 test scripts PASS, có thông báo runner hoàn tất. Các tên test cũ là regression của source v2.3.1 hiện tại, không phải version baseline khác. Test v23 xác minh5 dạng/partial/weights/invalid points/shuffle/legacy; integration xác minh điểm5/10, Excel scoring roundtrip, snapshot freeze, timeout, save/reload/submit/point report; v22 all10; v2211000 student fixtures; v222 folders/import cũ; MathJax resource wiring.

Audit checks cũ: 16 PASS, 5 FAIL/21. Hai HIGH check F001/F003 chuyển FAIL→PASS; không PASS cũ thành FAIL. Legacy checks: 4 PASS, 2 FAIL/6, trạng thái giống hoàn toàn audit cũ. Global runner exit1 do7 MEDIUM chưa sửa, không giả báo toàn suite PASS.

### Race probe cũ

`race_probe.py` nguyên trạng, hash trong runner-results.json. Vẫn ép cả hai request thấy submitted_at=NULL ở fast path; correct request commit trước wrong request. Candidate recheck dưới khóa, request thua không ghi.

- Hai reads: {'first_correct': {'submitted_at': None}, 'late_wrong': {'submitted_at': None}}.
- Responses: {'first_correct': 302, 'late_wrong': 302}.
- Stored score: 10.0; regraded: 10.0; stored fully correct: 1.
- **PASS, exit0**, so với audit gốc stored10/regrade0 FAIL. Không đổi probe để tránh race.

### Browser cũ

Browser-checks.json statusPASS, local Waitress thực sự chạy, real GV/HS login, 20-câu controls cho5 dạng, autosave/reload/submit/result10 và DB20 answer rows. Preview/exam SVG MathJax hoạt động, không pageerror hoặc external request trong luồng. Screenshot/log trong original-candidate.

## Browser riêng cho F003

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/comma_browser.py --source hotfix-r1-candidate/PHAN_MEM --output HOTFIX_R1_EVIDENCE/comma-browser
```

**PASS, exit0**. GV chọn checkbox thật “Chủ đề, có dấu phẩy” cùng môn Toán; availability20/1 mỗi ô, totals4/type5/level20/đề. Form create ghi topic list + metadata; đọc lại DB; HS login→build20 đúng môn/chủ đề, không trùng→trả lời5 dạng→autosave/reload→submit→result10. Stored score=10.0=regrade, answer rows=20. Không external request/pageerror; không đổi UI. Hai screenshot: F003_teacher_comma_matrix.png, F003_exam_five_types.png.

## FAIL đã biết, ngoài phạm vi

| Finding | Severity giữ nguyên | Check | Trạng thái |
|---|---|---|---|
| F006 | MEDIUM | `invalid_duration_handled` | FAIL trước và sau; không sửa |
| F004 | MEDIUM | `legacy_lowercase_level_consistent` | FAIL trước và sau; không sửa |
| F005 | MEDIUM | `clone_preserves_grade` | FAIL trước và sau; không sửa |
| F007 | MEDIUM | `result_requires_valid_attempt_token` | FAIL trước và sau; không sửa |
| F017 | MEDIUM | `teacher_unlock_revokes_old_session` | FAIL trước và sau; không sửa |
| F008 | MEDIUM | `student_excel_export_keeps_names_as_text` | FAIL trước và sau; không sửa |
| F009 | MEDIUM | `legacy_editor_rejects_invalid_answer` | FAIL trước và sau; không sửa |

F010 invalid snapshot probes chia0/NaN/âm/vượt max vẫn như audit (observations, không cộng vào checks). F011/F012 static và LOW/INFO không sửa, không dùng static để kết luận PASS exploit/runtime. Không đóng finding ngoài3 HIGH hoặc hạ severity.

## Tổng và giới hạn

Candidate có54 đơn vị kết quả top-level: 18 focused +6 test scripts +21 audit checks +6 legacy checks +1 race +1 browser cũ +1 comma browser = **47 PASS, 7 FAIL MEDIUM hiện hữu**. 18 baseline focused là phép so sánh riêng, không cộng vào candidate. Script gốc không có pytest case count;6 là số script thực thi đầy đủ, không phải tổng assertions.

No skipped/disabled/XFAIL trong checks đã thực thi. Windows EXE/build/firewall, physical LAN,1000 simultaneous clients, browsers khác và DB thật của trường **UNRUN** như audit; không có production. Transaction được kiểm qua nhiều SQLite connections/request threads, writer waiting, rollback và Waitress browser; chưa đo load/thời gian chờ ở quy mô trường.

Scope verification: chỉ2 source files đổi; scoring/types/UI/schema/library/test gốc giữ nguyên, old script hashes được kiểm. Baseline original ZIP/archive/checksum cũ được bảo toàn. Các bước packaging kiểm byte từng ZIP entry và checksum; không coi save/ZIP là deploy.

**F001 = PASS; F002 = PASS; F003 = PASS. HOTFIX_R1 = PASS.**
