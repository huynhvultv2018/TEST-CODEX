# HOTFIX ROUND 1 — REGRESSION REPORT

Ngày báo cáo: 2026-10-02T08:43:46+07:00 (Asia/Bangkok). Baseline duy nhất: v2.3.1 đã audit, ZIP SHA-256 `0a65c964413c9485e973dd91c8d9263d07fa541bb1a08f54603e3390f18738f2`.

## Tiêu chí

HOTFIX_R1 chỉ PASS khi3 HIGH đều có runtime evidence PASS và không có regression mới trong kiểm tra bắt buộc. Finding MEDIUM/LOW/INFO vẫn giữ mức/trạng thái, không bị sửa để đạt PASS. Baseline audit source và BASELINE_LOCK cũ không được đổi.

| Phạm vi | Evidence | Kết quả |
|---|---|---|
| F001 late POST | Empty0, saved ALL2/PARTIAL4.5, exact deadline, writer-wait, saved winner after timeout | PASS; POST muộn không dùng đáp án mới |
| F002 atomic submit | Original race unchanged,8 concurrent requests/mode, queued autosave409, rollback/retry,rowcount0, regrade invariants | PASS; loser không ghi answers, regrade=score |
| F003 comma topic | 20-cell API/load/build20 và40; DOM comma select/create/result10; legacy14 cases + persisted2 | PASS;1 tên có dấu phẩy round-trip đúng, dữ liệu cũ không migration |
| SINGLE | Original v23/v22/integration, focused/live/late/browser | PASS luồng liên quan; radio/answer/scoring code không đổi |
| MULTI | Partial/duplicate/invalid choice unit cases, live/late/browser/concurrency | PASS luồng; không đổi answer set/penalty |
| TF | ALL/PARTIAL weights1,3, autosave/result | PASS luồng; dữ liệu invalid ngoài scope vẫn như audit |
| MATCH | Shuffle unit/integration, weights/partial, DOM select | PASS luồng; không đổi shuffle/answer logic |
| FILL | Synonyms/case/NFC/diacritics unit,partial/late/browser input | PASS luồng; question_types byte-identical |
| ALL/PARTIAL | Focused5-type ALL2,PARTIAL4.5; all-correct10; integrationpartial5 | PASS, không đổi công thức |
| weights/max_score | scoring unit + audit481 bounded-grade cases/13 invalid-config rejects; focused weighted scoring | PASS phạm vi dữ liệu hợp lệ; F010 corrupted-snapshot observations không sửa |
| Snapshot scoring | Bank scoring changed to1000/all after login; snapshot vẫn4.5; integration frozen timeout | PASS; max/mode/weights của snapshot không đổi theo bank |
| Ma trận5×4 | Original audit50 draws; original browser totals; comma20/40 +10 draws/config | PASS; số lượng/type/level/random/unique không đổi |
| Môn/chủ đề | Availability/shortage/subject-topic matching + comma serialization | PASS luồng; F004 lowercase legacy vẫn FAIL ngoài scope |
| Autosave | Five types saved/reload; before-deadline accepted, at/after409; queued after submitted409; valid save winning lock retained | PASS; session null-token rule F017 giữ nguyên |
| Submit | Live/expired/GET timeout/duplicate/concurrent/rollback | PASS theo chính sách deadline và chốt mới được yêu cầu |
| Result/point report | Browser10, auditweighted4.5, v23integrationpoints/monitor/export | PASS luồng hợp lệ; F007 result stale-token vẫn FAIL ngoài scope |
| Legacy/data/schema |14 legacy sampler cases;2 actual persisted CSV rows unchanged after2 init; schema equality; old migrations/import fixtures | PASS đã thử; không có schema/data rewrite application |
| HS/GV/quản lý cũ |6 original scripts + audit/legacy existing passes | Không PASS cũ thành FAIL; known issues giữ nguyên |
| UI/MathJax |26 templates +static byte-identical; browser previews/exam SVG; comma checkbox flow | Không đổi UI; MathJax/browser scenarios PASS |

## So sánh với audit

- Original audit checks:14 PASS/7 FAIL →16 PASS/5 FAIL; chỉ F001/F003 đổi FAIL→PASS.
- Original race scenario: FAIL stored10/regrade0 →PASS stored10/regrade10.
- Original legacy checks:4 PASS/2 FAIL giữ nguyên; không mask lỗi export/editor.
- Original browser:PASS giữ nguyên. Original6 scripts:PASS giữ nguyên.
- New focused18 checks: candidate18 PASS; cùng file test trên baseline 7 PASS/11 FAIL. Concurrency baseline có yếu tố lịch chạy, nên probe deterministic là bằng chứng chính cho race cũ.
- JSON/static probes invalid scoring không đổi. AST/source hash bảo đảm60 file khác nguyên byte và không chỉnh function ngoài targets trong2 file.

7 FAIL còn lại được giữ và báo nguyên trạng: F004,F005,F006,F007,F008,F009,F017. F010–F016 và các rủi ro static không tự xử lý. Việc thêm topic-format metadata chỉ phục vụ F003; không thêm question kind, level, scoring option hoặc UI feature.

## Giới hạn và điểm dừng

PASS áp dụng HOTFIX ROUND1 trong phạm vi kiểm thử có bằng chứng, không phải tuyên bố phần mềm không còn lỗi hoặc production-ready. Không kiểm Windows/EXE/LAN vật lý/DB trường/1000 concurrency. Không suy đoán sửa các legacy CSV row đã mơ hồ; candidate đọc đúng hợp đồng dữ liệu cũ và tạo representation mới rõ ràng khi cần. Schema không đổi, metadata mới không cam kết cho binary cũ đọc ngược.

Đã tạo candidate ZIP +4 báo cáo +evidence +CHECKSUMS.sha256. Baseline/sourceZIP/audit archive được giữ nguyên. Không bump version/v2.4/production/commit/push, không tự khóa baseline mới. Đã dừng và chờ người dùng duyệt HOTFIX ROUND1.

**F001 = PASS**

**F002 = PASS**

**F003 = PASS**

**HOTFIX_R1 = PASS**
