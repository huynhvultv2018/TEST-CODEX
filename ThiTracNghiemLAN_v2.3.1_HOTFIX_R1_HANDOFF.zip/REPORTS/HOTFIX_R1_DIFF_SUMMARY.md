# HOTFIX ROUND 1 — DIFF SUMMARY

Ngày báo cáo: 2026-10-02T08:43:46+07:00 (Asia/Bangkok). Baseline duy nhất: v2.3.1 đã audit, ZIP SHA-256 `0a65c964413c9485e973dd91c8d9263d07fa541bb1a08f54603e3390f18738f2`.

## Application diff

Unified diff đầy đủ: `HOTFIX_R1_EVIDENCE/source.diff`. Hash/cấu trúc scope: scope-verification.json và candidate-manifest.json. Candidate có đúng62 file của baseline, không thêm/bỏ file source; chỉ2 file thay đổi.

| File | Bytes baseline | Bytes candidate |
|---|---:|---:|
| `PHAN_MEM/app.py` | 88,960 | 90,922 |
| `PHAN_MEM/multi_routes.py` | 18,217 | 18,237 |

| Hunk / hàm | Finding truy nguyên | Thay đổi |
|---|---|---|
| app.py — thêm exam_topics | F003 | Decoder JSON có metadata, fallback đúng format CSV legacy |
| app.py — build_exam compatibility | F003 | Gọi decoder cho chu_de, giữ nguyên chọn câu/level/scoring |
| app.py — create_exam lưu chu_de/type_quotas | F003 | Chỉ comma-containing topic dùng list JSON + metadata; quota/count/validation không đổi |
| app.py — exam deadline | F001 | Ranh giới deadline chính xác; sau lock chỉ dùng form trước hạn, dùng saved answers khi hết hạn |
| app.py — exam transaction | F002 | BEGIN IMMEDIATE, authoritative re-read, loser no-write, conditional commit/rollback, close on exception |
| app.py — save_answer transaction | F001/F002 | Deadline/submitted/session checks nằm cùng transaction với ghi đáp án; close/rollback lỗi |
| multi_routes.py — inner build_exam | F003 | Decode list theo metadata và bỏ qua đúng `_topics_format`; SQL bộ lọc/type/level và random.sample giữ nguyên |

AST comparison xác nhận app chỉ đổi `build_exam`, `create_exam`, `exam`, `save_answer`, thêm `exam_topics`. Trong multi_routes chỉ inner build_exam đổi; tất cả hàm khác giống AST. Các dòng indentation/close thay đổi để bao transaction cần thiết cho F002; không phải refactor các module khác.

## Những phần giữ nguyên có bằng chứng

- Scoring/config/max_score/ALL/PARTIAL/weights/rounding: scoring.py byte-identical.
- SINGLE/MULTI/TF/MATCH/FILL parse/snapshot/answer logic: question_types.py byte-identical.
- 26 templates, 3 JS assets, tài liệu/batch/license/requirements/6 test scripts và4 bytecode: byte-identical.
- init_db/schema/index/migration không thay code; snapshot sqlite_master của baseline/candidate giống nhau. Không tạo column/table mới trong application.
- SQLite journal_mode/busy_timeout/synchronous và cấu hình Waitress không đổi; writer lock dùng cơ chế DB hiện có, không đổi toolchain hoặc dependency.
- Ma trận: tất cả20 quota values và NB/TH/VD/VDC totals giữ nguyên. Metadata topic là thành phần representation cần cho F003, không phải loại câu/mức độ mới.

## Artifact/test diff

Harness mới hotfix_regression.py, comma_browser.py, runner/report generator và log/JSON/screenshots nằm trong HOTFIX_R1_EVIDENCE; không đưa vào application ZIP. Các audit harness cũ được copy nguyên byte vào staging; runner chỉ chọn input source và output directory, không sửa assert hoặc chính sách PASS.

`CHECKSUMS.sha256` root được cập nhật cho đầu ra hotfix theo yêu cầu. Bản checksum audit trước được giữ tại `HOTFIX_R1_EVIDENCE/BASELINE_AUDIT_CHECKSUMS.sha256` và vẫn có trong ZIP audit gốc. Không overwrite ZIP baseline hay ZIP audit. Git tracked diff rỗng; không commit/push.

## Candidate

`ThiTracNghiemLAN_v2.3.1_HOTFIX_R1_CANDIDATE.zip` có root `DOC_TRUOC.txt`, `CONG_CU_CAP_MA/`, `PHAN_MEM/` như gói baseline; không database/session/trial/log runtime hoặc file test hotfix sinh ra trong source. Archive testzip thành công và mọi entry khớp candidate source.

SHA-256 candidate ZIP: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202`.

**HOTFIX_R1 = PASS**
