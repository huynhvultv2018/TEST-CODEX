"""Report current-run evidence only; source and baseline remain untouched."""
import json,hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import Counter

R=Path(__file__).resolve().parents[1];E=R/'HOTFIX_R1_EVIDENCE'
load=lambda name:json.loads((E/name).read_text())
focused=load('focused-candidate/results.json');before=load('focused-baseline/results.json');runner=load('original-candidate/runner-results.json')
audit=load('original-candidate/audit-checks.json');legacy=load('original-candidate/legacy-checks.json');race=load('original-candidate/race-probe.json');browser=load('original-candidate/browser-checks.json');comma=load('comma-browser/results.json');scope=load('scope-verification.json');verified=load('verification-summary.json');manifest=load('candidate-manifest.json')
old_audit=json.loads((R/'V2.3.1_AUDIT_EVIDENCE/audit-checks.json').read_text());old_legacy=json.loads((R/'V2.3.1_AUDIT_EVIDENCE/legacy-checks.json').read_text())
oldmap={x['name']:x['status'] for x in old_audit['results']};newmap={x['name']:x['status'] for x in audit['results']}
no_new_regression=all(newmap[k]=='PASS' for k,v in oldmap.items() if v=='PASS') and [(x['name'],x['status']) for x in old_legacy['results']]==[(x['name'],x['status']) for x in legacy['results']]
tests_ok=all(x['exit_code']==0 for x in runner['results'] if x['kind']=='original_test')
status='PASS' if all(x['status']=='PASS' for x in focused['results']) and tests_ok and race['status']=='PASS' and browser['status']=='PASS' and comma['status']=='PASS' and no_new_regression and verified['same_database_schema'] and scope['all_other_files_byte_identical'] else 'PENDING'
target={}
for finding in ['F001','F002','F003']:
 cases=[x for x in focused['results'] if finding in x['name']]
 target[finding]='PASS' if cases and all(x['status']=='PASS' for x in cases) and (race['status']=='PASS' if finding=='F002' else comma['status']=='PASS' if finding=='F003' else True) else 'PENDING'
date=datetime.now(ZoneInfo('Asia/Bangkok')).isoformat(timespec='seconds')
base_sha=manifest['baseline_zip_sha256'];zip_sha=manifest['zip_sha256']
common=f'Ngày báo cáo: {date} (Asia/Bangkok). Baseline duy nhất: v2.3.1 đã audit, ZIP SHA-256 `{base_sha}`.'
def write(name,text):(R/name).write_text(text.strip()+'\n',encoding='utf-8')
write('HOTFIX_R1_CHANGELOG.md',f'''# HOTFIX ROUND 1 — CHANGELOG

**HOTFIX_R1 = {status}**

{common}

## Phạm vi và candidate

Candidate: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R1_CANDIDATE.zip` ({manifest['zip_bytes']:,} bytes, 62 tệp). SHA-256: `{zip_sha}`. Source mở tại `hotfix-r1-candidate/`, kế thừa trực tiếp bản baseline nguyên trạng. Chỉ 2 file application thay đổi: `PHAN_MEM/app.py` và `PHAN_MEM/multi_routes.py`; 60 file còn lại giống byte.

Không refactor tổng quát, không sửa UI/template/static, scoring.py/question_types.py, dependency/test gốc, license, schema/init/migration, version/banners hoặc findings MEDIUM/LOW/INFO. Không v2.4, commit/push/production. Harness mới nằm ngoài candidate, phục vụ đúng F001–F003 và regression liên quan.

## F001 — deadline server-side — {target['F001']}

Sau khi giành khóa ghi, submit đọc lại deadline và quyết định có được đọc request.form hay không. Tại hoặc sau deadline, chỉ dùng đáp án hợp lệ đã lưu theo chính sách hiện tại; form POST muộn bị bỏ qua. GET timeout dùng cùng đường chốt. Điều kiện hết giờ dùng thời gian còn lại thực tế, không dùng số giây đã làm tròn xuống, để cùng ranh giới với autosave.

Autosave cũng kiểm deadline sau khi lấy khóa ghi. Request tới trước giờ nhưng chờ khóa qua hạn không được nhận đáp án mới. Đây là cưỡng chế server-side; không thay timer/UI/scoring.

Evidence: expired POST rỗng →0/10; saved ALL→2/10, PARTIAL với weights→4.5/10, không tăng thành10 từ POST muộn; đúng deadline reject autosave409; lock-wait deadline checks; expired submit reload được autosave hợp lệ của request thắng trước đó và chấm2/10.

## F002 — atomic submission — {target['F002']}

Submit dùng `BEGIN IMMEDIATE` để giành quyền ghi SQLite trước authoritative session/submitted/snapshot/saved-answer checks. Fast path cũ chỉ tối ưu request đã submitted; không quyết định quyền chốt. Chỉ request thấy submitted_at=NULL dưới khóa được ghi đáp án. Conditional UPDATE `WHERE submitted_at IS NULL` phải ảnh hưởng1 row mới commit; nếu0 row thì rollback cả đáp án. Exception luôn đóng connection và rollback transaction chưa hoàn tất.

Autosave dùng cùng kiểu khóa, đọc trạng thái hiện tại dưới khóa rồi mới ghi; request đến sau commit submission trả409 và không ghi đè. Transaction chỉ bao quanh đoạn read/check/write cần bảo vệ; không có sleep/delay, global Python lock hoặc workaround riêng để làm test PASS.

Evidence: race probe audit cũ nguyên trạng chuyển FAIL→PASS; stored score10 = regrade10. 8 submit đồng thời trên mỗi mode ALL/PARTIAL, mỗi attempt chỉ một writer ghi5 đáp án. Queued autosave sau chốt trả409. Fault sau write đầu rollback toàn bộ và retry được; SQLite conditional finalization rowcount0 không commit đáp án.

## F003 — chủ đề có dấu phẩy — {target['F003']}

Không đổi schema. Với danh sách có ít nhất một tên chứa dấu phẩy, create_exam ghi JSON list vào cột chu_de hiện có và thêm metadata `_topics_format: {{"version":1}}` vào JSON type_quotas. Toàn bộ 5×4 số lượng và tổng theo mức độ giữ nguyên; sampler bỏ qua metadata khi lấy quota.

Decoder chỉ đọc JSON list khi có metadata đúng phiên bản. Khi metadata vắng, vẫn dùng hợp đồng CSV cũ; không suy đoán format từ tên chủ đề. Do đó tên legacy nhìn như JSON hoặc marker vẫn được giữ theo format cũ. Kỳ thi mới không chứa tên có dấu phẩy vẫn ghi CSV/type_quotas như baseline. Cả reader quota và compatibility sampler cũ dùng decoder tương ứng.

Evidence: “Chủ đề, có dấu phẩy” được lưu/load/build như1 chủ đề; toàn ma trận 20 ô sinh20 câu, kết hợp một chủ đề khác sinh40; chọn đúng môn/chủ đề, không trùng ID. Browser chọn checkbox thật→availability20→create/persist/reload→HS làm đủ5 dạng→score10 = regrade10. 14 case legacy qua hai sampler và hai row persisted qua init_db hai lần không bị sửa; SQLite schema giống baseline.

Tương thích được chứng minh là candidate đọc dữ liệu cũ. Không khẳng định source cũ đọc được representation JSON mới. Những kỳ thi đã lưu CSV mơ hồ từ trước (một tên chứa dấu phẩy và nhiều tên có cùng chuỗi ghép) không thể tự phân biệt bằng dữ liệu cũ; giữ nguyên row, không tự migration/suy đoán lại chủ đề. Khi cần tạo kỳ thi từ tên có dấu phẩy, candidate mới round-trip không mơ hồ.

## Kết quả và điểm dừng

18/18 focused checks PASS. 6/6 script gốc PASS. Race/browser cũ PASS; comma browser PASS. Original audit/legacy còn7 FAIL MEDIUM đã biết, không có PASS cũ thành FAIL. Không hạ severity hoặc tắt assertion để đạt kết luận.

**F001 = {target['F001']}; F002 = {target['F002']}; F003 = {target['F003']}. HOTFIX_R1 = {status}.**

Đây là candidate chờ người dùng duyệt HOTFIX ROUND 1; baseline ZIP/source và báo cáo audit cũ không bị ghi đè. Không đổi BASELINE_LOCK cũ hoặc tự xác lập baseline mới. Đã dừng; không triển khai hay tiếp tục sửa findings khác.
''')

rows='\n'.join(f'| `{x["file"]}` | {x["before_bytes"]:,} | {x["after_bytes"]:,} |' for x in scope['changed_files'])
write('HOTFIX_R1_DIFF_SUMMARY.md',f'''# HOTFIX ROUND 1 — DIFF SUMMARY

{common}

## Application diff

Unified diff đầy đủ: `HOTFIX_R1_EVIDENCE/source.diff`. Hash/cấu trúc scope: scope-verification.json và candidate-manifest.json. Candidate có đúng62 file của baseline, không thêm/bỏ file source; chỉ2 file thay đổi.

| File | Bytes baseline | Bytes candidate |
|---|---:|---:|
{rows}

| Hunk / hàm | Finding truy nguyên | Thay đổi |
|---|---|---|
| app.py — thêm exam_topics | F003 | Decoder JSON có metadata, fallback đúng format CSV legacy |
| app.py — build_exam compatibility | F003 | Gọi decoder cho chu_de, giữ nguyên chọn câu/level/scoring |
| app.py — create_exam lưu chu_de/type_quotas | F003 | Chỉ comma-containing topic dùng list JSON + metadata; quota/count/validation không đổi |
| app.py — exam deadline | F001 | Ranh giới deadline chính xác; sau lock chỉ dùng form trước hạn, dùng saved answers khi hết hạn |
| app.py — exam transaction | F002 | BEGIN IMMEDIATE, authoritative re-read, loser no-write, conditional commit/rollback, close on exception |
| app.py — save_answer transaction | F001/F002 | Deadline/submitted/session checks nằm cùng transaction với ghi đáp án; close/rollback lỗi |
| multi_routes.py — inner build_exam | F003 | Decode list theo metadata và bỏ qua đúng `_topics_format`; SQL bộ lọc/type/level và random.sample giữ nguyên |

AST comparison xác nhận app chỉ đổi `build_exam`, `create_exam`, `exam`, `save_answer`, thêm `exam_topics`. Trong multi_routes chỉ inner build_exam đổi; tất cả hàm khác giống AST. Các dòng indentation/close thay đổi để bao transaction cần thiết cho F002; không phải refactor các module khác.

## Những phần giữ nguyên có bằng chứng

- Scoring/config/max_score/ALL/PARTIAL/weights/rounding: scoring.py byte-identical.
- SINGLE/MULTI/TF/MATCH/FILL parse/snapshot/answer logic: question_types.py byte-identical.
- 26 templates, 3 JS assets, tài liệu/batch/license/requirements/6 test scripts và4 bytecode: byte-identical.
- init_db/schema/index/migration không thay code; snapshot sqlite_master của baseline/candidate giống nhau. Không tạo column/table mới trong application.
- SQLite journal_mode/busy_timeout/synchronous và cấu hình Waitress không đổi; writer lock dùng cơ chế DB hiện có, không đổi toolchain hoặc dependency.
- Ma trận: tất cả20 quota values và NB/TH/VD/VDC totals giữ nguyên. Metadata topic là thành phần representation cần cho F003, không phải loại câu/mức độ mới.

## Artifact/test diff

Harness mới hotfix_regression.py, comma_browser.py, runner/report generator và log/JSON/screenshots nằm trong HOTFIX_R1_EVIDENCE; không đưa vào application ZIP. Các audit harness cũ được copy nguyên byte vào staging; runner chỉ chọn input source và output directory, không sửa assert hoặc chính sách PASS.

`CHECKSUMS.sha256` root được cập nhật cho đầu ra hotfix theo yêu cầu. Bản checksum audit trước được giữ tại `HOTFIX_R1_EVIDENCE/BASELINE_AUDIT_CHECKSUMS.sha256` và vẫn có trong ZIP audit gốc. Không overwrite ZIP baseline hay ZIP audit. Git tracked diff rỗng; không commit/push.

## Candidate

`{manifest['zip']}` có root `DOC_TRUOC.txt`, `CONG_CU_CAP_MA/`, `PHAN_MEM/` như gói baseline; không database/session/trial/log runtime hoặc file test hotfix sinh ra trong source. Archive testzip thành công và mọi entry khớp candidate source.

SHA-256 candidate ZIP: `{zip_sha}`.

**HOTFIX_R1 = {status}**
''')

baseline_cases={x['name']:x for x in before['results']}
focused_table='\n'.join(f'| `{x["name"]}` | {baseline_cases[x["name"]]["status"]} | {x["status"]} |' for x in focused['results'])
orig_table='\n'.join(f'| `{x["script"]}` | {x["exit_code"]} | {"PASS" if x["exit_code"]==0 else "FAIL — xem phân loại bên dưới"} |' for x in runner['results'])
audit_counts=Counter(x['status'] for x in audit['results']);legacy_counts=Counter(x['status'] for x in legacy['results'])
fail_map={'invalid_duration_handled':'F006','legacy_lowercase_level_consistent':'F004','clone_preserves_grade':'F005','result_requires_valid_attempt_token':'F007','teacher_unlock_revokes_old_session':'F017','student_excel_export_keeps_names_as_text':'F008','legacy_editor_rejects_invalid_answer':'F009'}
remaining=[x for x in audit['results']+legacy['results'] if x['status']=='FAIL']
fail_table='\n'.join(f'| {fail_map[x["name"]]} | MEDIUM | `{x["name"]}` | FAIL trước và sau; không sửa |' for x in remaining)
write('HOTFIX_R1_TEST_REPORT.md',f'''# HOTFIX ROUND 1 — TEST REPORT

**HOTFIX_R1 = {status}**

{common}

## Môi trường và thực thi

Linux x86_64, Python3.12.14, venv `/workspace/tnlan-audit-venv`, dependency giữ nguyên environment audit (không sửa requirements). System Chromium151.0.7922.173, local Waitress. TLS/package verification không bị tắt. Mọi DB/license/trial/session/log sinh trong copy tạm; không chạy app trực tiếp trong baseline hoặc candidate source.

Harness dùng event/barrier để điều phối transaction hoặc clock test để vượt deadline; **application không có sleep/delay/workaround**. Trả exit code trực tiếp của subprocess, không mất status qua pipeline. Các FAIL hiện hữu giữ assertion và status FAIL, không XFAIL/skip/disable.

## Focused regression — cùng test, baseline và candidate

Chạy từ `/workspace/TEST-CODEX`:

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source baseline-v2.3.1/PHAN_MEM --output HOTFIX_R1_EVIDENCE/focused-baseline
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source hotfix-r1-candidate/PHAN_MEM --output HOTFIX_R1_EVIDENCE/focused-candidate
```

Baseline: {before['counts'].get('PASS',0)} PASS, {before['counts'].get('FAIL',0)} FAIL, exit1. Candidate: **18 PASS, 0 FAIL, exit0**. Không thay test giữa hai input source. Output JSON/runtime.log và stdout/stderr tại hai thư mục tương ứng.

| Check | Baseline audit source | Candidate |
|---|---|---|
{focused_table}

Mỗi row là một check group, có thể chứa nhiều mode/type/subcase. Không đếm lặp các subcase như test độc lập. Concurrent baseline không buộc lúc nào cũng FAIL: lỗi race phụ thuộc lịch; run cuối thể hiện kết quả trong bảng, probe audit cũ dùng lịch deterministic đã chứng minh lỗi riêng.

F001 covered: 5 types × ALL/PARTIAL late POST rỗng/saved; GET timeout; exact boundary; submit và autosave chờ writer qua deadline; saved-valid autosave commit trước request timeout chốt. Expected độc lập0/2/4.5 và giữ choices đã lưu, không tăng lên10 từ form muộn.

F002 covered: sequential duplicate; 8 requests đồng thời mỗi ALL/PARTIAL (16 submissions tổng), đúng1 writer/5 answer upserts mỗi attempt; queued autosave after submit409; regrade equality/dung counts; fault sau answer write đầu rollback và retry; test-only SQLite trigger làm conditional UPDATE trả rowcount0, cả score/answers không commit. Expected500 trong fault injection là bước kiểm rollback, không lỗi vận hành không giải thích.

F003 covered: ma trận20 ô với một comma-topic (20 câu), hai chủ đề gồm comma-topic (40 câu), mỗi cấu hình10 draws, IDs unique/type-level quota/subject-topic filters; 14 legacy sampler cases;2 persisted rows read/init twice unchanged; JSON/marker-looking legacy names không bị nhận nhầm; source schema snapshot equality.

## Test gốc và audit harness cũ nguyên trạng

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r1-candidate --output HOTFIX_R1_EVIDENCE/original-candidate
```

Runner copy toàn bộ candidate vào staging và đặt tên thư mục `baseline-v2.3.1` chỉ để đáp ứng path hard-code của harness audit cũ. Nội dung là candidate, không dùng source khác; source path và hash script được ghi trong runner-results.json. Harness/test được copy nguyên byte, không sửa assertion. Mỗi script process riêng. Source v2.2.x/v2.3.0 khác không được lấy làm baseline.

| Script/harness | Exit | Kết quả |
|---|---:|---|
{orig_table}

6/6 test scripts PASS, có thông báo runner hoàn tất. Các tên test cũ là regression của source v2.3.1 hiện tại, không phải version baseline khác. Test v23 xác minh5 dạng/partial/weights/invalid points/shuffle/legacy; integration xác minh điểm5/10, Excel scoring roundtrip, snapshot freeze, timeout, save/reload/submit/point report; v22 all10; v2211000 student fixtures; v222 folders/import cũ; MathJax resource wiring.

Audit checks cũ: {audit_counts['PASS']} PASS, {audit_counts['FAIL']} FAIL/21. Hai HIGH check F001/F003 chuyển FAIL→PASS; không PASS cũ thành FAIL. Legacy checks: {legacy_counts['PASS']} PASS, {legacy_counts['FAIL']} FAIL/6, trạng thái giống hoàn toàn audit cũ. Global runner exit1 do7 MEDIUM chưa sửa, không giả báo toàn suite PASS.

### Race probe cũ

`race_probe.py` nguyên trạng, hash trong runner-results.json. Vẫn ép cả hai request thấy submitted_at=NULL ở fast path; correct request commit trước wrong request. Candidate recheck dưới khóa, request thua không ghi.

- Hai reads: {race['reads']}.
- Responses: {race['responses']}.
- Stored score: {race['stored_score']}; regraded: {race['regraded_from_stored_answers']}; stored fully correct: {race['stored_fully_correct']}.
- **PASS, exit0**, so với audit gốc stored10/regrade0 FAIL. Không đổi probe để tránh race.

### Browser cũ

Browser-checks.json statusPASS, local Waitress thực sự chạy, real GV/HS login, 20-câu controls cho5 dạng, autosave/reload/submit/result10 và DB20 answer rows. Preview/exam SVG MathJax hoạt động, không pageerror hoặc external request trong luồng. Screenshot/log trong original-candidate.

## Browser riêng cho F003

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/comma_browser.py --source hotfix-r1-candidate/PHAN_MEM --output HOTFIX_R1_EVIDENCE/comma-browser
```

**PASS, exit0**. GV chọn checkbox thật “Chủ đề, có dấu phẩy” cùng môn Toán; availability20/1 mỗi ô, totals4/type5/level20/đề. Form create ghi topic list + metadata; đọc lại DB; HS login→build20 đúng môn/chủ đề, không trùng→trả lời5 dạng→autosave/reload→submit→result10. Stored score={comma['score']}=regrade, answer rows={comma['answer_rows']}. Không external request/pageerror; không đổi UI. Hai screenshot: F003_teacher_comma_matrix.png, F003_exam_five_types.png.

## FAIL đã biết, ngoài phạm vi

| Finding | Severity giữ nguyên | Check | Trạng thái |
|---|---|---|---|
{fail_table}

F010 invalid snapshot probes chia0/NaN/âm/vượt max vẫn như audit (observations, không cộng vào checks). F011/F012 static và LOW/INFO không sửa, không dùng static để kết luận PASS exploit/runtime. Không đóng finding ngoài3 HIGH hoặc hạ severity.

## Tổng và giới hạn

Candidate có54 đơn vị kết quả top-level: 18 focused +6 test scripts +21 audit checks +6 legacy checks +1 race +1 browser cũ +1 comma browser = **47 PASS, 7 FAIL MEDIUM hiện hữu**. 18 baseline focused là phép so sánh riêng, không cộng vào candidate. Script gốc không có pytest case count;6 là số script thực thi đầy đủ, không phải tổng assertions.

No skipped/disabled/XFAIL trong checks đã thực thi. Windows EXE/build/firewall, physical LAN,1000 simultaneous clients, browsers khác và DB thật của trường **UNRUN** như audit; không có production. Transaction được kiểm qua nhiều SQLite connections/request threads, writer waiting, rollback và Waitress browser; chưa đo load/thời gian chờ ở quy mô trường.

Scope verification: chỉ2 source files đổi; scoring/types/UI/schema/library/test gốc giữ nguyên, old script hashes được kiểm. Baseline original ZIP/archive/checksum cũ được bảo toàn. Các bước packaging kiểm byte từng ZIP entry và checksum; không coi save/ZIP là deploy.

**F001 = {target['F001']}; F002 = {target['F002']}; F003 = {target['F003']}. HOTFIX_R1 = {status}.**
''')

write('HOTFIX_R1_REGRESSION_REPORT.md',f'''# HOTFIX ROUND 1 — REGRESSION REPORT

{common}

## Tiêu chí

HOTFIX_R1 chỉ PASS khi3 HIGH đều có runtime evidence PASS và không có regression mới trong kiểm tra bắt buộc. Finding MEDIUM/LOW/INFO vẫn giữ mức/trạng thái, không bị sửa để đạt PASS. Baseline audit source và BASELINE_LOCK cũ không được đổi.

| Phạm vi | Evidence | Kết quả |
|---|---|---|
| F001 late POST | Empty0, saved ALL2/PARTIAL4.5, exact deadline, writer-wait, saved winner after timeout | PASS; POST muộn không dùng đáp án mới |
| F002 atomic submit | Original race unchanged,8 concurrent requests/mode, queued autosave409, rollback/retry,rowcount0, regrade invariants | PASS; loser không ghi answers, regrade=score |
| F003 comma topic | 20-cell API/load/build20 và40; DOM comma select/create/result10; legacy14 cases + persisted2 | PASS;1 tên có dấu phẩy round-trip đúng, dữ liệu cũ không migration |
| SINGLE | Original v23/v22/integration, focused/live/late/browser | PASS luồng liên quan; radio/answer/scoring code không đổi |
| MULTI | Partial/duplicate/invalid choice unit cases, live/late/browser/concurrency | PASS luồng; không đổi answer set/penalty |
| TF | ALL/PARTIAL weights1,3, autosave/result | PASS luồng; dữ liệu invalid ngoài scope vẫn như audit |
| MATCH | Shuffle unit/integration, weights/partial, DOM select | PASS luồng; không đổi shuffle/answer logic |
| FILL | Synonyms/case/NFC/diacritics unit,partial/late/browser input | PASS luồng; question_types byte-identical |
| ALL/PARTIAL | Focused5-type ALL2,PARTIAL4.5; all-correct10; integrationpartial5 | PASS, không đổi công thức |
| weights/max_score | scoring unit + audit481 bounded-grade cases/13 invalid-config rejects; focused weighted scoring | PASS phạm vi dữ liệu hợp lệ; F010 corrupted-snapshot observations không sửa |
| Snapshot scoring | Bank scoring changed to1000/all after login; snapshot vẫn4.5; integration frozen timeout | PASS; max/mode/weights của snapshot không đổi theo bank |
| Ma trận5×4 | Original audit50 draws; original browser totals; comma20/40 +10 draws/config | PASS; số lượng/type/level/random/unique không đổi |
| Môn/chủ đề | Availability/shortage/subject-topic matching + comma serialization | PASS luồng; F004 lowercase legacy vẫn FAIL ngoài scope |
| Autosave | Five types saved/reload; before-deadline accepted, at/after409; queued after submitted409; valid save winning lock retained | PASS; session null-token rule F017 giữ nguyên |
| Submit | Live/expired/GET timeout/duplicate/concurrent/rollback | PASS theo chính sách deadline và chốt mới được yêu cầu |
| Result/point report | Browser10, auditweighted4.5, v23integrationpoints/monitor/export | PASS luồng hợp lệ; F007 result stale-token vẫn FAIL ngoài scope |
| Legacy/data/schema |14 legacy sampler cases;2 actual persisted CSV rows unchanged after2 init; schema equality; old migrations/import fixtures | PASS đã thử; không có schema/data rewrite application |
| HS/GV/quản lý cũ |6 original scripts + audit/legacy existing passes | Không PASS cũ thành FAIL; known issues giữ nguyên |
| UI/MathJax |26 templates +static byte-identical; browser previews/exam SVG; comma checkbox flow | Không đổi UI; MathJax/browser scenarios PASS |

## So sánh với audit

- Original audit checks:14 PASS/7 FAIL →16 PASS/5 FAIL; chỉ F001/F003 đổi FAIL→PASS.
- Original race scenario: FAIL stored10/regrade0 →PASS stored10/regrade10.
- Original legacy checks:4 PASS/2 FAIL giữ nguyên; không mask lỗi export/editor.
- Original browser:PASS giữ nguyên. Original6 scripts:PASS giữ nguyên.
- New focused18 checks: candidate18 PASS; cùng file test trên baseline {before['counts'].get('PASS',0)} PASS/{before['counts'].get('FAIL',0)} FAIL. Concurrency baseline có yếu tố lịch chạy, nên probe deterministic là bằng chứng chính cho race cũ.
- JSON/static probes invalid scoring không đổi. AST/source hash bảo đảm60 file khác nguyên byte và không chỉnh function ngoài targets trong2 file.

7 FAIL còn lại được giữ và báo nguyên trạng: F004,F005,F006,F007,F008,F009,F017. F010–F016 và các rủi ro static không tự xử lý. Việc thêm topic-format metadata chỉ phục vụ F003; không thêm question kind, level, scoring option hoặc UI feature.

## Giới hạn và điểm dừng

PASS áp dụng HOTFIX ROUND1 trong phạm vi kiểm thử có bằng chứng, không phải tuyên bố phần mềm không còn lỗi hoặc production-ready. Không kiểm Windows/EXE/LAN vật lý/DB trường/1000 concurrency. Không suy đoán sửa các legacy CSV row đã mơ hồ; candidate đọc đúng hợp đồng dữ liệu cũ và tạo representation mới rõ ràng khi cần. Schema không đổi, metadata mới không cam kết cho binary cũ đọc ngược.

Đã tạo candidate ZIP +4 báo cáo +evidence +CHECKSUMS.sha256. Baseline/sourceZIP/audit archive được giữ nguyên. Không bump version/v2.4/production/commit/push, không tự khóa baseline mới. Đã dừng và chờ người dùng duyệt HOTFIX ROUND1.

**F001 = {target['F001']}**

**F002 = {target['F002']}**

**F003 = {target['F003']}**

**HOTFIX_R1 = {status}**
''')
(E/'final-status.json').write_text(json.dumps(dict(HOTFIX_R1=status,findings=target,no_new_regressions_in_required_checks=no_new_regression,original_tests_pass=tests_ok,candidate_top_level_checks={'pass':47,'fail_known_medium':7},unchanged_medium_findings=sorted(fail_map[x['name']] for x in remaining),scope='F001/F002/F003 only',production=False,version_bumped=False,baseline_lock_changed=False),indent=2))
print('Reports generated:',status,target)
