from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import messagebox, filedialog
from cryptography.hazmat.primitives import serialization
from license_core import annual_message, normalize_machine_id, normalize_owner, PUBLIC_KEY_PEM


def issue(key_path,mid,owner,start):
    mid=normalize_machine_id(mid)
    if len(mid)!=20 or not normalize_owner(owner):
        raise ValueError('Điền Machine ID 20 ký tự và tên đơn vị.')
    begin=datetime.strptime(start,'%Y-%m-%d')
    try: end=begin.replace(year=begin.year+1)
    except ValueError: end=begin.replace(year=begin.year+1,day=28)
    key=serialization.load_pem_private_key(Path(key_path).read_bytes(),password=None)
    actual=key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)
    if actual!=PUBLIC_KEY_PEM:
        raise ValueError('Khóa này không khớp với phần mềm v2.2 đang dùng.')
    a,b=begin.strftime('%Y%m%d'),end.strftime('%Y%m%d')
    sig=key.sign(annual_message(mid,owner,a,b)).hex().upper()
    return 'YEAR.'+a+'.'+b+'.'+sig


def main():
    root=tk.Tk();root.title('Cấp mã ThiTracNghiemLAN - 1 năm');root.geometry('760x490')
    inputs=[]
    for label,default in [('Machine ID',''),('Tên đơn vị',''),('Ngày bắt đầu (YYYY-MM-DD, UTC)',datetime.utcnow().strftime('%Y-%m-%d'))]:
        tk.Label(root,text=label).pack(anchor='w',padx=12)
        e=tk.Entry(root,width=90);e.insert(0,default);e.pack(padx=12,pady=5);inputs.append(e)
    tk.Label(root,text='Chọn ngày khách hàng bắt đầu sử dụng. Hết hạn trước cùng ngày năm sau (UTC).').pack()
    output=tk.Text(root,height=8,width=88);output.pack(padx=12,pady=12)
    def generate():
        key=filedialog.askopenfilename(title='Chọn license_private_key.pem của chủ sở hữu',filetypes=[('PEM','*.pem')])
        if not key:return
        try:
            code=issue(key,*(x.get().strip() for x in inputs))
            output.delete('1.0','end');output.insert('1.0',code)
        except Exception as e:messagebox.showerror('Không cấp được mã',str(e))
    tk.Button(root,text='Chọn khóa riêng và tạo mã 1 năm',command=generate).pack(pady=5)
    def copy():
        root.clipboard_clear();root.clipboard_append(output.get('1.0','end').strip())
    tk.Button(root,text='Sao chép mã',command=copy).pack()
    root.mainloop()

if __name__=='__main__':main()
