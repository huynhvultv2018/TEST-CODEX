@echo off
cd /d "%~dp0"
py -3 -m pip install cryptography
if errorlevel 1 goto end
py -3 TaoMa1Nam.py
:end
pause
