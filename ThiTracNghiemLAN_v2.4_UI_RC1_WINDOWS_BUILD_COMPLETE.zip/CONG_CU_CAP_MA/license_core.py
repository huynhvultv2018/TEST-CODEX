import re

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization


PRODUCT_ID = "THITRACNGHIEMLAN"
LICENSE_VERSION = "2.1"
LICENSE_TYPE = "PERPETUAL"

PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAFBMKOVJJm1A4ZXsd66CPHZDhC41wAGr4puBUkK/PzH4=
-----END PUBLIC KEY-----
"""


def normalize_machine_id(value):
    return re.sub(r"[^0-9A-F]", "", str(value or "").upper())


def normalize_owner(value):
    return " ".join(str(value or "").strip().upper().split())


def normalize_license_code(value):
    return re.sub(r"[^0-9A-F]", "", str(value or "").upper())


def license_message(machine_id, owner):
    return "|".join([
        PRODUCT_ID,
        LICENSE_VERSION,
        normalize_machine_id(machine_id),
        normalize_owner(owner),
        LICENSE_TYPE,
    ]).encode("utf-8")


def verify_legacy_license(code, machine_id, owner):
    clean_code = normalize_license_code(code)
    clean_mid = normalize_machine_id(machine_id)
    clean_owner = normalize_owner(owner)
    if len(clean_code) != 128 or len(clean_mid) != 20 or not clean_owner:
        return False
    try:
        signature = bytes.fromhex(clean_code)
        public_key = serialization.load_pem_public_key(PUBLIC_KEY_PEM)
        public_key.verify(signature, license_message(clean_mid, clean_owner))
        return True
    except (ValueError, TypeError, InvalidSignature):
        return False


def format_legacy_code(code):
    clean = normalize_license_code(code)
    return "-".join(clean[i:i + 8] for i in range(0, len(clean), 8))


# Annual codes contain a signed start date and expiry; re-entering a code
# cannot extend its validity. The issuer selects the customer's activation day.
from datetime import datetime, timezone
import json, math


def annual_message(mid, owner, start, end):
    return "|".join([PRODUCT_ID, "2.2", normalize_machine_id(mid),
                     normalize_owner(owner), "ANNUAL", start, end]).encode("utf-8")


def format_license_code(code):
    code = str(code or "").strip()
    return code if code.startswith("YEAR.") else format_legacy_code(code)


def license_details(code, mid, owner, now=None):
    now = now or datetime.now(timezone.utc)
    try:
        if str(code).startswith("YEAR."):
            tag, start, end, signature = code.strip().split(".")
            begin = datetime.strptime(start, "%Y%m%d").replace(tzinfo=timezone.utc)
            expiry = datetime.strptime(end, "%Y%m%d").replace(tzinfo=timezone.utc)
            public_key = serialization.load_pem_public_key(PUBLIC_KEY_PEM)
            public_key.verify(bytes.fromhex(signature), annual_message(mid, owner, start, end))
            expected = begin.replace(year=begin.year+1) if not (begin.month==2 and begin.day==29) else begin.replace(year=begin.year+1, day=28)
            if expiry != expected:
                raise ValueError("Invalid term")
            active = begin <= now < expiry
            return dict(active=active, kind="annual", expires=end,
                        label=("Đã kích hoạt 1 năm" if active else "Giấy phép chưa có hiệu lực hoặc đã hết hạn") +
                        " — từ " + begin.strftime("%d/%m/%Y") + " đến trước " + expiry.strftime("%d/%m/%Y") + " (UTC)")
        if verify_legacy_license(code, mid, owner):
            return dict(active=True, kind="legacy", label="Giấy phép vĩnh viễn đã cấp trước đây")
    except (ValueError, TypeError, InvalidSignature, OverflowError):
        pass
    return dict(active=False, kind="invalid", label="Chưa có mã kích hoạt hợp lệ")


def verify_license_code(code, machine_id, owner):
    return license_details(code, machine_id, owner)["active"]


def _trial_status(paths, mid, now=None):
    # Two copies survive a database restore or moving the program folder.
    # This offline state is tamper-resistant only against casual resets.
    stamp = (now or datetime.now(timezone.utc)).timestamp()
    states=[]
    try:
        for path in paths:
            if path.exists():
                obj=json.loads(path.read_text(encoding="utf-8"))
                if obj["mid"] != mid or not all(math.isfinite(obj[k]) for k in ("start","last")):
                    raise ValueError("Invalid trial state")
                states.append(obj)
        start=min([x["start"] for x in states], default=stamp)
        last=max([x["last"] for x in states], default=stamp)
        if stamp < last-300 or start > last:
            return dict(active=False, kind="clock", label="Cần kiểm tra ngày giờ máy chủ")
        last=max(last,stamp)
        state=json.dumps(dict(mid=mid,start=start,last=last))
        for path in paths:
            path.parent.mkdir(parents=True,exist_ok=True)
            temp=path.with_suffix(".tmp")
            temp.write_text(state,encoding="utf-8")
            temp.replace(path)
        remaining=max(0,math.ceil((start+7*86400-stamp)/86400))
        return dict(active=stamp < start+7*86400, kind="trial", label=(
            "Dùng thử miễn phí — còn %s ngày" % remaining if remaining else "Đã hết 7 ngày dùng thử"))
    except (OSError, ValueError, KeyError, TypeError):
        return dict(active=False,kind="state",label="Không đọc/ghi được thời hạn dùng thử; liên hệ hỗ trợ")

from threading import Lock
_state_lock = Lock()

def trial_status(paths, mid, now=None):
    with _state_lock:
        return _trial_status(paths, mid, now)
