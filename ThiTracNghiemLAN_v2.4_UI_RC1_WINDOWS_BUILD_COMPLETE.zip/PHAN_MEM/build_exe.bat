@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title Dong goi Thi Trac Nghiem LAN v2.3 Thuong mai

echo ========================================================
echo      DONG GOI THI TRAC NGHIEM LAN v2.3 THUONG MAI
echo ========================================================

where py >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=py -3"
    goto :python_found
)
where python >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=python"
    goto :python_found
)
echo LOI: May chua cai Python.
echo Hay cai Python 3 va chon Add Python to PATH.
goto :failed

:python_found

if not exist "app.py" (
    echo LOI: Khong tim thay app.py trong thu muc nay.
    goto :failed
)
if not exist "templates\teacher.html" (
    echo LOI: Khong tim thay thu muc templates day du.
    goto :failed
)

echo [1/4] Kiem tra Python...
%PYTHON_CMD% --version
if errorlevel 1 goto :failed

echo [2/4] Cai dat cong cu can thiet...
%PYTHON_CMD% -m pip install -r requirements.txt
if errorlevel 1 goto :failed

echo Kiem tra tich hop tren du lieu tam...
%PYTHON_CMD% kiem_tra_v22.py
if errorlevel 1 goto :failed
%PYTHON_CMD% kiem_tra_v221.py
if errorlevel 1 goto :failed
%PYTHON_CMD% kiem_tra_mathjax.py
if errorlevel 1 goto :failed
%PYTHON_CMD% kiem_tra_v222.py
if errorlevel 1 goto :failed

%PYTHON_CMD% kiem_tra_v23.py
if errorlevel 1 goto :failed
%PYTHON_CMD% kiem_tra_v23_integration.py
if errorlevel 1 goto :failed

echo [3/4] Dong goi file EXE...
%PYTHON_CMD% -m PyInstaller --noconfirm --clean --onefile --console ^
  --name ThiTracNghiemLAN ^
  --add-data "templates;templates" ^
  --add-data "static;static" ^
  --hidden-import waitress ^
  --collect-all openpyxl ^
  --collect-all cryptography ^
  app.py
if errorlevel 1 goto :failed

echo [4/4] Tao bo chay hoan chinh...
if not exist "dist\templates" mkdir "dist\templates"
xcopy "templates" "dist\templates" /E /I /Y >nul
if not exist "dist\static" mkdir "dist\static"
xcopy "static" "dist\static" /E /I /Y >nul
copy /Y "CHAY_MAY_CHU.bat" "dist\CHAY_MAY_CHU.bat" >nul
copy /Y "CAU_HINH_FIREWALL.bat" "dist\CAU_HINH_FIREWALL.bat" >nul
copy /Y "HUONG_DAN_SU_DUNG.txt" "dist\HUONG_DAN_SU_DUNG.txt" >nul
copy /Y "HUONG_DAN_V22.txt" "dist\HUONG_DAN_V22.txt" >nul
copy /Y "README_v2.2.txt" "dist\README_v2.2.txt" >nul
copy /Y "README_v2.2.1.txt" "dist\README_v2.2.1.txt" >nul
copy /Y "README_v2.3.txt" "dist\README_v2.3.txt" >nul
copy /Y "Mau_DanhSachHocSinh.xlsx" "dist\Mau_DanhSachHocSinh.xlsx" >nul
copy /Y "Mau_NganHangCauHoi.xlsx" "dist\Mau_NganHangCauHoi.xlsx" >nul
if not exist "dist\backups" mkdir "dist\backups"
if not exist "dist\exports" mkdir "dist\exports"
if not exist "dist\imports" mkdir "dist\imports"
if not exist "dist\logs" mkdir "dist\logs"
if not exist "dist\uploads" mkdir "dist\uploads"

if not exist "dist\ThiTracNghiemLAN.exe" (
    echo LOI: Khong tao duoc file EXE.
    goto :failed
)

echo.
echo ========================================================
echo THANH CONG: dist\ThiTracNghiemLAN.exe
echo Mo thu muc dist va chay CHAY_MAY_CHU.bat
echo ========================================================
start "" "%~dp0dist"
pause
exit /b 0

:failed
echo.
echo DONG GOI KHONG THANH CONG. Hay chup cac dong loi phia tren.
pause
exit /b 1
