THI TRẮC NGHIỆM LAN v2.2.2 — NGÂN HÀNG THEO KHỐI VÀ MÔN

NÂNG CẤP CHÍNH
- Tổ chức câu hỏi thành thư mục Khối → Môn học.
- Mỗi thư mục hiển thị số lượng câu hỏi và mở bằng một lần nhấp.
- Nhập Excel trực tiếp vào Khối và Môn đã chọn.
- Lọc theo khối, môn, chủ đề, loại câu, mức độ, mã hoặc nội dung.
- Phân trang 25/50/100 câu, không tải toàn bộ danh sách dài cùng lúc.
- Xuất riêng thư mục đang chọn ra Excel.
- Mẫu Excel v2.2.2 có thêm cột Khối; vẫn nhập được mẫu 8 cột v2.2.1.
- Tự suy luận khối cho dữ liệu cũ từ môn, chủ đề hoặc mã như DS8, HH8, TIN6.
- Câu chưa xác định được khối nằm trong thư mục Chưa phân loại.

TƯƠNG THÍCH
- Giữ nguyên MathJax ngoại tuyến, 5 dạng câu hỏi, tạo đề, thi LAN, giám sát,
  báo cáo, quản lý học sinh, sao lưu và bản quyền của v2.2.1.
- Khi mở v2.2.2 lần đầu, cơ sở dữ liệu cũ được nâng cấp tự động.

SỬ DỤNG
1. Vào Trang giáo viên → Mở ngân hàng 5 dạng.
2. Chọn Khối và nhập tên Môn tại mục Nhập Excel vào thư mục.
3. Chọn tệp .xlsx rồi bấm Kiểm tra và nhập Excel.
4. Nhấp thư mục Khối → Môn để xem; dùng bộ lọc nếu cần tìm nhanh.
