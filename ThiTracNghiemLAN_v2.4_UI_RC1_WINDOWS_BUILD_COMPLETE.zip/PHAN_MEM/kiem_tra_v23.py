from scoring import grade, total_score, config
from question_types import snapshot
import json

def main():
    for kind,answer,value,expected in [
        ('SINGLE',0,0,2),('MULTI',[0,2],[0],1),
        ('MULTI',[0,2],[0,1,2],1),('MULTI',[0,2],[1],0),
        ('TF',['D','S'],['D','D'],1),('MATCH',[1,0],[1,None],1),
        ('FILL',[['hai','2'],['ba','3']],[' HAI ',''],1)]:
        item=dict(type=kind,options=['a','b','c'],answer=answer,scoring=dict(points=2,mode='partial'))
        assert grade(item,value)==(expected,2),(kind,value)
        assert grade(item,None)==(0,2)
    item=dict(type='TF',answer=['D','S'],scoring=dict(points=4,mode='partial',weights=[1,3]))
    assert grade(item,['D','D'])==(1,4)
    assert total_score([item],{0:['D','D']})==2.5
    assert total_score([dict(type='SINGLE',answer=0)],{0:0})==10
    for bad in ('nan','inf','-1','0'):
        try: config({'points':bad},'TF',2)
        except ValueError: pass
        else: raise AssertionError(bad)
    row=dict(id=1,question_type='MATCH',noi_dung='Test',hinh_anh='',payload=json.dumps(dict(options=['x','y'],right=['1','2'],answer=[0,1],scoring=dict(points=4,mode='partial',weights=[1,3]))))
    for i in range(20):
        q=snapshot(row)
        assert grade(q,[q['answer'][0],None])==(1,4)
    print('PASS v2.3: five kinds, partial credits, weights, invalid points, shuffled matching, legacy defaults.')

if __name__=='__main__': main()
