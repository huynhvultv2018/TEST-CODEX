"""Validate stored question data without repairing it or changing scoring rules."""
import json
import math


class SnapshotValidationError(ValueError):
    pass


def reject(message):
    raise SnapshotValidationError(message)


def number(value, label):
    if type(value) not in (int, float) or not 0 < value <= 1000 or not math.isfinite(value):
        reject(label + ' phải là số hữu hạn, lớn hơn 0 và không quá 1000.')


def validate_item(item, full=False):
    if not isinstance(item, dict):
        reject('Câu hỏi phải là một đối tượng.')
    kind = item.get('type', 'SINGLE')
    if kind not in ('SINGLE', 'MULTI', 'TF', 'MATCH', 'FILL'):
        reject('Loại câu hỏi trong snapshot không hợp lệ.')
    options = item.get('options')
    if options is not None and (not isinstance(options,list) or not options or not all(isinstance(x,str) for x in options)):
        reject('Các mục câu hỏi trong snapshot không hợp lệ.')
    if full or kind == 'MULTI':
        if not isinstance(options, list) or not options or not all(isinstance(x, str) for x in options):
            reject('Các mục câu hỏi trong snapshot không hợp lệ.')
        if not (2 <= len(options) <= 20 if kind in ('SINGLE', 'MULTI') else 1 <= len(options) <= 30):
            reject('Số mục câu hỏi trong snapshot không hợp lệ.')
    answer = item.get('answer')
    if kind == 'SINGLE':
        if type(answer) is not int or answer < 0 or (options is not None and answer >= len(options)):
            reject('Đáp án SINGLE trong snapshot không hợp lệ.')
    else:
        if not isinstance(answer, list) or not answer:
            reject('Danh sách đáp án trong snapshot không được rỗng.')
        if full and kind != 'MULTI' and len(answer) != len(options):
            reject('Số đáp án không khớp số mục câu hỏi.')
        if kind == 'MULTI':
            if any(type(x) is not int or not 0 <= x < len(options) for x in answer) or len(set(answer)) != len(answer):
                reject('Đáp án MULTI trong snapshot không hợp lệ.')
        elif kind == 'TF':
            if any(x not in ('D', 'S') for x in answer):
                reject('Đáp án TF trong snapshot không hợp lệ.')
        elif kind == 'MATCH':
            if any(type(x) is not int or not 0 <= x < len(answer) for x in answer) or len(set(answer)) != len(answer):
                reject('Đáp án MATCH trong snapshot không hợp lệ.')
            if full:
                right = item.get('right')
                if not isinstance(right, list) or len(right) != len(answer) or not all(isinstance(x, str) for x in right) or len(set(right)) != len(right):
                    reject('Cột phải MATCH trong snapshot không hợp lệ.')
        elif any(not isinstance(xs, list) or not xs or any(not isinstance(x, str) or not x.strip() for x in xs) for xs in answer):
            reject('Đáp án FILL trong snapshot không hợp lệ.')
    rule = item.get('scoring', {})
    if not isinstance(rule, dict):
        reject('Cấu hình scoring trong snapshot không hợp lệ.')
    # Absence/empty rule is the documented legacy 1/all contract. Older rule
    # representations may omit mode/weights/version, which have existing defaults.
    if rule:
        if 'points' not in rule:
            reject('Cấu hình scoring thiếu điểm tối đa.')
        number(rule['points'], 'Điểm tối đa')
        if rule.get('mode', 'all') not in ('all', 'partial'):
            reject('Cách chấm trong snapshot không hợp lệ.')
        if 'version' in rule and (type(rule['version']) is not int or rule['version'] != 1):
            reject('Phiên bản scoring trong snapshot không hợp lệ.')
        if 'version' in rule and not all(k in rule for k in ('points','mode','weights')):
            reject('Cấu hình scoring version 1 thiếu trường bắt buộc.')
        weights = rule.get('weights', [])
        if not isinstance(weights, list):
            reject('Trọng số trong snapshot phải là danh sách.')
        if weights:
            if kind not in ('TF', 'MATCH', 'FILL') or len(weights) != len(answer):
                reject('Trọng số không khớp loại câu hoặc số ý.')
            for weight in weights:
                number(weight, 'Trọng số')
            if not math.isfinite(sum(weights)) or sum(weights) <= 0:
                reject('Tổng trọng số trong snapshot không hợp lệ.')
    if full:
        if type(item.get('id')) is not int or not 0 < item['id'] <= 2**63-1 or not isinstance(item.get('q'), str):
            reject('Snapshot thiếu mã/nội dung câu hỏi hợp lệ.')
        if 'history' in item:
            history = item['history']
            if not isinstance(history, dict) or not all(isinstance(history.get(k), str) for k in ('ma_cau', 'mon', 'chu_de', 'muc_do')):
                reject('Metadata lịch sử trong snapshot không hợp lệ.')
    return item


def parse_json(text, label):
    try:
        return json.loads(text)
    except (ValueError, TypeError, RecursionError):
        reject(label + ' không phải JSON hợp lệ.')


def load_snapshot(text):
    items = parse_json(text, 'Snapshot')
    if not isinstance(items, list):
        reject('Snapshot bài thi phải là danh sách câu hỏi.')
    for item in items:
        validate_item(item, full=True)
    return items


def question_data(row):
    """Read bank/legacy rows using the existing question-type fallback contract."""
    row = dict(row)
    kind = str(row.get('question_type') or '').strip().upper()
    if kind not in ('SINGLE', 'MULTI', 'TF', 'MATCH', 'FILL'):
        kind = 'SINGLE'
    if row.get('payload'):
        item = parse_json(row['payload'], 'Payload câu hỏi')
        if not isinstance(item, dict):
            reject('Payload câu hỏi phải là một đối tượng.')
    else:
        letter = str(row.get('dap_an_dung') or '').strip().upper()
        if letter not in ('A', 'B', 'C', 'D'):
            reject('Đáp án legacy phải là A, B, C hoặc D.')
        item = {'options': [row.get(x) for x in ('a', 'b', 'c', 'd')], 'answer': 'ABCD'.index(letter)}
    item.update(id=row.get('id'), q=row.get('noi_dung'), type=kind, image=row.get('hinh_anh') or '')
    return validate_item(item, full=True)
