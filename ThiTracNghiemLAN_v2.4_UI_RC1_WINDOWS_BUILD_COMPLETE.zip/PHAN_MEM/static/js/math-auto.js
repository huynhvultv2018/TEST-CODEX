(function () {
  "use strict";

  // Tự nhận dạng 4x^2, 7x^3y^2, -5a^2b và lệnh LaTeX thiếu dấu $.
  const plainPower = /[-+]?(?:\d+(?:[.,]\d+)?)?[A-Za-z](?:[A-Za-z0-9{}]*[\^_][{]?(?:-?\d+|[A-Za-z]+|\\[A-Za-z]+)[}]?)+[A-Za-z0-9{}]*/g;
  const latexCommand = /\\(?:d?frac|sqrt|widehat|overline|vec|angle|sin|cos|tan|log|ln)(?:\s*\{[^{}\r\n]*\}){1,3}(?:\s*[\^_]\s*\{?[^\s,.;:!?)]*\}?)?/g;
  const atom = "(?:(?:\\d+(?:[.,]\\d+)?)?[A-Za-z](?:[A-Za-z0-9]*(?:[\\^_][{]?(?:-?\\d+|[A-Za-z]+|\\\\[A-Za-z]+)[}]?)*)[A-Za-z0-9]*|\\d+(?:[.,]\\d+)?)";
  const plainFraction = new RegExp("([-+]?" + atom + ")\\s*\\/\\s*([-+]?" + atom + ")", "g");
  const exactFraction = new RegExp("^([-+]?" + atom + ")\\s*\\/\\s*([-+]?" + atom + ")$");
  const plainRoot = /\b(?:sqrt|SQRT)\s*(?:\(([^()\r\n]+)\)|\{([^{}\r\n]+)\}|([-+]?[A-Za-z0-9]+(?:[\^_][{]?[A-Za-z0-9+\\-]+[}]?)?))/g;
  const unicodeRoot = /√\s*(?:\(([^()\r\n]+)\)|\{([^{}\r\n]+)\}|([-+]?[A-Za-z0-9]+(?:[\^_][{]?[A-Za-z0-9+\\-]+[}]?)?))/g;
  const explicitMath = /\$|\\\(|\\\[|\\begin\s*\{/;

  function wrapMatches(text) {
    if (!text || explicitMath.test(text)) return text;
    const matches = [];
    function collect(pattern, priority, toTex) {
      pattern.lastIndex = 0;
      let match;
      while ((match = pattern.exec(text))) {
        matches.push({start:match.index,end:match.index + match[0].length,
                      priority:priority,tex:toTex(match)});
        if (!match[0].length) pattern.lastIndex++;
      }
    }
    function rootTex(match) {
      const value=(match[1]||match[2]||match[3]||"").trim();
      const fraction=value.match(exactFraction);
      const inside=fraction ? "\\frac{"+fraction[1]+"}{"+fraction[2]+"}" : value;
      return "\\sqrt{"+inside+"}";
    }
    collect(plainRoot,4,rootTex);
    collect(unicodeRoot,4,rootTex);
    collect(plainFraction,3,m=>"\\frac{"+m[1]+"}{"+m[2]+"}");
    collect(latexCommand,2,m=>m[0]);
    collect(plainPower,1,m=>m[0]);
    if (!matches.length) return text;
    matches.sort((a,b)=>a.start-b.start || b.priority-a.priority || b.end-a.end);
    const selected=[];
    matches.forEach(item=>{
      const last=selected[selected.length-1];
      if(!last || item.start>=last.end) selected.push(item);
    });
    let output = "", cursor = 0;
    selected.forEach(item => {
      output += text.slice(cursor,item.start) + "\\(" + item.tex + "\\)";
      cursor = item.end;
    });
    return output + text.slice(cursor);
  }

  function prepareElement(root) {
    if (!root || root.closest("mjx-container")) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      const parent = node.parentElement;
      if (!parent || parent.closest("script,style,textarea,input,select,option,mjx-container")) return;
      const converted = wrapMatches(node.nodeValue);
      if (converted !== node.nodeValue) node.nodeValue = converted;
    });
  }

  window.autoPrepareMath = function (nodes) {
    Array.from(nodes || document.querySelectorAll(".math-content")).forEach(prepareElement);
  };
  window.autoMathText = wrapMatches;
  window.autoPrepareMath();
}());
