/* Navigation changes presentation only; R4 choice/save/tick/ping/POST remain authoritative. */
(() => {
  const questions = [...document.querySelectorAll('.question')], buttons = [...document.querySelectorAll('[data-jump]')];
  const form = document.getElementById('form'), dialog = document.getElementById('submit_dialog');
  let current = 0; const flags = new Set();
  const storageKey = `exam-review:${form.dataset.attempt}`;
  try { JSON.parse(sessionStorage.getItem(storageKey) || '[]').forEach(i => { if (Number.isInteger(i) && i >= 0 && i < questions.length) flags.add(i); }); } catch (_) {}
  function answered(q) {
    const v = choice(q);
    return q.dataset.kind === 'SINGLE' ? Number.isInteger(v) : q.dataset.kind === 'MULTI' ? v.length > 0 : v.length > 0 && v.every(x => x !== null && String(x).trim() !== '');
  }
  function update() {
    buttons.forEach((b,i) => {
      const done = answered(questions[i]); b.classList.toggle('answered',done); b.classList.toggle('flagged',flags.has(i));
      b.setAttribute('aria-current',String(i === current));
      b.setAttribute('aria-label',`Câu ${i+1}: ${done ? 'Đã trả lời' : 'Chưa trả lời'}${flags.has(i) ? ', Đánh dấu xem lại' : ''}${i === current ? ', Hiện tại' : ''}`);
      b.title = b.getAttribute('aria-label');
    });
    document.getElementById('question_position').textContent = `Câu ${current+1} / ${questions.length}`;
    document.getElementById('answered_summary').textContent = `${questions.filter(answered).length} / ${questions.length} câu đã trả lời`;
    document.getElementById('question_prev').disabled = current === 0;
    document.getElementById('question_next').disabled = current === questions.length-1;
    const flag = document.getElementById('question_flag'); flag.setAttribute('aria-pressed',String(flags.has(current))); flag.textContent = flags.has(current) ? '★ Bỏ đánh dấu' : '☆ Đánh dấu xem lại';
  }
  function show(i) {
    current = Math.max(0,Math.min(questions.length-1,i)); questions.forEach((q,j) => { q.hidden = j !== current; }); update();
    if (window.renderMath) window.renderMath([questions[current]]);
  }
  buttons.forEach((b,i) => b.addEventListener('click',() => show(i)));
  document.getElementById('question_prev').addEventListener('click',() => show(current-1));
  document.getElementById('question_next').addEventListener('click',() => show(current+1));
  document.getElementById('question_flag').addEventListener('click',() => { flags.has(current) ? flags.delete(current) : flags.add(current); try { sessionStorage.setItem(storageKey,JSON.stringify([...flags])); } catch (_) {} update(); });
  questions.forEach(q => {
    q.addEventListener('input',update); q.addEventListener('change',update);
    const state = document.getElementById(`s${q.dataset.index}`);
    const decorate = () => { state.dataset.saveState = state.textContent === 'Đã lưu' ? 'saved' : state.textContent.startsWith('Đang lưu') ? 'saving' : state.textContent ? 'failed' : 'empty'; };
    state.setAttribute('role','status'); new MutationObserver(decorate).observe(state,{childList:true,characterData:true,subtree:true}); decorate();
  });
  const timer = document.getElementById('timer'); new MutationObserver(() => timer.classList.toggle('near-end',left <= 300)).observe(timer,{childList:true});
  window.openSubmitDialog = () => {
    const missing = questions.map((q,i) => answered(q) ? null : i+1).filter(i => i !== null);
    document.getElementById('submit_summary').textContent = `Em đã trả lời ${questions.length-missing.length} / ${questions.length} câu.`;
    document.getElementById('submit_missing').textContent = missing.length ? `Còn ${missing.length} câu chưa trả lời: ${missing.join(', ')}.` : 'Tất cả câu đã được trả lời. Em hãy kiểm tra trước khi nộp.';
    if (!dialog.open) dialog.showModal();
  };
  document.getElementById('open_submit').addEventListener('click',window.openSubmitDialog);
  document.getElementById('cancel_submit').addEventListener('click',() => dialog.close());
  document.getElementById('confirm_submit').addEventListener('click',() => { if (!submitted) { submitted = true; form.submit(); } });
  show(0);
})();
