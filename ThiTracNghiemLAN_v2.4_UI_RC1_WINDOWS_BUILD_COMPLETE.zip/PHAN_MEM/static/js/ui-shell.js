/* UI v2.4: presentation over unchanged R4 routes and data. */
document.addEventListener('DOMContentLoaded', () => {
  const path = location.pathname, view = new URLSearchParams(location.search).get('view');
  let active = 'dashboard';
  if (path.includes('/monitor/') || view === 'monitor') active = 'monitor';
  else if (path.includes('/report/') || path.includes('/analytics')) active = 'reports';
  else if (path.includes('/students')) active = 'students';
  else if (path.includes('/multi') && !path.includes('mixed-exam') || path.includes('/question') || view === 'bank') active = 'bank';
  else if (path.includes('mixed-exam') || view === 'exams') active = 'exams';
  else if (path.includes('/license')) active = 'license';
  else if (path !== '/teacher') active = 'system';
  document.querySelectorAll('[data-nav]').forEach(a => { if (a.dataset.nav === active) a.setAttribute('aria-current', 'page'); });
  document.querySelectorAll('[data-module]').forEach(s => { s.hidden = s.dataset.module !== (['exams','monitor','bank'].includes(view) ? view : 'dashboard'); });

  const wizard = document.getElementById('createExamForm');
  if (wizard) {
    const steps = [...wizard.querySelectorAll('[data-wizard-step]')]; let step = 0;
    const prev = document.getElementById('wizard_prev'), next = document.getElementById('wizard_next');
    function showStep() {
      steps.forEach((s,i) => { s.hidden = i !== step; });
      wizard.querySelectorAll('.wizard-stepper span').forEach((s,i) => s.classList.toggle('active', i === step));
      prev.disabled = step === 0; next.hidden = step === steps.length - 1;
      if (step === 3) {
        const f = wizard.elements;
        document.getElementById('wizard_summary').textContent = `${f.ten.value} · ${f.lop.value || 'Tất cả lớp'} · ${f.mon.value || 'Tất cả môn'} · ${f.thoi_gian.value} phút · ${document.getElementById('requested_total_text').textContent} câu. Chủ đề: ${selectedTopics().join(' / ') || 'Tất cả'}.`;
      }
    }
    next.addEventListener('click', () => {
      const invalid = [...steps[step].querySelectorAll('input,select')].find(x => !x.checkValidity());
      if (invalid) { invalid.reportValidity(); return; }
      step = Math.min(steps.length - 1, step + 1); showStep();
    });
    prev.addEventListener('click', () => { step = Math.max(0, step - 1); showStep(); });
    wizard.addEventListener('invalid', e => { const s = e.target.closest('[data-wizard-step]'); if (s) { step = steps.indexOf(s); showStep(); } }, true);
    showStep();
  }

  const tabs = [...document.querySelectorAll('[data-report-tab]')];
  if (tabs.length) {
    function select(tab) {
      tabs.forEach(t => { const selected = t === tab; t.setAttribute('aria-selected', String(selected)); t.tabIndex = selected ? 0 : -1; });
      document.querySelectorAll('[data-report-panel]').forEach(p => { p.hidden = p.dataset.reportPanel !== tab.dataset.reportTab; if (!p.hidden && window.renderMath) window.renderMath([p]); });
    }
    tabs.forEach((tab,i) => {
      tab.addEventListener('click', () => select(tab));
      tab.addEventListener('keydown', e => {
        let j = null;
        if (e.key === 'ArrowRight') j = (i+1)%tabs.length;
        if (e.key === 'ArrowLeft') j = (i+tabs.length-1)%tabs.length;
        if (e.key === 'Home') j = 0;
        if (e.key === 'End') j = tabs.length-1;
        if (j !== null) { e.preventDefault(); select(tabs[j]); tabs[j].focus(); }
      });
    }); select(tabs[0]);
  }

  const exam = document.getElementById('dashboard_exam');
  if (exam && !view) {
    fetch('/health', {cache:'no-store'}).then(r => { if (!r.ok) throw Error(); return r.json(); }).then(j => {
      document.getElementById('server_health').textContent = j.ok ? '✓ Máy chủ đang phản hồi' : '⚠ Máy chủ chưa xác nhận sẵn sàng';
    }).catch(() => { document.getElementById('server_health').textContent = '⚠ Không đọc được trạng thái máy chủ'; });
    fetch('/teacher/system-status', {cache:'no-store'}).then(r => { if (!r.ok) throw Error(); return r.text(); }).then(html => {
      const info = new DOMParser().parseFromString(html,'text/html').getElementById('system_snapshot'); if (!info) throw Error();
      const ips = JSON.parse(info.dataset.ips); document.getElementById('server_address').textContent = `${ips.join(' / ') || 'Chưa xác định IP'} · Cổng ${info.dataset.port}`;
    }).catch(() => { document.getElementById('server_address').textContent = 'Chưa đọc được IP / cổng'; });
    if (exam.options.length > 1) exam.selectedIndex = 1;
    let busy = false;
    async function refresh() {
      const id = exam.value;
      document.getElementById('dashboard_monitor').href = id ? `/teacher/monitor/${id}` : '/teacher?view=monitor';
      document.getElementById('dashboard_report').href = id ? `/teacher/report/${id}` : '/teacher/analytics';
      if (!id || busy || document.hidden) return;
      busy = true;
      try {
        const r = await fetch(`/teacher/api/monitor/${id}`,{cache:'no-store'}); if (!r.ok) throw Error(); const j = await r.json(); if (!j.ok || !Array.isArray(j.students)) throw Error();
        if (exam.value !== id) return;
        const s = j.students, count = status => s.filter(x => x.status === status).length;
        const counts = {total:s.length,entered:s.filter(x => x.attempt_id != null).length,doing:count('Đang thi'),done:count('Đã nộp'),lost:count('Mất kết nối'),not:count('Chưa vào')};
        document.querySelectorAll('#dashboard_metrics [data-count]').forEach(x => { x.textContent = counts[x.dataset.count]; });
        document.getElementById('dashboard_updated').textContent = `Đã cập nhật ${new Date().toLocaleTimeString('vi-VN')}. Kết nối cuối theo API R4; tự cập nhật mỗi 5 giây.`;
      } catch (_) { document.getElementById('dashboard_updated').textContent = '⚠ Chưa cập nhật được. Các số đang hiển thị là lần đọc thành công gần nhất.'; }
      finally { busy = false; }
    }
    exam.addEventListener('change', () => { document.querySelectorAll('#dashboard_metrics [data-count]').forEach(x => { x.textContent = '—'; }); refresh(); });
    refresh(); setInterval(refresh,5000);
  }
});
