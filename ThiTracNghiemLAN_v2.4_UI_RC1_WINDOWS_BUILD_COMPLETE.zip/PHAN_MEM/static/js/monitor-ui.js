/* Keyed DOM updates; unchanged R4 API and 3-second polling interval. */
(() => {
  const root = document.getElementById('monitor'), body = document.getElementById('monitor_body'), rows = new Map();
  let filter = '', students = [], busy = false;
  function applyFilter() {
    const search = document.getElementById('monitor_search').value.trim().toLocaleLowerCase('vi-VN'); let visible = 0;
    students.forEach(s => { const row = rows.get(s.ma_hs); row.hidden = Boolean(filter && s.status !== filter || search && !`${s.ma_hs} ${s.ho_ten}`.toLocaleLowerCase('vi-VN').includes(search)); if (!row.hidden) visible++; });
    document.getElementById('monitor_empty').hidden = visible !== 0;
  }
  document.querySelectorAll('[data-filter]').forEach(b => b.addEventListener('click',() => { filter = b.dataset.filter; document.querySelectorAll('[data-filter]').forEach(x => x.setAttribute('aria-pressed',String(x === b))); applyFilter(); }));
  document.getElementById('monitor_search').addEventListener('input',applyFilter);
  function setText(el, text) { if (el.textContent !== String(text)) el.textContent = text; }
  function paint(s,i) {
    let row = rows.get(s.ma_hs);
    if (!row) {
      row = document.createElement('tr'); row.dataset.student = s.ma_hs;
      for (let j = 0; j < 8; j++) row.appendChild(document.createElement('td'));
      body.appendChild(row); rows.set(s.ma_hs,row);
    }
    const cells = row.cells; setText(cells[0],i+1); setText(cells[1],s.ma_hs); setText(cells[2],`${s.ho_ten} · ${s.lop}`);
    let status = cells[3].firstElementChild;
    if (!status) { status = document.createElement('span'); cells[3].appendChild(status); }
    const kind = {'Đang thi':'doing','Mất kết nối':'lost','Đã nộp':'done','Chưa vào':'not'}[s.status] || 'error';
    status.className = `status ${kind}`; setText(status,`${s.status === 'Đã nộp' ? '✓ ' : s.status === 'Mất kết nối' ? '⚠ ' : ''}${s.status}`);
    cells[3].title = `Kết nối cuối: ${s.last_seen || 'Chưa có'}${s.score == null ? '' : ` · Điểm đã chốt: ${s.score}`}`;
    setText(cells[4],`${s.answered} / ${s.total}`);
    setText(cells[5],'Chưa có dữ liệu'); setText(cells[6],'Chưa có dữ liệu');
    const actionKey = `${s.attempt_id}:${s.status === 'Đã nộp'}`;
    if (cells[7].dataset.action !== actionKey) {
      cells[7].replaceChildren(); cells[7].dataset.action = actionKey;
      if (s.attempt_id != null) {
        const label = s.status === 'Đã nộp' ? 'Cho thi lại' : 'Mở khóa';
        const form = document.createElement('form'); form.method = 'post'; form.action = `/teacher/unlock/${s.attempt_id}`;
        const token = document.createElement('input'); token.type = 'hidden'; token.name = 'csrf_token'; token.value = document.querySelector('meta[name="csrf-token"]').content;
        const button = document.createElement('button'); button.type = 'submit'; button.textContent = label;
        form.append(token,button); form.addEventListener('submit', e => { if (!confirm(`${label} cho ${s.ho_ten}?`)) e.preventDefault(); }); cells[7].appendChild(form);
      }
    }
  }
  async function refresh() {
    if (busy || document.hidden) return; busy = true;
    try {
      const r = await fetch(`/teacher/api/monitor/${root.dataset.exam}`,{cache:'no-store'}); if (!r.ok) throw Error(); const j = await r.json(); if (!j.ok || !Array.isArray(j.students)) throw Error();
      students = j.students; const keys = new Set(students.map(s => s.ma_hs));
      rows.forEach((row,key) => { if (!keys.has(key)) { row.remove(); rows.delete(key); } }); students.forEach(paint);
      const count = status => students.filter(s => s.status === status).length;
      const counts = {total:students.length,entered:students.filter(s => s.attempt_id != null).length,doing:count('Đang thi'),done:count('Đã nộp'),lost:count('Mất kết nối'),not:count('Chưa vào')};
      Object.entries(counts).forEach(([key,value]) => setText(document.getElementById(`n_${key}`),value));
      setText(document.getElementById('monitor_updated'),`✓ Đã cập nhật ${new Date().toLocaleTimeString('vi-VN')}. ${students.length} học sinh trong kỳ thi.`); applyFilter();
    } catch (_) { setText(document.getElementById('monitor_updated'),'⚠ Chưa cập nhật được. Giữ trạng thái lần đọc thành công gần nhất.'); }
    finally { busy = false; }
  }
  refresh(); setInterval(refresh,3000);
})();
