(function () {
  "use strict";

  function addLine(box, text, prefix) {
    if (!text.trim()) return;
    const line = document.createElement("div");
    if (prefix) {
      const label = document.createElement("b");
      label.textContent = prefix + " ";
      line.appendChild(label);
    }
    line.appendChild(document.createTextNode(text));
    line.style.marginBottom = "6px";
    box.appendChild(line);
  }

  function setup(form) {
    const box = form.querySelector("[data-math-preview]");
    if (!box) return;
    const content = form.elements.namedItem("noi_dung");
    const items = form.elements.namedItem("items");
    const optionNames = ["a", "b", "c", "d"];
    let timer = null;
    let revision = 0;

    function update() {
      const mine = ++revision;
      if (window.MathJax && MathJax.typesetClear) MathJax.typesetClear([box]);
      box.replaceChildren();
      addLine(box, content ? content.value : "", "Câu hỏi:");

      if (items) {
        items.value.split(/\r?\n/).forEach((value, index) =>
          addLine(box, value, String(index + 1) + ".")
        );
      } else {
        optionNames.forEach(name => {
          const field = form.elements.namedItem(name);
          if (field) addLine(box, field.value, name.toUpperCase() + ".");
        });
      }
      if (!box.childNodes.length) box.textContent = "Nhập nội dung để xem trước công thức.";
      if (mine === revision && window.renderMath) window.renderMath([box]);
    }

    function schedule() {
      clearTimeout(timer);
      timer = setTimeout(update, 180);
    }

    form.querySelectorAll("textarea,input[name='a'],input[name='b'],input[name='c'],input[name='d']")
      .forEach(field => field.addEventListener("input", schedule));
    update();
    document.addEventListener("mathjax-ready", update, {once: true});
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-live-math-form]").forEach(setup);
  });
}());
