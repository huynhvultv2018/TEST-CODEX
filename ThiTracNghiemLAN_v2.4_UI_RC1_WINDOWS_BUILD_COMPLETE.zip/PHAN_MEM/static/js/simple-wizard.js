/* Alternate R4 form: four presentation steps, original field names and server checks. */
document.addEventListener('DOMContentLoaded',() => {
  const form = document.querySelector('[data-simple-wizard]'); if (!form) return;
  const panels = [...form.querySelectorAll('[data-simple-step]')]; let step = 0;
  const prev = document.getElementById('simple_prev'), next = document.getElementById('simple_next');
  function show() { panels.forEach((p,i) => { p.hidden = i !== step; }); prev.disabled = step === 0; next.hidden = step === panels.length-1; }
  prev.addEventListener('click',() => { step--; show(); });
  next.addEventListener('click',() => { const invalid = [...panels[step].querySelectorAll('input,select')].find(x => !x.checkValidity()); if (invalid) { invalid.reportValidity(); return; } step++; show(); });
  form.addEventListener('invalid',e => { const p = e.target.closest('[data-simple-step]'); if (p) { step = panels.indexOf(p); show(); } },true); show();
});
