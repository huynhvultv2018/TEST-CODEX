THI TRẮC NGHIỆM LAN v2.3 — CHẤM ĐIỂM LINH HOẠT
Nâng cấp từ đúng bộ nguồn v2.2.2 Khối/Môn đã gửi.

1. CÁCH DÙNG
Vào Ngân hàng câu hỏi → Sửa → Chấm điểm v2.3.
- Điểm tối đa câu: số dương, tối đa 1000. Mặc định 1.
- Chấm toàn bộ: đúng hết câu mới nhận điểm.
- Chấm từng phần: áp dụng cho MULTI, TF, MATCH, FILL.
- Trọng số ý: tùy chọn cho TF, MATCH, FILL; mỗi ý một số dương
  không quá 1000, phân cách dấu phẩy. Ví dụ 1,3: ý thứ hai chiếm 3/4 điểm.
  Để trống thì các ý bằng điểm nhau. Dùng dấu chấm cho số thập phân.
- SINGLE luôn chấm đúng/sai toàn câu, nhưng có thể đổi điểm tối đa.

2. CÔNG THỨC
SINGLE: đúng được toàn bộ điểm, sai/bỏ trống được 0.
MULTI ở chế độ từng phần:
  Điểm câu = điểm tối đa × max(0, (số lựa chọn đúng - số lựa chọn sai)
                                     / tổng số đáp án đúng).
  Ví dụ đúng A,C và câu 2 điểm: chọn A được 1; chọn A,B,C được 1;
  chọn A,C được 2. Chọn lặp không được cộng thêm điểm.
TF/MATCH/FILL ở chế độ từng phần:
  Điểm câu = điểm tối đa × tổng trọng số ý đúng / tổng trọng số các ý.
  Bỏ trống ý được 0 điểm ý đó. Không trừ điểm các ý đúng khác.
FILL: vẫn nhận các đáp án tương đương ngăn bằng |, không phân biệt
  hoa/thường, chuẩn hóa khoảng trắng, vẫn phân biệt dấu tiếng Việt.
Điểm bài = tổng điểm đạt / tổng điểm tối đa × 10; làm tròn 2 chữ số
  theo quy tắc 5 làm tròn lên. Điểm từng câu không làm tròn trước khi cộng.
Màn hình học sinh hiển thị điểm quy đổi và cách chấm từng câu.

3. EXCEL VÀ BÁO CÁO
Tải Excel mẫu trong ngân hàng: 12 cột, thêm 3 cột cuối:
  Điểm câu | Cách chấm (all/partial) | Trọng số ý.
Ví dụ: 2 | partial | 1,3.
Vẫn nhập được mẫu 8 cột v2.2.1 và 9 cột v2.2.2.
Mẫu cũ mặc định 1 điểm/câu, chấm toàn bộ.
Trong Báo cáo kỳ thi → Xuất điểm từng câu (Excel).
Số câu đúng và thống kê đúng/sai vẫn đếm câu đúng toàn bộ;
  điểm tổng có thể bao gồm điểm từng phần.

4. GIỮ DỮ LIỆU VÀ NÂNG CẤP
Chỉ nâng cấp khi không có học sinh đang thi. Dừng máy chủ và sao lưu
  toàn bộ thư mục đang sử dụng trước khi thay chương trình.
Nếu chạy Python: chép các file .py, templates, static và các file .bat
  của PHAN_MEM mới vào thư mục chương trình cũ.
Giữ nguyên cơ sở dữ liệu, uploads, backups và tất cả tệp giấy phép,
  trạng thái dùng thử, cấu hình/bí mật phiên có sẵn.
Nếu chạy EXE: đóng gói trong thư mục mới bằng build_exe.bat; sau khi
  thành công, chép EXE mới cùng templates và static sang thư mục chạy cũ.
Không chép cơ sở dữ liệu hoặc trạng thái dùng thử sinh ra từ chạy thử
  vào thư mục dùng thật. Không xóa dữ liệu/giấy phép cũ.
Cách chấm được chốt lúc học sinh bắt đầu bài. Đổi cấu hình trong ngân hàng
  chỉ áp dụng cho bài bắt đầu sau đó. Không tự tính lại bài đã nộp.
Giữ nguyên MathJax ngoại tuyến, phân loại Khối/Môn và quản lý học sinh.

5. ĐÓNG GÓI VÀ KIỂM THỬ
Đây là bộ nguồn và công cụ đóng gói, chưa phải EXE Windows đã tạo sẵn.
Chạy PHAN_MEM/build_exe.bat trên Windows có Python và kết nối mạng để
  cài các phụ thuộc nếu còn thiếu. Các kiểm tra dùng dữ liệu tạm.
Sau khi thành công, EXE ở PHAN_MEM/dist/ThiTracNghiemLAN.exe.
Máy chạy EXE không cần cài Python; thư mục chương trình cần quyền ghi dữ liệu.
Đã kiểm tra tại môi trường phát triển: 5 dạng, điểm từng phần, trọng số,
  bài cũ, nhập/xuất cấu hình, lưu đáp án, nộp bài, hết giờ, chốt cách chấm,
  báo cáo, 1000 học sinh, Khối/Môn, tích hợp tài nguyên MathJax và giấy phép.
Chưa xác minh chạy EXE và giao diện thực tế trên Windows.
