@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title Thi Trac Nghiem LAN v2.2 Thuong mai

if not exist "ThiTracNghiemLAN.exe" (
    echo LOI: Khong tim thay ThiTracNghiemLAN.exe trong thu muc nay.
    echo Hay chay build_exe.bat o thu muc ma nguon truoc.
    pause
    exit /b 1
)

echo Dang khoi dong may chu...
echo Trang giao vien: http://127.0.0.1:5000/teacher/login
echo Khong dong cua so nay trong khi hoc sinh dang thi.
echo.
"%~dp0ThiTracNghiemLAN.exe"

echo.
echo May chu da dung. Neu chuong trinh tu thoat, xem logs\app.log.
pause
