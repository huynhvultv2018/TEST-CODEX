"""Kiểm tra tích hợp MathJax ngoại tuyến của v2.2.1."""
import os
import shutil
import sys
import tempfile
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    engine = root / "static" / "vendor" / "mathjax" / "tex-svg.js"
    preview_js = root / "static" / "js" / "math-preview.js"
    auto_js = root / "static" / "js" / "math-auto.js"
    assert engine.is_file() and engine.stat().st_size > 1_000_000, "Thiếu bộ MathJax ngoại tuyến"
    assert preview_js.is_file(), "Thiếu mã xem trước công thức"
    assert auto_js.is_file(), "Thiếu mã nhận dạng công thức không có dấu phân cách"

    with tempfile.TemporaryDirectory(prefix="tnlan_mathjax_", ignore_cleanup_errors=True) as tmp:
        p = Path(tmp)
        for file in root.glob("*.py"):
            if file.name != Path(__file__).name:
                shutil.copy2(file, p / file.name)
        shutil.copytree(root / "templates", p / "templates")
        shutil.copytree(root / "static", p / "static")
        os.environ["LOCALAPPDATA"] = str(p / "localappdata")
        sys.path.insert(0, tmp)
        import app as m

        m.init_db()
        client = m.app.test_client()
        with client.session_transaction() as session:
            session["teacher_logged_in"] = True
            session["teacher_role"] = "ADMIN"
            session["teacher_username"] = "admin"

        static = client.get("/static/vendor/mathjax/tex-svg.js")
        assert static.status_code == 200 and len(static.data) > 1_000_000

        teacher = client.get("/teacher").get_data(as_text=True)
        assert "/static/vendor/mathjax/tex-svg.js" in teacher
        assert "/static/js/math-auto.js" in teacher
        assert "data-live-math-form" in teacher and "data-math-preview" in teacher
        assert "cdn.jsdelivr" not in teacher, "Không được phụ thuộc CDN khi thi LAN"

        bank = client.get("/teacher/questions").get_data(as_text=True)
        assert "/static/vendor/mathjax/tex-svg.js" in bank

        with m.app.test_request_context("/exam"):
            html = m.render_template(
                "exam.html",
                bt={"ten": "Kiểm tra Toán", "ho_ten": "Học sinh", "lop": "8A"},
                questions=[{"q": r"Tính $\frac{1}{2}+x^2$", "type": "SINGLE",
                            "options": [r"$\frac{3}{2}$", "$x$"], "image": ""}],
                saved={}, seconds_left=60,
            )
        assert 'class="card question math-content"' in html
        assert r"\frac{1}{2}" in html
        print("PASS MathJax: ngoại tuyến, ngân hàng, xem trước và màn hình học sinh.")


if __name__ == "__main__":
    main()
