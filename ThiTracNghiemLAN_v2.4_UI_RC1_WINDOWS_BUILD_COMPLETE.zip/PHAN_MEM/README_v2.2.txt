THI TRẮC NGHIỆM LAN — GHI CHÚ NỀN v2.2

Tệp này ghi lại các sửa lỗi nền của v2.2. Bản phát hành hiện tại là v2.2.2.
Giấy phép hiện tại: dùng thử miễn phí 7 ngày, sau đó dùng mã 1 năm.
Giấy phép vĩnh viễn đã cấp trước đây tiếp tục được công nhận.

Các lỗi đã sửa:
- Xóa 11 hàm và đường dẫn Flask bị chép lặp làm EXE tự thoát.
- Bổ sung platform và uuid cho chức năng Machine ID/bản quyền.
- Bổ sung danh sách kỳ thi và nút Giám sát phòng thi.
- Sắp xếp lại giao diện trang giáo viên.
- Ưu tiên thư mục templates bên cạnh EXE để có thể cập nhật giao diện dễ dàng.
- Sửa tệp BAT theo UTF-8 không BOM và giữ cửa sổ lại khi có lỗi.
- Kiểm tra giấy phép bằng chữ ký số Ed25519 theo Machine ID và tên đơn vị.
- Sau khi hết dùng thử hoặc hết hạn giấy phép sẽ không thể tổ chức thi.
- Khóa tạo mã không nằm trong phần mềm giao cho khách hàng.

Tài khoản quản trị khởi tạo:
Tên đăng nhập: admin
Mật khẩu: 123456

Hãy đổi mật khẩu sau lần đăng nhập đầu tiên.

Thư mục dữ liệu nằm cạnh EXE:
- thi_trac_nghiem.db: cơ sở dữ liệu
- backups: bản sao lưu
- exports: bảng điểm xuất ra
- imports: tệp nhập
- logs/app.log: nhật ký lỗi
- uploads: hình ảnh câu hỏi và logo

Đọc HUONG_DAN_V22.txt cho quy trình câu hỏi nhiều dạng, nâng cấp dữ liệu và phạm vi kiểm thử.
