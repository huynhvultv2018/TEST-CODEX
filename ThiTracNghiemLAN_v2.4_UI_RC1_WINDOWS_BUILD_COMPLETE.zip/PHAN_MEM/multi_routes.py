import json
import re
from io import BytesIO
from pathlib import Path
from datetime import datetime
from flask import request, render_template, redirect, url_for, flash, send_file
from openpyxl import Workbook, load_workbook
from question_types import TYPES, parse_spec
from scoring import config, grade
from snapshot_validation import load_snapshot, question_data, SnapshotValidationError

HEADERS=['Mã câu','Khối','Môn','Chủ đề','Mức độ','Loại','Nội dung câu hỏi','Các mục (mỗi dòng một mục)','Đáp án']
HEADERS += ['Điểm câu','Cách chấm (all/partial)','Trọng số ý']
GRADE_OPTIONS=('6','7','8','9','10','11','12')

def normalize_grade(value):
    text=str(value or '').strip()
    match=re.search(r'(?<!\d)(6|7|8|9|10|11|12)(?!\d)',text)
    return match.group(1) if match else ''

def infer_grade(ma_cau='',mon='',chu_de=''):
    for text in (mon,chu_de):
        grade=normalize_grade(text)
        if grade: return grade
    code=str(ma_cau or '').strip().upper()
    match=re.search(r'(?:DS|HH|TIN|TOAN|MATH|HINH)[_-]?(6|7|8|9|10|11|12)(?:_|\b)',code)
    return match.group(1) if match else ''

def install_multi_routes(g):
    app=g['app']; db=g['db']; guard=g['teacher_required']
    old_init=g['init_db']
    def init_db():
        # Back up the original schema before the first v2.2 migration.
        path=g['DB_PATH']
        if path.exists():
            c=db(); exists=c.execute("SELECT 1 FROM sqlite_master WHERE name='cau_hoi'").fetchone()
            columns={r[1] for r in c.execute('PRAGMA table_info(cau_hoi)')}; c.close()
            if exists and 'question_type' not in columns:
                g['create_sqlite_backup'](g['BACKUP_DIR']/('before_v22_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.db'))
            elif exists and 'khoi_lop' not in columns:
                g['create_sqlite_backup'](g['BACKUP_DIR']/('before_v222_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.db'))
        old_init()
        c=db()
        for table,name,definition in [('cau_hoi','question_type',"TEXT NOT NULL DEFAULT 'SINGLE'"),('cau_hoi','payload',"TEXT NOT NULL DEFAULT ''"),('cau_hoi','khoi_lop',"TEXT NOT NULL DEFAULT ''"),('ky_thi','type_quotas',"TEXT NOT NULL DEFAULT ''")]:
            if name not in {r[1] for r in c.execute('PRAGMA table_info('+table+')')}:
                c.execute(f'ALTER TABLE {table} ADD COLUMN {name} {definition}')
        # v2.2.2: classify old questions when grade can be inferred safely.
        for row in c.execute("SELECT id,ma_cau,mon,chu_de FROM cau_hoi WHERE TRIM(COALESCE(khoi_lop,''))='' ").fetchall():
            grade=infer_grade(row['ma_cau'],row['mon'],row['chu_de'])
            if grade: c.execute('UPDATE cau_hoi SET khoi_lop=? WHERE id=?',(grade,row['id']))
        c.execute('CREATE INDEX IF NOT EXISTS idx_cau_hoi_khoi_mon ON cau_hoi(khoi_lop,mon)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_cau_hoi_folder_filter ON cau_hoi(khoi_lop,mon,question_type,muc_do)')
        c.commit(); c.close()
    g['init_db']=init_db

    @app.get('/teacher/report/<int:eid>/points')
    @guard
    def export_question_points(eid):
        c=db(); attempts=c.execute('SELECT * FROM bai_thi WHERE ky_thi_id=? AND submitted_at IS NOT NULL',(eid,)).fetchall()
        wb=Workbook(); ws=wb.active; ws.title='DiemTungCau'
        ws.append(['Mã HS','Họ tên','Câu','Loại','Điểm đạt','Điểm tối đa','Điểm quy đổi /10'])
        for bt in attempts:
            try:
                items=load_snapshot(bt['de_json'])
            except SnapshotValidationError:
                c.close()
                raise
            choices={r['vi_tri_cau']:r['lua_chon'] for r in c.execute('SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(bt['id'],))}
            scored=[grade(item,choices.get(i)) for i,item in enumerate(items)]
            maximum=sum(b for a,b in scored)
            for i,(a,b) in enumerate(scored):
                ws.append([bt['ma_hs'],bt['ho_ten'],i+1,items[i].get('type','SINGLE'),a,b,a/maximum*10 if maximum else 0])
        c.close()
        for row in ws:
            for cell in row:
                if isinstance(cell.value,str) and cell.value.startswith('='): cell.data_type='s'
        out=BytesIO(); wb.save(out); out.seek(0)
        return send_file(out,as_attachment=True,download_name='DiemTungCau.xlsx')

    def values(f):
        level=str(f.get('muc_do','NB')).strip().upper(); kind=str(f.get('question_type','SINGLE')).strip().upper()
        if level not in ('NB','TH','VD','VDC'): raise ValueError('Mức độ không hợp lệ.')
        question=str(f.get('noi_dung','')).strip()
        if not question: raise ValueError('Cần nhập nội dung câu hỏi.')
        spec=parse_spec(kind,str(f.get('items','')),str(f.get('answers','')))
        spec['scoring']=config(f,kind,len(spec['options']))
        code=str(f.get('ma_cau','')).strip(); subject=str(f.get('mon','')).strip(); topic=str(f.get('chu_de','')).strip()
        grade=normalize_grade(f.get('khoi_lop','')) or infer_grade(code,subject,topic)
        return (code,grade,subject,topic,level,question,kind,json.dumps(spec,ensure_ascii=False))
    def insert(c,v):
        c.execute("INSERT INTO cau_hoi(ma_cau,khoi_lop,mon,chu_de,muc_do,noi_dung,question_type,payload,a,b,c,d,dap_an_dung,hinh_anh) VALUES(?,?,?,?,?,?,?,?,'','','','','A','')",v)

    @app.route('/teacher/multi',methods=['GET'])
    @guard
    def multi_bank():
        grade=normalize_grade(request.args.get('khoi',''))
        subject=request.args.get('mon','').strip()
        topic=request.args.get('chu_de','').strip()
        kind=request.args.get('question_type','').strip().upper()
        level=request.args.get('muc_do','').strip().upper()
        keyword=request.args.get('q','').strip()
        try: per_page=int(request.args.get('per_page','50'))
        except ValueError: per_page=50
        if per_page not in (25,50,100): per_page=50
        try: page=max(1,int(request.args.get('page','1')))
        except ValueError: page=1

        where=[]; args=[]
        if grade: where.append('khoi_lop=?'); args.append(grade)
        elif request.args.get('khoi')=='none': where.append("TRIM(COALESCE(khoi_lop,''))=''")
        if subject: where.append('mon=?'); args.append(subject)
        if topic: where.append('chu_de=?'); args.append(topic)
        if kind in TYPES: where.append('question_type=?'); args.append(kind)
        if level in ('NB','TH','VD','VDC'): where.append('muc_do=?'); args.append(level)
        if keyword:
            like='%'+keyword+'%'; where.append('(ma_cau LIKE ? OR noi_dung LIKE ?)'); args.extend((like,like))
        clause=(' WHERE '+' AND '.join(where)) if where else ''

        c=db()
        total=c.execute('SELECT COUNT(*) FROM cau_hoi'+clause,args).fetchone()[0]
        pages=max(1,(total+per_page-1)//per_page); page=min(page,pages)
        rows=c.execute('SELECT * FROM cau_hoi'+clause+' ORDER BY id DESC LIMIT ? OFFSET ?',args+[per_page,(page-1)*per_page]).fetchall()
        folder_rows=c.execute("""SELECT COALESCE(NULLIF(TRIM(khoi_lop),''),'none') AS khoi,
                              COALESCE(NULLIF(TRIM(mon),''),'Chưa xác định môn') AS mon,COUNT(*) AS n
                              FROM cau_hoi GROUP BY khoi,mon
                              ORDER BY CASE WHEN khoi='none' THEN 99 ELSE CAST(khoi AS INTEGER) END,mon COLLATE NOCASE""").fetchall()
        folder_tree={}
        for item in folder_rows: folder_tree.setdefault(item['khoi'],[]).append(dict(item))
        subjects=[r[0] for r in c.execute("SELECT DISTINCT mon FROM cau_hoi WHERE TRIM(COALESCE(mon,''))<>'' ORDER BY mon COLLATE NOCASE")]
        topic_sql="SELECT DISTINCT chu_de FROM cau_hoi WHERE TRIM(COALESCE(chu_de,''))<>''"; topic_args=[]
        if grade: topic_sql+=' AND khoi_lop=?'; topic_args.append(grade)
        if subject: topic_sql+=' AND mon=?'; topic_args.append(subject)
        topics=[r[0] for r in c.execute(topic_sql+' ORDER BY chu_de COLLATE NOCASE',topic_args)]
        c.close()
        return render_template('multi_bank.html',rows=rows,types=TYPES,grades=GRADE_OPTIONS,
                               folder_tree=folder_tree,subjects=subjects,topics=topics,
                               selected_grade=request.args.get('khoi',''),selected_subject=subject,
                               selected_topic=topic,selected_kind=kind,selected_level=level,
                               keyword=keyword,total=total,page=page,pages=pages,per_page=per_page)

    @app.route('/teacher/multi/new',methods=['GET','POST'],defaults={'qid':None})
    @app.route('/teacher/multi/edit/<int:qid>',methods=['GET','POST'])
    @guard
    def multi_editor(qid):
        f={}
        if qid:
            c=db(); row=c.execute('SELECT * FROM cau_hoi WHERE id=?',(qid,)).fetchone(); c.close()
            if not row: return 'Không tìm thấy câu hỏi',404
            f=dict(row)
            spec=question_data(f); kind=spec['type']
            rule=spec.get('scoring',{})
            f.update(points=rule.get('points',1),scoring_mode=rule.get('mode','all'),weights=','.join(str(x) for x in rule.get('weights',[])))
            f['items']='\n'.join(spec['options'])
            f['answers']=str(spec['answer']+1) if kind=='SINGLE' else ','.join(str(i+1) for i in spec['answer']) if kind=='MULTI' else '\n'.join(spec['answer']) if kind=='TF' else '\n'.join(spec['right']) if kind=='MATCH' else '\n'.join('|'.join(x) for x in spec['answer'])
        if request.method=='POST':
            f=request.form.to_dict()
            try:
                v=values(f); c=db()
                if qid: c.execute('UPDATE cau_hoi SET ma_cau=?,khoi_lop=?,mon=?,chu_de=?,muc_do=?,noi_dung=?,question_type=?,payload=? WHERE id=?',v+(qid,))
                else: insert(c,v)
                c.commit(); c.close(); flash('Đã lưu câu hỏi.')
                return redirect(url_for('multi_bank',khoi=v[1],mon=v[2]))
            except ValueError as e: flash(str(e))
        return render_template('multi_editor.html',f=f,types=TYPES,grades=GRADE_OPTIONS)

    @app.get('/teacher/multi/excel')
    @guard
    def multi_excel():
        wb=Workbook(); ws=wb.active; ws.title='CauHoi'; ws.append(HEADERS)
        if request.args.get('sample'):
            rows=[('VD1','6','Tin học','Ví dụ','NB','SINGLE','Chọn số chẵn.','2\n3','1'),('VD2','6','Tin học','Ví dụ','TH','MULTI','Chọn các số chẵn.','2\n3\n4','1,3'),('VD3','6','Tin học','Ví dụ','NB','TF','Đánh giá các ý.','2 là số chẵn\n3 là số chẵn','D\nS'),('VD4','6','Tin học','Ví dụ','TH','MATCH','Ghép phép tính với kết quả.','1 + 1\n2 + 2','2\n4'),('VD5','6','Tin học','Ví dụ','NB','FILL','Điền kết quả vào ô.','Một cộng một bằng','2|hai')]
        else:
            grade=normalize_grade(request.args.get('khoi','')); subject=request.args.get('mon','').strip()
            where=[]; args=[]
            if grade: where.append('khoi_lop=?'); args.append(grade)
            elif request.args.get('khoi')=='none': where.append("TRIM(COALESCE(khoi_lop,''))=''")
            if subject: where.append('mon=?'); args.append(subject)
            clause=(' WHERE '+' AND '.join(where)) if where else ''
            c=db(); rows=[]
            for r in c.execute('SELECT * FROM cau_hoi'+clause+' ORDER BY id',args):
                if r['payload']:
                    try:
                        d=question_data(r)
                    except SnapshotValidationError:
                        c.close()
                        raise
                    k=d['type']; items='\n'.join(d['options'])
                    ans=str(d['answer']+1) if k=='SINGLE' else ','.join(str(x+1) for x in d['answer']) if k=='MULTI' else '\n'.join(d['answer']) if k=='TF' else '\n'.join(d['right']) if k=='MATCH' else '\n'.join('|'.join(x) for x in d['answer'])
                else: k='SINGLE'; items='\n'.join(r[x] for x in ('a','b','c','d')); ans=str('ABCD'.index(r['dap_an_dung'])+1)
                rule=json.loads(r['payload']).get('scoring',{}) if r['payload'] else {}
                rows.append((r['ma_cau'],r['khoi_lop'],r['mon'],r['chu_de'],r['muc_do'],k,r['noi_dung'],items,ans,rule.get('points',1),rule.get('mode','all'),','.join(str(x) for x in rule.get('weights',[]))))
            c.close()
        for row in rows: ws.append(tuple(row)+(1,'all','') if len(row)==9 else row)
        from openpyxl.styles import Alignment,Font,PatternFill
        from openpyxl.utils import get_column_letter
        for j,width in enumerate([16,10,20,24,14,16,55,45,35,14,24,24],1): ws.column_dimensions[get_column_letter(j)].width=width
        for row in ws:
            for cell in row:
                cell.alignment=Alignment(wrap_text=True,vertical='top')
                if isinstance(cell.value,str) and cell.value.startswith('='): cell.data_type='s'
        for cell in ws[1]: cell.font=Font(bold=True,color='FFFFFF'); cell.fill=PatternFill('solid',fgColor='234567')
        ws.freeze_panes='A2'; out=BytesIO(); wb.save(out); out.seek(0)
        return send_file(out,as_attachment=True,download_name='CauHoi_NhieuDang_v23.xlsx')

    @app.post('/teacher/multi/import')
    @guard
    def multi_import():
        try:
            upload=request.files.get('file')
            if not upload: raise ValueError('Chọn tệp Excel.')
            folder_grade=normalize_grade(request.form.get('khoi_lop',''))
            folder_subject=request.form.get('mon_folder','').strip()
            with BytesIO(upload.read()) as stream:
                wb=load_workbook(stream,data_only=True)
            ws=wb.active; prepared=[]
            headers=[str(x or '').strip().lower() for x in next(ws.iter_rows(min_row=1,max_row=1,values_only=True))]
            has_grade_column=len(headers)>=9 and ('khối' in headers[1] or 'khoi' in headers[1])
            for i,row in enumerate(ws.iter_rows(min_row=2,values_only=True),2):
                if not any(v is not None for v in row): continue
                vals=list(row)+['']*9
                names=['ma_cau','khoi_lop','mon','chu_de','muc_do','question_type','noi_dung','items','answers'] if has_grade_column else ['ma_cau','mon','chu_de','muc_do','question_type','noi_dung','items','answers']
                names+=['points','scoring_mode','weights']
                f=dict(zip(names,['' if x is None else str(x) for x in vals[:len(names)]]))
                if folder_grade: f['khoi_lop']=folder_grade
                if folder_subject: f['mon']=folder_subject
                try: prepared.append(values(f))
                except ValueError as e: raise ValueError(f'Dòng {i}: {e}')
            if not prepared: raise ValueError('Tệp không có câu hỏi hợp lệ.')
            c=db()
            with c:
                for v in prepared: insert(c,v)
            c.close(); actual_grade=folder_grade or prepared[0][1]; actual_subject=folder_subject or prepared[0][2]
            flash(f'Đã nhập {len(prepared)} câu hỏi vào Khối {actual_grade or "chưa phân loại"} → {actual_subject or "chưa xác định môn"}.')
        except Exception as e:
            flash('Không nhập dữ liệu: '+str(e))
            return redirect(url_for('multi_bank'))
        return redirect(url_for('multi_bank',khoi=actual_grade or 'none',mon=actual_subject))

    old_build=g['build_exam']
    def build_exam(kt):
        if not dict(kt).get('type_quotas'): return old_build(kt)
        from question_types import snapshot
        import random
        quotas=json.loads(kt['type_quotas']); c=db(); selected=[]
        topics=g['exam_topics'](kt['chu_de'],quotas)
        for kind,levels in quotas.items():
            if kind=='_topics_format': continue
            for level,n in levels.items():
                n=int(n or 0)
                if n<=0: continue
                sql='SELECT * FROM cau_hoi WHERE (?="" OR mon=?)'
                args=[kt['mon'],kt['mon']]
                if topics:
                    sql+=' AND chu_de IN (%s)' % ','.join('?'*len(topics))
                    args+=topics
                rows=c.execute(sql,args).fetchall()
                rows=[r for r in rows if g['question_classification'](r)==(level,kind)]
                if len(rows)<n: c.close(); return []
                selected.extend(random.sample(rows,n))
        c.close(); random.shuffle(selected); return [snapshot(dict(r,question_type=g['question_classification'](r)[1])) for r in selected]
    g['build_exam']=build_exam

    @app.route('/teacher/mixed-exam',methods=['GET','POST'])
    @guard
    def mixed_exam():
        if request.method=='POST':
            try:
                f=request.form; title=f.get('ten','').strip(); mon=f.get('mon','').strip(); minutes=g['exam_integer'](f,'minutes',15,1,180)
                if not title or not 1<=minutes<=180: raise ValueError('Nhập tên kỳ thi và thời gian 1–180 phút.')
                quotas={k:{lv:g['exam_integer'](f,k+'_'+lv,0) for lv in ('NB','TH','VD','VDC')} for k in TYPES}
                if any(n<0 for q in quotas.values() for n in q.values()): raise ValueError('Số câu không được âm.')
                total=sum(n for q in quotas.values() for n in q.values())
                if not total: raise ValueError('Chọn ít nhất một câu.')
                _,available=g['question_availability'](mon)
                c=db()
                for k,q in quotas.items():
                    for lv,n in q.items():
                        count=available[k][lv]
                        if n>count: c.close(); raise ValueError(f'{TYPES[k]} / {lv}: yêu cầu {n}, hiện có {count}.')
                c.execute('INSERT INTO ky_thi(ten,lop,mon,so_cau,thoi_gian_phut,chu_de,muc_do,nb_count,th_count,vd_count,vdc_count,hien_diem,trang_thai,created_at,type_quotas) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(title,f.get('lop','').strip(),mon,total,minutes,'','NB,TH,VD,VDC',*(sum(q[lv] for q in quotas.values()) for lv in ('NB','TH','VD','VDC')),1 if f.get('hien_diem') else 0,'MO',g['now_text'](),json.dumps(quotas)))
                c.commit();c.close();flash('Đã tạo kỳ thi nhiều dạng.');return redirect(url_for('teacher'))
            except ValueError as e: flash(str(e))
        c=db(); counts=c.execute('SELECT mon,question_type,muc_do,COUNT(*) AS n FROM cau_hoi GROUP BY mon,question_type,muc_do').fetchall(); c.close()
        return render_template('mixed_exam.html',types=TYPES,counts=counts)
