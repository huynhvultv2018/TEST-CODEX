"""Versioned scoring stored inside each question snapshot."""
from decimal import Decimal, ROUND_HALF_UP
from question_types import correct, decode, normalize
import math
from snapshot_validation import validate_item, SnapshotValidationError

def config(form, kind, count):
    try:
        points=float(form.get('points',1) or 1)
        weights=[float(x.strip()) for x in str(form.get('weights','')).split(',') if x.strip()]
    except ValueError:
        raise ValueError('Điểm và trọng số phải là số.')
    mode=form.get('scoring_mode','all') or 'all'
    if mode not in ('all','partial'): raise ValueError('Cách chấm không hợp lệ.')
    if not math.isfinite(points) or not 0<points<=1000: raise ValueError('Điểm câu phải lớn hơn 0 và không quá 1000.')
    if weights and (kind not in ('TF','MATCH','FILL') or len(weights)!=count or any(not math.isfinite(x) or x<=0 or x>1000 for x in weights)):
        raise ValueError('Trọng số: một số dương cho mỗi ý, chỉ dùng cho đúng–sai, ghép nối, điền khuyết.')
    return dict(version=1,points=points,mode=mode,weights=weights)

def grade(item, value):
    validate_item(item)
    rule=item.get('scoring',{}); maximum=rule.get('points',1)
    if rule.get('mode','all')=='all' or item.get('type','SINGLE')=='SINGLE':
        return maximum*int(correct(item,value)),maximum
    value=decode(value); ans=item['answer']; kind=item['type']
    if not isinstance(value,list): return 0,maximum
    if kind=='MULTI':
        if any(type(v) is not int or v<0 or v>=len(item['options']) for v in value): return 0,maximum
        chosen=set(value); right=set(ans)
        fraction=max(0,(len(chosen & right)-len(chosen-right))/len(right))
    else:
        if len(value)!=len(ans): return 0,maximum
        weights=rule.get('weights') or [1]*len(ans)
        hits=[]
        for v,a in zip(value,ans):
            if kind=='FILL': hit=isinstance(v,str) and normalize(v) in [normalize(x) for x in a]
            elif kind=='MATCH': hit=type(v) is int and v==a
            else: hit=isinstance(v,str) and v==a
            hits.append(int(hit))
        fraction=sum(w*h for w,h in zip(weights,hits))/sum(weights)
    return maximum*fraction,maximum

def total_score(items, choices):
    if not isinstance(items,list):
        raise SnapshotValidationError('Danh sách câu hỏi để chấm không hợp lệ.')
    scored=[grade(item,choices.get(i)) for i,item in enumerate(items)]
    if any(not math.isfinite(a) or not math.isfinite(b) or not 0<=a<=b for a,b in scored):
        raise SnapshotValidationError('Điểm từng câu không thuộc miền hợp lệ.')
    maximum=sum(b for a,b in scored)
    raw=sum(a for a,b in scored)/maximum*10 if maximum else 0
    if not math.isfinite(raw) or not 0<=raw<=10:
        raise SnapshotValidationError('Điểm bài thi không thuộc miền hợp lệ.')
    return float(Decimal(str(raw)).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
