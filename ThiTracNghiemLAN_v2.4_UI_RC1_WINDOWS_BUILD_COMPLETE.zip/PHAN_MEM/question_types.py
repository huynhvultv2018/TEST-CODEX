import json
import random
import unicodedata
from snapshot_validation import question_data

TYPES={'SINGLE':'Một đáp án','MULTI':'Nhiều đáp án','TF':'Đúng–sai','MATCH':'Ghép nối','FILL':'Điền khuyết'}

def normalize(s):
    return ' '.join(unicodedata.normalize('NFC',str(s)).casefold().split())

def parse_spec(kind, text, answers):
    kind=kind.upper()
    if kind not in TYPES: raise ValueError('Loại câu hỏi không hợp lệ.')
    lines=[s.strip() for s in text.splitlines() if s.strip()]
    ans=[s.strip() for s in answers.splitlines() if s.strip()]
    if kind in ('SINGLE','MULTI'):
        if not 2<=len(lines)<=20: raise ValueError('Cần 2 đến 20 phương án, mỗi phương án một dòng.')
        try: keys=sorted(set(int(x.strip())-1 for x in answers.split(',')))
        except ValueError: raise ValueError('Đáp án dùng số thứ tự, ví dụ 1 hoặc 1,3.')
        if not keys or min(keys)<0 or max(keys)>=len(lines) or (kind=='SINGLE' and len(keys)!=1): raise ValueError('Số thứ tự đáp án không hợp lệ.')
        return {'options':lines,'answer':keys[0] if kind=='SINGLE' else keys}
    if not lines or len(lines)>30 or len(lines)!=len(ans): raise ValueError('Cần 1–30 dòng nội dung và số dòng đáp án phải bằng số dòng nội dung.')
    if kind=='TF':
        if any(a.upper() not in ('D','S') for a in ans): raise ValueError('Mỗi dòng đáp án đúng–sai là D hoặc S.')
        return {'options':lines,'answer':[a.upper() for a in ans]}
    if kind=='MATCH':
        if len(set(ans))!=len(ans): raise ValueError('Các mục ở cột phải phải khác nhau.')
        return {'options':lines,'right':ans,'answer':list(range(len(lines)))}
    accepted=[[a.strip() for a in x.split('|') if a.strip()] for x in ans]
    if any(not a for a in accepted): raise ValueError('Mỗi ô cần ít nhất một đáp án.')
    return {'options':lines,'answer':accepted}

def snapshot(row):
    row=dict(row); item=question_data(row); kind=item['type']
    if kind in ('SINGLE','MULTI'):
        order=list(range(len(item['options']))); random.shuffle(order)
        item['options']=[item['options'][i] for i in order]
        item['answer']=order.index(item['answer']) if kind=='SINGLE' else sorted(order.index(i) for i in item['answer'])
    elif kind=='MATCH':
        order=list(range(len(item['right']))); random.shuffle(order)
        item['right']=[item['right'][i] for i in order]
        item['answer']=[order.index(i) for i in item['answer']]
    item.update(id=row['id'],q=row['noi_dung'],image=row['hinh_anh'] or '',type=kind)
    # F012: these are the only bank fields needed by historical report/export.
    item['history']={k:str(row.get(k) or '') for k in ('ma_cau','mon','chu_de','muc_do')}
    item['history']['muc_do']=item['history']['muc_do'].strip().upper()
    return item

def decode(value):
    if isinstance(value,str):
        try: return json.loads(value)
        except (ValueError,TypeError): return None
    return value

def correct(item, value):
    value=decode(value); kind=item.get('type','SINGLE'); ans=item['answer']
    if kind=='SINGLE': return type(value) is int and value==ans
    if not isinstance(value,list): return False
    if kind=='MULTI': return all(type(x) is int for x in value) and sorted(set(value))==sorted(ans)
    if len(value)!=len(ans): return False
    if kind=='FILL': return all(isinstance(v,str) and normalize(v) in [normalize(a) for a in opts] for v,opts in zip(value,ans))
    if kind=='MATCH': return all(type(v) is int for v in value) and value==ans
    return value==ans

def from_form(form,index,item):
    key=f'q_{index}'; kind=item.get('type','SINGLE')
    if kind=='SINGLE':
        v=form.get(key,''); return int(v) if v.isdigit() else None
    if kind=='MULTI': return [int(v) for v in form.getlist(key) if v.isdigit()]
    values=[form.get(f'{key}_{j}','') for j in range(len(item['options']))]
    if kind=='MATCH': return [int(v) if v.isdigit() else None for v in values]
    return values

def completed(item,value):
    value=decode(value); kind=item.get('type','SINGLE')
    if kind=='SINGLE': return type(value) is int
    if not isinstance(value,list): return False
    if kind=='MULTI': return bool(value)
    return len(value)==len(item['options']) and all(v is not None and str(v).strip()!='' for v in value)
