THI TRẮC NGHIỆM LAN v2.2.1 — ỔN ĐỊNH VÀ QUẢN LÝ HỌC SINH

NÂNG CẤP CHÍNH
- Trang Quản lý học sinh riêng, không tải toàn bộ danh sách lên trang giáo viên.
- Tìm theo mã hoặc họ tên; lọc lớp; sắp xếp và phân trang 25/50/100 dòng.
- Chọn nhiều học sinh để chuyển lớp hoặc xóa; tự sao lưu trước khi xóa hàng loạt.
- Nhập Excel có bước xem trước, thống kê dòng lỗi/trùng và chọn cập nhật hoặc bỏ qua.
- Xuất Excel theo danh sách đang lọc.
- Thêm chỉ mục cơ sở dữ liệu để thao tác tốt với khoảng 1.000 học sinh trở lên.
- Sửa lỗi WinError 32 khi xác nhận nhập Excel trên Windows.
- Giữ nguyên 5 dạng câu hỏi, giám sát, báo cáo, sao lưu và giấy phép 7 ngày/1 năm.

ĐÓNG GÓI
1. Chạy build_exe.bat trên Windows có Python.
2. Giao toàn bộ thư mục dist cho máy chủ sử dụng.
3. Khi nâng cấp máy đang dùng, sao lưu thư mục cũ và giữ database cùng dữ liệu hiện có.

NHẬP HỌC SINH
File Excel gồm 3 cột theo thứ tự: Mã học sinh, Họ tên, Lớp.
Vào Trang giáo viên > Quản lý học sinh > Xem trước khi nhập.

LƯU Ý
Không gửi công cụ cấp mã hoặc khóa riêng cho khách hàng.
NÂNG CẤP MATHJAX HOÀN CHỈNH
- Hiển thị công thức tại màn hình học sinh, ngân hàng câu hỏi và phần xem trước.
- Tự đổi lũy thừa nhập kiểu 4x^2, 7x^3y^2 thành công thức MathJax.
- Tự đổi 1/x, a/b, 2x/3y, x^2/y thành phân số đứng.
- Tự đổi sqrt(x), sqrt{x}, √x và √(x+1) thành căn bậc hai.
- Có MathJax 3.2.2 ngoại tuyến trong thư mục static; máy học sinh không cần Internet.
- Hỗ trợ công thức trong $...$, $$...$$, \\( ... \\) và \\[ ... \\].
- Xem trước tự động khi nhập hoặc sửa nội dung và phương án.
- build_exe.bat tự kiểm tra và đóng gói cả thư mục static.
