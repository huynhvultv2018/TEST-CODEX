@echo off
chcp 65001 >nul
setlocal EnableExtensions
title Cau hinh Firewall - Thi Trac Nghiem LAN v2.2

net session >nul 2>&1
if not %errorlevel%==0 (
    echo Hay nhap phai file nay va chon Run as administrator.
    pause
    exit /b 1
)

set "PORT=5000"
set /p "PORT=Nhap cong may chu, Enter de dung 5000: "
if "%PORT%"=="" set "PORT=5000"

netsh advfirewall firewall delete rule name="Thi Trac Nghiem LAN v2.2" >nul 2>&1
netsh advfirewall firewall add rule name="Thi Trac Nghiem LAN v2.2" dir=in action=allow protocol=TCP localport=%PORT%
if errorlevel 1 (
    echo Khong the tao quy tac Firewall.
) else (
    echo Da mo cong %PORT% cho may hoc sinh truy cap trong mang LAN.
)
pause
