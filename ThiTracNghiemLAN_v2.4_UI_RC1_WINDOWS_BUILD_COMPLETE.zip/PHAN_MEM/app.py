from scoring import total_score
from snapshot_validation import load_snapshot, question_data, SnapshotValidationError
from urllib.parse import urlsplit

from flask import Flask, render_template, request, redirect, url_for, session, send_file, flash, jsonify
import sqlite3, random, json, os, shutil, hashlib, secrets, socket, logging, sys, time, platform, uuid, math
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta
from pathlib import Path
from werkzeug.utils import secure_filename
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter
from functools import wraps
from question_types import TYPES, snapshot, correct as answer_correct, decode, from_form, completed
from license_core import format_license_code, verify_license_code, license_details, trial_status

# PyInstaller-safe paths:
# RESOURCE_DIR: bundled read-only resources such as templates.
# DATA_DIR: persistent writable data beside the EXE.
if getattr(sys, "frozen", False):
    RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    DATA_DIR = Path(sys.executable).resolve().parent
else:
    RESOURCE_DIR = Path(__file__).resolve().parent
    DATA_DIR = RESOURCE_DIR

# Prefer the editable templates folder beside the EXE. Fall back to the copy
# bundled by PyInstaller when the external folder is unavailable.
EXTERNAL_TEMPLATE_DIR = DATA_DIR / "templates"
TEMPLATE_DIR = EXTERNAL_TEMPLATE_DIR if EXTERNAL_TEMPLATE_DIR.exists() else RESOURCE_DIR / "templates"
EXTERNAL_STATIC_DIR = DATA_DIR / "static"
STATIC_DIR = EXTERNAL_STATIC_DIR if EXTERNAL_STATIC_DIR.exists() else RESOURCE_DIR / "static"
app = Flask(__name__, template_folder=str(TEMPLATE_DIR),
            static_folder=str(STATIC_DIR), static_url_path="/static")

BASE_DIR = DATA_DIR
SECRET_FILE = DATA_DIR / ".session_secret"
try:
    if SECRET_FILE.exists():
        app.secret_key = SECRET_FILE.read_text(encoding="utf-8").strip()
    else:
        _secret = secrets.token_hex(32)
        SECRET_FILE.write_text(_secret, encoding="utf-8")
        app.secret_key = _secret
except Exception:
    app.secret_key = secrets.token_hex(32)

# F011: synchronizer nonce in the signed session; every unsafe request is checked.
def csrf_token():
    if not session.get('_csrf_token'):
        session['_csrf_token']=secrets.token_urlsafe(32)
    return session['_csrf_token']

@app.context_processor
def inject_csrf():
    return {'csrf_token':csrf_token}

@app.before_request
def protect_csrf():
    if request.method not in ('POST','PUT','PATCH','DELETE'):
        return None
    expected=session.get('_csrf_token')
    supplied=request.headers.get('X-CSRF-Token') or request.form.get('csrf_token')
    valid=isinstance(expected,str) and isinstance(supplied,str) and secrets.compare_digest(expected.encode('utf-8'),supplied.encode('utf-8'))
    # Tokens are primary; reject explicit foreign/null origin as defense in depth.
    origin=request.headers.get('Origin')
    reference=origin if origin is not None else request.headers.get('Referer')
    if reference is not None:
        try:
            source=urlsplit(reference); target=urlsplit(request.host_url)
            valid=valid and (source.scheme.lower(),source.netloc.lower())==(target.scheme.lower(),target.netloc.lower())
        except ValueError:
            valid=False
    if not valid:
        if request.path.startswith('/api/') or request.path.startswith('/teacher/api/'):
            return jsonify(ok=False,reason='csrf'),403
        return app.response_class('Yêu cầu không hợp lệ (CSRF). Hãy mở lại trang và gửi từ ứng dụng.',status=403,mimetype='text/plain')

@app.errorhandler(SnapshotValidationError)
def invalid_snapshot(error):
    if request.path.startswith('/api/') or request.path.startswith('/teacher/api/'):
        return jsonify(ok=False,reason='invalid_snapshot',message=str(error)),400
    return app.response_class('Dữ liệu câu hỏi/bài thi không hợp lệ: '+str(error),status=400,mimetype='text/plain')

DB_PATH = DATA_DIR / "thi_trac_nghiem.db"
UPLOAD_DIR = DATA_DIR / "uploads"
IMPORT_DIR = DATA_DIR / "imports"
EXPORT_DIR = DATA_DIR / "exports"
BACKUP_DIR = DATA_DIR / "backups"
LOG_DIR = DATA_DIR / "logs"
for p in [UPLOAD_DIR, IMPORT_DIR, EXPORT_DIR, BACKUP_DIR, LOG_DIR]:
    p.mkdir(parents=True, exist_ok=True)

# ---------- Logging ----------
handler = RotatingFileHandler(LOG_DIR / "app.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")
handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)
app.logger.setLevel(logging.INFO)

# ---------- DB helpers ----------
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn

def hash_password(password, salt=None):
    salt=salt or secrets.token_hex(16)
    digest=hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 120000).hex()
    return salt,digest

def verify_password(password,salt,digest):
    _,check=hash_password(password,salt)
    return secrets.compare_digest(check,digest)

def teacher_required(f):
    @wraps(f)
    def wrapped(*args,**kwargs):
        if not session.get("teacher_logged_in"):
            return redirect(url_for("teacher_login"))
        return f(*args,**kwargs)
    return wrapped


def admin_required(f):
    @wraps(f)
    def wrapped(*args,**kwargs):
        if not session.get("teacher_logged_in"):
            return redirect(url_for("teacher_login"))
        if session.get("teacher_role")!="ADMIN":
            flash("Chức năng này chỉ dành cho quản trị viên.")
            return redirect(url_for("teacher"))
        return f(*args,**kwargs)
    return wrapped

def audit(action, detail=""):
    try:
        c=db()
        c.execute("""INSERT INTO nhat_ky(thoi_gian,username,hanh_dong,chi_tiet,ip)
                     VALUES(?,?,?,?,?)""",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                   session.get("teacher_username",""),
                   action,
                   str(detail)[:1000],
                   request.remote_addr if request else ""))
        c.commit()
        c.close()
    except Exception:
        app.logger.exception("Audit log failed")

def is_locked(row):
    if not row or not row["locked_until"]:
        return False
    try:
        return datetime.strptime(row["locked_until"],"%Y-%m-%d %H:%M:%S") > datetime.now()
    except:
        return False

def create_sqlite_backup(target):
    src=sqlite3.connect(DB_PATH)
    dst=sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def get_setting(key, default=""):
    c=db()
    row=c.execute("SELECT gia_tri FROM cai_dat WHERE khoa=?",(key,)).fetchone()
    c.close()
    return row["gia_tri"] if row else default

def set_setting(key, value):
    c=db()
    c.execute("""INSERT INTO cai_dat(khoa,gia_tri) VALUES(?,?)
                 ON CONFLICT(khoa) DO UPDATE SET gia_tri=excluded.gia_tri""",
              (key,str(value)))
    c.commit()
    c.close()

def get_all_settings():
    c=db()
    rows=c.execute("SELECT khoa,gia_tri FROM cai_dat").fetchall()
    c.close()
    return {r["khoa"]:r["gia_tri"] for r in rows}


def get_lan_ips():
    ips=[]
    try:
        host=socket.gethostname()
        for item in socket.getaddrinfo(host,None,socket.AF_INET):
            ip=item[4][0]
            if ip and not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except:
        pass

    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(("8.8.8.8",80))
        ip=s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127.") and ip not in ips:
            ips.insert(0,ip)
    except:
        pass

    return ips or ["127.0.0.1"]

def get_server_port():
    try:
        p=int(get_setting("server_port","5000") or 5000)
        return p if 1024 <= p <= 65535 else 5000
    except:
        return 5000

def system_snapshot():
    import shutil as _shutil
    try:
        usage=_shutil.disk_usage(DATA_DIR)
        free_gb=round(usage.free/(1024**3),2)
    except:
        free_gb=0

    try:
        db_size=round(DB_PATH.stat().st_size/(1024*1024),2) if DB_PATH.exists() else 0
    except:
        db_size=0

    c=db()
    try:
        counts={
            "students":c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0],
            "questions":c.execute("SELECT COUNT(*) FROM cau_hoi").fetchone()[0],
            "exams":c.execute("SELECT COUNT(*) FROM ky_thi").fetchone()[0],
            "submitted":c.execute("SELECT COUNT(*) FROM bai_thi WHERE submitted_at IS NOT NULL").fetchone()[0],
            "active":c.execute("""SELECT COUNT(*) FROM bai_thi
                                WHERE submitted_at IS NULL
                                AND last_seen_at IS NOT NULL""").fetchone()[0]
        }
    finally:
        c.close()

    return {
        "ips":get_lan_ips(),
        "port":get_server_port(),
        "db_size_mb":db_size,
        "free_gb":free_gb,
        "counts":counts,
        "data_dir":str(DATA_DIR),
        "python":sys.version.split()[0],
        "frozen":bool(getattr(sys,"frozen",False))
    }

def machine_id():
    raw=f"{platform.node()}|{platform.system()}|{platform.machine()}|{uuid.getnode()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20].upper()

def get_license_status():
    mid=machine_id()
    local_state=DATA_DIR / "license_trial.json"
    system_state=Path(os.environ.get("LOCALAPPDATA", str(Path.home()/".local"/"share"))) / "ThiTracNghiemLAN" / (mid+".json")
    trial=trial_status([local_state,system_state],mid)
    paid=license_details(get_setting("license_code",""),mid,get_setting("license_name",""))
    if paid["kind"]=="legacy":
        return paid
    if trial["kind"] in {"clock","state"}:
        return trial
    if paid["kind"]=="annual":
        return paid
    return trial


def is_access_allowed():
    return get_license_status()["active"]


def is_license_valid():
    owner=get_setting("license_name","")
    code=get_setting("license_code","")
    return verify_license_code(code,machine_id(),owner)

def auto_backup_daily():
    try:
        if not DB_PATH.exists():
            return
        BACKUP_DIR.mkdir(exist_ok=True)
        today=datetime.now().strftime("%Y%m%d")
        target=BACKUP_DIR/f"auto_{today}.db"
        if not target.exists():
            create_sqlite_backup(target)
            app.logger.info("Automatic daily backup created: %s", target.name)

        autos=sorted(BACKUP_DIR.glob("auto_*.db"), key=lambda p:p.stat().st_mtime, reverse=True)
        for old in autos[15:]:
            try:
                old.unlink()
            except:
                pass
    except Exception:
        app.logger.exception("Automatic backup failed")

def init_db():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS tai_khoan_gv(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      ho_ten TEXT,
      vai_tro TEXT NOT NULL DEFAULT 'GIAOVIEN',
      active INTEGER NOT NULL DEFAULT 1,
      failed_attempts INTEGER NOT NULL DEFAULT 0,
      locked_until TEXT,
      last_login TEXT,
      created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS nhat_ky(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      thoi_gian TEXT NOT NULL,
      username TEXT,
      hanh_dong TEXT NOT NULL,
      chi_tiet TEXT,
      ip TEXT
    );
    CREATE TABLE IF NOT EXISTS cai_dat(
      khoa TEXT PRIMARY KEY,
      gia_tri TEXT
    );
    CREATE TABLE IF NOT EXISTS hoc_sinh(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ma_hs TEXT UNIQUE NOT NULL,
      ho_ten TEXT NOT NULL,
      lop TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cau_hoi(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ma_cau TEXT,
      mon TEXT,
      chu_de TEXT,
      muc_do TEXT,
      noi_dung TEXT NOT NULL,
      a TEXT NOT NULL,b TEXT NOT NULL,c TEXT NOT NULL,d TEXT NOT NULL,
      dap_an_dung TEXT NOT NULL,
      hinh_anh TEXT
    );
    CREATE TABLE IF NOT EXISTS ky_thi(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ten TEXT NOT NULL,
      lop TEXT,
      mon TEXT,
      so_cau INTEGER NOT NULL,
      thoi_gian_phut INTEGER NOT NULL,
      chu_de TEXT,
      muc_do TEXT,
      nb_count INTEGER NOT NULL DEFAULT 0,
      th_count INTEGER NOT NULL DEFAULT 0,
      vd_count INTEGER NOT NULL DEFAULT 0,
      vdc_count INTEGER NOT NULL DEFAULT 0,
      hien_diem INTEGER NOT NULL DEFAULT 1,
      trang_thai TEXT NOT NULL DEFAULT 'MO',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS bai_thi(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ky_thi_id INTEGER NOT NULL,
      ma_hs TEXT NOT NULL,
      ho_ten TEXT NOT NULL,
      lop TEXT NOT NULL,
      started_at TEXT NOT NULL,
      deadline_at TEXT NOT NULL,
      submitted_at TEXT,
      de_json TEXT NOT NULL,
      so_cau_dung INTEGER,
      tong_so_cau INTEGER,
      diem REAL,
      last_seen_at TEXT,
      client_token TEXT,
      force_relogin INTEGER NOT NULL DEFAULT 0,
      UNIQUE(ky_thi_id,ma_hs)
    );
    CREATE TABLE IF NOT EXISTS cau_tra_loi(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      bai_thi_id INTEGER NOT NULL,
      vi_tri_cau INTEGER NOT NULL,
      cau_hoi_id INTEGER NOT NULL,
      lua_chon INTEGER,
      dung INTEGER NOT NULL DEFAULT 0,
      saved_at TEXT NOT NULL,
      UNIQUE(bai_thi_id,vi_tri_cau)
    );
    """)
    cols=[r["name"] for r in c.execute("PRAGMA table_info(cau_hoi)").fetchall()]
    if "hinh_anh" not in cols:
        c.execute("ALTER TABLE cau_hoi ADD COLUMN hinh_anh TEXT")
    cols=[r["name"] for r in c.execute("PRAGMA table_info(bai_thi)").fetchall()]
    if "last_seen_at" not in cols:
        c.execute("ALTER TABLE bai_thi ADD COLUMN last_seen_at TEXT")
    if "client_token" not in cols:
        c.execute("ALTER TABLE bai_thi ADD COLUMN client_token TEXT")
    if "force_relogin" not in cols:
        c.execute("ALTER TABLE bai_thi ADD COLUMN force_relogin INTEGER NOT NULL DEFAULT 0")
    acc_cols=[r["name"] for r in c.execute("PRAGMA table_info(tai_khoan_gv)").fetchall()]
    if "ho_ten" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN ho_ten TEXT")
    if "vai_tro" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN vai_tro TEXT NOT NULL DEFAULT 'GIAOVIEN'")
    if "active" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
    if "failed_attempts" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN failed_attempts INTEGER NOT NULL DEFAULT 0")
    if "locked_until" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN locked_until TEXT")
    if "last_login" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN last_login TEXT")
    if "created_at" not in acc_cols:
        c.execute("ALTER TABLE tai_khoan_gv ADD COLUMN created_at TEXT")
    # v2.2.1: indexes keep search/filter responsive with large school rosters.
    c.execute("CREATE INDEX IF NOT EXISTS idx_hoc_sinh_lop_hoten ON hoc_sinh(lop,ho_ten)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_hoc_sinh_hoten ON hoc_sinh(ho_ten)")
    exam_cols=[r["name"] for r in c.execute("PRAGMA table_info(ky_thi)").fetchall()]
    if "nb_count" not in exam_cols:
        c.execute("ALTER TABLE ky_thi ADD COLUMN nb_count INTEGER NOT NULL DEFAULT 0")
    if "th_count" not in exam_cols:
        c.execute("ALTER TABLE ky_thi ADD COLUMN th_count INTEGER NOT NULL DEFAULT 0")
    if "vd_count" not in exam_cols:
        c.execute("ALTER TABLE ky_thi ADD COLUMN vd_count INTEGER NOT NULL DEFAULT 0")
    if "vdc_count" not in exam_cols:
        c.execute("ALTER TABLE ky_thi ADD COLUMN vdc_count INTEGER NOT NULL DEFAULT 0")
    if not c.execute("SELECT 1 FROM tai_khoan_gv WHERE username='admin'").fetchone():
        salt,digest=hash_password("123456")
        c.execute("""INSERT INTO tai_khoan_gv(
                     username,password_salt,password_hash,ho_ten,vai_tro,active,
                     failed_attempts,created_at)
                     VALUES(?,?,?,?, 'ADMIN',1,0,?)""",
                  ("admin",salt,digest,"Quản trị viên",datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    else:
        c.execute("UPDATE tai_khoan_gv SET vai_tro='ADMIN',active=1 WHERE username='admin'")

    defaults={
        "school_name":"TRƯỜNG THCS",
        "system_name":"THI TRẮC NGHIỆM LAN",
        "support_text":"",
        "logo_file":"",
        "license_name":"",
        "license_code":"",
        "server_port":"5000"
    }
    for k,v in defaults.items():
        c.execute("INSERT OR IGNORE INTO cai_dat(khoa,gia_tri) VALUES(?,?)",(k,v))
    c.commit(); c.close()

def norm_answer(x):
    s="" if x is None else str(x).strip().upper()
    return s if s in ("A","B","C","D") else ""


def now_text():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def seconds_since(ts):
    if not ts:
        return 10**9
    try:
        dt=datetime.strptime(ts,"%Y-%m-%d %H:%M:%S")
        return (datetime.now()-dt).total_seconds()
    except:
        return 10**9

def validate_attempt_session(c, aid):
    token=session.get("client_token")
    row=c.execute("SELECT * FROM bai_thi WHERE id=?",(aid,)).fetchone()
    if not row:
        return None
    # F017: NULL is compatible with legacy attempts only when not revoked.
    if row["force_relogin"]:
        return None
    if row["client_token"] and token != row["client_token"]:
        return None
    return row

def _question_filters(mon="", topics=None):
    sql="SELECT * FROM cau_hoi WHERE 1=1"
    args=[]
    if mon:
        sql+=" AND mon=?"
        args.append(mon)
    topics=topics or []
    topics=[x.strip() for x in topics if x and x.strip()]
    if topics:
        sql+=" AND chu_de IN (%s)" % ",".join("?"*len(topics))
        args+=topics
    return sql,args

def question_classification(row):
    level=(row["muc_do"] or "").strip().upper()
    kind=(row["question_type"] or "SINGLE").strip().upper() if "question_type" in row.keys() else "SINGLE"
    return level,kind if kind in TYPES else "SINGLE"

def question_availability(mon="", topics=None):
    sql,args=_question_filters(mon,topics)
    c=db()
    rows=c.execute(sql,args).fetchall()
    c.close()
    counts={"NB":0,"TH":0,"VD":0,"VDC":0,"TOTAL":0}
    by_type={k:{"NB":0,"TH":0,"VD":0,"VDC":0,"TOTAL":0} for k in TYPES}
    for r in rows:
        lv,kind=question_classification(r)
        if lv in ("NB","TH","VD","VDC"):
            counts[lv]+=1
            by_type[kind][lv]+=1
            by_type[kind]["TOTAL"]+=1
        counts["TOTAL"]+=1
    return counts,by_type

def exam_topics(value, quotas=None):
    # F003: metadata distinguishes new lists from every legacy topic-name string.
    if (quotas or {}).get("_topics_format")=={"version":1}:
        decoded=json.loads(value)
        if isinstance(decoded,list) and all(isinstance(x,str) for x in decoded):
            return [x.strip() for x in decoded if x.strip()]
        raise ValueError("Danh sách chủ đề kỳ thi không hợp lệ.")
    return [x.strip() for x in (value or "").split(",") if x.strip()]

def build_exam(kt):
    topics=exam_topics(kt["chu_de"])
    sql,args=_question_filters(kt["mon"] or "",topics)
    c=db()
    rows=list(c.execute(sql,args).fetchall())
    c.close()

    quotas={
        "NB": int(kt["nb_count"] or 0),
        "TH": int(kt["th_count"] or 0),
        "VD": int(kt["vd_count"] or 0),
        "VDC": int(kt["vdc_count"] or 0),
    }

    selected=[]
    if sum(quotas.values())>0:
        # Exact number of questions from each cognitive level.
        by_level={"NB":[],"TH":[],"VD":[],"VDC":[]}
        for r in rows:
            lv=(r["muc_do"] or "").strip().upper()
            if lv in by_level:
                by_level[lv].append(r)

        for lv,needed in quotas.items():
            random.shuffle(by_level[lv])
            selected.extend(by_level[lv][:needed])
    else:
        # Compatibility with older exams: filter selected levels if present.
        allowed=[x.strip().upper() for x in (kt["muc_do"] or "").split(",") if x.strip()]
        if allowed:
            rows=[r for r in rows if (r["muc_do"] or "").strip().upper() in allowed]
        random.shuffle(rows)
        selected=rows[:min(int(kt["so_cau"]),len(rows))]

    random.shuffle(selected)
    out=[snapshot(dict(r,question_type=question_classification(r)[1])) for r in selected]
    return out



@app.context_processor
def inject_branding():
    s=get_all_settings()
    return {
        "brand_school":s.get("school_name","TRƯỜNG THCS"),
        "brand_system":s.get("system_name","THI TRẮC NGHIỆM LAN"),
        "brand_logo":s.get("logo_file",""),
        "brand_support":s.get("support_text",""),
        "license_valid":is_license_valid(),
        "license_status":get_license_status()
    }

@app.before_request
def enforce_commercial_license():
    if is_access_allowed():
        return None

    allowed={
        "teacher_login",
        "teacher_logout",
        "license_page",
        "health",
        "about_page",
        "static",
    }
    if request.endpoint in allowed:
        return None

    if request.path.startswith("/teacher"):
        if session.get("teacher_logged_in") and session.get("teacher_role")=="ADMIN":
            return redirect(url_for("license_page"))
        return redirect(url_for("teacher_login"))

    if request.path.startswith("/api/"):
        return jsonify(ok=False,reason="license_required"),403

    return render_template("license_required.html",machine_id=machine_id()),403

@app.before_request
def _daily_maintenance():
    # Lightweight check; actual copy occurs only once per day.
    if request.path.startswith("/teacher"):
        auto_backup_daily()

# ---------- Teacher auth ----------
@app.route("/teacher/login",methods=["GET","POST"])
def teacher_login():
    if request.method=="POST":
        u=request.form.get("username","").strip()
        p=request.form.get("password","")
        c=db()
        row=c.execute("SELECT * FROM tai_khoan_gv WHERE username=?",(u,)).fetchone()

        if row and int(row["active"] or 0)==0:
            c.close()
            flash("Tài khoản đã bị vô hiệu hóa.")
            return render_template("teacher_login.html")

        if row and is_locked(row):
            until=row["locked_until"]
            c.close()
            flash(f"Tài khoản đang tạm khóa do đăng nhập sai nhiều lần. Thử lại sau {until}.")
            return render_template("teacher_login.html")

        if row and verify_password(p,row["password_salt"],row["password_hash"]):
            now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute("""UPDATE tai_khoan_gv
                         SET failed_attempts=0,locked_until=NULL,last_login=?
                         WHERE id=?""",(now,row["id"]))
            c.commit()
            c.close()

            session.clear()
            csrf_token()
            session["teacher_logged_in"]=True
            session["teacher_username"]=u
            session["teacher_name"]=row["ho_ten"] or u
            session["teacher_role"]=row["vai_tro"] or "GIAOVIEN"
            audit("ĐĂNG NHẬP","Đăng nhập thành công")
            app.logger.info("Teacher login: %s", u)
            if not is_access_allowed():
                if session.get("teacher_role")=="ADMIN":
                    flash("Hãy kích hoạt bản quyền để sử dụng phần mềm.")
                    return redirect(url_for("license_page"))
                session.clear()
                flash("Phần mềm chưa kích hoạt. Vui lòng liên hệ quản trị viên.")
                return redirect(url_for("teacher_login"))
            return redirect(url_for("teacher"))

        if row:
            attempts=int(row["failed_attempts"] or 0)+1
            locked_until=None
            if attempts>=5:
                locked_until=(datetime.now()+timedelta(minutes=15)).strftime("%Y-%m-%d %H:%M:%S")
                attempts=0
            c.execute("UPDATE tai_khoan_gv SET failed_attempts=?,locked_until=? WHERE id=?",
                      (attempts,locked_until,row["id"]))
            c.commit()
        c.close()
        flash("Sai tài khoản hoặc mật khẩu.")
    return render_template("teacher_login.html")

@app.post("/teacher/logout")
def teacher_logout():
    if session.get("teacher_logged_in"):
        audit("ĐĂNG XUẤT","Đăng xuất hệ thống")
    session.clear()
    return redirect(url_for("teacher_login"))

@app.route("/teacher")
@teacher_required
def teacher():
    c=db()
    exams=c.execute("SELECT * FROM ky_thi ORDER BY id DESC").fetchall()
    student_count=c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0]
    class_count=c.execute("SELECT COUNT(DISTINCT lop) FROM hoc_sinh").fetchone()[0]
    questions=c.execute("SELECT * FROM cau_hoi ORDER BY id DESC LIMIT 100").fetchall()
    classes=[r[0] for r in c.execute("SELECT DISTINCT lop FROM hoc_sinh ORDER BY lop").fetchall()]
    subjects=[r[0] for r in c.execute("SELECT DISTINCT mon FROM cau_hoi WHERE mon<>'' ORDER BY mon").fetchall()]
    topics=[r[0] for r in c.execute("SELECT DISTINCT chu_de FROM cau_hoi WHERE chu_de<>'' ORDER BY chu_de").fetchall()]
    c.close()
    return render_template("teacher.html",exams=exams,student_count=student_count,
                           class_count=class_count,questions=questions,classes=classes,
                           subjects=subjects,topics=topics,question_types=TYPES)


# ---------- Security & account management v1.6 ----------
@app.route("/teacher/change-password",methods=["GET","POST"])
@teacher_required
def change_password():
    if request.method=="POST":
        old=request.form.get("old_password","")
        new=request.form.get("new_password","")
        confirm=request.form.get("confirm_password","")

        if len(new)<8:
            flash("Mật khẩu mới phải có ít nhất 8 ký tự.")
            return render_template("change_password.html")
        if new!=confirm:
            flash("Xác nhận mật khẩu mới không khớp.")
            return render_template("change_password.html")

        c=db()
        row=c.execute("SELECT * FROM tai_khoan_gv WHERE username=?",
                      (session.get("teacher_username"),)).fetchone()
        if not row or not verify_password(old,row["password_salt"],row["password_hash"]):
            c.close()
            flash("Mật khẩu hiện tại không đúng.")
            return render_template("change_password.html")

        salt,digest=hash_password(new)
        c.execute("""UPDATE tai_khoan_gv
                     SET password_salt=?,password_hash=?,failed_attempts=0,locked_until=NULL
                     WHERE id=?""",(salt,digest,row["id"]))
        c.commit()
        c.close()
        audit("ĐỔI MẬT KHẨU","Tài khoản tự đổi mật khẩu")
        flash("Đã đổi mật khẩu thành công.")
        return redirect(url_for("teacher"))
    return render_template("change_password.html")

@app.get("/teacher/accounts")
@admin_required
def teacher_accounts():
    c=db()
    rows=c.execute("""SELECT id,username,ho_ten,vai_tro,active,last_login,created_at
                      FROM tai_khoan_gv ORDER BY CASE WHEN username='admin' THEN 0 ELSE 1 END,username""").fetchall()
    c.close()
    return render_template("accounts.html",accounts=rows)

@app.post("/teacher/accounts/add")
@admin_required
def add_teacher_account():
    username=request.form.get("username","").strip()
    name=request.form.get("ho_ten","").strip()
    role=request.form.get("vai_tro","GIAOVIEN").strip().upper()
    password=request.form.get("password","")

    if not username or len(password)<8:
        flash("Tên đăng nhập không được trống và mật khẩu phải có ít nhất 8 ký tự.")
        return redirect(url_for("teacher_accounts"))
    if role not in ("ADMIN","GIAOVIEN"):
        role="GIAOVIEN"

    salt,digest=hash_password(password)
    c=db()
    try:
        c.execute("""INSERT INTO tai_khoan_gv(
                     username,password_salt,password_hash,ho_ten,vai_tro,active,
                     failed_attempts,created_at)
                     VALUES(?,?,?,?,?,1,0,?)""",
                  (username,salt,digest,name,role,datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        c.commit()
        audit("TẠO TÀI KHOẢN",f"{username} - {role}")
        flash("Đã tạo tài khoản giáo viên.")
    except sqlite3.IntegrityError:
        flash("Tên đăng nhập đã tồn tại.")
    finally:
        c.close()
    return redirect(url_for("teacher_accounts"))

@app.post("/teacher/accounts/<int:uid>/toggle")
@admin_required
def toggle_teacher_account(uid):
    c=db()
    row=c.execute("SELECT * FROM tai_khoan_gv WHERE id=?",(uid,)).fetchone()
    if not row:
        c.close()
        flash("Không tìm thấy tài khoản.")
        return redirect(url_for("teacher_accounts"))

    if row["username"]=="admin":
        c.close()
        flash("Không thể vô hiệu hóa tài khoản admin mặc định.")
        return redirect(url_for("teacher_accounts"))

    new_active=0 if int(row["active"] or 0)==1 else 1
    c.execute("UPDATE tai_khoan_gv SET active=? WHERE id=?",(new_active,uid))
    c.commit()
    c.close()
    audit("ĐỔI TRẠNG THÁI TÀI KHOẢN",f"{row['username']} -> {'Bật' if new_active else 'Tắt'}")
    flash("Đã cập nhật trạng thái tài khoản.")
    return redirect(url_for("teacher_accounts"))

@app.post("/teacher/accounts/<int:uid>/reset-password")
@admin_required
def reset_teacher_password(uid):
    new=request.form.get("new_password","")
    if len(new)<8:
        flash("Mật khẩu mới phải có ít nhất 8 ký tự.")
        return redirect(url_for("teacher_accounts"))

    c=db()
    row=c.execute("SELECT * FROM tai_khoan_gv WHERE id=?",(uid,)).fetchone()
    if not row:
        c.close()
        flash("Không tìm thấy tài khoản.")
        return redirect(url_for("teacher_accounts"))

    salt,digest=hash_password(new)
    c.execute("""UPDATE tai_khoan_gv
                 SET password_salt=?,password_hash=?,failed_attempts=0,locked_until=NULL
                 WHERE id=?""",(salt,digest,uid))
    c.commit()
    c.close()
    audit("ĐẶT LẠI MẬT KHẨU",row["username"])
    flash(f"Đã đặt lại mật khẩu cho {row['username']}.")
    return redirect(url_for("teacher_accounts"))

@app.get("/teacher/audit")
@admin_required
def audit_log():
    c=db()
    rows=c.execute("SELECT * FROM nhat_ky ORDER BY id DESC LIMIT 500").fetchall()
    c.close()
    return render_template("audit.html",logs=rows)



# ---------- Branding & licensing v1.7 ----------
@app.route("/teacher/settings",methods=["GET","POST"])
@admin_required
def system_settings():
    if request.method=="POST":
        school=request.form.get("school_name","").strip()
        system_name=request.form.get("system_name","").strip()
        support=request.form.get("support_text","").strip()
        port_raw=request.form.get("server_port","5000").strip()

        if school:
            set_setting("school_name",school)
        if system_name:
            set_setting("system_name",system_name)
        set_setting("support_text",support)

        try:
            port_num=int(port_raw)
            if not (1024 <= port_num <= 65535):
                raise ValueError()
            set_setting("server_port",str(port_num))
        except:
            flash("Cổng máy chủ phải từ 1024 đến 65535.")
            return redirect(url_for("system_settings"))

        f=request.files.get("logo")
        if f and f.filename:
            safe=secure_filename(f.filename)
            ext=Path(safe).suffix.lower()
            if ext in (".png",".jpg",".jpeg",".webp"):
                logo_name="school_logo"+ext
                f.save(UPLOAD_DIR/logo_name)
                set_setting("logo_file",logo_name)
            else:
                flash("Logo phải là PNG/JPG/JPEG/WEBP.")
                return redirect(url_for("system_settings"))

        audit("CẬP NHẬT CÀI ĐẶT","Tên trường / tên hệ thống / logo / hỗ trợ")
        flash("Đã lưu cài đặt hệ thống.")
        return redirect(url_for("system_settings"))

    return render_template("settings.html",settings=get_all_settings())

@app.route("/teacher/license",methods=["GET","POST"])
@admin_required
def license_page():
    mid=machine_id()
    if request.method=="POST":
        owner=request.form.get("license_name","").strip()
        code=format_license_code(request.form.get("license_code",""))
        if verify_license_code(code,mid,owner):
            set_setting("license_name",owner)
            set_setting("license_code",code)
            audit("KÍCH HOẠT BẢN QUYỀN",f"{owner} - {mid}")
            flash("Đã lưu mã kích hoạt. Xem ngày hết hạn bên dưới.")
        else:
            flash("Mã không hợp lệ, chưa đến ngày hiệu lực hoặc đã hết hạn. Mã đang lưu được giữ nguyên.")
        return redirect(url_for("license_page"))

    return render_template(
        "license.html",
        machine_id=mid,
        valid=is_license_valid(),
        settings=get_all_settings()
    )

@app.get("/about")
def about_page():
    return render_template(
        "about.html",
        machine_id=machine_id(),
        settings=get_all_settings(),
        valid=is_license_valid()
    )



# ---------- Production readiness v2.1 ----------
@app.get("/health")
def health():
    try:
        c=db()
        c.execute("SELECT 1").fetchone()
        c.close()
        return jsonify(
            ok=True,
            version="2.2.1",
            time=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
    except Exception as e:
        app.logger.exception("Health check failed")
        return jsonify(ok=False,version="2.2.1"),500

@app.get("/teacher/system-status")
@teacher_required
def system_status():
    return render_template(
        "system_status.html",
        info=system_snapshot()
    )


# ---------- Student management ----------
def student_filters():
    q=request.args.get("q","").strip()
    lop=request.args.get("lop","").strip()
    where=[]; args=[]
    if q:
        where.append("(ma_hs LIKE ? OR ho_ten LIKE ?)")
        args.extend([f"%{q}%",f"%{q}%"])
    if lop:
        where.append("lop=?"); args.append(lop)
    return q,lop,(" WHERE "+" AND ".join(where) if where else ""),args


@app.get("/teacher/students")
@teacher_required
def students_page():
    q,lop,where,args=student_filters()
    try: page=max(1,int(request.args.get("page","1")))
    except ValueError: page=1
    try: per_page=int(request.args.get("per_page","50"))
    except ValueError: per_page=50
    if per_page not in (25,50,100): per_page=50
    sort_key=request.args.get("sort","class")
    order={"code":"ma_hs COLLATE NOCASE","name":"ho_ten COLLATE NOCASE",
           "class":"lop COLLATE NOCASE,ho_ten COLLATE NOCASE"}.get(sort_key,
           "lop COLLATE NOCASE,ho_ten COLLATE NOCASE")
    c=db()
    total=c.execute("SELECT COUNT(*) FROM hoc_sinh"+where,args).fetchone()[0]
    pages=max(1,(total+per_page-1)//per_page)
    page=min(page,pages)
    students=c.execute("SELECT * FROM hoc_sinh"+where+f" ORDER BY {order} LIMIT ? OFFSET ?",
                       args+[per_page,(page-1)*per_page]).fetchall()
    class_rows=c.execute("SELECT lop,COUNT(*) AS n FROM hoc_sinh GROUP BY lop ORDER BY lop").fetchall()
    grand_total=c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0]
    c.close()
    return render_template("students.html",students=students,class_rows=class_rows,
                           total=total,grand_total=grand_total,q=q,selected_class=lop,
                           page=page,pages=pages,per_page=per_page,sort=sort_key)


@app.post("/teacher/student/add")
@teacher_required
def add_student():
    ma=request.form.get("ma_hs","").strip()
    name=request.form.get("ho_ten","").strip()
    lop=request.form.get("lop","").strip()
    if ma and name and lop:
        c=db()
        c.execute("""INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES(?,?,?)
                     ON CONFLICT(ma_hs) DO UPDATE SET ho_ten=excluded.ho_ten,lop=excluded.lop""",(ma,name,lop))
        c.commit(); c.close(); flash(f"Đã lưu học sinh {ma}.")
    else:
        flash("Vui lòng nhập đủ mã học sinh, họ tên và lớp.")
    return redirect(url_for("students_page"))

@app.post("/teacher/student/delete/<int:sid>")
@teacher_required
def delete_student(sid):
    c=db(); c.execute("DELETE FROM hoc_sinh WHERE id=?",(sid,)); c.commit(); c.close()
    flash("Đã xóa học sinh khỏi danh sách.")
    return redirect(url_for("students_page"))


@app.post("/teacher/students/bulk")
@teacher_required
def students_bulk():
    ids=[]
    for value in request.form.getlist("student_ids"):
        try: ids.append(int(value))
        except ValueError: pass
    ids=list(dict.fromkeys(ids))
    if not ids:
        flash("Chưa chọn học sinh nào.")
        return redirect(url_for("students_page"))
    action=request.form.get("action","")
    marks=",".join("?" for _ in ids)
    if action=="move":
        new_class=request.form.get("new_class","").strip()
        if not new_class:
            flash("Vui lòng nhập lớp mới.")
            return redirect(url_for("students_page"))
        c=db(); cur=c.execute(f"UPDATE hoc_sinh SET lop=? WHERE id IN ({marks})",[new_class]+ids)
        c.commit(); changed=cur.rowcount; c.close()
        audit("CHUYỂN LỚP HỌC SINH",f"{changed} học sinh sang {new_class}")
        flash(f"Đã chuyển {changed} học sinh sang lớp {new_class}.")
    elif action=="delete":
        BACKUP_DIR.mkdir(exist_ok=True)
        backup_name=f"before_delete_students_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.db"
        create_sqlite_backup(BACKUP_DIR/backup_name)
        c=db(); cur=c.execute(f"DELETE FROM hoc_sinh WHERE id IN ({marks})",ids)
        c.commit(); changed=cur.rowcount; c.close()
        audit("XÓA HỌC SINH HÀNG LOẠT",f"{changed} học sinh; backup {backup_name}")
        flash(f"Đã xóa {changed} học sinh. Hệ thống đã sao lưu dữ liệu trước khi xóa.")
    else:
        flash("Thao tác hàng loạt không hợp lệ.")
    return redirect(url_for("students_page"))


@app.get("/teacher/students/export")
@teacher_required
def export_students():
    q,lop,where,args=student_filters()
    c=db(); rows=c.execute("SELECT ma_hs,ho_ten,lop FROM hoc_sinh"+where+
                          " ORDER BY lop COLLATE NOCASE,ho_ten COLLATE NOCASE",args).fetchall(); c.close()
    wb=Workbook(); ws=wb.active; ws.title="DanhSachHocSinh"
    ws.append(["Mã học sinh","Họ tên","Lớp"])
    for row in rows: ws.append([row["ma_hs"],row["ho_ten"],row["lop"]])
    excel_text_cells(cell for row in ws.iter_rows(min_row=2) for cell in row)
    for cell in ws[1]: cell.font=Font(bold=True)
    ws.column_dimensions["A"].width=20; ws.column_dimensions["B"].width=38; ws.column_dimensions["C"].width=15
    fn=EXPORT_DIR/f"DanhSachHocSinh_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    wb.save(fn)
    audit("XUẤT DANH SÁCH HỌC SINH",f"{len(rows)} học sinh")
    return send_file(fn,as_attachment=True,download_name=fn.name)

# ---------- Question management ----------
@app.post("/teacher/question/add")
@teacher_required
def add_question():
    f=request.files.get("image"); img=""
    if f and f.filename:
        fn=secure_filename(f.filename)
        f.save(UPLOAD_DIR/fn)
        img=fn
    vals=[
        request.form.get("ma_cau","").strip(),
        request.form.get("mon","").strip(),
        request.form.get("chu_de","").strip(),
        request.form.get("muc_do","").strip(),
        request.form.get("noi_dung","").strip(),
        request.form.get("a","").strip(),
        request.form.get("b","").strip(),
        request.form.get("c","").strip(),
        request.form.get("d","").strip(),
        norm_answer(request.form.get("dap_an_dung","")),
        img
    ]
    if vals[4] and all(vals[5:9]) and vals[9]:
        c=db()
        c.execute("""INSERT INTO cau_hoi(ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,hinh_anh)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?)""",vals)
        c.commit(); c.close()
    return redirect(url_for("teacher"))

@app.route("/teacher/question/edit/<int:qid>",methods=["GET","POST"])
@teacher_required
def edit_question(qid):
    c=db(); row=c.execute("SELECT * FROM cau_hoi WHERE id=?",(qid,)).fetchone()
    if not row:
        c.close(); return "Không tìm thấy",404
    if row["payload"]:
        c.close()
        return redirect(url_for("multi_editor",qid=qid))
    if request.method=="POST":
        answer=norm_answer(request.form.get("dap_an_dung",""))
        if not answer:
            c.close()
            return "Đáp án đúng phải là A, B, C hoặc D.",400
        c.execute("""UPDATE cau_hoi SET ma_cau=?,mon=?,chu_de=?,muc_do=?,noi_dung=?,a=?,b=?,c=?,d=?,dap_an_dung=? WHERE id=?""",
                  (request.form.get("ma_cau",""),request.form.get("mon",""),request.form.get("chu_de",""),
                   request.form.get("muc_do",""),request.form.get("noi_dung",""),
                   request.form.get("a",""),request.form.get("b",""),request.form.get("c",""),
                   request.form.get("d",""),answer,qid))
        c.commit(); c.close()
        return redirect(url_for("question_bank"))
    c.close()
    return render_template("edit_question.html",q=row)

@app.post("/teacher/question/delete/<int:qid>")
@teacher_required
def delete_question(qid):
    c=db()
    used=c.execute("SELECT 1 FROM cau_tra_loi WHERE cau_hoi_id=? LIMIT 1",(qid,)).fetchone()
    if used:
        c.close()
        flash("Không thể xóa câu hỏi đã xuất hiện trong bài thi vì sẽ làm hỏng báo cáo. Có thể sửa nội dung hoặc giữ lại.")
        return redirect(request.referrer or url_for("question_bank"))
    c.execute("DELETE FROM cau_hoi WHERE id=?",(qid,))
    c.commit()
    c.close()
    flash("Đã xóa câu hỏi.")
    return redirect(request.referrer or url_for("question_bank"))


# ---------- Advanced question bank v1.4 ----------
@app.get("/teacher/questions")
@teacher_required
def question_bank():
    keyword=request.args.get("q","").strip()
    mon=request.args.get("mon","").strip()
    topic=request.args.get("chu_de","").strip()
    level=request.args.get("muc_do","").strip().upper()

    sql="SELECT * FROM cau_hoi WHERE 1=1"
    args=[]
    if keyword:
        sql+=" AND (noi_dung LIKE ? OR ma_cau LIKE ? OR a LIKE ? OR b LIKE ? OR c LIKE ? OR d LIKE ?)"
        kw=f"%{keyword}%"
        args += [kw,kw,kw,kw,kw,kw]
    if mon:
        sql+=" AND mon=?"
        args.append(mon)
    if topic:
        sql+=" AND chu_de=?"
        args.append(topic)
    if level:
        sql+=" AND UPPER(muc_do)=?"
        args.append(level)

    sql+=" ORDER BY id DESC"
    c=db()
    rows=c.execute(sql,args).fetchall()
    subjects=[r[0] for r in c.execute("SELECT DISTINCT mon FROM cau_hoi WHERE mon<>'' ORDER BY mon").fetchall()]
    topics=[r[0] for r in c.execute("SELECT DISTINCT chu_de FROM cau_hoi WHERE chu_de<>'' ORDER BY chu_de").fetchall()]
    counts={lv:c.execute("SELECT COUNT(*) FROM cau_hoi WHERE UPPER(muc_do)=?",(lv,)).fetchone()[0]
            for lv in ("NB","TH","VD","VDC")}
    total=c.execute("SELECT COUNT(*) FROM cau_hoi").fetchone()[0]
    c.close()
    return render_template(
        "question_bank.html",
        questions=rows,
        subjects=subjects,
        topics=topics,
        keyword=keyword,
        selected_mon=mon,
        selected_topic=topic,
        selected_level=level,
        counts=counts,
        total=total
    )

@app.post("/teacher/question/clone/<int:qid>")
@teacher_required
def clone_question(qid):
    c=db()
    q=c.execute("SELECT * FROM cau_hoi WHERE id=?",(qid,)).fetchone()
    if not q:
        c.close()
        flash("Không tìm thấy câu hỏi.")
        return redirect(url_for("question_bank"))

    base=(q["ma_cau"] or "").strip()
    new_code=(base + "_COPY") if base else ""
    c.execute("""INSERT INTO cau_hoi(
                 ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung,hinh_anh,question_type,payload,khoi_lop)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (new_code,q["mon"],q["chu_de"],q["muc_do"],q["noi_dung"],
               q["a"],q["b"],q["c"],q["d"],q["dap_an_dung"],q["hinh_anh"],q["question_type"],q["payload"],q["khoi_lop"]))
    c.commit()
    c.close()
    flash("Đã nhân bản câu hỏi.")
    return redirect(request.referrer or url_for("question_bank"))

@app.post("/teacher/questions/bulk-delete")
@teacher_required
def bulk_delete_questions():
    raw=request.form.getlist("qid")
    ids=[]
    for x in raw:
        try:
            ids.append(int(x))
        except:
            pass
    if not ids:
        flash("Chưa chọn câu hỏi nào.")
        return redirect(request.referrer or url_for("question_bank"))

    c=db()
    marks=",".join("?"*len(ids))
    # Protect questions already referenced by saved student answers.
    used={r[0] for r in c.execute(
        f"SELECT DISTINCT cau_hoi_id FROM cau_tra_loi WHERE cau_hoi_id IN ({marks})",ids
    ).fetchall()}
    deletable=[x for x in ids if x not in used]
    if deletable:
        marks2=",".join("?"*len(deletable))
        c.execute(f"DELETE FROM cau_hoi WHERE id IN ({marks2})",deletable)
    c.commit()
    c.close()

    if used:
        flash(f"Đã xóa {len(deletable)} câu. Giữ lại {len(used)} câu đã xuất hiện trong bài thi để bảo toàn báo cáo.")
    else:
        flash(f"Đã xóa {len(deletable)} câu hỏi.")
    return redirect(url_for("question_bank"))

@app.get("/teacher/export-questions")
@teacher_required
def export_questions():
    c=db()
    has_multi=c.execute("SELECT 1 FROM cau_hoi WHERE payload<>'' LIMIT 1").fetchone()
    c.close()
    if has_multi:
        flash("Dùng xuất Excel nhiều dạng để giữ đầy đủ đáp án mới; tệp này xuất toàn bộ ngân hàng.")
        return redirect(url_for("multi_bank"))
    keyword=request.args.get("q","").strip()
    mon=request.args.get("mon","").strip()
    topic=request.args.get("chu_de","").strip()
    level=request.args.get("muc_do","").strip().upper()

    sql="SELECT * FROM cau_hoi WHERE 1=1"
    args=[]
    if keyword:
        sql+=" AND (noi_dung LIKE ? OR ma_cau LIKE ?)"
        kw=f"%{keyword}%"
        args += [kw,kw]
    if mon:
        sql+=" AND mon=?"
        args.append(mon)
    if topic:
        sql+=" AND chu_de=?"
        args.append(topic)
    if level:
        sql+=" AND UPPER(muc_do)=?"
        args.append(level)
    sql+=" ORDER BY id"

    c=db()
    rows=c.execute(sql,args).fetchall()
    c.close()

    wb=Workbook()
    ws=wb.active
    ws.title="NganHangCauHoi"
    ws.append(["Ma cau","Mon","Chu de","Muc do","Noi dung","A","B","C","D","Dap an dung","Hinh anh"])
    for q in rows:
        ws.append([q["ma_cau"],q["mon"],q["chu_de"],q["muc_do"],q["noi_dung"],
                   q["a"],q["b"],q["c"],q["d"],q["dap_an_dung"],q["hinh_anh"] or ""])
    excel_text_cells(cell for row in ws.iter_rows(min_row=2) for cell in row)

    fn=EXPORT_DIR/f"NganHangCauHoi_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    wb.save(fn)
    return send_file(fn,as_attachment=True,download_name=fn.name)


# ---------- Import ----------
def remove_import_file(path):
    """Best-effort cleanup; Windows may briefly keep uploaded workbooks locked."""
    try:
        path.unlink(missing_ok=True)
    except OSError as exc:
        app.logger.warning("Could not remove temporary import file %s: %s",path.name,exc)


def read_student_excel(path):
    wb=load_workbook(path,data_only=True,read_only=True)
    try:
        ws=wb.active
        by_code={}; invalid=0; duplicate_rows=0
        for index,row in enumerate(ws.iter_rows(min_row=2,values_only=True),start=2):
            if index>20001:
                raise ValueError("File vượt quá giới hạn 20.000 dòng.")
            vals=list(row)+[None]*3; ma,hoten,lop=vals[:3]
            ma=str(ma or "").strip(); hoten=str(hoten or "").strip(); lop=str(lop or "").strip()
            if not ma and not hoten and not lop:
                continue
            if not ma or not hoten or not lop:
                invalid+=1; continue
            if ma in by_code: duplicate_rows+=1
            by_code[ma]=(ma,hoten,lop)
        return list(by_code.values()),invalid,duplicate_rows
    finally:
        # Required on Windows: otherwise Path.unlink raises WinError 32.
        wb.close()


@app.post("/teacher/students/import-preview")
@teacher_required
def preview_student_import():
    f=request.files.get("file")
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash("Vui lòng chọn file danh sách .xlsx.")
        return redirect(url_for("students_page"))
    token=secrets.token_hex(16)
    path=IMPORT_DIR/f"students_preview_{token}.xlsx"
    f.save(path)
    try:
        rows,invalid,duplicate_rows=read_student_excel(path)
    except Exception:
        remove_import_file(path)
        app.logger.exception("Student import preview failed")
        flash("Không đọc được file. Hãy dùng mẫu gồm 3 cột: Mã học sinh, Họ tên, Lớp.")
        return redirect(url_for("students_page"))
    c=db(); existing={r[0] for r in c.execute("SELECT ma_hs FROM hoc_sinh").fetchall()}; c.close()
    existing_count=sum(1 for row in rows if row[0] in existing)
    session["student_import_token"]=token
    return render_template("students_import_preview.html",token=token,rows=rows[:20],
                           valid_count=len(rows),invalid_count=invalid,
                           duplicate_rows=duplicate_rows,existing_count=existing_count)


@app.post("/teacher/students/import-confirm")
@teacher_required
def confirm_student_import():
    token=request.form.get("token","")
    if not secrets.compare_digest(token,session.get("student_import_token","")):
        flash("Phiên xem trước đã hết hạn. Vui lòng chọn lại file.")
        return redirect(url_for("students_page"))
    path=IMPORT_DIR/f"students_preview_{token}.xlsx"
    if not path.exists():
        flash("Không tìm thấy file xem trước.")
        return redirect(url_for("students_page"))
    mode=request.form.get("mode","update")
    if mode not in ("update","skip"): mode="update"
    c=None
    try:
        rows,invalid,duplicate_rows=read_student_excel(path)
        c=db(); existing={r[0] for r in c.execute("SELECT ma_hs FROM hoc_sinh").fetchall()}
        created=updated=skipped=0
        for ma,hoten,lop in rows:
            if ma in existing:
                if mode=="skip": skipped+=1; continue
                c.execute("UPDATE hoc_sinh SET ho_ten=?,lop=? WHERE ma_hs=?",(hoten,lop,ma)); updated+=1
            else:
                c.execute("INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES(?,?,?)",(ma,hoten,lop)); created+=1
        c.commit(); c.close(); c=None
        audit("NHẬP HỌC SINH",f"thêm {created}, cập nhật {updated}, bỏ qua {skipped}, lỗi {invalid}")
        flash(f"Nhập xong: thêm {created}, cập nhật {updated}, bỏ qua {skipped}, dòng thiếu dữ liệu {invalid}.")
    except Exception:
        if c is not None:
            c.rollback(); c.close()
        app.logger.exception("Student import confirmation failed")
        flash("Nhập danh sách không thành công; dữ liệu hiện có không bị thay đổi.")
    finally:
        remove_import_file(path)
        session.pop("student_import_token",None)
    return redirect(url_for("students_page"))


@app.post("/teacher/import-students")
@teacher_required
def import_students():
    f=request.files.get("file")
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash("Chọn file .xlsx"); return redirect(url_for("students_page"))
    path=IMPORT_DIR/secure_filename(f.filename); f.save(path)
    ws=load_workbook(path,data_only=True).active
    c=db(); n=0
    for row in ws.iter_rows(min_row=2,values_only=True):
        vals=list(row)+[None]*3; ma,hoten,lop=vals[:3]
        if ma and hoten and lop:
            c.execute("""INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES(?,?,?)
                         ON CONFLICT(ma_hs) DO UPDATE SET ho_ten=excluded.ho_ten,lop=excluded.lop""",
                      (str(ma).strip(),str(hoten).strip(),str(lop).strip()))
            n+=1
    c.commit(); c.close()
    flash(f"Đã nhập/cập nhật {n} học sinh.")
    return redirect(url_for("students_page"))

@app.post("/teacher/import-questions")
@teacher_required
def import_questions():
    f=request.files.get("file")
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash("Chọn file .xlsx")
        return redirect(request.referrer or url_for("teacher"))

    path=IMPORT_DIR/secure_filename(f.filename)
    f.save(path)

    try:
        ws=load_workbook(path,data_only=True).active
    except Exception:
        flash("Không đọc được file Excel.")
        return redirect(request.referrer or url_for("teacher"))

    prepared=[]
    errors=[]

    for excel_row,row in enumerate(ws.iter_rows(min_row=2,values_only=True),start=2):
        vals=list(row)+[None]*10
        ma,mon,topic,level,q,a,b,cc,d,ans=vals[:10]

        # Skip completely empty rows.
        if not any(v is not None and str(v).strip() for v in vals[:10]):
            continue

        ma=str(ma or "").strip()
        mon=str(mon or "").strip()
        topic=str(topic or "").strip()
        level=str(level or "").strip().upper()
        q=str(q or "").strip()
        a=str(a or "").strip()
        b=str(b or "").strip()
        cc=str(cc or "").strip()
        d=str(d or "").strip()
        ans=norm_answer(ans)

        row_errors=[]
        if not q:
            row_errors.append("thiếu nội dung")
        if not all([a,b,cc,d]):
            row_errors.append("thiếu phương án A/B/C/D")
        if not ans:
            row_errors.append("đáp án đúng phải là A/B/C/D")
        if level not in ("NB","TH","VD","VDC"):
            row_errors.append("mức độ phải là NB/TH/VD/VDC")

        if row_errors:
            errors.append(f"Dòng {excel_row}: " + ", ".join(row_errors))
        else:
            prepared.append((ma,mon,topic,level,q,a,b,cc,d,ans))

    if errors:
        preview=" | ".join(errors[:8])
        extra="" if len(errors)<=8 else f" | ... còn {len(errors)-8} lỗi khác"
        flash(f"KHÔNG nhập dữ liệu vì file có {len(errors)} dòng lỗi. {preview}{extra}")
        return redirect(request.referrer or url_for("teacher"))

    if not prepared:
        flash("File không có câu hỏi hợp lệ để nhập.")
        return redirect(request.referrer or url_for("teacher"))

    c=db()
    for vals in prepared:
        c.execute("""INSERT INTO cau_hoi(
                     ma_cau,mon,chu_de,muc_do,noi_dung,a,b,c,d,dap_an_dung)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",vals)
    c.commit()
    c.close()
    flash(f"Đã kiểm tra file và nhập thành công {len(prepared)} câu hỏi. Không có dòng lỗi.")
    return redirect(request.referrer or url_for("question_bank"))

# ---------- Exam management ----------
@app.get("/teacher/api/question-availability")
@teacher_required
def api_question_availability():
    mon=request.args.get("mon","").strip()
    topics=request.args.getlist("chu_de")
    counts,by_type=question_availability(mon,topics)
    return jsonify(ok=True,counts=counts,by_type=by_type,types=TYPES)

def exam_integer(form,name,default,minimum=0,maximum=None):
    raw=form.get(name,str(default)).strip()
    digits=raw[1:] if raw.startswith(("+","-")) else raw
    if not digits or not digits.isdecimal():
        raise ValueError(f"Trường {name} phải là số nguyên.")
    try:
        value=int(raw)
    except ValueError:
        raise ValueError(f"Trường {name} phải là số nguyên hợp lệ.")
    if value<minimum or (maximum is not None and value>maximum):
        limit=f"{minimum}–{maximum}" if maximum is not None else f">= {minimum}"
        raise ValueError(f"Trường {name} phải có giá trị {limit}.")
    return value

@app.post("/teacher/create-exam")
@teacher_required
def create_exam():
    ten=request.form.get("ten","").strip()
    lop=request.form.get("lop","").strip()
    mon=request.form.get("mon","").strip()
    topics=request.form.getlist("chu_de")

    # v2.3.1: chọn chính xác số câu theo 5 loại trắc nghiệm x 4 mức độ.
    levels=("NB","TH","VD","VDC")
    has_type_fields=any(f"{k}_{lv}" in request.form for k in TYPES for lv in levels)
    try:
        tg=exam_integer(request.form,"thoi_gian",15,1,180)
        quotas={k:{lv:exam_integer(request.form,f"{k}_{lv}",0) for lv in levels} for k in TYPES}
        # Tương thích biểu mẫu cũ nếu cần.
        if not has_type_fields:
            old_counts={lv:exam_integer(request.form,lv.lower()+"_count",0) for lv in levels}
            quotas={k:{lv:0 for lv in levels} for k in TYPES}
            for lv,n in old_counts.items():
                quotas["SINGLE"][lv]=n
    except ValueError as error:
        flash(str(error))
        return redirect(url_for("teacher"))

    level_totals={lv:sum(quotas[k][lv] for k in TYPES) for lv in levels}
    total=sum(level_totals.values())

    if not ten:
        flash("Cần nhập tên kỳ thi.")
        return redirect(url_for("teacher"))
    if total<=0:
        flash("Hãy chọn ít nhất 1 câu trong bảng Loại câu hỏi × Mức độ.")
        return redirect(url_for("teacher"))

    available,by_type=question_availability(mon,topics)
    missing=[]
    for kind,label in TYPES.items():
        for lv in levels:
            n=quotas[kind][lv]
            have=by_type.get(kind,{}).get(lv,0)
            if n>have:
                missing.append(f"{label} / {lv}: cần {n}, hiện có {have}")
    if missing:
        flash("Không thể tạo kỳ thi vì ngân hàng chưa đủ câu. " + " | ".join(missing[:10]))
        return redirect(url_for("teacher"))

    show=1 if request.form.get("hien_diem")=="on" else 0
    topic_value=",".join(topics)
    if any("," in x for x in topics):
        topic_value=json.dumps(topics,ensure_ascii=False)
        quotas["_topics_format"]={"version":1}
    c=db()
    c.execute("""INSERT INTO ky_thi(
                 ten,lop,mon,so_cau,thoi_gian_phut,chu_de,muc_do,
                 nb_count,th_count,vd_count,vdc_count,
                 hien_diem,trang_thai,created_at,type_quotas)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (ten,lop,mon,total,tg,topic_value,"NB,TH,VD,VDC",
               level_totals["NB"],level_totals["TH"],level_totals["VD"],level_totals["VDC"],
               show,"MO",now_text(),json.dumps(quotas,ensure_ascii=False)))
    c.commit()
    c.close()
    parts=[f"{lv} {level_totals[lv]}" for lv in levels if level_totals[lv]]
    flash(f"Đã tạo kỳ thi '{ten}' với {total} câu (" + ", ".join(parts) + ").")
    return redirect(url_for("teacher"))

@app.post("/teacher/toggle-exam/<int:eid>")
@teacher_required
def toggle_exam(eid):
    c=db(); r=c.execute("SELECT trang_thai FROM ky_thi WHERE id=?",(eid,)).fetchone()
    if r:
        c.execute("UPDATE ky_thi SET trang_thai=? WHERE id=?",
                  ("DONG" if r["trang_thai"]=="MO" else "MO",eid))
        c.commit()
    c.close()
    return redirect(url_for("teacher"))

@app.post("/teacher/delete-exam/<int:eid>")
@teacher_required
def delete_exam(eid):
    """Xóa kỳ thi và toàn bộ dữ liệu bài làm/câu trả lời liên quan."""
    c=db()
    try:
        exam=c.execute("SELECT id,ten FROM ky_thi WHERE id=?",(eid,)).fetchone()
        if not exam:
            flash("Không tìm thấy kỳ thi cần xóa.")
            return redirect(url_for("teacher"))

        # Lấy các bài thi thuộc kỳ thi trước khi xóa để dọn câu trả lời liên quan.
        attempt_ids=[r["id"] for r in c.execute(
            "SELECT id FROM bai_thi WHERE ky_thi_id=?",(eid,)
        ).fetchall()]

        c.execute("BEGIN")
        if attempt_ids:
            placeholders=",".join("?"*len(attempt_ids))
            c.execute(f"DELETE FROM cau_tra_loi WHERE bai_thi_id IN ({placeholders})",attempt_ids)
        deleted_attempts=c.execute("DELETE FROM bai_thi WHERE ky_thi_id=?",(eid,)).rowcount
        c.execute("DELETE FROM ky_thi WHERE id=?",(eid,))
        c.commit()

        audit("XÓA KỲ THI",f"ID {eid} - {exam['ten']} - {deleted_attempts} bài thi")
        flash(f"Đã xóa kỳ thi '{exam['ten']}' và toàn bộ dữ liệu bài làm liên quan.")
    except Exception:
        c.rollback()
        app.logger.exception("Delete exam failed: %s",eid)
        flash("Không thể xóa kỳ thi. Vui lòng thử lại.")
    finally:
        c.close()
    return redirect(url_for("teacher"))

# F012: aggregate the metadata that each submitted attempt actually recorded.
def historical_question_stats(c,eid):
    grouped={}; levels={}
    for attempt in c.execute('SELECT id,de_json FROM bai_thi WHERE ky_thi_id=? AND submitted_at IS NOT NULL ORDER BY id',(eid,)).fetchall():
        items=load_snapshot(attempt['de_json'])
        for answer in c.execute('SELECT vi_tri_cau,dung FROM cau_tra_loi WHERE bai_thi_id=? ORDER BY vi_tri_cau',(attempt['id'],)):
            position=answer['vi_tri_cau']
            if type(position) is not int or not 0<=position<len(items):
                raise SnapshotValidationError('Vị trí đáp án không khớp snapshot bài thi.')
            item=items[position]; history=item.get('history'); missing=history is None
            # No bank lookup/backfill: a legacy snapshot has content, but no confirmed classification.
            data={k:'Không rõ (legacy)' for k in ('ma_cau','mon','chu_de','muc_do')} if missing else history
            level=data['muc_do']
            if not missing and level not in ('NB','TH','VD','VDC'):
                level='Không rõ'
            key=(item['id'],data['ma_cau'],data['mon'],data['chu_de'],level,item['q'],missing)
            if key not in grouped:
                grouped[key]=dict(cau_hoi_id=item['id'],ma_cau=data['ma_cau'],mon=data['mon'],chu_de=data['chu_de'],muc_do=level,noi_dung=item['q'],so_luot=0,so_dung=0,history_missing=missing)
            group=grouped[key];group['so_luot']+=1;group['so_dung']+=int(answer['dung']==1)
            if level not in levels:levels[level]=dict(muc_do=level,so_luot=0,so_dung=0)
            levels[level]['so_luot']+=1;levels[level]['so_dung']+=int(answer['dung']==1)
    return [grouped[key] for key in sorted(grouped)],list(levels.values())

@app.get("/teacher/report/<int:eid>")
@teacher_required
def report(eid):
    c=db()
    exam=c.execute("SELECT * FROM ky_thi WHERE id=?",(eid,)).fetchone()
    if not exam:
        c.close()
        return "Không tìm thấy kỳ thi.",404

    rows=c.execute("""
        SELECT * FROM bai_thi
        WHERE ky_thi_id=?
        ORDER BY CASE WHEN diem IS NULL THEN 1 ELSE 0 END, diem DESC, ho_ten
    """,(eid,)).fetchall()

    try:
        stats,level_stats=historical_question_stats(c,eid)
    except SnapshotValidationError:
        c.close()
        raise
    c.close()

    submitted=[r for r in rows if r["submitted_at"] is not None and r["diem"] is not None]
    scores=[float(r["diem"]) for r in submitted]

    total_students=len(rows)
    submitted_count=len(submitted)
    avg=round(sum(scores)/len(scores),2) if scores else 0
    highest=round(max(scores),2) if scores else 0
    lowest=round(min(scores),2) if scores else 0

    pass_count=sum(1 for s in scores if s>=5)
    good_count=sum(1 for s in scores if s>=8)
    below5_count=sum(1 for s in scores if s<5)
    pass_rate=round(pass_count/len(scores)*100,1) if scores else 0
    good_rate=round(good_count/len(scores)*100,1) if scores else 0

    bands=[
        {"label":"0–<2","min":0,"max":2,"count":0},
        {"label":"2–<5","min":2,"max":5,"count":0},
        {"label":"5–<6.5","min":5,"max":6.5,"count":0},
        {"label":"6.5–<8","min":6.5,"max":8,"count":0},
        {"label":"8–10","min":8,"max":10.0001,"count":0},
    ]
    for s in scores:
        for b in bands:
            if b["min"] <= s < b["max"]:
                b["count"]+=1
                break
    max_band=max([b["count"] for b in bands] or [1])
    for b in bands:
        b["pct"]=round(b["count"]/len(scores)*100,1) if scores else 0
        b["bar"]=round(b["count"]/max_band*100,1) if max_band else 0

    qstats=[]
    for s in stats:
        rate=round(s["so_dung"]/s["so_luot"]*100,1) if s["so_luot"] else 0
        difficulty="Khó" if rate<40 else ("Trung bình" if rate<75 else "Dễ")
        qstats.append({
            "id":s["cau_hoi_id"],
            "code":s["ma_cau"] or "",
            "text":s["noi_dung"],
            "cognitive":s["muc_do"],
            "attempts":s["so_luot"],
            "correct":s["so_dung"],
            "rate":rate,
            "level":difficulty,
            "history_missing":s["history_missing"]
        })

    levels={lv:{"attempts":0,"correct":0,"rate":0} for lv in ("NB","TH","VD","VDC")}
    for s in level_stats:
        lv=s["muc_do"]
        if lv not in levels:
            levels[lv]={"attempts":0,"correct":0,"rate":0}
        attempts=int(s["so_luot"] or 0)
        correct=int(s["so_dung"] or 0)
        levels[lv]={
            "attempts":attempts,
            "correct":correct,
            "rate":round(correct/attempts*100,1) if attempts else 0
        }

    top_students=[{
        "ma_hs":r["ma_hs"],
        "ho_ten":r["ho_ten"],
        "lop":r["lop"],
        "diem":r["diem"]
    } for r in submitted[:10]]

    return render_template(
        "report.html",
        exam=exam,
        rows=rows,
        qstats=qstats,
        historical_missing=sum(r["so_luot"] for r in stats if r["history_missing"]),
        avg=avg,
        highest=highest,
        lowest=lowest,
        submitted_count=submitted_count,
        total_students=total_students,
        pass_count=pass_count,
        pass_rate=pass_rate,
        good_count=good_count,
        good_rate=good_rate,
        below5_count=below5_count,
        bands=bands,
        levels=levels,
        top_students=top_students
    )

@app.get("/teacher/report/<int:eid>/export")
@teacher_required
def export_exam_report(eid):
    c=db()
    exam=c.execute("SELECT * FROM ky_thi WHERE id=?",(eid,)).fetchone()
    if not exam:
        c.close()
        return "Không tìm thấy kỳ thi.",404

    students=c.execute("""
        SELECT ma_hs,ho_ten,lop,started_at,submitted_at,so_cau_dung,tong_so_cau,diem
        FROM bai_thi
        WHERE ky_thi_id=?
        ORDER BY lop,ho_ten
    """,(eid,)).fetchall()

    try:
        qstats,level_stats=historical_question_stats(c,eid)
    except SnapshotValidationError:
        c.close()
        raise
    c.close()

    wb=Workbook()

    # Sheet 1: Summary
    ws=wb.active
    ws.title="TongQuan"
    ws["A1"]="BÁO CÁO KỲ THI"
    ws["A1"].font=Font(bold=True,size=16)
    ws.merge_cells("A1:D1")
    ws["A2"]="Tên kỳ thi"; ws["B2"]=exam["ten"]
    ws["A3"]="Lớp"; ws["B3"]=exam["lop"] or "Tất cả lớp"
    ws["A4"]="Môn"; ws["B4"]=exam["mon"] or "Tất cả môn"
    ws["A5"]="Số câu"; ws["B5"]=exam["so_cau"]
    ws["A6"]="Thời gian"; ws["B6"]=f'{exam["thoi_gian_phut"]} phút'

    scores=[float(r["diem"]) for r in students if r["submitted_at"] and r["diem"] is not None]
    submitted=len(scores)
    avg=round(sum(scores)/submitted,2) if submitted else 0
    high=round(max(scores),2) if scores else 0
    low=round(min(scores),2) if scores else 0
    passed=sum(1 for x in scores if x>=5)
    good=sum(1 for x in scores if x>=8)

    summary_rows=[
        ("Số bài đã nộp",submitted),
        ("Điểm trung bình",avg),
        ("Điểm cao nhất",high),
        ("Điểm thấp nhất",low),
        ("Số bài >= 5",passed),
        ("Tỷ lệ >= 5",round(passed/submitted*100,1) if submitted else 0),
        ("Số bài >= 8",good),
        ("Tỷ lệ >= 8",round(good/submitted*100,1) if submitted else 0),
    ]
    row=8
    for name,val in summary_rows:
        ws.cell(row=row,column=1,value=name)
        ws.cell(row=row,column=2,value=val)
        row+=1

    # Sheet 2: Students
    ws2=wb.create_sheet("KetQuaHocSinh")
    headers=["Mã HS","Họ tên","Lớp","Bắt đầu","Nộp bài","Số câu đúng","Tổng số câu","Điểm"]
    ws2.append(headers)
    for cell in ws2[1]:
        cell.font=Font(bold=True)
        cell.alignment=Alignment(horizontal="center")
    for r in students:
        ws2.append([r["ma_hs"],r["ho_ten"],r["lop"],r["started_at"],r["submitted_at"],
                    r["so_cau_dung"],r["tong_so_cau"],r["diem"]])

    # Sheet 3: Question analysis
    ws3=wb.create_sheet("PhanTichCauHoi")
    headers3=["Mã câu","Môn","Chủ đề","Mức độ","Nội dung","Số lượt","Số đúng","Tỷ lệ đúng (%)","Độ khó"]
    ws3.append(headers3)
    for cell in ws3[1]:
        cell.font=Font(bold=True)
        cell.alignment=Alignment(horizontal="center")
    for r in qstats:
        attempts=int(r["so_luot"] or 0)
        correct=int(r["so_dung"] or 0)
        rate=round(correct/attempts*100,1) if attempts else 0
        difficulty="Khó" if rate<40 else ("Trung bình" if rate<75 else "Dễ")
        ws3.append([r["ma_cau"],r["mon"],r["chu_de"],r["muc_do"],r["noi_dung"],
                    attempts,correct,rate,difficulty])

    # Sheet 4: Level analysis
    ws4=wb.create_sheet("TheoMucDo")
    ws4.append(["Mức độ","Số lượt trả lời","Số đúng","Tỷ lệ đúng (%)"])
    for cell in ws4[1]:
        cell.font=Font(bold=True)
        cell.alignment=Alignment(horizontal="center")
    level_map={r["muc_do"]:r for r in level_stats}
    for lv in ("NB","TH","VD","VDC")+tuple(lv for lv in ("Không rõ (legacy)","Không rõ") if lv in level_map):
        r=level_map.get(lv)
        attempts=int(r["so_luot"] or 0) if r else 0
        correct=int(r["so_dung"] or 0) if r else 0
        rate=round(correct/attempts*100,1) if attempts else 0
        ws4.append([lv,attempts,correct,rate])

    # Adjust widths
    for sheet in wb.worksheets:
        for col in range(1, sheet.max_column+1):
            width=10
            for cell in sheet[get_column_letter(col)]:
                if cell.value is not None:
                    width=max(width,min(45,len(str(cell.value))+2))
            sheet.column_dimensions[get_column_letter(col)].width=width

    excel_text_cells(ws[cell] for cell in ("B2","B3","B4"))
    for sheet,columns in ((ws2,5),(ws3,5)):
        excel_text_cells(cell for row in sheet.iter_rows(min_row=2,max_col=columns) for cell in row)

    fn=EXPORT_DIR/f"BaoCao_{secure_filename(str(exam['ten']))}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    wb.save(fn)
    return send_file(fn,as_attachment=True,download_name=fn.name)


# ---------- Analytics dashboard v1.5 ----------
@app.get("/teacher/analytics")
@teacher_required
def analytics_dashboard():
    c=db()
    exams=c.execute("""
        SELECT kt.*,
               COUNT(bt.id) AS so_bai,
               SUM(CASE WHEN bt.submitted_at IS NOT NULL THEN 1 ELSE 0 END) AS da_nop,
               ROUND(AVG(CASE WHEN bt.submitted_at IS NOT NULL THEN bt.diem END),2) AS diem_tb,
               MAX(CASE WHEN bt.submitted_at IS NOT NULL THEN bt.diem END) AS diem_cao,
               MIN(CASE WHEN bt.submitted_at IS NOT NULL THEN bt.diem END) AS diem_thap
        FROM ky_thi kt
        LEFT JOIN bai_thi bt ON bt.ky_thi_id=kt.id
        GROUP BY kt.id
        ORDER BY kt.id DESC
    """).fetchall()

    totals={
        "students":c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0],
        "questions":c.execute("SELECT COUNT(*) FROM cau_hoi").fetchone()[0],
        "exams":c.execute("SELECT COUNT(*) FROM ky_thi").fetchone()[0],
        "submitted":c.execute("SELECT COUNT(*) FROM bai_thi WHERE submitted_at IS NOT NULL").fetchone()[0],
    }

    overall=c.execute("""
        SELECT ROUND(AVG(diem),2) AS avg_score,
               MAX(diem) AS max_score,
               MIN(diem) AS min_score,
               SUM(CASE WHEN diem>=5 THEN 1 ELSE 0 END) AS pass_count,
               COUNT(*) AS total
        FROM bai_thi
        WHERE submitted_at IS NOT NULL AND diem IS NOT NULL
    """).fetchone()
    c.close()

    overall_dict={
        "avg":overall["avg_score"] or 0,
        "max":overall["max_score"] or 0,
        "min":overall["min_score"] or 0,
        "pass_rate":round((overall["pass_count"] or 0)/(overall["total"] or 1)*100,1) if overall["total"] else 0
    }

    return render_template("analytics.html",exams=exams,totals=totals,overall=overall_dict)


# ---------- Realtime exam monitoring ----------
@app.get("/teacher/monitor/<int:eid>")
@teacher_required
def monitor_exam(eid):
    c=db()
    exam=c.execute("SELECT * FROM ky_thi WHERE id=?",(eid,)).fetchone()
    c.close()
    if not exam:
        return "Không tìm thấy kỳ thi.",404
    return render_template("monitor.html",exam=exam)

@app.get("/teacher/api/monitor/<int:eid>")
@teacher_required
def monitor_exam_data(eid):
    c=db()
    exam=c.execute("SELECT * FROM ky_thi WHERE id=?",(eid,)).fetchone()
    if not exam:
        c.close()
        return jsonify(ok=False),404

    sql="SELECT * FROM hoc_sinh WHERE 1=1"
    args=[]
    if exam["lop"]:
        sql+=" AND lop=?"
        args.append(exam["lop"])
    students=c.execute(sql,args).fetchall()

    attempts={r["ma_hs"]:r for r in c.execute(
        "SELECT * FROM bai_thi WHERE ky_thi_id=?",(eid,)).fetchall()}

    data=[]
    for hs in students:
        at=attempts.get(hs["ma_hs"])
        if not at:
            status="Chưa vào"
            answered=0
            score=None
            last_seen=""
            aid=None
        else:
            aid=at["id"]
            saved_rows={r['vi_tri_cau']:r['lua_chon'] for r in c.execute('SELECT vi_tri_cau,lua_chon FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))}
            try:
                answered=sum(completed(q,saved_rows.get(i)) for i,q in enumerate(load_snapshot(at['de_json'])))
            except SnapshotValidationError:
                c.close()
                raise
            score=at["diem"]
            last_seen=at["last_seen_at"] or ""
            if at["submitted_at"]:
                status="Đã nộp"
            else:
                status="Đang thi" if seconds_since(last_seen)<=15 else "Mất kết nối"

        data.append({
            "attempt_id":aid,
            "ma_hs":hs["ma_hs"],
            "ho_ten":hs["ho_ten"],
            "lop":hs["lop"],
            "status":status,
            "answered":answered,
            "total":exam["so_cau"],
            "score":score,
            "last_seen":last_seen
        })

    c.close()
    return jsonify(ok=True,students=data)

@app.post("/teacher/unlock/<int:attempt_id>")
@teacher_required
def unlock_attempt(attempt_id):
    c=db()
    row=c.execute("SELECT ky_thi_id,submitted_at FROM bai_thi WHERE id=?",(attempt_id,)).fetchone()
    if not row:
        c.close()
        flash("Không tìm thấy bài thi.")
        return redirect(url_for("teacher"))

    # For in-progress attempt: let the student reconnect immediately.
    # For submitted attempt: same flag means a fresh retake is allowed on next login.
    c.execute("""UPDATE bai_thi
                 SET force_relogin=1,client_token=NULL,last_seen_at=NULL
                 WHERE id=?""",(attempt_id,))
    c.commit()
    eid=row["ky_thi_id"]
    c.close()

    if row["submitted_at"]:
        flash("Đã cho phép học sinh thi lại từ đầu.")
    else:
        flash("Đã mở khóa. Học sinh có thể đăng nhập lại ngay.")
    return redirect(url_for("monitor_exam",eid=eid))


# ---------- Backup ----------
def backup_file_info(path):
    stat = path.stat()
    try:
        dt = datetime.fromtimestamp(stat.st_mtime)
        time_text = dt.strftime("%d/%m/%Y %H:%M:%S")
    except:
        time_text = ""
    size_mb = round(stat.st_size / (1024 * 1024), 2)
    if size_mb == 0:
        size_text = f"{round(stat.st_size / 1024, 1)} KB"
    else:
        size_text = f"{size_mb} MB"
    return {
        "name": path.name,
        "time": time_text,
        "size": size_text,
        "is_auto": path.name.startswith("before_restore_")
    }

@app.get("/teacher/backups")
@teacher_required
def backup_manager():
    BACKUP_DIR.mkdir(exist_ok=True)
    files = sorted(
        [p for p in BACKUP_DIR.glob("*.db") if p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True
    )
    items = [backup_file_info(p) for p in files]
    return render_template("backups.html", backups=items)

@app.post("/teacher/backup")
@teacher_required
def backup():
    if not DB_PATH.exists():
        flash("Chưa có dữ liệu để sao lưu.")
        return redirect(url_for("backup_manager"))

    fn = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    target = BACKUP_DIR / fn

    # Use SQLite backup API so the copy is consistent even when WAL is enabled.
    create_sqlite_backup(target)
    audit("TẠO BACKUP",fn)
    app.logger.info("Created backup: %s", fn)
    flash(f"Đã tạo bản sao lưu: {fn}")
    return redirect(url_for("backup_manager"))

@app.get("/teacher/backup/download/<path:name>")
@teacher_required
def download_backup(name):
    safe = secure_filename(name)
    path = BACKUP_DIR / safe
    if not path.exists() or path.suffix.lower() != ".db":
        return "Không tìm thấy bản sao lưu.", 404
    return send_file(path, as_attachment=True, download_name=safe)

def restore_database_from_path(source_path):
    # Validate DB first.
    test = sqlite3.connect(Path(source_path).resolve().as_uri()+"?mode=ro",uri=True)
    test.row_factory=sqlite3.Row
    try:
        if test.execute("PRAGMA integrity_check").fetchone()[0]!="ok":
            raise SnapshotValidationError("SQLite integrity check thất bại.")
        tables = {r[0] for r in test.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        required = {"hoc_sinh", "cau_hoi", "ky_thi", "bai_thi"}
        if not required.issubset(tables):
            raise ValueError("Không đúng cơ sở dữ liệu của ThiTracNghiemLAN")
        # F010: preflight semantic validation before backup or database replacement.
        for row in test.execute('SELECT * FROM cau_hoi'):
            question_data(row)
        for row in test.execute('SELECT * FROM bai_thi'):
            load_snapshot(row['de_json'])
            if row['diem'] is not None and (type(row['diem']) not in (int,float) or not math.isfinite(row['diem']) or not 0<=row['diem']<=10):
                raise SnapshotValidationError('Điểm đã lưu trong backup không hợp lệ.')
    finally:
        test.close()

    # Preserve the current DB before replacing it.
    if DB_PATH.exists():
        before = BACKUP_DIR / f"before_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        src = sqlite3.connect(DB_PATH)
        dst = sqlite3.connect(before)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()

    # Restore safely through SQLite backup API.
    source = sqlite3.connect(source_path)
    destination = sqlite3.connect(DB_PATH)
    try:
        source.backup(destination)
    finally:
        destination.close()
        source.close()
    init_db()

@app.post("/teacher/restore")
@teacher_required
def restore():
    f = request.files.get("file")
    if not f or not f.filename.lower().endswith(".db"):
        flash("Vui lòng chọn file sao lưu .db.")
        return redirect(url_for("backup_manager"))

    temp = BACKUP_DIR / ("uploaded_restore_" + secure_filename(f.filename))
    f.save(temp)
    try:
        restore_database_from_path(temp)
        audit("KHÔI PHỤC DỮ LIỆU",f"Từ file tải lên: {f.filename}")
        app.logger.info("Restored uploaded backup: %s", f.filename)
        flash("Đã khôi phục dữ liệu từ file đã chọn. Hãy kiểm tra lại học sinh, câu hỏi và kỳ thi.")
    except SnapshotValidationError as error:
        flash('Không khôi phục: dữ liệu scoring/snapshot không hợp lệ. '+str(error))
    except Exception:
        app.logger.exception("Restore failed")
        flash("Khôi phục thất bại: file không hợp lệ hoặc không đúng dữ liệu của phần mềm.")
    finally:
        try:
            temp.unlink()
        except:
            pass
    return redirect(url_for("backup_manager"))

@app.post("/teacher/backup/restore/<path:name>")
@teacher_required
def restore_saved_backup(name):
    safe = secure_filename(name)
    path = BACKUP_DIR / safe
    if not path.exists() or path.suffix.lower() != ".db":
        flash("Không tìm thấy bản sao lưu.")
        return redirect(url_for("backup_manager"))

    try:
        restore_database_from_path(path)
        audit("KHÔI PHỤC DỮ LIỆU",f"Từ backup: {safe}")
        app.logger.info("Restored saved backup: %s", safe)
        flash(f"Đã khôi phục từ: {safe}")
    except SnapshotValidationError as error:
        flash('Không khôi phục: dữ liệu scoring/snapshot không hợp lệ. '+str(error))
    except Exception:
        app.logger.exception("Restore saved backup failed")
        flash("Khôi phục thất bại. Hãy kiểm tra file sao lưu.")
    return redirect(url_for("backup_manager"))

# ---------- Export ----------
def excel_text_cells(cells):
    # F008: only caller-selected text fields; numeric/system formula cells stay intact.
    for cell in cells:
        if isinstance(cell.value,str) and cell.value.startswith(("=","+","-","@")):
            cell.data_type="s"

@app.get("/teacher/export-results")
@teacher_required
def export_results():
    c=db()
    rows=c.execute("""SELECT bt.*,kt.ten AS ten_ky_thi FROM bai_thi bt
                      JOIN ky_thi kt ON kt.id=bt.ky_thi_id
                      WHERE bt.submitted_at IS NOT NULL
                      ORDER BY kt.id,bt.lop,bt.ho_ten""").fetchall()
    c.close()
    wb=Workbook(); ws=wb.active; ws.title="Bang diem"
    ws.append(["STT","Kỳ thi","Mã HS","Họ tên","Lớp","Đúng","Tổng câu","Điểm","Bắt đầu","Nộp bài"])
    for i,r in enumerate(rows,1):
        ws.append([i,r["ten_ky_thi"],r["ma_hs"],r["ho_ten"],r["lop"],r["so_cau_dung"],
                   r["tong_so_cau"],r["diem"],r["started_at"],r["submitted_at"]])
    excel_text_cells(row[i-1] for row in ws.iter_rows(min_row=2) for i in (2,3,4,5,9,10))
    fn=f"BangDiem_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    path=EXPORT_DIR/fn; wb.save(path)
    return send_file(path,as_attachment=True,download_name=fn)


# ---------- Student ----------
@app.route("/",methods=["GET","POST"])
def student_login():
    c=db()
    exams=c.execute("SELECT * FROM ky_thi WHERE trang_thai='MO' ORDER BY id DESC").fetchall()
    if request.method=="POST":
        ma=request.form.get("ma_hs","").strip()
        kid=request.form.get("ky_thi_id","")
        hs=c.execute("SELECT * FROM hoc_sinh WHERE ma_hs=?",(ma,)).fetchone()
        kt=c.execute("SELECT * FROM ky_thi WHERE id=? AND trang_thai='MO'",(int(kid),)).fetchone() if kid.isdigit() else None

        if not hs or not kt:
            c.close()
            return render_template("login.html",exams=exams,error="Sai mã HS hoặc kỳ thi.")

        if kt["lop"] and hs["lop"]!=kt["lop"]:
            c.close()
            return render_template("login.html",exams=exams,error="Kỳ thi không dành cho lớp của em.")

        ex=c.execute("SELECT * FROM bai_thi WHERE ky_thi_id=? AND ma_hs=?",(kt["id"],ma)).fetchone()

        if ex:
            # Submitted attempts are only viewable unless teacher explicitly grants retake.
            if ex["submitted_at"] and not ex["force_relogin"]:
                session["attempt_id"]=ex["id"]
                session["client_token"]=ex["client_token"] or ""
                session['_csrf_token']=secrets.token_urlsafe(32)
                c.close()
                return redirect(url_for("result"))

            # Teacher-granted retake: clear old answers and rebuild a fresh exam.
            if ex["submitted_at"] and ex["force_relogin"]:
                try:
                    de=build_exam(kt)
                except SnapshotValidationError:
                    c.close()
                    raise
                if len(de)<kt["so_cau"]:
                    c.close()
                    return render_template("login.html",exams=exams,error="Ngân hàng câu hỏi chưa đủ để cho thi lại.")
                c.execute("DELETE FROM cau_tra_loi WHERE bai_thi_id=?",(ex["id"],))
                token=secrets.token_urlsafe(24)
                now=datetime.now()
                deadline=now+timedelta(minutes=kt["thoi_gian_phut"])
                c.execute("""UPDATE bai_thi
                             SET started_at=?,deadline_at=?,submitted_at=NULL,de_json=?,
                                 so_cau_dung=NULL,tong_so_cau=NULL,diem=NULL,last_seen_at=?,
                                 client_token=?,force_relogin=0
                             WHERE id=?""",
                          (now_text(),deadline.strftime("%Y-%m-%d %H:%M:%S"),
                           json.dumps(de,ensure_ascii=False),now_text(),token,ex["id"]))
                c.commit()
                session["attempt_id"]=ex["id"]
                session["client_token"]=token
                session['_csrf_token']=secrets.token_urlsafe(32)
                c.close()
                return redirect(url_for("exam"))

            # In-progress attempt: block a second machine while the first one is still alive.
            if not ex["force_relogin"] and ex["client_token"] and seconds_since(ex["last_seen_at"]) <= 20:
                c.close()
                return render_template(
                    "login.html",exams=exams,
                    error="Mã học sinh này đang làm bài trên một máy khác. Nếu máy cũ bị lỗi, báo giáo viên bấm Mở khóa."
                )

            # Stale/disconnected or teacher-unlocked attempt: allow reconnect with a new token.
            token=secrets.token_urlsafe(24)
            c.execute("UPDATE bai_thi SET client_token=?,force_relogin=0,last_seen_at=? WHERE id=?",
                      (token,now_text(),ex["id"]))
            c.commit()
            session["attempt_id"]=ex["id"]
            session["client_token"]=token
            session['_csrf_token']=secrets.token_urlsafe(32)
            c.close()
            return redirect(url_for("exam"))

        try:
            de=build_exam(kt)
        except SnapshotValidationError:
            c.close()
            raise
        if len(de)<kt["so_cau"]:
            c.close()
            return render_template("login.html",exams=exams,error="Kỳ thi chưa đủ câu phù hợp trong ngân hàng. Giáo viên cần kiểm tra cơ cấu NB–TH–VD–VDC.")

        token=secrets.token_urlsafe(24)
        now=datetime.now()
        deadline=now+timedelta(minutes=kt["thoi_gian_phut"])
        cur=c.execute("""INSERT INTO bai_thi(
                         ky_thi_id,ma_hs,ho_ten,lop,started_at,deadline_at,de_json,
                         last_seen_at,client_token,force_relogin)
                         VALUES(?,?,?,?,?,?,?,?,?,0)""",
                      (kt["id"],hs["ma_hs"],hs["ho_ten"],hs["lop"],
                       now_text(),deadline.strftime("%Y-%m-%d %H:%M:%S"),
                       json.dumps(de,ensure_ascii=False),now_text(),token))
        c.commit()
        session["attempt_id"]=cur.lastrowid
        session["client_token"]=token
        session['_csrf_token']=secrets.token_urlsafe(32)
        c.close()
        return redirect(url_for("exam"))

    c.close()
    return render_template("login.html",exams=exams)

@app.route("/exam",methods=["GET","POST"])
def exam():
    aid=session.get("attempt_id")
    if not aid:
        return redirect(url_for("student_login"))

    c=db()
    bt=validate_attempt_session(c,aid)
    if not bt:
        c.close()
        session.pop("attempt_id",None)
        session.pop("client_token",None)
        return render_template("session_conflict.html")

    kt=c.execute("SELECT ten,hien_diem FROM ky_thi WHERE id=?",(bt["ky_thi_id"],)).fetchone()
    if bt["submitted_at"]:
        c.close()
        return redirect(url_for("result"))

    try:
        data=load_snapshot(bt["de_json"])
    except SnapshotValidationError:
        c.close()
        raise
    saved={r["vi_tri_cau"]:decode(r["lua_chon"]) for r in c.execute(
        "SELECT vi_tri_cau,lua_chon FROM cau_tra_loi WHERE bai_thi_id=?",(aid,))}
    deadline=datetime.strptime(bt["deadline_at"],"%Y-%m-%d %H:%M:%S")
    remaining=(deadline-datetime.now()).total_seconds()
    sec=max(0,int(remaining))

    if request.method=="POST" or remaining<=0:
        # Fast path only; the authoritative check is inside the write transaction.
        fresh=c.execute("SELECT submitted_at FROM bai_thi WHERE id=?",(aid,)).fetchone()
        if fresh and fresh["submitted_at"]:
            c.close()
            return redirect(url_for("result"))

        try:
            # F002: serialize submit/autosave before reading the state to commit.
            c.execute("BEGIN IMMEDIATE")
            bt=validate_attempt_session(c,aid)
            if not bt:
                session.pop("attempt_id",None)
                session.pop("client_token",None)
                return render_template("session_conflict.html")
            if bt["submitted_at"]:
                return redirect(url_for("result"))
            data=load_snapshot(bt["de_json"])
            saved={r["vi_tri_cau"]:decode(r["lua_chon"]) for r in c.execute(
                "SELECT vi_tri_cau,lua_chon FROM cau_tra_loi WHERE bai_thi_id=?",(aid,))}
            deadline=datetime.strptime(bt["deadline_at"],"%Y-%m-%d %H:%M:%S")
            # F001: a request that waited for a writer must recheck the deadline.
            use_post=request.method=="POST" and datetime.now()<deadline
            correct=0
            grading_choices={}
            for i,item in enumerate(data):
                choice=from_form(request.form,i,item) if use_post else saved.get(i)
                grading_choices[i]=choice
                is_ok=int(answer_correct(item,choice))
                ch=json.dumps(choice,ensure_ascii=False)
                correct+=is_ok
                c.execute("""INSERT INTO cau_tra_loi(
                         bai_thi_id,vi_tri_cau,cau_hoi_id,lua_chon,dung,saved_at)
                         VALUES(?,?,?,?,?,?)
                         ON CONFLICT(bai_thi_id,vi_tri_cau)
                         DO UPDATE SET lua_chon=excluded.lua_chon,
                                       dung=excluded.dung,
                                       saved_at=excluded.saved_at""",
                          (aid,i,item["id"],ch,is_ok,now_text()))

            score=total_score(data,grading_choices)
            sub=now_text()
            changed=c.execute("""UPDATE bai_thi
                     SET submitted_at=?,so_cau_dung=?,tong_so_cau=?,diem=?,last_seen_at=?
                     WHERE id=? AND submitted_at IS NULL""",
                      (sub,correct,len(data),score,sub,aid)).rowcount
            if changed==1:
                c.commit()
            else:
                c.rollback()
            return redirect(url_for("result"))
        finally:
            # Closing also rolls back an incomplete transaction on any exception.
            c.close()

    c.execute("UPDATE bai_thi SET last_seen_at=? WHERE id=?",(now_text(),aid))
    c.commit()
    bt_view=dict(bt)
    bt_view["ten"]=kt["ten"] if kt else ""
    bt_view["hien_diem"]=kt["hien_diem"] if kt else 1
    c.close()
    return render_template("exam.html",bt=bt_view,questions=data,saved=saved,seconds_left=sec)

@app.post("/api/save-answer")
def save_answer():
    aid=session.get("attempt_id")
    p=request.get_json(silent=True) or {}
    i=p.get("index"); ch=p.get("choice")
    if aid is None or not isinstance(i,int) :
        return jsonify(ok=False,reason="bad_request"),400

    c=db()
    try:
        # F002: checks and the answer write share the submit write lock.
        c.execute("BEGIN IMMEDIATE")
        bt=validate_attempt_session(c,aid)
        if not bt:
            return jsonify(ok=False,reason="session_conflict"),409
        if bt["submitted_at"]:
            return jsonify(ok=False,reason="submitted"),409

        if datetime.now()>=datetime.strptime(bt["deadline_at"],"%Y-%m-%d %H:%M:%S"):
            return jsonify(ok=False,reason="expired"),409
        data=load_snapshot(bt["de_json"])
        if i<0 or i>=len(data):
            return jsonify(ok=False,reason="bad_index"),400

        item=data[i]
        is_ok=int(answer_correct(item,ch))
        ch=json.dumps(ch,ensure_ascii=False)
        now=now_text()
        c.execute("""INSERT INTO cau_tra_loi(
                 bai_thi_id,vi_tri_cau,cau_hoi_id,lua_chon,dung,saved_at)
                 VALUES(?,?,?,?,?,?)
                 ON CONFLICT(bai_thi_id,vi_tri_cau)
                 DO UPDATE SET lua_chon=excluded.lua_chon,
                               dung=excluded.dung,
                               saved_at=excluded.saved_at""",
                  (aid,i,item["id"],ch,is_ok,now))
        c.execute("UPDATE bai_thi SET last_seen_at=? WHERE id=?",(now,aid))
        c.commit()
        return jsonify(ok=True)
    finally:
        c.close()

@app.post("/api/ping")
def ping():
    aid=session.get("attempt_id")
    if not aid:
        return jsonify(ok=False),401
    c=db()
    bt=validate_attempt_session(c,aid)
    if not bt:
        c.close()
        return jsonify(ok=False,reason="session_conflict"),409
    if bt["submitted_at"]:
        c.close()
        return jsonify(ok=False,reason="submitted"),409
    c.execute("UPDATE bai_thi SET last_seen_at=? WHERE id=?",(now_text(),aid))
    c.commit()
    c.close()
    return jsonify(ok=True)

@app.route("/result")
def result():
    aid=session.get("attempt_id")
    if not aid:
        return redirect(url_for("student_login"))
    c=db()
    if not validate_attempt_session(c,aid):
        c.close()
        session.pop("attempt_id",None)
        session.pop("client_token",None)
        return render_template("session_conflict.html")
    row=c.execute("""SELECT bt.*,kt.ten,kt.hien_diem
                     FROM bai_thi bt
                     JOIN ky_thi kt ON kt.id=bt.ky_thi_id
                     WHERE bt.id=?""",(aid,)).fetchone()
    c.close()
    if not row:
        return redirect(url_for("student_login"))
    return render_template("result.html",row=row)

@app.route("/uploads/<path:name>")
def uploaded_file(name):
    return send_file(UPLOAD_DIR/secure_filename(name))

@app.errorhandler(Exception)
def handle_exception(e):
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        return e
    app.logger.exception("Unhandled error: %s", e)
    return "Đã xảy ra lỗi. Vui lòng báo giáo viên và kiểm tra file logs/app.log.",500

from multi_routes import install_multi_routes
install_multi_routes(globals())

if __name__=="__main__":
    init_db()
    get_license_status()
    auto_backup_daily()
    port=get_server_port()
    ips=get_lan_ips()

    print("="*72)
    print("THI TRAC NGHIEM LAN v2.3 THUONG MAI")
    for ip in ips:
        print(f"Hoc sinh:  http://{ip}:{port}")
    print(f"Giao vien: http://127.0.0.1:{port}/teacher/login")
    print(f"Kiem tra:  http://127.0.0.1:{port}/health")
    print("Tai khoan khoi tao: admin / 123456")
    print("Khuyen nghi doi mat khau admin sau lan dang nhap dau tien.")
    print("="*72)

    try:
        from waitress import serve
        print("May chu: Waitress production WSGI")
        serve(app, host="0.0.0.0", port=port, threads=12,
              connection_limit=200, channel_timeout=120)
    except ImportError:
        print("CANH BAO: Chua co Waitress, tam chay Flask server.")
        app.run(host="0.0.0.0",port=port,debug=False,threaded=True)
