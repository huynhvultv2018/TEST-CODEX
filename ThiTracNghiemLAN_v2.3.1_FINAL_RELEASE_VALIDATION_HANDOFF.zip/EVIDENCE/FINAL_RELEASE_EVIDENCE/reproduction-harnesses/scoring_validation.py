"""Validate frozen R4 against an independent oracle, not a workspace/R3 scorer."""
import copy,json,math,sys,traceback
from pathlib import Path
from independent_scoring import earned,score
sys.path.insert(0,'/workspace/final-release-validation-r4/locked-source/PHAN_MEM')
from scoring import config,grade,total_score
from snapshot_validation import SnapshotValidationError,load_snapshot

results=[]
values={'SINGLE':[0,1,None,'0',False],'MULTI':[[0],[0,2],[0,1,2],[],[0,0],None,[-1],[99]],'TF':[['D','S'],['D',''],['','S'],['',''],None],'MATCH':[[1,0],[1,None],[None,0],[],None],'FILL':[[' HAI ','ba'],['2',''],['','3'],['',''],None]}
answers={'SINGLE':0,'MULTI':[0,2],'TF':['D','S'],'MATCH':[1,0],'FILL':[['hai','2'],['ba','3']]}
try:
    cases=[]
    for kind in values:
        for mode in ('all','partial'):
            for points in (.001,1,4,1000):
                for weights in ([],[1,3]) if kind in ('TF','MATCH','FILL') else ([],):
                    item=dict(type=kind,options=['A','B','C'] if kind in ('SINGLE','MULTI') else ['A','B'],answer=answers[kind],scoring=config(dict(points=points,scoring_mode=mode,weights=','.join(map(str,weights))),kind,2))
                    for value in values[kind]:
                        actual,maximum=grade(item,value);expect,expected_maximum=earned(item,value)
                        assert math.isfinite(actual) and 0<=actual<=maximum
                        assert math.isclose(actual,float(expect),rel_tol=1e-12,abs_tol=1e-12) and maximum==float(expected_maximum)
                        actual_total=total_score([item],{0:value});expected_total=score([item],{0:value});assert actual_total==expected_total
                        cases.append(dict(item=item,choice=value,stored_grade=[actual,maximum],independent_grade=[float(expect),float(expected_maximum)],score=actual_total,independent_score=expected_total))
    assert len(cases)==344
    assert grade(dict(type='SINGLE',answer=0),0)==(1,1)
    assert grade(dict(type='TF',answer=['D','S'],scoring=dict(points=4,mode='partial')),['D',''])==(2,4)
    results.append(dict(name='valid_v23_scoring_independent_oracle',status='PASS',cases=cases,legacy_defaults_preserved=True,oracle='Independent Fraction arithmetic/Decimal half-up; no R3 or development application imports.'))
except Exception:results.append(dict(name='valid_v23_scoring_independent_oracle',status='FAIL',traceback=traceback.format_exc()))
try:
    base=dict(type='TF',options=['A','B'],answer=['D','S'],scoring=dict(version=1,points=4,mode='partial',weights=[1,3]))
    malformed=[]
    for key,value in [('points',0),('points',-1),('points',float('nan')),('points',float('inf')),('points',10**500),('weights',[0,0]),('weights',[-1,2]),('weights',[float('nan'),1]),('weights',[1]),('mode','bad'),('version',2)]:
        item=copy.deepcopy(base);item['scoring'][key]=value;malformed.append((key+'='+str(value),item))
    for field in ('points','mode','weights'):
        item=copy.deepcopy(base);item['scoring'].pop(field);malformed.append(('version1_missing_'+field,item))
    malformed += [('MULTI_empty',dict(type='MULTI',options=['A','B'],answer=[],scoring=dict(points=1,mode='partial'))),('FILL_empty',dict(type='FILL',options=['A','B'],answer=[[],['x']],scoring=dict(points=1))),('not_mapping','bad'),('missing_answer',dict(type='SINGLE',scoring=dict(points=1)))]
    checks=[]
    for name,item in malformed:
        for fn in (grade,total_score):
            try:fn(item,[]) if fn is grade else fn([item],{0:[]})
            except SnapshotValidationError as error:checks.append(dict(name=name,function=fn.__name__,controlled_error=str(error)))
            else:raise AssertionError((name,fn.__name__))
    results.append(dict(name='malformed_scoring_controlled_rejection',status='PASS',calls=len(checks),cases=checks))
except Exception:results.append(dict(name='malformed_scoring_controlled_rejection',status='FAIL',traceback=traceback.format_exc()))
Path('/workspace/TEST-CODEX/FINAL_RELEASE_EVIDENCE/scoring-independent.json').write_text(json.dumps(dict(results=results),ensure_ascii=False,indent=2,allow_nan=False)+'\n')
print([(r['name'],r['status']) for r in results])
raise SystemExit(int(any(r['status']=='FAIL' for r in results)))
