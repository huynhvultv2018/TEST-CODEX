"""Independent implementation of the frozen v2.3 binary-float arithmetic contract.

The exact-rational oracle and its raw failures remain unchanged. This diagnostic
retains float multiplication/division/summation order and Decimal(str(raw))
rounding, which are observable parts of the existing v2.3 formula.
"""
from decimal import Decimal,ROUND_HALF_UP
from independent_scoring import choice,complete,normalized

def earned_v23(item,value):
    rule=item.get('scoring',{});maximum=rule.get('points',1);kind=item.get('type','SINGLE')
    value=choice(value);answer=item['answer']
    if rule.get('mode','all')=='all' or kind=='SINGLE':return maximum*int(complete(item,value)),maximum
    if not isinstance(value,list):return 0,maximum
    if kind=='MULTI':
        if any(type(v) is not int or v<0 or v>=len(item['options']) for v in value):return 0,maximum
        selected=set(value);right=set(answer);ratio=max(0,(len(selected & right)-len(selected-right))/len(right))
    else:
        if len(value)!=len(answer):return 0,maximum
        weights=rule.get('weights') or [1]*len(answer);hits=[]
        for v,a in zip(value,answer):
            if kind=='FILL':ok=isinstance(v,str) and normalized(v) in [normalized(x) for x in a]
            elif kind=='MATCH':ok=type(v) is int and v==a
            else:ok=isinstance(v,str) and v==a
            hits.append(int(ok))
        ratio=sum(weight*hit for weight,hit in zip(weights,hits))/sum(weights)
    return maximum*ratio,maximum

def score_v23(items,values,raw=False):
    parts=[earned_v23(item,values.get(i)) for i,item in enumerate(items)]
    maximum=sum(b for a,b in parts);number=sum(a for a,b in parts)/maximum*10 if maximum else 0
    return number if raw else float(Decimal(str(number)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))
