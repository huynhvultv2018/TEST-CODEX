"""Read all fifty finalized records; preserve both arithmetic comparisons."""
import hashlib,json,sqlite3,sys
from pathlib import Path
from independent_scoring import choice,score
from v23_float_oracle import score_v23

db=Path('/workspace/final-release-validation-r4/clean-runtime-3/PHAN_MEM/thi_trac_nghiem.db')
e=Path('/workspace/TEST-CODEX/FINAL_RELEASE_EVIDENCE')
expected=json.loads((e/'lan-verified/50-answers-before-submit.json').read_text())
con=sqlite3.connect(db);con.row_factory=sqlite3.Row;records=[]
sys.path.insert(0,'/workspace/final-release-validation-r4/locked-source/PHAN_MEM')
from scoring import total_score
for before in expected:
    row=con.execute('SELECT * FROM bai_thi WHERE id=?',(before['attempt_id'],)).fetchone()
    items=json.loads(row['de_json']);actual={r['vi_tri_cau']:choice(r['lua_chon']) for r in con.execute('SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(row['id'],))}
    wanted={int(k):v for k,v in before['expected_answers'].items()}
    float_grade=score_v23(items,actual);rational_grade=score(items,actual);frozen_grade=total_score(items,actual)
    assert float_grade==frozen_grade
    records.append(dict(client=before['client'],attempt_id=row['id'],submitted_at=row['submitted_at'],stored_score=row['diem'],independent_v23_float_regrade=float_grade,frozen_candidate_regrade=frozen_grade,rational_regrade=rational_grade,v23_raw_float_repr=repr(score_v23(items,actual,raw=True)),v23_score_mismatch=int(row['diem']!=float_grade),rational_difference=int(row['diem']!=rational_grade),expected_answers_match=actual==wanted,snapshot_hash_preserved=hashlib.sha256(row['de_json'].encode()).hexdigest()==before['snapshot_sha256'],stored_answers=actual,snapshot=items))
con.close()
result=dict(classification='HARNESS_ORACLE_ARITHMETIC_CONTRACT_DIFFERENCE',clients=50,v23_score_mismatch=sum(r['v23_score_mismatch'] for r in records),rational_difference=sum(r['rational_difference'] for r in records),all_expected_answers_match=all(r['expected_answers_match'] for r in records),all_snapshots_preserved=all(r['snapshot_hash_preserved'] for r in records),all_submitted=all(r['submitted_at'] is not None for r in records),explanation='Frozen v2.3 computes binary floats before Decimal(str(raw)) half-up. A precise rational oracle is a different arithmetic contract at ties. No candidate formula or prior oracle/assertion was changed; both raw comparisons are preserved.',records=records)
(e/'50-regrade-arithmetic-diagnostic.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
