"""Complete result/duplicate checks without changing the earlier failed oracle.

The original 50-submit burst and saved answers are retained as evidence. This
phase restores only that isolated test DB into another exact candidate extract,
uses normal authenticated workflows, and independently re-grades with the frozen
v2.3 float contract. No trial state is copied, reset, edited or bypassed.
"""
import hashlib,json,math,os,re,sqlite3,threading,traceback
from collections import Counter
from pathlib import Path
import lan_validation as h
from independent_scoring import answers_for,choice,complete,submit_form,wrong_value
from v23_float_oracle import score_v23

def verify(client,expected):
    row=h.rows('SELECT * FROM bai_thi WHERE id=?',(client.attempt,))[0];actual=h.saved_answers(client)
    regraded=score_v23(client.items,actual);mismatches=[i for i in set(actual)|set(expected) if actual.get(i)!=expected.get(i) or (i in actual)!=(i in expected)]
    record=dict(client=client.code,student_id=row['ma_hs'],attempt_id=client.attempt,submitted_at=row['submitted_at'],stored_score=row['diem'],independent_v23_float_regrade=regraded,score_mismatch=int(row['diem']!=regraded),answer_mismatch_positions=mismatches,expected_answers=expected,stored_answers=actual,snapshot=client.items,snapshot_sha256=h.digest(row['de_json']),stored_correct=row['so_cau_dung'],independent_correct=sum(complete(q,actual.get(i)) for i,q in enumerate(client.items)))
    assert row['ma_hs']==client.code and not mismatches and not record['score_mismatch']
    assert row['submitted_at'] is not None and math.isfinite(row['diem']) and 0<=row['diem']<=10
    assert row['tong_so_cau']==40 and row['so_cau_dung']==record['independent_correct']
    return record

def main():
    h.E.mkdir(parents=True,exist_ok=True);server=h.Server();results=[]
    def check(name,fn):
        try:v=fn();results.append(dict(name=name,status='PASS',detail=v));print(name,'PASS',flush=True);return v
        except Exception:results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()));print(name,'FAIL',flush=True);return None
    try:
        server.start();teacher=h.teacher_login()
        previous=h.ROOT/'clean-runtime-3/PHAN_MEM/thi_trac_nghiem.db'
        backup=h.ROOT/'test-databases/completion-source.db';src=sqlite3.connect(previous);dst=sqlite3.connect(backup)
        try:src.backup(dst)
        finally:dst.close();src.close()
        data=backup.read_bytes();source_sha=h.digest(data)
        teacher.post('/teacher/restore',files=[('file','isolated-stress-test.db',data)],group='RESTORE TEST DATA');page=teacher.html('/teacher/backups','RESTORE TEST DATA')
        assert 'Đã khôi phục dữ liệu' in page and h.digest(backup.read_bytes())==source_sha
        before=json.loads(Path('/workspace/TEST-CODEX/FINAL_RELEASE_EVIDENCE/lan-verified/50-answers-before-submit.json').read_text())
        eid=h.rows('SELECT ky_thi_id FROM bai_thi WHERE id=?',(before[0]['attempt_id'],))[0]['ky_thi_id']
        def results_duplicates():
            def login_existing(item,i):
                client=h.Client(item['client'],'50-completion');client.html('/','LOGIN')
                _,_,headers=client.post('/',form={'ma_hs':client.code,'ky_thi_id':str(eid)},group='LOGIN');assert headers['location']=='/result'
                page=client.html('/result','RESULT');assert 'Student '+client.code in page
                row=h.rows('SELECT * FROM bai_thi WHERE ky_thi_id=? AND ma_hs=?',(eid,client.code))[0];client.attempt=row['id'];client.items=json.loads(row['de_json'])
                assert client.attempt==item['attempt_id'] and h.digest(row['de_json'])==item['snapshot_sha256']
                return client
            clients=h.burst([h.Client(item['client'],'50-completion') for item in before],lambda c,i:login_existing(before[i],i))
            identities=[c.identity() for c in clients]
            for key in ('cookie_sha256','csrf_sha256','client_token_sha256'):assert len({r[key] for r in identities})==50
            expected=[{int(k):v for k,v in r['expected_answers'].items()} for r in before]
            finalized=[h.rows('SELECT * FROM bai_thi WHERE id=?',(c.attempt,))[0] for c in clients]
            def duplicate(c,i):
                c.post('/exam',form=submit_form(c.items,{j:wrong_value(q,'duplicate_wrong') for j,q in enumerate(c.items)}),group='DUPLICATE SUBMIT')
                h.save_answer(c,0,wrong_value(c.items[0]),expected=(409,),group='DUPLICATE AUTOSAVE')
                page=c.html('/result','RESULT');assert 'Student '+c.code in page and str(finalized[i]['diem']) in page
            h.burst(clients,duplicate)
            assert all(h.rows('SELECT * FROM bai_thi WHERE id=?',(c.attempt,))[0]==finalized[i] for i,c in enumerate(clients))
            comparison=[verify(c,expected[i]) for i,c in enumerate(clients)]
            h.save('50-final-answer-score-comparison.json',comparison);h.save('50-isolated-identities.json',identities);h.integrity('50-completion',clients)
            return dict(status='PASS',clients=50,original_primary_exam_id=eid,stored_data_native_restored=True,restored_test_database_sha256=source_sha,all_original_attempts_snapshots_scores_preserved=True,score_mismatch_count=0,answer_mismatch_count=0,cross_student_contamination=0,duplicates_cannot_change_finalized_state=True,results_identify_correct_students=True)
        verified=check('50_existing_submit_data_results_duplicates_independent_v23_regrade',results_duplicates)
        if verified is not None:
            def sixty():
                codes=[f'FINAL_50_{i:02d}' for i in range(1,51)]+[f'FINAL_60_{i:02d}' for i in range(51,61)]
                eid60=h.create_exam(teacher,'FINAL_60_HEADROOM_FLOAT_V23');clients=h.burst([h.Client(code,'60-headroom') for code in codes],lambda c,i:h.login_student(c.code,eid60,'60-headroom'))
                expected=[answers_for(c.items,i,4) for i,c in enumerate(clients)]
                h.burst(clients,lambda c,i:[h.save_answer(c,j,expected[i][j]) for j in range(40)])
                h.burst(clients,lambda c,i:h.save_answer(c,0,expected[i][0]))
                initial=len(h.REQUESTS)
                h.burst(clients,lambda c,i:c.post('/exam',form=submit_form(c.items,expected[i]),group='SUBMIT'))
                submit_events=[r for r in h.REQUESTS[initial:] if r['group']=='SUBMIT' and r['scope']=='60-headroom'];assert len(submit_events)==60
                h.burst(clients,lambda c,i:c.html('/result','RESULT'))
                comparison=[verify(c,expected[i]) for i,c in enumerate(clients)];h.save('60-final-answer-score-comparison.json',comparison);h.integrity('60-headroom',clients)
                h.save('60-submit-burst.json',dict(clients=60,dispatch_span_ms=(max(x['started_epoch'] for x in submit_events)-min(x['started_epoch'] for x in submit_events))*1000,peak_in_flight=max(x['in_flight_at_start'] for x in submit_events),responses=Counter(str(x['status']) for x in submit_events)))
                return dict(status='PASS',clients=60,exam_id=eid60,score_mismatch_count=0,answer_mismatch_count=0,cross_student_contamination=0)
            check('60_client_headroom',sixty)
    except Exception:results.append(dict(name='completion_setup',status='FAIL',traceback=traceback.format_exc()))
    finally:
        server.stop();h.save('results.json',dict(results=results,peak_client_requests_in_flight=h.PEAK,server_starts=server.starts));h.save('requests.json',h.REQUESTS);h.save('metrics-50.json',h.metrics('50'));h.save('metrics-60.json',h.metrics('60'))
        h.save('server-resource-samples.json',dict(measurement_error=server.measurement_error,samples=server.samples,CPU='MEASURED' if server.samples else 'NOT MEASURED',MEMORY='MEASURED' if server.samples else 'NOT MEASURED'))
        for logfile in h.ROOT.glob('server-start-*.log'):
            safe=['[DEFAULT ACCOUNT BANNER REDACTED]' if 'Tai khoan khoi tao:' in line else line for line in logfile.read_text(errors='replace').splitlines()];(h.E/logfile.name).write_text('\n'.join(safe)+'\n')
        (h.E/'route-error.log').write_bytes((h.APP/'logs/app.log').read_bytes())
    return int(any(r['status']=='FAIL' for r in results))
if __name__=='__main__':raise SystemExit(main())
