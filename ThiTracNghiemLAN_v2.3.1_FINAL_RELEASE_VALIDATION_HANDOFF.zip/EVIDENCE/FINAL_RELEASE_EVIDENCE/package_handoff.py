"""Create the report/evidence-only final handoff, preserving previous artifacts."""
import hashlib,json,shutil,zipfile
from pathlib import Path

REPO=Path('/workspace/TEST-CODEX');E=REPO/'FINAL_RELEASE_EVIDENCE'
STAGE=REPO/'FINAL_RELEASE_HANDOFF_CONTENTS'
ZIP=REPO/'ThiTracNghiemLAN_v2.3.1_FINAL_RELEASE_VALIDATION_HANDOFF.zip'
REPORTS=['FINAL_RELEASE_VALIDATION_REPORT.md','FINAL_REGRESSION_REPORT.md','FINAL_SECURITY_REPORT.md','FINAL_DATABASE_REPORT.md','FINAL_PACKAGING_REPORT.md','50_CLIENT_LAN_TEST_REPORT.md','50_CLIENT_PERFORMANCE_REPORT.md','50_CLIENT_DATA_INTEGRITY_REPORT.md','50_CLIENT_SESSION_ISOLATION_REPORT.md','FINAL_FINDINGS.md','FINAL_RELEASE_GATE.md']
def sha(data):return hashlib.sha256(data).hexdigest()
assert not STAGE.exists() and not ZIP.exists(),'Never overwrite a previous final handoff'
summary=json.loads((E/'final-summary.json').read_text());assert summary['FINAL_RELEASE_VALIDATION']=='PENDING' and summary['50_CLIENT_GATE']=='PASS'
lock=json.loads((E/'baseline-lock.json').read_text());assert sha(Path(lock['candidate_path']).read_bytes())==lock['candidate_sha256']
original_checksum=REPO/'CHECKSUMS.sha256';before_sha=sha(original_checksum.read_bytes())
assert before_sha=='5164dd12b8e9c405e52039763f4668f0951a27b76f4dbaa84148cf878704056a'
STAGE.mkdir();(STAGE/'REPORTS').mkdir()
for name in REPORTS:
    p=REPO/name;assert p.is_file() and p.stat().st_size>0;shutil.copyfile(p,STAGE/'REPORTS'/name)
for p in E.rglob('*'):
    if not p.is_file():continue
    assert p.suffix not in ('.db','.sqlite','.zip','.pyc','.pem','.key'),p
    assert '__pycache__' not in p.parts and p.name not in ('.session_secret','license_trial.json'),p
    assert p.name not in ('app.py','scoring.py','question_types.py','multi_routes.py','snapshot_validation.py','license_core.py'),p
shutil.copytree(E,STAGE/'EVIDENCE'/'FINAL_RELEASE_EVIDENCE')
members=sorted(p.relative_to(STAGE).as_posix() for p in STAGE.rglob('*') if p.is_file())
manifest={n:sha((STAGE/n).read_bytes()) for n in members}
(STAGE/'CHECKSUMS.sha256').write_text(''.join(h+'  '+n+'\n' for n,h in manifest.items()))
with zipfile.ZipFile(ZIP,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(STAGE).as_posix())
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(members)|{'CHECKSUMS.sha256'}
    assert all(sha(z.read(n))==h for n,h in manifest.items())
    assert z.read('CHECKSUMS.sha256')==(STAGE/'CHECKSUMS.sha256').read_bytes()
    assert len([n for n in z.namelist() if n.startswith('REPORTS/')])==11
assert sha(original_checksum.read_bytes())==before_sha
assert sha(Path(lock['candidate_path']).read_bytes())==lock['candidate_sha256']
proof={'status':'PASS','path':str(ZIP),'bytes':ZIP.stat().st_size,'sha256':sha(ZIP.read_bytes()),'file_count':len(members)+1,'report_count':11,'evidence_count':len(members)-11,'checksum_entries':len(manifest),'all_checksums_match':True,'CRC':'PASS','no_application_source_candidate_runtime_DB_or_credentials':True,'candidate_baseline_sha256':lock['candidate_sha256'],'R1_original_checksum_file_unchanged':True,'final_release_validation':'PENDING','50_client_gate':'PASS'}
(REPO/'FINAL_RELEASE_PACKAGE_VALIDATION.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
