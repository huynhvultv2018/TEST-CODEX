"""Seal evidence, derive measured metrics and write review reports once."""
import hashlib,json,math,re,shutil,statistics
from collections import Counter
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

REPO=Path('/workspace/TEST-CODEX');ROOT=Path('/workspace/final-release-validation-r4');E=REPO/'FINAL_RELEASE_EVIDENCE'
def read(name):return json.loads((E/name).read_text())
def write(name,obj):(E/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def sha(data):return hashlib.sha256(data).hexdigest()
lock=read('baseline-lock.json');assert sha(Path(lock['candidate_path']).read_bytes())=='68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2'
for directory in ['locked-source','clean-release','clean-runtime-2','clean-runtime-3','clean-runtime-4']:
    assert all(sha((ROOT/directory/name).read_bytes())==expected for name,expected in lock['file_hashes'].items())
write('source-freeze-final.json',dict(status='PASS',baseline_sha256=lock['candidate_sha256'],original_files=59,all_five_extracts_match_candidate=True,application_source_or_original_tests_changed=False,new_candidate_created=False,old_R4_workspace_source_used=False))

harnesses=E/'reproduction-harnesses';harnesses.mkdir()
for p in (ROOT/'harness').glob('*.py'):shutil.copyfile(p,harnesses/p.name)
write('final-harness-hashes.json',{p.name:sha(p.read_bytes()) for p in sorted(harnesses.glob('*.py'))})

regression={}
for suite in ['r1','r2','r3-original','r3-contract-A']:
    data=read(suite+'/results.json')['results'];regression[suite]={s:sum(r['status']==s for r in data) for s in ['PASS','FAIL']}
assert regression['r1']=={'PASS':18,'FAIL':0} and regression['r2']=={'PASS':15,'FAIL':0}
assert regression['r3-original']=={'PASS':14,'FAIL':1} and regression['r3-contract-A']=={'PASS':15,'FAIL':0}
assert all(r['exit_code']==0 for r in read('original/runner-results.json')['results'])
assert read('browser-csrf/results.json')['status']=='PASS'
assert all(r['status']=='PASS' for r in read('scoring-independent.json')['results'])
native=read('lan-verified/results.json')['results'];completion=read('lan-completion/results.json')['results']
assert next(r for r in native if r['name'].startswith('native_smoke'))['status']=='PASS'
assert all(next(r for r in native if r['name']==n)['status']=='PASS' for n in ['50_client_mixed','50_client_deadline_under_load','HTTP_retry_and_atomic_race'])
assert next(r for r in native if r['name']=='native_restart_same_data_directory')['status']=='FAIL'
assert all(r['status']=='PASS' for r in completion)
checks=read('lan-completion/50-final-answer-score-comparison.json');assert len(checks)==50
assert all(r['score_mismatch']==0 and not r['answer_mismatch_positions'] for r in checks)
assert read('database-integrity-final.json')['status']=='PASS'

all_requests=[]
for phase in ['lan','lan-final','lan-verified','lan-completion']:
    for r in read(phase+'/requests.json'):all_requests.append(dict(r,phase=phase))
final_requests=[r for r in all_requests if r['phase'] in ('lan-verified','lan-completion')]
fifty=[r for r in all_requests if r['scope'].startswith('50')]
final50=[r for r in final_requests if r['scope'].startswith('50')]
sixty=[r for r in final_requests if r['scope'].startswith('60')]
assert len(fifty)==11298 and len(final50)==8587 and len(sixty)==2760
assert not any(not r['success'] for r in fifty)
assert not any(r['status'] is not None and r['status']>=500 for r in fifty+sixty)
def stats(events):
    a=sorted(r['latency_ms'] for r in events)
    return dict(requests=len(events),expectation_pass=sum(r['success'] for r in events),unexpected_fail=sum(not r['success'] for r in events),status_distribution=dict(Counter(str(r['status']) for r in events)),min_ms=min(a),median_ms=statistics.median(a),p95_ms=a[math.ceil(.95*len(a))-1],max_ms=max(a),expected_4xx=sum(r['expected_rejection'] for r in events),timeouts=sum(r['error']=='TimeoutError' for r in events))
groups={g:stats([r for r in final50 if r['group']==g]) for g in sorted({r['group'] for r in final50})}
initial=[]
for r in [r for r in final_requests if r['scope']=='50-main' and r['group']=='LOGIN' and r['method']=='POST']:
    if r['client'] not in {x['client'] for x in initial}:initial.append(r)
assert len(initial)==50
burst=read('lan-verified/50-submit-burst.json');sixty_burst=read('lan-completion/60-submit-burst.json')
assert burst['client_count']==50 and burst['peak_in_flight']==50
lock_errors=[]
for p in E.rglob('*.log'):
    for i,line in enumerate(p.read_text(errors='replace').splitlines(),1):
        if re.search(r'database (?:table )?is locked|database is busy',line,re.I):lock_errors.append(dict(file=str(p.relative_to(E)),line=i))
assert not lock_errors
resources={}
for phase in ['lan-verified','lan-completion']:
    resource=read(phase+'/server-resource-samples.json');samples=resource['samples']
    resources[phase]=dict(samples=len(samples),CPU=resource['CPU'],MEMORY=resource['MEMORY'],CPU_peak_percent=max(r['cpu_percent'] for r in samples),RSS_peak_bytes=max(r['rss_bytes'] for r in samples),sampling_interval_s=.1,CPU_percent_is_not_normalized_to_machine_core_count=True)
summary=dict(FINAL_RELEASE_VALIDATION='PENDING',reason='Native restart is blocked in Codex Linux by an unstable machine fingerprint; readiness on a stable target machine has not been verified. No source or license-state workaround applied.',F010='PASS',F011='PASS',F012='PASS',**{'50_CLIENT_GATE':'PASS','50_CLIENT_SIMULATION':'PASS','60_CLIENT_HEADROOM':'PASS','PHYSICAL_50_PC_LAN':'NOT_TESTED','WINDOWS_RUNTIME':'NOT_VERIFIED'},TOTAL_50_CLIENT_REQUESTS=len(fifty),FINAL_VERIFIED_50_REQUESTS=len(final50),EARLIER_CALIBRATION_50_REQUESTS=len(fifty)-len(final50),FAILED_REQUESTS=0,FAILED_REQUESTS_definition='Unexpected request status/transport outcome; planned rejections and one intentional client read timeout are counted separately.',RAW_CLIENT_TIMEOUT_COUNT=sum(r['error']=='TimeoutError' for r in fifty),EXPECTED_4XX_COUNT=sum(r['expected_rejection'] for r in fifty),HTTP_500_COUNT=0,HTTP_5XX_COUNT=0,DB_LOCK_ERRORS=0,CROSS_STUDENT_CONTAMINATION=0,SCORE_MISMATCH_COUNT=0,RATIONAL_ORACLE_DIFFERENCES=4,independent_regrade_contract='Frozen v2.3 binary float arithmetic followed by Decimal(str(raw)) ROUND_HALF_UP; no application grader import in the independent oracle.',regression=regression,login_burst=stats(initial),final_50_metrics=stats(final50),all_50_metrics=stats(fifty),headroom_60_metrics=stats(sixty),groups=groups,submit_burst_50=burst,submit_burst_60=sixty_burst,resources=resources,SERVER_BIND='0.0.0.0',PORT=5000,LAN_URL='http://172.26.91.254:5000',LAN_ACCESS='PASS',native_restart_raw='FAIL',source_freeze='PASS')
write('final-summary.json',summary);write('combined-request-ledger.json',all_requests)

date=datetime.now(ZoneInfo('Asia/Bangkok')).strftime('%Y-%m-%d %H:%M:%S %Z')
common=f'Kiểm chứng {date}. Baseline SHA-256 `{lock["candidate_sha256"]}`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.\n'
def report(name,text):
    p=REPO/name;assert not p.exists(),p;p.write_text(text.strip()+'\n')
def table(metrics,groups_wanted):
    lines=['| Nhóm | Requests | Bất thường | Min ms | Median ms | P95 ms | Max ms |','|---|---:|---:|---:|---:|---:|---:|']
    for group in groups_wanted:
        r=metrics[group];lines.append(f'| {group} | {r["requests"]} | {r["unexpected_fail"]} | {r["min_ms"]:.2f} | {r["median_ms"]:.2f} | {r["p95_ms"]:.2f} | {r["max_ms"]:.2f} |')
    return '\n'.join(lines)

report('FINAL_RELEASE_VALIDATION_REPORT.md',f'''# FINAL RELEASE VALIDATION — ThiTracNghiemLAN v2.3.1

FINAL_RELEASE_VALIDATION = PENDING. 50_CLIENT_GATE = PASS; 50_CLIENT_SIMULATION = PASS; 60_CLIENT_HEADROOM = PASS.

{common}
## Kết luận

Các workflow từ lần khởi động sạch, 5 loại, scoring, F010/F011/F012, R1–R4 required findings, backup/restore và dữ liệu dưới tải đều có bằng chứng đạt. Chưa kết luận sẵn sàng nâng Production: khi restart trên Codex Linux, `uuid.getnode()` trả node ngẫu nhiên khác process trước, nên native license guard từ chối state của máy cũ. Không reset trial, không override machine ID, không patch nguồn. Cần chứng cứ restart trên máy triển khai có fingerprint ổn định; Windows chưa chạy.

## Phạm vi đã thực hiện

Từ HANDOFF người dùng upload, đọc đúng member candidate 785.622 byte, verify hash trước extract. Tạo source sạch 59 file, chạy entry point `PHAN_MEM/app.py` thật bằng Python, Waitress 12 thread, bind `0.0.0.0:5000`; HTTP qua IP nội bộ `172.26.91.254`, không chỉ loopback. Dependency trong requirements đều có. Không dùng app source từ R1/R2/R3/workspace phát triển.

Native smoke: teacher/student login, question bank/new/edit, matrix/create/build 40 câu (5 loại × 4 mức × 2), autosave, submit/result, UI/Excel report, backup/download, valid/legacy/corrupt/semantic-invalid restore, admin settings/accounts, import preview/confirm, unlock/relogin/retake. Scoring: 344 phép so sánh độc lập và 36 rejection calls; corruption runtime 6 trường hợp × 5 endpoint đều HTTP 400, không ghi dữ liệu.

50 client riêng có cookie/nonce/client_token/attempt riêng. Tải jitter, burst, 10 disconnect thật hơn 20 giây, reconnect giữ câu/answers, mixed 10 load/20 save/10 reload/10 submit, deadline 15 trước/15 gần/20 sau, HTTP atomic race 8 request và một client read-timeout chủ đích/retry. 50 submit bắt đầu trong {burst['dispatch_span_ms']:.2f} ms, peak 50 request in flight; 50 đáp án/score/snapshot được đọc và đối chiếu. Headroom 60 thực hiện sau khi các bằng chứng bắt buộc của 50 đủ, không thay requirement 50.

## Không che raw failure

R3 nguyên bản 14 PASS/1 FAIL: một kỳ vọng lấy marker bank sửa sau thi trái contract F012. Bản scenario có sẵn trong HANDOFF chuẩn bị marker trước thi, giữ 61 assertion, đạt 15/15. R3 gốc không bị sửa hoặc đổi thành PASS.

Các run của harness mới còn được giữ: một lần startup bị license/environment chặn; một lần sai parser SQLite INTEGER và giả định POST backup trả download; run `lan-verified` dừng tổng hợp score vì oracle phân số chính xác khác phép float v2.3 ở tie. Bốn score có chênh 0,01 với rational oracle; **0 score khác frozen v2.3 khi re-grade độc lập theo đúng arithmetic**. Không sửa scorer hoặc oracle/assertion cũ; cung cấp cả hai phép đối chiếu, và kiểm tiếp result/duplicate qua native restore của test DB. Native restart raw vẫn FAIL, final gate PENDING.

## Giới hạn

PHYSICAL_50_PC_LAN = NOT_TESTED. WINDOWS_RUNTIME = NOT_VERIFIED. Simulation dùng các thread HTTP riêng trên cùng cloud host với server; network latency và CPU không đại diện cho 50 PC/switch thật. Không có SLO tự đặt. Server kiểm thử đã dừng; không nâng Production, không R5/bump version.
''')

report('FINAL_REGRESSION_REPORT.md',f'''# FINAL REGRESSION REPORT

Required product findings R1–R4 = PASS; native restart readiness = PENDING (environment). Không gọi toàn bộ raw harness runs là PASS.

{common}
| Suite | Kết quả | Evidence |
|---|---|---|
| R1 | 18/18 PASS | r1/results.json |
| R2 | 15/15 PASS | r2/results.json |
| R3 nguyên bản | 14 PASS / 1 FAIL | r3-original/results.json |
| R3 scenario theo contract A | 15/15 PASS | r3-contract-A/results.json |
| Sáu script gốc | 6 exit 0 | original/runner-results.json |
| Audit/legacy/race/browser gốc | 21/21, 6/6, PASS, PASS | original/*.json |
| Browser CSRF thật | PASS | browser-csrf/results.json |
| Independent scoring/corruption | 344 cases, 36 calls PASS | scoring-independent.json |
| Native F010/F011/F012/backup/unlock | PASS | lan-verified/smoke-security-database-history.json |
| Mixed/deadline/HTTP race/retry | PASS | lan-verified/results.json |
| 50 result/duplicates/v2.3 independent re-grade | PASS | lan-completion/results.json |
| 60 headroom | PASS | lan-completion/results.json |
| Same-directory native restart | FAIL trong Codex; readiness PENDING | lan-verified/startup-restart.json |

F001/F002: R1 lock/deadline/rollback/8-submit tests giữ kết quả, HTTP race và deadline dưới tải giữ answers ↔ score. F003/F004: round-trip comma topic, normalization và ma trận 20 ô vẫn đạt. F005/F006/F008: clone 4 khối/5 loại/2 mode, numeric validation, Excel text safety giữ nguyên. F007/F009/F017: token/result/legacy editor/unlock/relogin/retake giữ kết quả. F010/F011/F012: pure validation + native HTTP + real Chromium + history BEFORE/AFTER và legacy.

SINGLE/MULTI/TF/MATCH/FILL render/browser, save/reload/submit/result/report/Excel đều được exercise bởi suite gốc và native workloads. ALL/PARTIAL/weights/points/snapshot giữ công thức cũ. `harness-provenance.json` chứng minh upstream script giống byte với HANDOFF; các test gốc trong candidate giống byte. Adapter pre-CSRF chỉ lấy nonce HTML thật, không exemption.

R3 FAIL là OBSOLETE TEST EXPECTATION về nguồn history, không true regression. Precision oracle mới dùng Fraction/Decimal tạo 4 khác biệt tại rounding tie so với float v2.3; diagnostic chứng minh scoring cũ và independent float re-grade khớp cả 50. Raw assert Fraction không bị bỏ, đổi expected, skip/XFAIL hoặc ghi lại PASS. Source-freeze kiểm 59 member ở cả năm bản giải nén; không patch.
''')

report('FINAL_SECURITY_REPORT.md',f'''# FINAL SECURITY REPORT

F010 = PASS. F011 = PASS. Token/session isolation = PASS trong simulation. Native restart license limitation được giữ riêng, không bypass.

{common}
F010: 344 valid cases theo oracle độc lập; 36 malformed scorer calls bị `SnapshotValidationError` kiểm soát. HTTP snapshot hỏng: missing answer, zero/NaN points, malformed history, SQLite id overflow, non-list JSON; GET exam/autosave/submit/report/Excel trả 400 và không ghi attempt/answers. Restore semantic-invalid có SQLite integrity ok bị reject trước thay active DB. Dữ liệu hợp lệ và legacy thiếu rule giữ default cũ, không tự sửa payload.

F011: AST inventory đúng 35 POST route; 175 native HTTP probes (missing, wrong, Unicode wrong, valid nonce + foreign Origin, valid nonce + foreign Referer) đều 403, DB không đổi. GET logout 405 không clear session. Valid HTML-field token/admin/import/restore/unlock/API/save/submit/result đều chạy. Token lấy từ HTML/session ứng dụng, không hard-code hoặc disable CSRF.

Chromium 151 dùng cookie thật, foreign same-site/cross-site HTML POST bị 403; forged student POST không finalize; GET logout 405. JSON browser wire chỉ OPTIONS và CORS chặn POST; không dùng preflight làm bằng chứng thay cho HTML CSRF. Probe passive, không intercept request hoặc tắt browser security. Evidence `browser-csrf/`.

50-cookie/nonce/client-token hashes đều unique. Nonce client A + cookie B bị 403; sửa client_token trong signed cookie B thành token A giữ signature cũ bị 403. Client_token là signed-session state, không phải header riêng. 10 cookie cũ sau reconnect/revocation bị 409 với valid CSRF nonce cũ, proving native DB token ownership check. Không share cookie jar.

Evidence không có password, actual cookie/CSRF/client token hoặc signing key. Raw status/timing/state bảo toàn; chỉ default account startup banner và nonce trong HTML được redacted. Test accounts/IDs đều synthetic. Không sửa route/template/cookie policy/license/machine ID hoặc environment configuration.
''')

report('FINAL_DATABASE_REPORT.md',f'''# FINAL DATABASE REPORT

Database correctness/integrity = PASS trong test fixtures; không sử dụng production data.

{common}
Native backup POST tạo file và redirect manager, GET download trả SQLite readable. Invalid physical DB và semantically invalid scoring DB bị reject có thông báo, active logical dump không đổi. Legacy DB không rule scoring restore/build/submit score 10; valid DB restore thành công, source backup hashes giữ nguyên. Không tự sửa dữ liệu hỏng. Raw ở `lan-verified/smoke-security-database-history.json`.

F012: native question NB, exam/submit, capture UI/XLSX BEFORE; edit content/mức độ NB→VD/mã/points bằng editor; historical UI và cả bốn sheet values AFTER giữ nguyên, stored attempt không đổi, score 10. Legacy history thiếu hiển thị Không rõ (legacy), score/snapshot giữ nguyên, không backfill. HTML evidence redacts nonce; XLSX giữ nguyên.

Sau stress và completion/headroom: PRAGMA integrity_check = ok, foreign_key_check rỗng. Schema không khai báo FK, nên có kiểm độc lập orphan student/exam/answer/question, duplicate attempt/answer, answer qid/position khớp snapshot, correct flag khớp re-grade, missing answer ở finalized row, unexpected SQL NULL và score/state hợp lệ. {read('database-integrity-final.json')['attempt_count']} attempts, {read('database-integrity-final.json')['answer_count']} answer rows; mọi lỗi nêu trên = 0. Active/unanswered states theo contract không bị xem nhầm là corruption.

50 primary và 60 headroom expected answers == stored answers, stored scores == independent frozen-v2.3 float re-grade. 50 snapshots giữ hash sau submit và qua native restore test DB để kiểm tiếp duplicates/result. Temporary DB/backup/credentials không đưa vào handoff/Git. Không sửa schema; SQLite INTEGER affinity của lua_chon được decoder harness xử lý đúng kiểu dữ liệu vốn có.
''')

report('FINAL_PACKAGING_REPORT.md',f'''# FINAL PACKAGING REPORT

Candidate integrity/source freeze = PASS; runtime initial extraction = PASS; deployment restart evidence = PENDING.

{common}
Candidate lấy từ đúng upload HANDOFF SHA `2e220d29fb81d4b969327f1b30ccdad7807a5ee60a79b248bd7a9dd0d5dfbc3e`. Candidate 785.622 byte, 59 member, CRC PASS, SHA bắt buộc khớp trước thao tác. Không tạo candidate source mới. Năm extraction chỉ khác generated test data; toàn bộ 59 member gốc vẫn khớp byte/hash. Baseline/development workspace không cung cấp runtime app source.

Không có absolute development path, nested baseline ZIP, cache, session secret hoặc runtime DB trong candidate. Local Python application modules và templates/static có trong ZIP; libraries từ requirements được cài sẵn: Flask 3.1.3, openpyxl 3.1.5, Waitress 3.0.2, cryptography 50.0.0, PyInstaller 6.22.3, Python 3.12.14. Harness dùng stdlib HTTP, Playwright/psutil chỉ cho kiểm thử/đo lường, không thành dependency ứng dụng. Không cần cài/chỉnh config môi trường.

Startup thật từ `app.py` với cwd nằm trong extraction sạch; process PYTHONPATH không lấy harness/development source, data/log/export/backup/trial state được tạo theo relative DATA_DIR hiện hành. Windows CHAY_MAY_CHU.bat dùng `%~dp0`, cần EXE tạo bằng build_exe.bat; candidate là source, không có EXE. Firewall script cho chọn TCP port, đã đọc nhưng không execute. Native port setting 5000→5001 được honor sau restart, bind/health 200 qua IP; chức năng logged-in bị native license guard chặn vì cloud fingerprint thay đổi. WINDOWS_RUNTIME = NOT_VERIFIED, không suy ra EXE/firewall/restart PASS.

Health/version và vài title script vẫn có label cũ (2.2.1/2.2/2.3); provenance xác định release bằng filename/hash v2.3.1, ghi INFO, không đổi version hoặc source.

Final HANDOFF chỉ REPORTS/, EVIDENCE/, CHECKSUMS.sha256. Không có candidate/source app, DB/backup runtime, credential, cache hay ZIP cũ lồng. Chỉ các harness tái hiện cần thiết, không upstream app/source R3. Manifest mới ở gốc staging/HANDOFF, manifest R1 đang có ở workspace giữ nguyên. CRC, member/checksum proof ghi `FINAL_RELEASE_PACKAGE_VALIDATION.json` ngoài ZIP; handoff hash báo riêng để tránh self-reference.
''')

report('50_CLIENT_LAN_TEST_REPORT.md',f'''# 50-CLIENT LAN TEST REPORT

50_CLIENT_GATE = PASS. 50_CLIENT_SIMULATION = PASS. 60_CLIENT_HEADROOM = PASS. PHYSICAL_50_PC_LAN = NOT_TESTED.

{common}
SERVER_BIND = 0.0.0.0; PORT = 5000; LAN_ACCESS = PASS qua IP nội bộ 172.26.91.254. Đây là HTTP thread-client simulation trên cloud host, không phải 50 PC/switch thật. Một server active tại một thời điểm, Waitress profile native 12 threads/200 connections. Không sửa bind/source.

Primary: một exam 40 câu, 50 tài khoản khác nhau, 50 snapshot/attempt/session riêng. Mỗi client trả lời/thay đổi nhiều câu, 40 autosaves có jitter nhỏ; burst 50 autosaves và một lượt cập nhật toàn bộ 40 câu. Teacher đọc monitor/report song song. 10/50 clients không gửi traffic >20 giây, native reconnect cùng attempt giữ snapshot/answers; token cũ bị chặn. 50 submit khởi động trong {burst['dispatch_span_ms']:.2f} ms, peak in-flight 50; không phải tuần tự.

Mixed và deadline dùng exam/50-session test cohorts bổ sung để không finalize sớm primary. Mixed có 10 load/20 autosave/10 reload/10 submit đồng thời, data khớp. Deadline dùng fixture rows rút thời hạn, không monkeypatch clock/source: 15 trước, 15 sát, 20 sau; late POST không lấy đáp án mới, score bằng stored-answer re-grade. HTTP race 8 request trên một attempt có một winner nhất quán; một read-timeout 0,5 ms chủ đích rồi retry không tạo double result.

Primary run lưu đủ 50 submit/answers; tổng hợp bằng rational oracle dừng ở tie precision. Raw failure được giữ. Diagnostic trên tất cả 50 rows: 4 khác biệt với rational arithmetic, 0 khác biệt với v2.3 float, không mất/chồng answers hoặc đổi snapshot. Completion dùng native restore chính test DB vào extraction mới (để tránh sửa/bypass trial state) rồi kiểm 50 result pages, wrong duplicate submits và submitted autosaves: score/answers/finalized rows giữ nguyên. Đây là tiếp tục chứng cứ trên cùng 50 attempts, không thay source/expected gốc hoặc tạo candidate mới.

60 probe sau coverage 50 đầy đủ: 60 session riêng, 40 autosaves/client + burst + 60 submit/result; {sixty_burst['dispatch_span_ms']:.2f} ms dispatch span, peak {sixty_burst['peak_in_flight']}; zero data/score mismatch và DB integrity ok. Không đặt SLO hay suy ra sức chứa tối đa.

Tất cả raw failed/calibration runs cũng được bàn giao; restart raw FAIL do identity môi trường giữ riêng và khiến FINAL_RELEASE_VALIDATION PENDING. Không gọi raw LAN harness suite toàn bộ PASS.
''')

report('50_CLIENT_PERFORMANCE_REPORT.md',f'''# 50-CLIENT PERFORMANCE REPORT

Số liệu đo thực, không đặt ngưỡng P95/SLO tùy ý. Môi trường cloud host chia sẻ server + client load generators; không phải latency LAN vật lý.

{common}
## Phạm vi đếm

TOTAL_50_CLIENT_REQUESTS = {len(fifty)} trên mọi run của cohort 50, gồm {len(fifty)-len(final50)} request calibration có raw failure harness và {len(final50)} request của primary/mixed/deadline/retry/completion đã kiểm chứng. 60 probe tách riêng {len(sixty)} request. GET nonce/login, POST login và exam load là request riêng. Teacher/setup/security requests tách khỏi tổng 50. Status/timing/client/scope/phase đầy đủ trong combined-request-ledger.json.

FAILED_REQUESTS = 0 theo định nghĩa **unexpected** status/transport outcome. Raw 50 có {summary['EXPECTED_4XX_COUNT']} intentional 4xx và {summary['RAW_CLIENT_TIMEOUT_COUNT']} intentional read-timeout; chúng không bị xóa hoặc gọi HTTP 2xx success. `expectation_pass` trong ledger chỉ nghĩa đúng kịch bản. Raw client timeout không phản ánh server timeout/persistent failure; retry finalize đúng.

## Login burst chính thức 50

50 POST login đầu tiên của primary: success 50, unexpected fail 0, distribution `{summary['login_burst']['status_distribution']}`. Min {summary['login_burst']['min_ms']:.2f} ms, median {summary['login_burst']['median_ms']:.2f} ms, P95 {summary['login_burst']['p95_ms']:.2f} ms, max {summary['login_burst']['max_ms']:.2f} ms. CSRF GET và GET exam ghi riêng, không chỉ báo average.

## Các nhóm trong {len(final50)} request cuối

{table(groups,['LOGIN','LOAD EXAM','AUTOSAVE','SUBMIT','RESULT'])}

Không gộp duplicate/deadline/retry vào SUBMIT/AUTOSAVE thường; JSON metrics có từng nhóm riêng và HTTP status distribution. P95 dùng nearest rank `ceil(0.95*n)`; latency từ trước HTTP dispatch tới đọc response/error, gồm queue/network/client overhead; raw không làm tròn, bảng làm tròn 2 chữ số.

HTTP_500_COUNT = 0; HTTP 5xx = 0; persistent DB lock/error = 0. Intentional 403/409 và client timeout được liệt kê. Queue-depth warnings của Waitress dưới burst nếu có được giữ trong server logs, không bị đổi thành DB lock hoặc bịa server timing.

## Resources

Process PID samples mỗi 0,1 giây, psutil CPU/RSS thật. Native smoke + 50 cohorts: {resources['lan-verified']['samples']} samples, CPU peak {resources['lan-verified']['CPU_peak_percent']:.1f}%, RSS peak {resources['lan-verified']['RSS_peak_bytes']/1048576:.2f} MiB. Completion + 60: {resources['lan-completion']['samples']} samples, CPU peak {resources['lan-completion']['CPU_peak_percent']:.1f}%, RSS peak {resources['lan-completion']['RSS_peak_bytes']/1048576:.2f} MiB. CPU % theo process/core, có thể vượt 100%, chưa normalize theo tổng cores. Không gán các peak toàn phase thành metric riêng của từng endpoint. Không đo switch/PC/network RTT vật lý hoặc server-side per-route time.
''')

report('50_CLIENT_DATA_INTEGRITY_REPORT.md',f'''# 50-CLIENT DATA INTEGRITY REPORT

CROSS_STUDENT_CONTAMINATION = 0. SCORE_MISMATCH_COUNT = 0 theo scoring float v2.3. DB integrity = PASS.

{common}
50 primary expected/stored answers sau autosave và trước submit khớp theo attempt/student. 50 snapshots hash giữ nguyên. Submit burst 50 responses 302, 50 rows finalized; finalized state, stored correct count, question count 40 và độc lập re-grade đều hợp lệ. Completion duplicate wrong POST và autosave 409 không đổi bất kỳ finalized row/answers/score nào. Per-client full snapshots/expected/stored/score ở `lan-completion/50-final-answer-score-comparison.json`; dữ liệu burst và trước submit ở `lan-verified/`.

Arithmetic được giữ đúng contract: v2.3 tính binary float rồi Decimal(str(raw)) half-up. Một row raw float `{next(r['v23_raw_float_repr'] for r in read('50-regrade-arithmetic-diagnostic.json')['records'] if r['rational_difference'])}` lưu theo arithmetic hiện hành, khác rational ideal ở rounding tie; repr và cả hai điểm chính xác từng row có trong diagnostic. Diagnostic giữ cả hai, không đổi scoring để đạt mathematical ideal. 4 rational disagreements là lỗi lựa chọn oracle cho contract này; v2.3 independent re-grade và candidate re-grade khớp stored score 50/50. Không ghi lại raw assertion Fraction thành PASS.

Mixed workload 50: 40 active/10 finalized đúng expected riêng; deadline 50 giữ saved answers khi muộn, 20 late scores 0; atomic race/retry không inconsistent winner/double result. 60 headroom cũng 60/60 answer/score match.

Final DB: integrity ok, FK check rỗng; explicit orphan student/exam/answer/question, duplicate attempts/answers, wrong answer qid/position, wrong correct flag, missing finalized answer, unexpected SQL NULL, invalid finalized state = 0. 214 attempts/6902 answer rows gồm các cohort test và smoke, không phải 214 người dùng chính thức. Active score NULL/unanswered JSON null là trạng thái được phép.

Test DB và source backups chỉ tồn tại trong vùng test riêng, không commit/đóng gói. Source/archive/schema/scoring nguyên vẹn. Không có production data.
''')

report('50_CLIENT_SESSION_ISOLATION_REPORT.md',f'''# 50-CLIENT SESSION ISOLATION REPORT

SESSION_ISOLATION = PASS. TOKEN_ISOLATION = PASS. CROSS_STUDENT_CONTAMINATION = 0.

{common}
50 synthetic accounts FINAL_50_01..FINAL_50_50 có 50 client objects/cookie jars riêng. Signed cookie hash, CSRF nonce hash và client_token hash mỗi loại có 50 giá trị khác nhau; attempt_id và DB ma_hs đúng mapping. Đề cùng exam có thể cùng question IDs, nhưng snapshot shuffle/state/answers/score được kiểm theo từng attempt. Không dùng chung session để giả lập 50 users.

Nonce A trên cookie B bị 403, DB unchanged. Token A thay vào payload cookie B giữ signature B bị 403, chứng minh không thể forge authenticated session binding; client_token không truyền dưới header tự do. Native reconnect 10 clients sau >20 giây: same attempt/snapshot/answers, new token/session; old signed cookies vẫn có valid CSRF nhưng bị server validation 409, không ghi đè data. Các 40 client còn lại vẫn autosave bình thường.

Result pages sau submit/resume hiển thị đúng synthetic student name/score, không lộ state peer. Duplicate request tests chủ ý clone cookie của chính một client để kiểm retry/race, không biến normal 50 clients thành chung cookie jar.

Evidence: `lan-verified/50-identities-initial.json`, `50-token-negative-probes.json`, `50-disconnect-reconnect.json`, `lan-completion/50-isolated-identities.json`, per-client comparisons/requests. Chỉ lưu token/cookie hashes, không giá trị thật/password/signing key. PHYSICAL_50_PC_LAN = NOT_TESTED; Windows auth/runtime chưa verify.
''')

report('FINAL_FINDINGS.md',f'''# FINAL FINDINGS

FINAL_RELEASE_VALIDATION = PENDING. Source/candidate không được patch.

{common}
| ID | Phân loại | Bằng chứng / tác động |
|---|---|---|
| FV001 | ENVIRONMENT LIMITATION; thiếu readiness evidence | Linux cloud uuid.getnode trả random multicast node; 5 process → 5 fingerprint. Restart cùng data dir bị native license guard chặn login. Không reset state/override HWID. Stable-target/Windows restart cần kiểm; chưa kết luận release-blocking source defect trên target. |
| FV002 | HARNESS ORACLE CONTRACT DIFFERENCE, diagnosed | 4/50 rows khác exact-rational oracle 0,01; independent binary-float v2.3/candidate re-grade khớp stored score 50/50. Raw Fraction assert FAIL giữ nguyên, không sửa scoring/expected cũ. Không phải F002 race/answer inconsistency. |
| FV003 | OBSOLETE TEST EXPECTATION | R3 gốc 14/15, F008 fixture mong bank sửa sau thi xuất hiện trong report. Contract A chính thức khác; scenario giữ 61 assertions, marker trước thi, PASS 15/15. |
| FV004 | HARNESS INFRASTRUCTURE, diagnosed | Lua_chon INTEGER native type và backup-create redirect/download workflow khác giả định harness mới. Raw failed run giữ; decoder/transport được sửa theo contract trước verify, không đổi assertion dữ liệu/score hoặc original suite. |
| FV005 | INFO, observed pre-existing label | /health version 2.2.1, vài banner/script title cũ. Baseline identity theo artifact/hash v2.3.1. Không bump/patch label trong validation. |

F001/F002/F003/F004/F005/F006/F007/F008/F009/F010/F011/F012/F017 required invariants vẫn có bằng chứng PASS. Không phát hiện lost submission, cross-student corruption, frozen-v2.3 wrong score, database corruption, uncontrolled 500, persistent DB lock hoặc security bypass trong simulation. Native restart readiness chưa có evidence PASS, nên không cho phép suy ra Production readiness.

Không sửa finding mới, không R5/v2.4/version bump/Production. Windows/physical LAN là NOT_VERIFIED/NOT_TESTED, không hạ severity hay tự gán PASS.
''')

report('FINAL_RELEASE_GATE.md',f'''# FINAL RELEASE GATE

FINAL_RELEASE_VALIDATION = PENDING
50_CLIENT_GATE = PASS
50_CLIENT_SIMULATION = PASS
60_CLIENT_HEADROOM = PASS
PHYSICAL_50_PC_LAN = NOT_TESTED
WINDOWS_RUNTIME = NOT_VERIFIED

{common}
| Gate | Kết quả |
|---|---|
| Baseline hash / sạch / source freeze | PASS |
| Initial native startup + main smoke workflows | PASS |
| Five types / matrix / valid scoring / snapshot | PASS |
| F010 corruption + safe restore | PASS |
| F011 valid/invalid/missing/cross-origin/real browser | PASS |
| F012 UI/Excel history + legacy policy | PASS |
| R1–R4 required findings | PASS, xem raw obsolete expectation/oracle notes |
| 50 isolated login/load/autosave/burst/mixed/submit/result | PASS |
| 50 expected answers / independent v2.3 score / DB integrity | PASS |
| Deadline/race/retry/reconnect/isolation under load | PASS |
| Native restart on stable deployment target | PENDING; Codex raw FAIL bởi unstable machine identity |
| Physical 50-PC / Windows runtime | NOT_TESTED / NOT_VERIFIED |

TOTAL_50_CLIENT_REQUESTS = {len(fifty)}
FINAL_VERIFIED_50_REQUESTS = {len(final50)}
FAILED_REQUESTS = 0 (unexpected outcome)
RAW_PLANNED_CLIENT_TIMEOUTS = {summary['RAW_CLIENT_TIMEOUT_COUNT']}
EXPECTED_HTTP_4XX = {summary['EXPECTED_4XX_COUNT']}
HTTP_500_COUNT = 0
DB_LOCK_ERRORS = 0
CROSS_STUDENT_CONTAMINATION = 0
SCORE_MISMATCH_COUNT = 0 (frozen v2.3 float contract)

PENDING không do 60 probe hoặc physical 50 PC tự bị coi FAIL. Lý do là chưa có readiness restart được verify trên identity ổn định. Raw failure và reproduction bàn giao đầy đủ; không patch/bypass license/source/clock để làm PASS. Chưa nâng Production. Chờ người dùng kiểm chứng và quyết định.
''')
print(json.dumps({k:summary[k] for k in ['FINAL_RELEASE_VALIDATION','50_CLIENT_GATE','50_CLIENT_SIMULATION','60_CLIENT_HEADROOM','TOTAL_50_CLIENT_REQUESTS','FINAL_VERIFIED_50_REQUESTS','FAILED_REQUESTS','RAW_CLIENT_TIMEOUT_COUNT','EXPECTED_4XX_COUNT','HTTP_500_COUNT','DB_LOCK_ERRORS','CROSS_STUDENT_CONTAMINATION','SCORE_MISMATCH_COUNT']},indent=2))
