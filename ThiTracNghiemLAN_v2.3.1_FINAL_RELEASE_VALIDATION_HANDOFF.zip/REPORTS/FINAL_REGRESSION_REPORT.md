# FINAL REGRESSION REPORT

Required product findings R1–R4 = PASS; native restart readiness = PENDING (environment). Không gọi toàn bộ raw harness runs là PASS.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

| Suite | Kết quả | Evidence |
|---|---|---|
| R1 | 18/18 PASS | r1/results.json |
| R2 | 15/15 PASS | r2/results.json |
| R3 nguyên bản | 14 PASS / 1 FAIL | r3-original/results.json |
| R3 scenario theo contract A | 15/15 PASS | r3-contract-A/results.json |
| Sáu script gốc | 6 exit 0 | original/runner-results.json |
| Audit/legacy/race/browser gốc | 21/21, 6/6, PASS, PASS | original/*.json |
| Browser CSRF thật | PASS | browser-csrf/results.json |
| Independent scoring/corruption | 344 cases, 36 calls PASS | scoring-independent.json |
| Native F010/F011/F012/backup/unlock | PASS | lan-verified/smoke-security-database-history.json |
| Mixed/deadline/HTTP race/retry | PASS | lan-verified/results.json |
| 50 result/duplicates/v2.3 independent re-grade | PASS | lan-completion/results.json |
| 60 headroom | PASS | lan-completion/results.json |
| Same-directory native restart | FAIL trong Codex; readiness PENDING | lan-verified/startup-restart.json |

F001/F002: R1 lock/deadline/rollback/8-submit tests giữ kết quả, HTTP race và deadline dưới tải giữ answers ↔ score. F003/F004: round-trip comma topic, normalization và ma trận 20 ô vẫn đạt. F005/F006/F008: clone 4 khối/5 loại/2 mode, numeric validation, Excel text safety giữ nguyên. F007/F009/F017: token/result/legacy editor/unlock/relogin/retake giữ kết quả. F010/F011/F012: pure validation + native HTTP + real Chromium + history BEFORE/AFTER và legacy.

SINGLE/MULTI/TF/MATCH/FILL render/browser, save/reload/submit/result/report/Excel đều được exercise bởi suite gốc và native workloads. ALL/PARTIAL/weights/points/snapshot giữ công thức cũ. `harness-provenance.json` chứng minh upstream script giống byte với HANDOFF; các test gốc trong candidate giống byte. Adapter pre-CSRF chỉ lấy nonce HTML thật, không exemption.

R3 FAIL là OBSOLETE TEST EXPECTATION về nguồn history, không true regression. Precision oracle mới dùng Fraction/Decimal tạo 4 khác biệt tại rounding tie so với float v2.3; diagnostic chứng minh scoring cũ và independent float re-grade khớp cả 50. Raw assert Fraction không bị bỏ, đổi expected, skip/XFAIL hoặc ghi lại PASS. Source-freeze kiểm 59 member ở cả năm bản giải nén; không patch.
