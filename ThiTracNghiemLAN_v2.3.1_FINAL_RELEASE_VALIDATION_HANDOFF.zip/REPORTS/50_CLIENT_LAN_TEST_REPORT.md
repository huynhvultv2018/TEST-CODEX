# 50-CLIENT LAN TEST REPORT

50_CLIENT_GATE = PASS. 50_CLIENT_SIMULATION = PASS. 60_CLIENT_HEADROOM = PASS. PHYSICAL_50_PC_LAN = NOT_TESTED.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

SERVER_BIND = 0.0.0.0; PORT = 5000; LAN_ACCESS = PASS qua IP nội bộ 172.26.91.254. Đây là HTTP thread-client simulation trên cloud host, không phải 50 PC/switch thật. Một server active tại một thời điểm, Waitress profile native 12 threads/200 connections. Không sửa bind/source.

Primary: một exam 40 câu, 50 tài khoản khác nhau, 50 snapshot/attempt/session riêng. Mỗi client trả lời/thay đổi nhiều câu, 40 autosaves có jitter nhỏ; burst 50 autosaves và một lượt cập nhật toàn bộ 40 câu. Teacher đọc monitor/report song song. 10/50 clients không gửi traffic >20 giây, native reconnect cùng attempt giữ snapshot/answers; token cũ bị chặn. 50 submit khởi động trong 14.01 ms, peak in-flight 50; không phải tuần tự.

Mixed và deadline dùng exam/50-session test cohorts bổ sung để không finalize sớm primary. Mixed có 10 load/20 autosave/10 reload/10 submit đồng thời, data khớp. Deadline dùng fixture rows rút thời hạn, không monkeypatch clock/source: 15 trước, 15 sát, 20 sau; late POST không lấy đáp án mới, score bằng stored-answer re-grade. HTTP race 8 request trên một attempt có một winner nhất quán; một read-timeout 0,5 ms chủ đích rồi retry không tạo double result.

Primary run lưu đủ 50 submit/answers; tổng hợp bằng rational oracle dừng ở tie precision. Raw failure được giữ. Diagnostic trên tất cả 50 rows: 4 khác biệt với rational arithmetic, 0 khác biệt với v2.3 float, không mất/chồng answers hoặc đổi snapshot. Completion dùng native restore chính test DB vào extraction mới (để tránh sửa/bypass trial state) rồi kiểm 50 result pages, wrong duplicate submits và submitted autosaves: score/answers/finalized rows giữ nguyên. Đây là tiếp tục chứng cứ trên cùng 50 attempts, không thay source/expected gốc hoặc tạo candidate mới.

60 probe sau coverage 50 đầy đủ: 60 session riêng, 40 autosaves/client + burst + 60 submit/result; 19.99 ms dispatch span, peak 60; zero data/score mismatch và DB integrity ok. Không đặt SLO hay suy ra sức chứa tối đa.

Tất cả raw failed/calibration runs cũng được bàn giao; restart raw FAIL do identity môi trường giữ riêng và khiến FINAL_RELEASE_VALIDATION PENDING. Không gọi raw LAN harness suite toàn bộ PASS.
