# 50-CLIENT DATA INTEGRITY REPORT

CROSS_STUDENT_CONTAMINATION = 0. SCORE_MISMATCH_COUNT = 0 theo scoring float v2.3. DB integrity = PASS.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

50 primary expected/stored answers sau autosave và trước submit khớp theo attempt/student. 50 snapshots hash giữ nguyên. Submit burst 50 responses 302, 50 rows finalized; finalized state, stored correct count, question count 40 và độc lập re-grade đều hợp lệ. Completion duplicate wrong POST và autosave 409 không đổi bất kỳ finalized row/answers/score nào. Per-client full snapshots/expected/stored/score ở `lan-completion/50-final-answer-score-comparison.json`; dữ liệu burst và trước submit ở `lan-verified/`.

Arithmetic được giữ đúng contract: v2.3 tính binary float rồi Decimal(str(raw)) half-up. Một row raw float `4.074999999999999` lưu theo arithmetic hiện hành, khác rational ideal ở rounding tie; repr và cả hai điểm chính xác từng row có trong diagnostic. Diagnostic giữ cả hai, không đổi scoring để đạt mathematical ideal. 4 rational disagreements là lỗi lựa chọn oracle cho contract này; v2.3 independent re-grade và candidate re-grade khớp stored score 50/50. Không ghi lại raw assertion Fraction thành PASS.

Mixed workload 50: 40 active/10 finalized đúng expected riêng; deadline 50 giữ saved answers khi muộn, 20 late scores 0; atomic race/retry không inconsistent winner/double result. 60 headroom cũng 60/60 answer/score match.

Final DB: integrity ok, FK check rỗng; explicit orphan student/exam/answer/question, duplicate attempts/answers, wrong answer qid/position, wrong correct flag, missing finalized answer, unexpected SQL NULL, invalid finalized state = 0. 214 attempts/6902 answer rows gồm các cohort test và smoke, không phải 214 người dùng chính thức. Active score NULL/unanswered JSON null là trạng thái được phép.

Test DB và source backups chỉ tồn tại trong vùng test riêng, không commit/đóng gói. Source/archive/schema/scoring nguyên vẹn. Không có production data.
