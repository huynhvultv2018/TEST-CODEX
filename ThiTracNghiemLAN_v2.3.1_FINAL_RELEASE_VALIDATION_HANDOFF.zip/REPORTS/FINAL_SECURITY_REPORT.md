# FINAL SECURITY REPORT

F010 = PASS. F011 = PASS. Token/session isolation = PASS trong simulation. Native restart license limitation được giữ riêng, không bypass.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

F010: 344 valid cases theo oracle độc lập; 36 malformed scorer calls bị `SnapshotValidationError` kiểm soát. HTTP snapshot hỏng: missing answer, zero/NaN points, malformed history, SQLite id overflow, non-list JSON; GET exam/autosave/submit/report/Excel trả 400 và không ghi attempt/answers. Restore semantic-invalid có SQLite integrity ok bị reject trước thay active DB. Dữ liệu hợp lệ và legacy thiếu rule giữ default cũ, không tự sửa payload.

F011: AST inventory đúng 35 POST route; 175 native HTTP probes (missing, wrong, Unicode wrong, valid nonce + foreign Origin, valid nonce + foreign Referer) đều 403, DB không đổi. GET logout 405 không clear session. Valid HTML-field token/admin/import/restore/unlock/API/save/submit/result đều chạy. Token lấy từ HTML/session ứng dụng, không hard-code hoặc disable CSRF.

Chromium 151 dùng cookie thật, foreign same-site/cross-site HTML POST bị 403; forged student POST không finalize; GET logout 405. JSON browser wire chỉ OPTIONS và CORS chặn POST; không dùng preflight làm bằng chứng thay cho HTML CSRF. Probe passive, không intercept request hoặc tắt browser security. Evidence `browser-csrf/`.

50-cookie/nonce/client-token hashes đều unique. Nonce client A + cookie B bị 403; sửa client_token trong signed cookie B thành token A giữ signature cũ bị 403. Client_token là signed-session state, không phải header riêng. 10 cookie cũ sau reconnect/revocation bị 409 với valid CSRF nonce cũ, proving native DB token ownership check. Không share cookie jar.

Evidence không có password, actual cookie/CSRF/client token hoặc signing key. Raw status/timing/state bảo toàn; chỉ default account startup banner và nonce trong HTML được redacted. Test accounts/IDs đều synthetic. Không sửa route/template/cookie policy/license/machine ID hoặc environment configuration.
