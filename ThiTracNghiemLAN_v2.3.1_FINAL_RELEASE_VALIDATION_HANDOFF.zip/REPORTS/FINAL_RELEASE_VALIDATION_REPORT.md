# FINAL RELEASE VALIDATION — ThiTracNghiemLAN v2.3.1

FINAL_RELEASE_VALIDATION = PENDING. 50_CLIENT_GATE = PASS; 50_CLIENT_SIMULATION = PASS; 60_CLIENT_HEADROOM = PASS.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

## Kết luận

Các workflow từ lần khởi động sạch, 5 loại, scoring, F010/F011/F012, R1–R4 required findings, backup/restore và dữ liệu dưới tải đều có bằng chứng đạt. Chưa kết luận sẵn sàng nâng Production: khi restart trên Codex Linux, `uuid.getnode()` trả node ngẫu nhiên khác process trước, nên native license guard từ chối state của máy cũ. Diagnostic bổ sung xác nhận `_uuid` và `ip` có sẵn; getter đầu `_unix_getnode` trả multicast node, còn `_ip_getnode` có giá trị unicast. Đây không phải thiếu package Python đã được bỏ qua. Không reset trial, chọn lại getter, override machine ID hoặc patch nguồn. Cần chứng cứ restart trên máy triển khai có fingerprint ổn định; Windows chưa chạy.

## Phạm vi đã thực hiện

Từ HANDOFF người dùng upload, đọc đúng member candidate 785.622 byte, verify hash trước extract. Tạo source sạch 59 file, chạy entry point `PHAN_MEM/app.py` thật bằng Python, Waitress 12 thread, bind `0.0.0.0:5000`; HTTP qua IP nội bộ `172.26.91.254`, không chỉ loopback. Dependency trong requirements đều có. Không dùng app source từ R1/R2/R3/workspace phát triển.

Native smoke: teacher/student login, question bank/new/edit, matrix/create/build 40 câu (5 loại × 4 mức × 2), autosave, submit/result, UI/Excel report, backup/download, valid/legacy/corrupt/semantic-invalid restore, admin settings/accounts, import preview/confirm, unlock/relogin/retake. Scoring: 344 phép so sánh độc lập và 36 rejection calls; corruption runtime 6 trường hợp × 5 endpoint đều HTTP 400, không ghi dữ liệu.

50 client riêng có cookie/nonce/client_token/attempt riêng. Tải jitter, burst, 10 disconnect thật hơn 20 giây, reconnect giữ câu/answers, mixed 10 load/20 save/10 reload/10 submit, deadline 15 trước/15 gần/20 sau, HTTP atomic race 8 request và một client read-timeout chủ đích/retry. 50 submit bắt đầu trong 14.01 ms, peak 50 request in flight; 50 đáp án/score/snapshot được đọc và đối chiếu. Headroom 60 thực hiện sau khi các bằng chứng bắt buộc của 50 đủ, không thay requirement 50.

## Không che raw failure

R3 nguyên bản 14 PASS/1 FAIL: một kỳ vọng lấy marker bank sửa sau thi trái contract F012. Bản scenario có sẵn trong HANDOFF chuẩn bị marker trước thi, giữ 61 assertion, đạt 15/15. R3 gốc không bị sửa hoặc đổi thành PASS.

Các run của harness mới còn được giữ: một lần startup bị license/environment chặn; một lần sai parser SQLite INTEGER và giả định POST backup trả download; run `lan-verified` dừng tổng hợp score vì oracle phân số chính xác khác phép float v2.3 ở tie. Bốn score có chênh 0,01 với rational oracle; **0 score khác frozen v2.3 khi re-grade độc lập theo đúng arithmetic**. Không sửa scorer hoặc oracle/assertion cũ; cung cấp cả hai phép đối chiếu, và kiểm tiếp result/duplicate qua native restore của test DB. Native restart raw vẫn FAIL, final gate PENDING.

## Giới hạn

PHYSICAL_50_PC_LAN = NOT_TESTED. WINDOWS_RUNTIME = NOT_VERIFIED. Simulation dùng các thread HTTP riêng trên cùng cloud host với server; network latency và CPU không đại diện cho 50 PC/switch thật. Không có SLO tự đặt. Server kiểm thử đã dừng; không nâng Production, không R5/bump version.
