# 50-CLIENT PERFORMANCE REPORT

Số liệu đo thực, không đặt ngưỡng P95/SLO tùy ý. Môi trường cloud host chia sẻ server + client load generators; không phải latency LAN vật lý.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

## Phạm vi đếm

TOTAL_50_CLIENT_REQUESTS = 11298 trên mọi run của cohort 50, gồm 2711 request calibration có raw failure harness và 8587 request của primary/mixed/deadline/retry/completion đã kiểm chứng. 60 probe tách riêng 2760 request. GET nonce/login, POST login và exam load là request riêng. Teacher/setup/security requests tách khỏi tổng 50. Status/timing/client/scope/phase đầy đủ trong combined-request-ledger.json.

FAILED_REQUESTS = 0 theo định nghĩa **unexpected** status/transport outcome. Raw 50 có 104 intentional 4xx và 1 intentional read-timeout; chúng không bị xóa hoặc gọi HTTP 2xx success. `expectation_pass` trong ledger chỉ nghĩa đúng kịch bản. Raw client timeout không phản ánh server timeout/persistent failure; retry finalize đúng.

## Login burst chính thức 50

50 POST login đầu tiên của primary: success 50, unexpected fail 0, distribution `{'302': 50}`. Min 530.06 ms, median 1512.14 ms, P95 2315.96 ms, max 2368.47 ms. CSRF GET và GET exam ghi riêng, không chỉ báo average.

## Các nhóm trong 8587 request cuối

| Nhóm | Requests | Bất thường | Min ms | Median ms | P95 ms | Max ms |
|---|---:|---:|---:|---:|---:|---:|
| LOGIN | 424 | 0 | 3.99 | 205.71 | 2764.52 | 3236.92 |
| LOAD EXAM | 172 | 0 | 5.76 | 1043.49 | 2265.34 | 2540.74 |
| AUTOSAVE | 7599 | 0 | 2.31 | 135.46 | 273.17 | 1264.89 |
| SUBMIT | 60 | 0 | 26.75 | 182.56 | 327.77 | 398.94 |
| RESULT | 100 | 0 | 138.23 | 197.63 | 222.39 | 227.79 |

Không gộp duplicate/deadline/retry vào SUBMIT/AUTOSAVE thường; JSON metrics có từng nhóm riêng và HTTP status distribution. P95 dùng nearest rank `ceil(0.95*n)`; latency từ trước HTTP dispatch tới đọc response/error, gồm queue/network/client overhead; raw không làm tròn, bảng làm tròn 2 chữ số.

HTTP_500_COUNT = 0; HTTP 5xx = 0; persistent DB lock/error = 0. Intentional 403/409 và client timeout được liệt kê. Queue-depth warnings của Waitress dưới burst nếu có được giữ trong server logs, không bị đổi thành DB lock hoặc bịa server timing.

## Resources

Process PID samples mỗi 0,1 giây, psutil CPU/RSS thật. Native smoke + 50 cohorts: 565 samples, CPU peak 229.0%, RSS peak 93.69 MiB. Completion + 60: 144 samples, CPU peak 209.5%, RSS peak 67.76 MiB. CPU % theo process/core, có thể vượt 100%, chưa normalize theo tổng cores. Không gán các peak toàn phase thành metric riêng của từng endpoint. Không đo switch/PC/network RTT vật lý hoặc server-side per-route time.
