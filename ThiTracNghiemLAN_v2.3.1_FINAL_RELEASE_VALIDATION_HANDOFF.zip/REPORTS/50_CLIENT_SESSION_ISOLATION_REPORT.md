# 50-CLIENT SESSION ISOLATION REPORT

SESSION_ISOLATION = PASS. TOKEN_ISOLATION = PASS. CROSS_STUDENT_CONTAMINATION = 0.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

50 synthetic accounts FINAL_50_01..FINAL_50_50 có 50 client objects/cookie jars riêng. Signed cookie hash, CSRF nonce hash và client_token hash mỗi loại có 50 giá trị khác nhau; attempt_id và DB ma_hs đúng mapping. Đề cùng exam có thể cùng question IDs, nhưng snapshot shuffle/state/answers/score được kiểm theo từng attempt. Không dùng chung session để giả lập 50 users.

Nonce A trên cookie B bị 403, DB unchanged. Token A thay vào payload cookie B giữ signature B bị 403, chứng minh không thể forge authenticated session binding; client_token không truyền dưới header tự do. Native reconnect 10 clients sau >20 giây: same attempt/snapshot/answers, new token/session; old signed cookies vẫn có valid CSRF nhưng bị server validation 409, không ghi đè data. Các 40 client còn lại vẫn autosave bình thường.

Result pages sau submit/resume hiển thị đúng synthetic student name/score, không lộ state peer. Duplicate request tests chủ ý clone cookie của chính một client để kiểm retry/race, không biến normal 50 clients thành chung cookie jar.

Evidence: `lan-verified/50-identities-initial.json`, `50-token-negative-probes.json`, `50-disconnect-reconnect.json`, `lan-completion/50-isolated-identities.json`, per-client comparisons/requests. Chỉ lưu token/cookie hashes, không giá trị thật/password/signing key. PHYSICAL_50_PC_LAN = NOT_TESTED; Windows auth/runtime chưa verify.
