# FINAL FINDINGS

FINAL_RELEASE_VALIDATION = PENDING. Source/candidate không được patch.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

| ID | Phân loại | Bằng chứng / tác động |
|---|---|---|
| FV001 | ENVIRONMENT LIMITATION; thiếu readiness evidence | Linux cloud uuid.getnode trả random multicast node; 5 process → 5 fingerprint. Restart cùng data dir bị native license guard chặn login. Không reset state/override HWID. Stable-target/Windows restart cần kiểm; chưa kết luận release-blocking source defect trên target. |
| FV002 | HARNESS ORACLE CONTRACT DIFFERENCE, diagnosed | 4/50 rows khác exact-rational oracle 0,01; independent binary-float v2.3/candidate re-grade khớp stored score 50/50. Raw Fraction assert FAIL giữ nguyên, không sửa scoring/expected cũ. Không phải F002 race/answer inconsistency. |
| FV003 | OBSOLETE TEST EXPECTATION | R3 gốc 14/15, F008 fixture mong bank sửa sau thi xuất hiện trong report. Contract A chính thức khác; scenario giữ 61 assertions, marker trước thi, PASS 15/15. |
| FV004 | HARNESS INFRASTRUCTURE, diagnosed | Lua_chon INTEGER native type và backup-create redirect/download workflow khác giả định harness mới. Raw failed run giữ; decoder/transport được sửa theo contract trước verify, không đổi assertion dữ liệu/score hoặc original suite. |
| FV005 | INFO, observed pre-existing label | /health version 2.2.1, vài banner/script title cũ. Baseline identity theo artifact/hash v2.3.1. Không bump/patch label trong validation. |

F001/F002/F003/F004/F005/F006/F007/F008/F009/F010/F011/F012/F017 required invariants vẫn có bằng chứng PASS. Không phát hiện lost submission, cross-student corruption, frozen-v2.3 wrong score, database corruption, uncontrolled 500, persistent DB lock hoặc security bypass trong simulation. Native restart readiness chưa có evidence PASS, nên không cho phép suy ra Production readiness.

Không sửa finding mới, không R5/v2.4/version bump/Production. Windows/physical LAN là NOT_VERIFIED/NOT_TESTED, không hạ severity hay tự gán PASS.
