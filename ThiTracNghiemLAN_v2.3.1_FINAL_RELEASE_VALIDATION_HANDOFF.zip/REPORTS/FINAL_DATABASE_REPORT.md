# FINAL DATABASE REPORT

Database correctness/integrity = PASS trong test fixtures; không sử dụng production data.

Kiểm chứng 2026-10-02 19:29:32 +07. Baseline SHA-256 `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`. Application source, template, route, schema, scoring và candidate ZIP giữ nguyên. Raw timestamps trong evidence là UTC/Unix epoch.

Native backup POST tạo file và redirect manager, GET download trả SQLite readable. Invalid physical DB và semantically invalid scoring DB bị reject có thông báo, active logical dump không đổi. Legacy DB không rule scoring restore/build/submit score 10; valid DB restore thành công, source backup hashes giữ nguyên. Không tự sửa dữ liệu hỏng. Raw ở `lan-verified/smoke-security-database-history.json`.

F012: native question NB, exam/submit, capture UI/XLSX BEFORE; edit content/mức độ NB→VD/mã/points bằng editor; historical UI và cả bốn sheet values AFTER giữ nguyên, stored attempt không đổi, score 10. Legacy history thiếu hiển thị Không rõ (legacy), score/snapshot giữ nguyên, không backfill. HTML evidence redacts nonce; XLSX giữ nguyên.

Sau stress và completion/headroom: PRAGMA integrity_check = ok, foreign_key_check rỗng. Schema không khai báo FK, nên có kiểm độc lập orphan student/exam/answer/question, duplicate attempt/answer, answer qid/position khớp snapshot, correct flag khớp re-grade, missing answer ở finalized row, unexpected SQL NULL và score/state hợp lệ. 214 attempts, 6902 answer rows; mọi lỗi nêu trên = 0. Active/unanswered states theo contract không bị xem nhầm là corruption.

50 primary và 60 headroom expected answers == stored answers, stored scores == independent frozen-v2.3 float re-grade. 50 snapshots giữ hash sau submit và qua native restore test DB để kiểm tiếp duplicates/result. Temporary DB/backup/credentials không đưa vào handoff/Git. Không sửa schema; SQLite INTEGER affinity của lua_chon được decoder harness xử lý đúng kiểu dữ liệu vốn có.
