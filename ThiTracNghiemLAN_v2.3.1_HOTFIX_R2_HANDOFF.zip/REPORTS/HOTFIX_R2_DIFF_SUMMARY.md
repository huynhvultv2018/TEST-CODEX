# HOTFIX R2 — DIFF SUMMARY

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R1 candidate lấy từ HANDOFF người dùng tải lên.
SHA-256 đầu vào: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202` — MATCH.
Kết luận theo phạm vi được duyệt: **HOTFIX_R2 = PASS**.

## File thay đổi so với R1

| File | Finding | Thay đổi |
|---|---|---|
| PHAN_MEM/app.py | F004 | Helper question_classification; availability dùng helper; sampler legacy snapshot dùng type canonical trong bộ nhớ |
| PHAN_MEM/app.py | F007/F017 | Validator reject force_relogin; result dùng validator và conflict behavior sẵn có |
| PHAN_MEM/app.py | F009 | Validate normalized answer trước UPDATE/commit; invalid trả 400 |
| PHAN_MEM/multi_routes.py | F004 | Sampler áp quy tắc classification chung, canonical snapshot type; mixed-exam validation dùng availability chung |

Diff đầy đủ: `HOTFIX_R2_EVIDENCE/source.diff`.
AST scope: `scope-verification.json` ghi 5 function body thay đổi trong app.py và helper mới; trong install_multi_routes chỉ nested build_exam/mixed_exam thay đổi. Outer function AST khác do chứa hai nested function này.

## Vì sao canonical snapshot type cần thiết

Nếu chỉ chọn được row có question_type viết thường thì snapshot vẫn mang type viết thường; form/grade dispatch theo SINGLE/MULTI/TF/MATCH/FILL sẽ sai. R2 chuẩn hóa bản sao row ở đầu vào snapshot, giữ nguyên row DB và implementation scoring/question_types. Fallback unknown/blank → SINGLE bám đúng availability R1 hiện có.

## Session/token

NULL không tự mang ý nghĩa revoked: `force_relogin=1` là điều kiện thu hồi thực sự. Validator đọc cả flag/token cùng row và được R1 autosave/submit gọi dưới write lock. Khi unlock commit trước request giành khóa, request thấy flag mới; nếu request đã giành khóa/chốt trước unlock, transaction đó hoàn tất trước unlock. Không có ghi sau unlock bằng phiên cũ; relogin reset flag đồng thời token mới.

Không thay đổi login/unlock hay schema. Legacy unrevoked NULL/rỗng vẫn xem/lưu/nộp như trước. Result conflict trả HTTP 200 với trang session_conflict hiện có, không render score; save-answer conflict trả 409. Không redesign authentication.

## Những phần byte-identical

60/62 file, gồm scoring.py, question_types.py, license_core.py, templates, static, 6 test gốc, tài liệu/Windows scripts, Excel mẫu và pyc baseline. Body F001/F002 submit/autosave và representation F003 không đổi.

Candidate SHA-256: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff`.
Manifest từng file: `candidate-manifest.json`; baseline input lock: `baseline-lock.json`.
