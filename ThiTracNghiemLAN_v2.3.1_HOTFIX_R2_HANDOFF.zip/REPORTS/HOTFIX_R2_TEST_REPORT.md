# HOTFIX R2 — TEST REPORT

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R1 candidate lấy từ HANDOFF người dùng tải lên.
SHA-256 đầu vào: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202` — MATCH.
Kết luận theo phạm vi được duyệt: **HOTFIX_R2 = PASS**.

## Tổng quan kết quả thực tế

| Bộ kiểm tra | PASS | FAIL | Ý nghĩa |
|---|---:|---:|---|
| Regression R2 mới chạy trên R1 | 3 | 12 | Cùng harness tái hiện lỗi đầu vào |
| Regression R2 mới chạy trên R2 | 15 | 0 | 4 finding mục tiêu và tương thích |
| Regression R1 nguyên bản trên R2 | 18 | 0 | F001/F002/F003, scoring, snapshot |
| Test gốc | 6 | 0 | kiem_tra_v23/integration/v22/v221/v222/mathjax |
| Audit harness gốc trên R2 | 19 | 2 | FAIL F005/F006 đã có ở R1 |
| Legacy harness gốc trên R2 | 5 | 1 | FAIL F008 đã có ở R1 |
| Race probe gốc | 1 | 0 | Stored score = re-grade = 10 |
| Browser harness gốc | 1 | 0 | 5 dạng, 20 câu, MathJax offline |
| Comma browser R1 nguyên bản | 1 | 0 | Chủ đề dấu phẩy, workflow thật |
| Browser metadata legacy R2 mới | 1 | 0 | Lowercase/whitespace + comma, workflow thật |

Candidate có 70 nhóm kết quả: **67 PASS, 3 FAIL MEDIUM đã biết ngoài phạm vi**. Không chuyển FAIL thành XFAIL/PASS.
`run_original_checks.py` exit 1, `audit_checks.py` exit 1 và `legacy_checks.py` exit 1 vẫn được giữ trong log/JSON vì các FAIL này. 6 test gốc exit 0.

## Regression R2: cùng assertion trên cả hai candidate

| Case | R1 | R2 |
|---|---|---|
| F004_matrix_canonical | PASS | PASS |
| F004_matrix_lowercase | FAIL | PASS |
| F004_matrix_space | FAIL | PASS |
| F004_matrix_unicode_whitespace | FAIL | PASS |
| F004_legacy_blank_unknown_type_fallback | FAIL | PASS |
| F007_result_in_progress_tokens | FAIL | PASS |
| F007_result_submitted_tokens | FAIL | PASS |
| F017_F007_unlock_active_relogin | FAIL | PASS |
| F017_F007_unlock_submitted_retake | FAIL | PASS |
| F017_legacy_NULL_unlock_relogin | FAIL | PASS |
| F007_F017_unrevoked_legacy_NULL_empty_tokens | PASS | PASS |
| F017_queued_autosave_rechecks_unlock_under_lock | FAIL | PASS |
| F017_queued_submit_rechecks_unlock_under_lock | FAIL | PASS |
| F009_invalid_editor_rejects_before_commit | FAIL | PASS |
| F009_valid_ABCD_editor_scoring | PASS | PASS |

Evidence: `focused-r1/results.json`, `focused-r2/results.json` và hai log. SHA harness hai lần chạy khớp. Test fixture legacy chỉ nằm trong DB tạm, không sửa DB/source baseline.

F004 kiểm 5 loại × NB/TH/VD/VDC cho uppercase, lowercase, space và Unicode whitespace. Mỗi cấu hình chạy cả create-exam/mixed-exam, 3 draws/route; kiểm đủ 20 ID khác nhau, type canonical, score 10, legacy sampler, ngân hàng không bị rewrite. Blank/unknown type giữ fallback SINGLE của availability.

F007 kiểm token đúng/sai/thiếu/rỗng khi active/submitted; rejected response không chứa tên học sinh/Điểm/score. Attempt NULL/rỗng chưa revoked vẫn tương thích. Đang thi vẫn xem result theo chính sách cũ.

F017 kiểm unlock active, unlock submitted/retake, legacy NULL, phiên cũ save/submit/result bị từ chối, phiên mới login/save/submit/result bình thường. Hai race dùng Event barrier: teacher đã UPDATE trong transaction chưa commit; old autosave/submit chờ BEGIN IMMEDIATE; teacher commit rồi request đọc lại flag và bị từ chối. Không sleep trong patch hoặc hai regression race mới.

F009 kiểm INVALID, chuỗi rỗng, whitespace, AB, 1, thiếu field: HTTP 400, toàn bộ row trước/sau giống nhau. A/B/C/D và lowercase có space vẫn lưu đáp án đúng, shuffle giữ đáp án đúng, chấm đúng 10 và mọi phương án khác sai.

## Regression R1 và race

`r1-regression/results.json`: 18/18 PASS, gồm expired POST không saved/saved ALL/PARTIAL, GET timeout, boundary 1µs/deadline, writer chờ qua deadline, 8 submit đồng thời cho từng mode, queued autosave, timeout reload, fault rollback/retry và conditional claim thất bại. Comma topic 20-cell và 14 legacy cases đều PASS.

`original-r2/race-probe.json`: hai fast-path đọc submitted_at NULL, hai response 302, một score được chốt, đáp án lưu re-grade 10 khớp score 10.

## Lệnh đã chạy

Chạy từ repository `/workspace/TEST-CODEX`, Python `/workspace/tnlan-audit-venv/bin/python`, PYTHONDONTWRITEBYTECODE=1 cho runner gốc.

```sh
python HOTFIX_R2_EVIDENCE/r2_regression.py --source hotfix-r1-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/focused-r1
python HOTFIX_R2_EVIDENCE/r2_regression.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/focused-r2
python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/r1-regression
python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r2-candidate --output HOTFIX_R2_EVIDENCE/original-r2
python HOTFIX_R1_EVIDENCE/comma_browser.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/comma-browser
python HOTFIX_R2_EVIDENCE/normalized_browser.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/normalized-browser
```

Các harness nguyên bản được lưu byte-identical trong `unchanged-harnesses/`; runner gốc cần context repository với `V2.3.1_AUDIT_EVIDENCE/` như lệnh trên. Không thay đổi assertion, expected result hoặc exception handling của chúng.

## Môi trường và giới hạn

Python 3.12.14, Flask/SQLite và Chromium hệ thống, Waitress loopback cổng tạm. Mỗi suite chạy trên source/LOCALAPPDATA/DB tạm độc lập. Browser không có request ngoài hoặc page error. Các server test đã đóng.
Không triển khai production, không build/test Windows EXE hay LAN vật lý. Kết luận giới hạn ở source/workflow và regressions đã nêu; các finding còn mở không bị hạ severity.
