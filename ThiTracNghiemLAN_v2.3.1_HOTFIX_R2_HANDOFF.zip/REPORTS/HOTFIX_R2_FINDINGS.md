# HOTFIX R2 — FINDINGS

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R1 candidate lấy từ HANDOFF người dùng tải lên.
SHA-256 đầu vào: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202` — MATCH.
Kết luận theo phạm vi được duyệt: **HOTFIX_R2 = PASS**.

## Finding trong phạm vi

| Finding | Severity gốc | Trạng thái R2 | Evidence |
|---|---|---|---|
| F004 | MEDIUM | PASS | 20 cells × 4 metadata variants, 2 create routes, DB không rewrite, browser legacy |
| F007 | MEDIUM | PASS | result tokens active/submitted/unlocked + legacy compatibility |
| F009 | MEDIUM | PASS | invalid HTTP 400 DB unchanged; A/B/C/D vẫn đúng |
| F017 | MEDIUM | PASS | old save/submit/result revoked, new login/retake works, 2 writer-lock races |

F001/F002/F003 HIGH đã sửa R1: regression R2 PASS; không hạ severity gốc.

## Finding còn mở, không xử lý

| Finding | Severity | Trạng thái |
|---|---|---|
| F005 | MEDIUM | OPEN — raw harness vẫn FAIL: clone bỏ khoi_lop |
| F006 | MEDIUM | OPEN — raw harness vẫn FAIL: duration sai định dạng |
| F008 | MEDIUM | OPEN — raw harness vẫn FAIL: Excel formula text |
| F010 | MEDIUM | OPEN — snapshot/scoring hỏng, observations gốc còn nguyên |
| F011 | MEDIUM | OPEN — CSRF chung, không sửa |
| F012 | MEDIUM | OPEN — báo cáo phụ thuộc ngân hàng hiện tại, không sửa |
| F013 | LOW | OPEN — metadata phiên bản |
| F014 | LOW | OPEN — MathJax plain/explicit trong cùng text node |
| F015 | LOW | OPEN — mô tả UI cũ về scoring |
| F016 | INFO | OPEN — dependency/Windows EXE |

Không tìm thấy finding mới qua kiểm tra liên quan R2. Không chạy một vòng audit mới để mở rộng phạm vi; chỉ chạy lại harness/regression có sẵn và probes của 4 finding được yêu cầu.

## Điều kiện PASS

F004/F007/F009/F017 PASS; F001/F002/F003 PASS; 6/6 test gốc PASS; regression liên quan PASS; không có PASS cũ chuyển FAIL; candidate ZIP đóng gói và hash kiểm tra thành công. HOTFIX_R2 = PASS theo phạm vi này; không có kết luận rằng toàn bộ audit sạch finding.

Giữ raw FAIL/exit code ngoài phạm vi trong báo cáo. Không sửa test/harness để che lỗi, không XFAIL, không production/version bump/Round 3.
