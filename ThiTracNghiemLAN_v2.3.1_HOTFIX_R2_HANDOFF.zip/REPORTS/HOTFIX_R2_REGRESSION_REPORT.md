# HOTFIX R2 — REGRESSION REPORT

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R1 candidate lấy từ HANDOFF người dùng tải lên.
SHA-256 đầu vào: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202` — MATCH.
Kết luận theo phạm vi được duyệt: **HOTFIX_R2 = PASS**.

## Invariant sau Round 2

| Invariant | Kết quả | Bằng chứng |
|---|---|---|
| Expired POST chỉ dùng answers đã lưu; POST muộn không tăng điểm | PASS | r1-regression/results.json, 6 case deadline + writer wait |
| Stored answers → re-grade = stored score; attempt chốt một lần | PASS | 8 parallel submits/mode, queued autosave, fault/claim rollback; race-probe.json |
| Chủ đề có dấu phẩy là một chủ đề, build đủ ma trận | PASS | R1 suite + comma-browser/results.json |
| Legacy nb và metadata strip/upper: availability và sampler khớp | PASS | focused-r2/results.json + normalized-browser/results.json |
| Result kiểm attempt token và trạng thái revoked | PASS | valid/wrong/missing/empty tokens active/submitted/unlocked |
| INVALID editor không ghi DB hoặc mặc định A | PASS | 6 invalid inputs/8 valid inputs, row comparison |
| Teacher unlock → old save/submit rejected, relogin hoạt động | PASS | active/submitted/legacy + 2 synchronized writer-lock races |

## Scoring và question types

SINGLE/MULTI/TF/MATCH/FILL được kiểm riêng trong ma trận 20 cells và workflow browser. ALL/PARTIAL, weights 1,3, max_score, score bounds và snapshot scoring được test v23, integration, audit gốc và R1 suite kiểm. Ngân hàng đổi points/mode/weights sau login không đổi score của snapshot: 4.5/10. Source scoring.py/question_types.py byte-identical R1.

Workflow canonical và legacy: LOGIN → BUILD EXAM 20 câu → AUTOSAVE → RELOAD → SUBMIT → RESULT 10/10 → RE-GRADE 10/10. Browser canonical, comma và legacy whitespace/lowercase đều PASS.

## Đối chiếu R1/R2

`regression-comparison.json` so khớp từng tên của 21 audit checks và 6 legacy checks. Không có R1 PASS chuyển thành R2 FAIL.
4 FAIL cũ được sửa đúng phạm vi: legacy_lowercase_level_consistent, result_requires_valid_attempt_token, teacher_unlock_revokes_old_session, legacy_editor_rejects_invalid_answer.

FAIL còn nguyên:
- F006 invalid_duration_handled;
- F005 clone_preserves_grade;
- F008 student_excel_export_keeps_names_as_text.

F010/F011/F012 và LOW/INFO không được sửa; không có kết luận mới rằng các finding này PASS. Probe snapshot/scoring hỏng vẫn ghi nhận như baseline.

## Bảo toàn source

`scope-verification.json`: cùng 62 file, chỉ app.py/multi_routes.py khác, 60 file khác giữ nguyên; schema hai lần chạy R1/R2 giống nhau. Body exam/save_answer/unlock_attempt/student_login/exam_topics/init_db không thay đổi. F017 tận dụng transaction authoritative check sẵn có của R1.
Test gốc, templates/static và phiên bản không đổi. Không có migration/rewrite dữ liệu legacy. 4 pyc baseline giữ nguyên; không thêm file runtime vào source ZIP.

## Kết luận

Không phát hiện regression mới trong các kiểm tra bắt buộc. F001/F002/F003 và F004/F007/F009/F017 PASS. Các FAIL ngoài phạm vi vẫn được giữ nguyên trong kết quả thực tế.
