# HOTFIX R2 — CHANGELOG

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R1 candidate lấy từ HANDOFF người dùng tải lên.
SHA-256 đầu vào: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202` — MATCH.
Kết luận theo phạm vi được duyệt: **HOTFIX_R2 = PASS**.

## Thay đổi

| Finding | Patch trực tiếp | Kết quả |
|---|---|---|
| F004 — MEDIUM | `question_classification()` dùng cùng strip/upper và fallback SINGLE trong availability, sampler và type của snapshot. Sampler lọc metadata bằng quy tắc Python này; validation route mixed-exam dùng availability chung. | PASS |
| F007 — MEDIUM | `/result` gọi `validate_attempt_session()` trước khi đọc/render kết quả; sai token hoặc attempt bị thu hồi trả trang session_conflict và xóa attempt/token khỏi session. | PASS |
| F009 — MEDIUM | Legacy editor chuẩn hóa đáp án một lần; đáp án không thuộc A/B/C/D trả HTTP 400 trước UPDATE/commit. | PASS |
| F017 — MEDIUM | Validator từ chối `force_relogin=1`, kể cả DB token NULL. Unlock hiện có đặt flag này; autosave/submit R1 kiểm tra lại validator dưới BEGIN IMMEDIATE. | PASS |

## Tương thích

- Token NULL/rỗng với `force_relogin=0` giữ semantics attempt legacy hiện tại. Token NULL với `force_relogin=1` là revoked; không được autosave/submit/result.
- Token khác NULL/rỗng phải khớp session. Login mới dùng token mới, reset force_relogin; login hợp lệ để xem kết quả submitted vẫn hoạt động. Unlock bài submitted giữ cơ chế retake hiện có.
- Mức độ/loại legacy được chuẩn hóa trong bộ nhớ; không UPDATE dữ liệu ngân hàng hay migration schema. Whitespace Python strip gồm space/tab/newline/NBSP/em-space.
- ALL/PARTIAL, weights, max_score và snapshot scoring giữ nguyên. Metadata chủ đề dấu phẩy R1 giữ nguyên.

## Phạm vi source

Chỉ sửa `PHAN_MEM/app.py` và `PHAN_MEM/multi_routes.py`; 60/62 file còn lại byte-identical với baseline R1.
Không sửa UI, scoring.py, question_types.py, test gốc hay harness R1. Không bump version/production.
Body của `exam`, `save_answer`, `unlock_attempt`, `student_login`, `exam_topics`, init_db giữ nguyên; validator chung được sửa trực tiếp theo F017/F007.

## Candidate

`ThiTracNghiemLAN_v2.3.1_HOTFIX_R2_CANDIDATE.zip` — 862,765 byte, 62 file.
SHA-256: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff`.
Không chứa ZIP baseline lồng; không có file runtime/cache mới. 4 pyc có sẵn từ baseline R1 được giữ nguyên, không xử lý cleanup ngoài phạm vi.
R1 candidate/ZIP/reports/checksum giữ nguyên. Checksum R2 riêng tại `HOTFIX_R2_HANDOFF_CONTENTS/CHECKSUMS.sha256` và trong HANDOFF, dùng đúng đường dẫn bên trong gói.

## Điểm dừng

Không xử lý F005/F006/F008/F010/F011/F012/LOW/INFO. Chỉ commit/push riêng HANDOFF nếu được phép rồi dừng chờ người dùng kiểm chứng.
