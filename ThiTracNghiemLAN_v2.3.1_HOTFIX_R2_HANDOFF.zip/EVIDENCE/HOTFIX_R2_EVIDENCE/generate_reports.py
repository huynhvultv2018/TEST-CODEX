"""Generate R2 reports from recorded evidence, without modifying application source."""
import json,platform,sys
from pathlib import Path

r=Path(__file__).resolve().parents[1];e=r/'HOTFIX_R2_EVIDENCE'
read=lambda n:json.loads((e/n).read_text())
status=read('final-status.json');candidate=read('candidate-manifest.json');scope=read('scope-verification.json')
assert status['HOTFIX_R2']=='PASS'
header="""# {title}

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R1 candidate lấy từ HANDOFF người dùng tải lên.
SHA-256 đầu vào: `9341117414928c4062370a77e60775d996b5a05943b6c344d540c928be064202` — MATCH.
Kết luận theo phạm vi được duyệt: **HOTFIX_R2 = PASS**.

"""
def write(name,title,body):
    p=r/name;assert not p.exists();p.write_text(header.format(title=title)+body,encoding='utf-8')

write('HOTFIX_R2_CHANGELOG.md','HOTFIX R2 — CHANGELOG',f"""## Thay đổi

| Finding | Patch trực tiếp | Kết quả |
|---|---|---|
| F004 — MEDIUM | `question_classification()` dùng cùng strip/upper và fallback SINGLE trong availability, sampler và type của snapshot. Sampler lọc metadata bằng quy tắc Python này; validation route mixed-exam dùng availability chung. | PASS |
| F007 — MEDIUM | `/result` gọi `validate_attempt_session()` trước khi đọc/render kết quả; sai token hoặc attempt bị thu hồi trả trang session_conflict và xóa attempt/token khỏi session. | PASS |
| F009 — MEDIUM | Legacy editor chuẩn hóa đáp án một lần; đáp án không thuộc A/B/C/D trả HTTP 400 trước UPDATE/commit. | PASS |
| F017 — MEDIUM | Validator từ chối `force_relogin=1`, kể cả DB token NULL. Unlock hiện có đặt flag này; autosave/submit R1 kiểm tra lại validator dưới BEGIN IMMEDIATE. | PASS |

## Tương thích

- Token NULL/rỗng với `force_relogin=0` giữ semantics attempt legacy hiện tại. Token NULL với `force_relogin=1` là revoked; không được autosave/submit/result.
- Token khác NULL/rỗng phải khớp session. Login mới dùng token mới, reset force_relogin; login hợp lệ để xem kết quả submitted vẫn hoạt động. Unlock bài submitted giữ cơ chế retake hiện có.
- Mức độ/loại legacy được chuẩn hóa trong bộ nhớ; không UPDATE dữ liệu ngân hàng hay migration schema. Whitespace Python strip gồm space/tab/newline/NBSP/em-space.
- ALL/PARTIAL, weights, max_score và snapshot scoring giữ nguyên. Metadata chủ đề dấu phẩy R1 giữ nguyên.

## Phạm vi source

Chỉ sửa `PHAN_MEM/app.py` và `PHAN_MEM/multi_routes.py`; 60/62 file còn lại byte-identical với baseline R1.
Không sửa UI, scoring.py, question_types.py, test gốc hay harness R1. Không bump version/production.
Body của `exam`, `save_answer`, `unlock_attempt`, `student_login`, `exam_topics`, init_db giữ nguyên; validator chung được sửa trực tiếp theo F017/F007.

## Candidate

`{candidate['zip']}` — {candidate['zip_bytes']:,} byte, 62 file.
SHA-256: `{candidate['zip_sha256']}`.
Không chứa ZIP baseline lồng; không có file runtime/cache mới. 4 pyc có sẵn từ baseline R1 được giữ nguyên, không xử lý cleanup ngoài phạm vi.
R1 candidate/ZIP/reports/checksum giữ nguyên. Checksum R2 riêng tại `HOTFIX_R2_HANDOFF_CONTENTS/CHECKSUMS.sha256` và trong HANDOFF, dùng đúng đường dẫn bên trong gói.

## Điểm dừng

Không xử lý F005/F006/F008/F010/F011/F012/LOW/INFO. Chỉ commit/push riêng HANDOFF nếu được phép rồi dừng chờ người dùng kiểm chứng.
""")

new=read('focused-r2/results.json')['results'];old=read('focused-r1/results.json')['results'];r1=read('r1-regression/results.json')['results']
table='\n'.join(f"| {a['name']} | {b['status']} | {a['status']} |" for a,b in zip(new,old))
assert [x['name'] for x in new]==[x['name'] for x in old]
write('HOTFIX_R2_TEST_REPORT.md','HOTFIX R2 — TEST REPORT',f"""## Tổng quan kết quả thực tế

| Bộ kiểm tra | PASS | FAIL | Ý nghĩa |
|---|---:|---:|---|
| Regression R2 mới chạy trên R1 | 3 | 12 | Cùng harness tái hiện lỗi đầu vào |
| Regression R2 mới chạy trên R2 | 15 | 0 | 4 finding mục tiêu và tương thích |
| Regression R1 nguyên bản trên R2 | 18 | 0 | F001/F002/F003, scoring, snapshot |
| Test gốc | 6 | 0 | kiem_tra_v23/integration/v22/v221/v222/mathjax |
| Audit harness gốc trên R2 | 19 | 2 | FAIL F005/F006 đã có ở R1 |
| Legacy harness gốc trên R2 | 5 | 1 | FAIL F008 đã có ở R1 |
| Race probe gốc | 1 | 0 | Stored score = re-grade = 10 |
| Browser harness gốc | 1 | 0 | 5 dạng, 20 câu, MathJax offline |
| Comma browser R1 nguyên bản | 1 | 0 | Chủ đề dấu phẩy, workflow thật |
| Browser metadata legacy R2 mới | 1 | 0 | Lowercase/whitespace + comma, workflow thật |

Candidate có 70 nhóm kết quả: **67 PASS, 3 FAIL MEDIUM đã biết ngoài phạm vi**. Không chuyển FAIL thành XFAIL/PASS.
`run_original_checks.py` exit 1, `audit_checks.py` exit 1 và `legacy_checks.py` exit 1 vẫn được giữ trong log/JSON vì các FAIL này. 6 test gốc exit 0.

## Regression R2: cùng assertion trên cả hai candidate

| Case | R1 | R2 |
|---|---|---|
{table}

Evidence: `focused-r1/results.json`, `focused-r2/results.json` và hai log. SHA harness hai lần chạy khớp. Test fixture legacy chỉ nằm trong DB tạm, không sửa DB/source baseline.

F004 kiểm 5 loại × NB/TH/VD/VDC cho uppercase, lowercase, space và Unicode whitespace. Mỗi cấu hình chạy cả create-exam/mixed-exam, 3 draws/route; kiểm đủ 20 ID khác nhau, type canonical, score 10, legacy sampler, ngân hàng không bị rewrite. Blank/unknown type giữ fallback SINGLE của availability.

F007 kiểm token đúng/sai/thiếu/rỗng khi active/submitted; rejected response không chứa tên học sinh/Điểm/score. Attempt NULL/rỗng chưa revoked vẫn tương thích. Đang thi vẫn xem result theo chính sách cũ.

F017 kiểm unlock active, unlock submitted/retake, legacy NULL, phiên cũ save/submit/result bị từ chối, phiên mới login/save/submit/result bình thường. Hai race dùng Event barrier: teacher đã UPDATE trong transaction chưa commit; old autosave/submit chờ BEGIN IMMEDIATE; teacher commit rồi request đọc lại flag và bị từ chối. Không sleep trong patch hoặc hai regression race mới.

F009 kiểm INVALID, chuỗi rỗng, whitespace, AB, 1, thiếu field: HTTP 400, toàn bộ row trước/sau giống nhau. A/B/C/D và lowercase có space vẫn lưu đáp án đúng, shuffle giữ đáp án đúng, chấm đúng 10 và mọi phương án khác sai.

## Regression R1 và race

`r1-regression/results.json`: 18/18 PASS, gồm expired POST không saved/saved ALL/PARTIAL, GET timeout, boundary 1µs/deadline, writer chờ qua deadline, 8 submit đồng thời cho từng mode, queued autosave, timeout reload, fault rollback/retry và conditional claim thất bại. Comma topic 20-cell và 14 legacy cases đều PASS.

`original-r2/race-probe.json`: hai fast-path đọc submitted_at NULL, hai response 302, một score được chốt, đáp án lưu re-grade 10 khớp score 10.

## Lệnh đã chạy

Chạy từ repository `/workspace/TEST-CODEX`, Python `/workspace/tnlan-audit-venv/bin/python`, PYTHONDONTWRITEBYTECODE=1 cho runner gốc.

```sh
python HOTFIX_R2_EVIDENCE/r2_regression.py --source hotfix-r1-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/focused-r1
python HOTFIX_R2_EVIDENCE/r2_regression.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/focused-r2
python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/r1-regression
python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r2-candidate --output HOTFIX_R2_EVIDENCE/original-r2
python HOTFIX_R1_EVIDENCE/comma_browser.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/comma-browser
python HOTFIX_R2_EVIDENCE/normalized_browser.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R2_EVIDENCE/normalized-browser
```

Các harness nguyên bản được lưu byte-identical trong `unchanged-harnesses/`; runner gốc cần context repository với `V2.3.1_AUDIT_EVIDENCE/` như lệnh trên. Không thay đổi assertion, expected result hoặc exception handling của chúng.

## Môi trường và giới hạn

Python {platform.python_version()}, Flask/SQLite và Chromium hệ thống, Waitress loopback cổng tạm. Mỗi suite chạy trên source/LOCALAPPDATA/DB tạm độc lập. Browser không có request ngoài hoặc page error. Các server test đã đóng.
Không triển khai production, không build/test Windows EXE hay LAN vật lý. Kết luận giới hạn ở source/workflow và regressions đã nêu; các finding còn mở không bị hạ severity.
""")

write('HOTFIX_R2_REGRESSION_REPORT.md','HOTFIX R2 — REGRESSION REPORT',"""## Invariant sau Round 2

| Invariant | Kết quả | Bằng chứng |
|---|---|---|
| Expired POST chỉ dùng answers đã lưu; POST muộn không tăng điểm | PASS | r1-regression/results.json, 6 case deadline + writer wait |
| Stored answers → re-grade = stored score; attempt chốt một lần | PASS | 8 parallel submits/mode, queued autosave, fault/claim rollback; race-probe.json |
| Chủ đề có dấu phẩy là một chủ đề, build đủ ma trận | PASS | R1 suite + comma-browser/results.json |
| Legacy nb và metadata strip/upper: availability và sampler khớp | PASS | focused-r2/results.json + normalized-browser/results.json |
| Result kiểm attempt token và trạng thái revoked | PASS | valid/wrong/missing/empty tokens active/submitted/unlocked |
| INVALID editor không ghi DB hoặc mặc định A | PASS | 6 invalid inputs/8 valid inputs, row comparison |
| Teacher unlock → old save/submit rejected, relogin hoạt động | PASS | active/submitted/legacy + 2 synchronized writer-lock races |

## Scoring và question types

SINGLE/MULTI/TF/MATCH/FILL được kiểm riêng trong ma trận 20 cells và workflow browser. ALL/PARTIAL, weights 1,3, max_score, score bounds và snapshot scoring được test v23, integration, audit gốc và R1 suite kiểm. Ngân hàng đổi points/mode/weights sau login không đổi score của snapshot: 4.5/10. Source scoring.py/question_types.py byte-identical R1.

Workflow canonical và legacy: LOGIN → BUILD EXAM 20 câu → AUTOSAVE → RELOAD → SUBMIT → RESULT 10/10 → RE-GRADE 10/10. Browser canonical, comma và legacy whitespace/lowercase đều PASS.

## Đối chiếu R1/R2

`regression-comparison.json` so khớp từng tên của 21 audit checks và 6 legacy checks. Không có R1 PASS chuyển thành R2 FAIL.
4 FAIL cũ được sửa đúng phạm vi: legacy_lowercase_level_consistent, result_requires_valid_attempt_token, teacher_unlock_revokes_old_session, legacy_editor_rejects_invalid_answer.

FAIL còn nguyên:
- F006 invalid_duration_handled;
- F005 clone_preserves_grade;
- F008 student_excel_export_keeps_names_as_text.

F010/F011/F012 và LOW/INFO không được sửa; không có kết luận mới rằng các finding này PASS. Probe snapshot/scoring hỏng vẫn ghi nhận như baseline.

## Bảo toàn source

`scope-verification.json`: cùng 62 file, chỉ app.py/multi_routes.py khác, 60 file khác giữ nguyên; schema hai lần chạy R1/R2 giống nhau. Body exam/save_answer/unlock_attempt/student_login/exam_topics/init_db không thay đổi. F017 tận dụng transaction authoritative check sẵn có của R1.
Test gốc, templates/static và phiên bản không đổi. Không có migration/rewrite dữ liệu legacy. 4 pyc baseline giữ nguyên; không thêm file runtime vào source ZIP.

## Kết luận

Không phát hiện regression mới trong các kiểm tra bắt buộc. F001/F002/F003 và F004/F007/F009/F017 PASS. Các FAIL ngoài phạm vi vẫn được giữ nguyên trong kết quả thực tế.
""")

write('HOTFIX_R2_DIFF_SUMMARY.md','HOTFIX R2 — DIFF SUMMARY',f"""## File thay đổi so với R1

| File | Finding | Thay đổi |
|---|---|---|
| PHAN_MEM/app.py | F004 | Helper question_classification; availability dùng helper; sampler legacy snapshot dùng type canonical trong bộ nhớ |
| PHAN_MEM/app.py | F007/F017 | Validator reject force_relogin; result dùng validator và conflict behavior sẵn có |
| PHAN_MEM/app.py | F009 | Validate normalized answer trước UPDATE/commit; invalid trả 400 |
| PHAN_MEM/multi_routes.py | F004 | Sampler áp quy tắc classification chung, canonical snapshot type; mixed-exam validation dùng availability chung |

Diff đầy đủ: `HOTFIX_R2_EVIDENCE/source.diff`.
AST scope: `scope-verification.json` ghi 5 function body thay đổi trong app.py và helper mới; trong install_multi_routes chỉ nested build_exam/mixed_exam thay đổi. Outer function AST khác do chứa hai nested function này.

## Vì sao canonical snapshot type cần thiết

Nếu chỉ chọn được row có question_type viết thường thì snapshot vẫn mang type viết thường; form/grade dispatch theo SINGLE/MULTI/TF/MATCH/FILL sẽ sai. R2 chuẩn hóa bản sao row ở đầu vào snapshot, giữ nguyên row DB và implementation scoring/question_types. Fallback unknown/blank → SINGLE bám đúng availability R1 hiện có.

## Session/token

NULL không tự mang ý nghĩa revoked: `force_relogin=1` là điều kiện thu hồi thực sự. Validator đọc cả flag/token cùng row và được R1 autosave/submit gọi dưới write lock. Khi unlock commit trước request giành khóa, request thấy flag mới; nếu request đã giành khóa/chốt trước unlock, transaction đó hoàn tất trước unlock. Không có ghi sau unlock bằng phiên cũ; relogin reset flag đồng thời token mới.

Không thay đổi login/unlock hay schema. Legacy unrevoked NULL/rỗng vẫn xem/lưu/nộp như trước. Result conflict trả HTTP 200 với trang session_conflict hiện có, không render score; save-answer conflict trả 409. Không redesign authentication.

## Những phần byte-identical

60/62 file, gồm scoring.py, question_types.py, license_core.py, templates, static, 6 test gốc, tài liệu/Windows scripts, Excel mẫu và pyc baseline. Body F001/F002 submit/autosave và representation F003 không đổi.

Candidate SHA-256: `{candidate['zip_sha256']}`.
Manifest từng file: `candidate-manifest.json`; baseline input lock: `baseline-lock.json`.
""")

write('HOTFIX_R2_FINDINGS.md','HOTFIX R2 — FINDINGS',"""## Finding trong phạm vi

| Finding | Severity gốc | Trạng thái R2 | Evidence |
|---|---|---|---|
| F004 | MEDIUM | PASS | 20 cells × 4 metadata variants, 2 create routes, DB không rewrite, browser legacy |
| F007 | MEDIUM | PASS | result tokens active/submitted/unlocked + legacy compatibility |
| F009 | MEDIUM | PASS | invalid HTTP 400 DB unchanged; A/B/C/D vẫn đúng |
| F017 | MEDIUM | PASS | old save/submit/result revoked, new login/retake works, 2 writer-lock races |

F001/F002/F003 HIGH đã sửa R1: regression R2 PASS; không hạ severity gốc.

## Finding còn mở, không xử lý

| Finding | Severity | Trạng thái |
|---|---|---|
| F005 | MEDIUM | OPEN — raw harness vẫn FAIL: clone bỏ khoi_lop |
| F006 | MEDIUM | OPEN — raw harness vẫn FAIL: duration sai định dạng |
| F008 | MEDIUM | OPEN — raw harness vẫn FAIL: Excel formula text |
| F010 | MEDIUM | OPEN — snapshot/scoring hỏng, observations gốc còn nguyên |
| F011 | MEDIUM | OPEN — CSRF chung, không sửa |
| F012 | MEDIUM | OPEN — báo cáo phụ thuộc ngân hàng hiện tại, không sửa |
| F013 | LOW | OPEN — metadata phiên bản |
| F014 | LOW | OPEN — MathJax plain/explicit trong cùng text node |
| F015 | LOW | OPEN — mô tả UI cũ về scoring |
| F016 | INFO | OPEN — dependency/Windows EXE |

Không tìm thấy finding mới qua kiểm tra liên quan R2. Không chạy một vòng audit mới để mở rộng phạm vi; chỉ chạy lại harness/regression có sẵn và probes của 4 finding được yêu cầu.

## Điều kiện PASS

F004/F007/F009/F017 PASS; F001/F002/F003 PASS; 6/6 test gốc PASS; regression liên quan PASS; không có PASS cũ chuyển FAIL; candidate ZIP đóng gói và hash kiểm tra thành công. HOTFIX_R2 = PASS theo phạm vi này; không có kết luận rằng toàn bộ audit sạch finding.

Giữ raw FAIL/exit code ngoài phạm vi trong báo cáo. Không sửa test/harness để che lỗi, không XFAIL, không production/version bump/Round 3.
""")

print('Generated 5 R2 reports from evidence; existing R1 reports unchanged.')
