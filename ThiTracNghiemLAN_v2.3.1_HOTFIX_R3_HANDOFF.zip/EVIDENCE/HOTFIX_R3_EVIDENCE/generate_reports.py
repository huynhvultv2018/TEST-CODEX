"""R3 reports from preserved results; no application source changes."""
import json,platform
from pathlib import Path
r=Path(__file__).resolve().parents[1];e=r/'HOTFIX_R3_EVIDENCE'
read=lambda n:json.loads((e/n).read_text())
status=read('final-status.json');candidate=read('candidate-manifest.json');assert status['HOTFIX_R3']=='PASS'
intro="""# {title}

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R2 candidate bên trong HANDOFF người dùng gửi.
SHA-256 bắt buộc: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff` — MATCH trước patch.
Kết luận theo phạm vi yêu cầu: **HOTFIX_R3 = PASS**.

"""
def write(name,title,body):
 p=r/name;assert not p.exists();p.write_text(intro.format(title=title)+body,encoding='utf-8')

write('HOTFIX_R3_CHANGELOG.md','HOTFIX R3 — CHANGELOG',f"""## Patch trực tiếp

| Finding | Severity gốc | Thay đổi | Kết quả |
|---|---|---|---|
| F005 | MEDIUM | Clone INSERT thêm khoi_lop lấy nguyên giá trị từ row nguồn | PASS |
| F006 | MEDIUM | exam_integer dùng chung cho duration/counts ở create-exam và mixed-exam; reject thay coercion/clamp | PASS |
| F008 | MEDIUM | excel_text_cells chỉ áp vào trường text người dùng của 4 export được chỉ định | PASS |

## F005

Grade nguồn giữ nguyên, không suy luận hoặc gọi init_db để sửa clone. Source row, mon/chu_de/muc_do, question_type và payload/scoring giữ nguyên. ID mới và suffix _COPY giữ semantics cũ. Regression kiểm 6/7/8/9 × 5 types × ALL/PARTIAL (40 case), cùng legacy grade blank/space và ma_cau rỗng.

## F006

Duration phải là số nguyên 1–180 phút; count phải là số nguyên >=0. Strip whitespace ngoài chuỗi, chấp nhận dấu +/-, chữ số decimal và leading zero như int hợp lệ; giá trị toán học -0 vẫn là 0. Decimal float, exponent, underscore, khoảng trắng bên trong, chuỗi rỗng/nonnumeric đều bị reject. Giá trị quá lớn không parse được bị reject bằng ValueError hẹp.

Field thiếu giữ default duration 15/count 0 cho tương thích biểu mẫu; field được gửi rỗng không dùng default âm thầm. Không clamp duration ngoài miền; không đổi count sai/âm thành 0. Tổng 0 và shortage vẫn bị từ chối theo quy tắc cũ, không đổi matrix 5×4 hay chính sách tổng.

Thông báo dùng flash sẵn có, gồm tên field/ô. Main route redirect /teacher; route mixed render trang cảnh báo như trước. Chưa validate xong không INSERT/commit kỳ thi. Route legacy nb_count/th_count/vd_count/vdc_count dùng cùng helper.

## F008

User-controlled strings bắt đầu =/+/-/@ được ghi data_type s tại các ô được chọn. Giá trị hiển thị giữ nguyên, không thêm apostrophe. Giữ numeric thực, score, ngày/giờ và ô formula hệ thống ở cột khác.

- export_students: 3 cột text của học sinh;
- export_questions legacy: 11 cột text của câu hỏi;
- export_exam_report: summary B2/B3/B4, 5 cột text học sinh, 5 cột text phân tích câu hỏi;
- export_results: tên kỳ thi/mã/tên/lớp/thời gian; bỏ nguyên các cột STT/count/score;
- multi Excel và points export vốn đã có guard an toàn, không sửa; kiểm lại TEXT/numeric/weights.

## Bảo toàn

Chỉ PHAN_MEM/app.py và PHAN_MEM/multi_routes.py thay đổi, 60/62 file khác byte-identical R2. Không sửa UI, schema, scoring.py, question_types.py, authentication, body F001/F002/F003/F004/F007/F009/F017.
Không xử lý F010/F011/F012/F013/F014/F015/F016, không version bump, Round 4 hoặc production.
R1/R2 ZIP/source/reports/checksum nguyên vẹn, hash được kiểm lại.

## Artifact

Candidate: `{candidate['zip']}` — {candidate['zip_bytes']:,} byte, 62 file.
SHA-256: `{candidate['zip_sha256']}`.
4 pyc kế thừa baseline được giữ nguyên; không thêm runtime/cache/ZIP lồng. CHECKSUMS R3 riêng trong `HOTFIX_R3_HANDOFF_CONTENTS/CHECKSUMS.sha256` và HANDOFF, đường dẫn khớp bố cục gói; không ghi đè checksum R1/R2.
""")

final=read('final-focused-r3/results.json')['results'];before=read('final-focused-r2/results.json')['results'];assert [x['name'] for x in final]==[x['name'] for x in before]
table='\n'.join(f"| {a['name']} | {b['status']} | {a['status']} |" for a,b in zip(final,before))
write('HOTFIX_R3_TEST_REPORT.md','HOTFIX R3 — TEST REPORT',f"""## Kết quả cuối cùng

| Suite | PASS | FAIL |
|---|---:|---:|
| Cùng regression R3 chạy trên baseline R2 | 3 | 12 |
| Regression R3 hoàn chỉnh trên R3 | 15 | 0 |
| R1 regression nguyên bản trên R3 | 18 | 0 |
| R2 regression nguyên bản trên R3 | 15 | 0 |
| 6 test gốc | 6 | 0 |
| Audit harness gốc | 21 | 0 |
| Legacy harness gốc | 6 | 0 |
| Race probe gốc | 1 | 0 |
| Browser harness gốc | 1 | 0 |
| Browser comma R1 nguyên bản | 1 | 0 |
| Browser normalized legacy R2 nguyên bản | 1 | 0 |

85/85 nhóm kiểm tra candidate cuối cùng PASS. Runner/harness gốc đều exit 0; không XFAIL/skip/đổi expected result. Không có PASS R2 chuyển thành FAIL.

## R3 case đối chiếu

| Case | R2 | R3 |
|---|---|---|
{table}

Hai run final-focused dùng cùng hash harness. R2 FAIL với clone mất grade, invalid time/count, Excel text thành f; R3 PASS. Baseline vẫn PASS với valid inputs và 2 related exports đã có guard.

## Coverage F005

40 clone: 4 grades × 5 types × 2 scoring modes; so toàn bộ row ngoài ID/ma_cau, payload byte-identical, source unchanged, correct shuffled snapshot score 10. 6 legacy metadata cases giữ exact grade gồm blank/' 8 ', ma_cau rỗng, không init_db lại.

## Coverage F006

- 11 invalid durations × 2 routes: abc, rỗng, whitespace, 0, -1, 181, 1.5, 1e2, 1_0, NaN, 5000 decimal digits;
- 7 invalid count representations × 20 cells × 2 routes = 280 requests;
- 5 invalid representations × 4 legacy count fields = 20 requests;
- mọi rejection: HTTP không 500, bảng ky_thi trước/sau giống nhau, thông báo chỉ rõ field/ô;
- valid durations 1/180/15/whitespace/+ và omitted default; count +1/00/-0/omitted; đủ số câu build; tổng 0 và shortage vẫn reject; legacy SINGLE counts hợp lệ vẫn tạo/build.

322 request invalid có bằng chứng trong JSON final-focused-r3; không gọi DB migration hoặc update để che validation.

## Coverage F008

5 harmless markers: =1+1, +test, -test, @test, Tên bình thường. Dùng load_workbook(data_only=False) để kiểm data_type s và value chính xác. Kiểm students, 11 cột câu legacy, summary/student/question sheets, results, points, multi questions. Các XLSX response được giữ nguyên trong evidence.
Report fixtures có workflow thực create → login → autosave → submit → result, 5 types, PARTIAL/weights/max_score, stored/re-grade 4.5/10. Export giữ count/score numeric và timestamps y hệt DB. Points sum 4.5 khớp stored score.
Helper boundary giữ numeric -7.25, datetime và system formula =SUM(1,1) ở ô khác. Không thay toàn workbook thành text.

## Lần chạy đầu của harness R3 mới

`focused-r3/results.json` ghi 13 PASS/2 FAIL và exit 1; kết quả không bị xóa hoặc đổi trạng thái. Hai FAIL là lỗi instrumentation do harness mới đọc _flashes trong session sau khi mixed-exam render/consume flash. Template cũ hiển thị warning trong response HTTP 200. Main redirect giữ flash đến GET.
`r3_regression.py` ban đầu giữ nguyên. `r3_regression_ui_observer.py` quan sát warning thực trong HTML cho response render, flash session cho response redirect; giữ tất cả invariant/status/DB/message-field assertions. Không thay source để khớp test, không sửa test/harness cũ R1/R2. Giải thích/diff hành vi quan sát tại NEW_HARNESS_OBSERVATION.md; final-focused là bằng chứng hoàn chỉnh theo cơ chế hiện có.
Không có test gốc/R1/R2 bị sai; quy tắc dừng khi test cũ sai không được kích hoạt.

## Lệnh và reproducibility

Từ `/workspace/TEST-CODEX`, Python `/workspace/tnlan-audit-venv/bin/python`:

```sh
python HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/final-focused-r2
python HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/final-focused-r3
python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/r1-regression
python HOTFIX_R2_EVIDENCE/r2_regression.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/r2-regression
python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r3-candidate --output HOTFIX_R3_EVIDENCE/original-r3
python HOTFIX_R1_EVIDENCE/comma_browser.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/comma-browser
python HOTFIX_R2_EVIDENCE/normalized_browser.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/normalized-browser
```

Các harness trước được lưu byte-identical trong unchanged-harnesses/ cùng recorded hashes. Runner gốc dùng context repository V2.3.1_AUDIT_EVIDENCE và tên directory baseline-v2.3.1 trong staging tạm; source bên trong staging là R3, không dùng baseline gốc để chạy.

## Môi trường/giới hạn

Python {platform.python_version()}, Flask/SQLite, Waitress loopback, Chromium hệ thống. Mọi DB/source/LOCALAPPDATA runtime dùng copy tạm riêng. Browser không external requests/page errors, server đã đóng. Không Windows EXE, LAN vật lý hoặc production. Test source/workflow đã nêu, không kết luận F010–F016 được giải quyết.
""")

write('HOTFIX_R3_REGRESSION_REPORT.md','HOTFIX R3 — REGRESSION REPORT',"""## Invariant

| Finding | Invariant | Kết quả |
|---|---|---|
| F005 | Clone giữ nguyên khoi_lop/payload/scoring/type; source không đổi | PASS |
| F006 | Invalid time → no 500/no exam; invalid count → reject/no silent coercion | PASS |
| F008 | User text =/+/-/@ → exact value/text, numeric/time/system formula nguyên vẹn | PASS |
| F001 | Expired POST không nhận fresh answers, dùng saved theo deadline server | PASS |
| F002 | Concurrent submit single writer, stored answers re-grade = stored score | PASS |
| F003 | Comma topic round-trip/build đủ 20 cells, old representation tương thích | PASS |
| F004 | Lowercase/whitespace availability = sampler, 5×4 đủ câu | PASS |
| F007 | Result chỉ hiện cho attempt session hợp lệ; legacy policy giữ nguyên | PASS |
| F009 | INVALID legacy editor HTTP 400/DB unchanged, A/B/C/D hợp lệ | PASS |
| F017 | Unlock revoke old save/submit/result, token mới/relogin/retake hoạt động | PASS |

## R1/R2 suite

R1: 18/18 PASS, gồm deadline/1µs boundary/lock-wait, ALL/PARTIAL, weights, frozen max_score, 8 submissions đồng thời mỗi mode, queued autosave, fault rollback/retry, conditional claim thất bại, comma + 14 legacy cases.
R2: 15/15 PASS, gồm normalization 5×4 canonical/lowercase/space/Unicode, 2 create routes/3 draws, DB không rewrite, wrong/missing/empty token active/submitted, unlock/retake/legacy NULL, 2 race queued writers khi teacher unlock, legacy editor invalid/ABCD.
Race probe nguyên bản: 2 fast reads submitted_at NULL, responses 302, stored score 10=re-grade 10. Không thêm delay/sleep trong application patch.

## Scoring/type/workflow

SINGLE/MULTI/TF/MATCH/FILL, ALL/PARTIAL, weights/max_score/snapshot đều PASS qua 6 test gốc, R1 suite, audit và browser. scoring.py/question_types.py byte-identical R2.
Create/build/login/autosave/reload/submit/result, unlock/relogin và 20-cell matrix giữ nguyên. Browser gốc/canonical, comma và lowercase/whitespace legacy đều build 20/submit 10/re-grade 10.
F008 workflow thật cho 5 marker đạt 4.5; Excel points/count/score/timestamp không đổi. Clone đủ 40 typed cases giữ exact payload/scoring, không infer grade.

## So sánh trước/sau

21 audit + 6 legacy assertions được so tên/status với R2: không có PASS chuyển FAIL. Chỉ 3 FAIL R2 chuyển PASS đúng scope: invalid_duration_handled (F006), clone_preserves_grade (F005), student_excel_export_keeps_names_as_text (F008).
Các harness gốc không sửa assertion hoặc expected result. Lỗi observer của harness R3 mới được lưu và giải thích riêng, không xóa/hạ trạng thái record ban đầu.

## Source và artifact

62 file, chỉ app.py/multi_routes.py thay đổi; 60 file khác giữ nguyên. AST bảo toàn bodies các function deadline/submit/autosave/auth/result/topic/normalization/editor của R1/R2; schema giống nhau; UI/static/version không đổi. Original tests và harness hashes khớp trước/sau.
Candidate không ZIP lồng/runtime mới; 4 pyc baseline được giữ nguyên. Hash R1/R2 source/ZIP/checksum đã xác minh, không ghi đè.

## Giới hạn kết luận

Không phát hiện regression mới trong các suite bắt buộc. F010–F016 vẫn OPEN; các probe snapshot/scoring hỏng gốc vẫn chỉ ghi observation, không đồng nghĩa chúng PASS. Không mở audit/refactor/Round 4/production.
""")

write('HOTFIX_R3_DIFF_SUMMARY.md','HOTFIX R3 — DIFF SUMMARY',f"""## File/function thay đổi

| File/function | Finding | Thay đổi cần thiết |
|---|---|---|
| app.py clone_question | F005 | INSERT thêm cột/value khoi_lop từ source |
| app.py exam_integer/create_exam | F006 | Shared integer/domain validation; bỏ safe_int coercion; flash+reject trước persistence |
| multi_routes.py nested mixed_exam | F006 | Duration và 20 quota fields gọi helper chung, giữ flow/template hiện tại |
| app.py excel_text_cells + export_students/questions/exam_report/results | F008 | Chọn ô user text, prefix-risk chuyển data_type s, value không đổi |

Diff đầy đủ `source.diff`; hashes/AST `scope-verification.json`.
6 app function bodies đổi, 2 helper mới; safe_int cũ bỏ theo F006. install_multi_routes chỉ nested mixed_exam thay đổi; outer AST khác vì chứa function này.

## Vì sao không sửa scoring/auth/DB

F005 cần thêm một metadata cột vào INSERT hiện có; không migration. F006 validate input form trước DB, domain có sẵn 1–180/nonnegative. F008 sửa kiểu ghi XLSX ở cột text, không sửa dữ liệu DB hay scorer, không strip/tạo apostrophe trong nội dung.

Không sanitize tràn mọi cell: summary numeric, student count/score, question statistics và result numeric giữ nguyên; chỉ summary B2–B4 và các cột text được chọn. Export points/multi đã an toàn, chỉ regression chứ không đổi source.

## Các phần giữ nguyên

Body exam/save_answer/result/validate_attempt_session/question_availability/question_classification/build_exam/edit_question/unlock_attempt/student_login/exam_topics/init_db cùng nested sampler/init/multi_excel/points giữ nguyên R2. create_exam đổi parsing đúng F006; representation comma/type quotas/availability check giữ nguyên.
60/62 file byte-identical, gồm scorer/types/templates/static/license/tests/docs/Windows scripts/Excel mẫu/pyc. Không bump version/schema hoặc production.

## Package

R3 candidate SHA-256 `{candidate['zip_sha256']}`; {candidate['zip_bytes']:,} byte, 62 members, đọc/CRC và hash từng member khớp source-manifest.
R2 candidate vẫn d89b2f...12eff. R1/R2 artifacts và checksum được đối chiếu nguyên vẹn. Checksum R3 đặt riêng theo layout HANDOFF, không overwrite bản cũ.
""")

write('HOTFIX_R3_FINDINGS.md','HOTFIX R3 — FINDINGS',"""## Scope R3

| Finding | Severity gốc | Trạng thái | Evidence |
|---|---|---|---|
| F005 | MEDIUM | PASS | Clone 40 typed + 6 legacy cases, exact grade/payload/source |
| F006 | MEDIUM | PASS | 322 invalid requests, both routes, valid boundaries/defaults/legacy |
| F008 | MEDIUM | PASS | 4 named exports + related guards, exact text + numeric/date/formula boundary |

F001/F002/F003 HIGH và F004/F007/F009/F017 MEDIUM đã sửa trước: regression R3 PASS. Không hạ severity gốc.

## Finding chưa sửa

| Finding | Severity | Trạng thái |
|---|---|---|
| F010 | MEDIUM | OPEN — invalid snapshot/scoring, probe observations không được sửa |
| F011 | MEDIUM | OPEN — CSRF chung, không sửa |
| F012 | MEDIUM | OPEN — historical reports phụ thuộc ngân hàng, không sửa |
| F013 | LOW | OPEN — metadata phiên bản |
| F014 | LOW | OPEN — MathJax plain/explicit cùng text node |
| F015 | LOW | OPEN — mô tả UI scoring cũ |
| F016 | INFO | OPEN — dependency pin/Windows EXE |

Không tìm thấy application finding mới trong các kiểm tra liên quan. Không mở rộng audit để xử lý những finding còn lại.

## Sự cố instrumentation mới, không phải finding ứng dụng

Harness R3 mới bản đầu kiểm session _flashes sau khi mixed-exam render nên ghi 2 FAIL mặc dù cảnh báo đã được hiển thị. Ghi nhận/đối chiếu template và giữ nguyên record/script cũ tại focused-r3/results.json và r3_regression.py. Observer mới kiểm actual `<p class="warn">` cho response render, giữ assertions DB/status/field. Chi tiết NEW_HARNESS_OBSERVATION.md.
Không sửa bất kỳ test/harness gốc hoặc R1/R2 nào, không đổi expected behavior, không sửa source để làm test PASS. Lần chạy đầu và script của nó vẫn trong evidence, không XFAIL hoặc xóa case FAIL.

## Kết luận/điểm dừng

85/85 final candidate groups PASS; candidate đóng gói, CRC/member hashes đã kiểm; không có PASS cũ chuyển FAIL. HOTFIX_R3 = PASS trong phạm vi đã yêu cầu. Không đồng nghĩa F010–F016 được sửa hay hệ thống đạt production readiness.
Sau HANDOFF + commit riêng/push nếu được phép, dừng chờ người dùng kiểm chứng. Không Round 4/version bump/v2.4/production.
""")
print('Generated 5 R3 reports; historical artifacts unchanged.')
