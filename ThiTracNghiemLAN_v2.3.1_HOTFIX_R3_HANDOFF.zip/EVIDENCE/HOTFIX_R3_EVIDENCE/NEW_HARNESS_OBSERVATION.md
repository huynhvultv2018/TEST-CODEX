# New R3 harness observation correction

The first newly authored r3_regression.py run retained 2 FAILs on R3: it expected `_flashes` after mixed-exam renders its template. Existing mixed_exam.html consumes the flash with get_flashed_messages() and displays `<p class="warn">...` in the HTTP 200 response. Main create-exam redirects and retains its flash until GET.

The original new harness and initial results are preserved unchanged. r3_regression_ui_observer.py changes only the observation location for notices, not expected behavior. It still asserts acceptable non-500 status, exact exam table before/after equality, a non-empty error notice containing the offending field. HTTP 200 validates the rendered warning element, never form field labels/inputs. HTTP 302 validates the pending flash.

No original application test or R1/R2 harness was wrong or edited; all passed. No application code was modified after this observation correction. Both R2 and R3 run the same new observer script. Initial FAIL records are included in HANDOFF rather than deleted/XFAILed. They are a new probe defect, not an application finding or production workaround.
