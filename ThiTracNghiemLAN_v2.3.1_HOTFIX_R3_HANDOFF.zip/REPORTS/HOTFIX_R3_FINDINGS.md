# HOTFIX R3 — FINDINGS

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R2 candidate bên trong HANDOFF người dùng gửi.
SHA-256 bắt buộc: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff` — MATCH trước patch.
Kết luận theo phạm vi yêu cầu: **HOTFIX_R3 = PASS**.

## Scope R3

| Finding | Severity gốc | Trạng thái | Evidence |
|---|---|---|---|
| F005 | MEDIUM | PASS | Clone 40 typed + 6 legacy cases, exact grade/payload/source |
| F006 | MEDIUM | PASS | 322 invalid requests, both routes, valid boundaries/defaults/legacy |
| F008 | MEDIUM | PASS | 4 named exports + related guards, exact text + numeric/date/formula boundary |

F001/F002/F003 HIGH và F004/F007/F009/F017 MEDIUM đã sửa trước: regression R3 PASS. Không hạ severity gốc.

## Finding chưa sửa

| Finding | Severity | Trạng thái |
|---|---|---|
| F010 | MEDIUM | OPEN — invalid snapshot/scoring, probe observations không được sửa |
| F011 | MEDIUM | OPEN — CSRF chung, không sửa |
| F012 | MEDIUM | OPEN — historical reports phụ thuộc ngân hàng, không sửa |
| F013 | LOW | OPEN — metadata phiên bản |
| F014 | LOW | OPEN — MathJax plain/explicit cùng text node |
| F015 | LOW | OPEN — mô tả UI scoring cũ |
| F016 | INFO | OPEN — dependency pin/Windows EXE |

Không tìm thấy application finding mới trong các kiểm tra liên quan. Không mở rộng audit để xử lý những finding còn lại.

## Sự cố instrumentation mới, không phải finding ứng dụng

Harness R3 mới bản đầu kiểm session _flashes sau khi mixed-exam render nên ghi 2 FAIL mặc dù cảnh báo đã được hiển thị. Ghi nhận/đối chiếu template và giữ nguyên record/script cũ tại focused-r3/results.json và r3_regression.py. Observer mới kiểm actual `<p class="warn">` cho response render, giữ assertions DB/status/field. Chi tiết NEW_HARNESS_OBSERVATION.md.
Không sửa bất kỳ test/harness gốc hoặc R1/R2 nào, không đổi expected behavior, không sửa source để làm test PASS. Lần chạy đầu và script của nó vẫn trong evidence, không XFAIL hoặc xóa case FAIL.

## Kết luận/điểm dừng

85/85 final candidate groups PASS; candidate đóng gói, CRC/member hashes đã kiểm; không có PASS cũ chuyển FAIL. HOTFIX_R3 = PASS trong phạm vi đã yêu cầu. Không đồng nghĩa F010–F016 được sửa hay hệ thống đạt production readiness.
Sau HANDOFF + commit riêng/push nếu được phép, dừng chờ người dùng kiểm chứng. Không Round 4/version bump/v2.4/production.
