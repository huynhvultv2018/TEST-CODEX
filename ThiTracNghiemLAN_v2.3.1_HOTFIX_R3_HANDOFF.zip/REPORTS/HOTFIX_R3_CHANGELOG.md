# HOTFIX R3 — CHANGELOG

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R2 candidate bên trong HANDOFF người dùng gửi.
SHA-256 bắt buộc: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff` — MATCH trước patch.
Kết luận theo phạm vi yêu cầu: **HOTFIX_R3 = PASS**.

## Patch trực tiếp

| Finding | Severity gốc | Thay đổi | Kết quả |
|---|---|---|---|
| F005 | MEDIUM | Clone INSERT thêm khoi_lop lấy nguyên giá trị từ row nguồn | PASS |
| F006 | MEDIUM | exam_integer dùng chung cho duration/counts ở create-exam và mixed-exam; reject thay coercion/clamp | PASS |
| F008 | MEDIUM | excel_text_cells chỉ áp vào trường text người dùng của 4 export được chỉ định | PASS |

## F005

Grade nguồn giữ nguyên, không suy luận hoặc gọi init_db để sửa clone. Source row, mon/chu_de/muc_do, question_type và payload/scoring giữ nguyên. ID mới và suffix _COPY giữ semantics cũ. Regression kiểm 6/7/8/9 × 5 types × ALL/PARTIAL (40 case), cùng legacy grade blank/space và ma_cau rỗng.

## F006

Duration phải là số nguyên 1–180 phút; count phải là số nguyên >=0. Strip whitespace ngoài chuỗi, chấp nhận dấu +/-, chữ số decimal và leading zero như int hợp lệ; giá trị toán học -0 vẫn là 0. Decimal float, exponent, underscore, khoảng trắng bên trong, chuỗi rỗng/nonnumeric đều bị reject. Giá trị quá lớn không parse được bị reject bằng ValueError hẹp.

Field thiếu giữ default duration 15/count 0 cho tương thích biểu mẫu; field được gửi rỗng không dùng default âm thầm. Không clamp duration ngoài miền; không đổi count sai/âm thành 0. Tổng 0 và shortage vẫn bị từ chối theo quy tắc cũ, không đổi matrix 5×4 hay chính sách tổng.

Thông báo dùng flash sẵn có, gồm tên field/ô. Main route redirect /teacher; route mixed render trang cảnh báo như trước. Chưa validate xong không INSERT/commit kỳ thi. Route legacy nb_count/th_count/vd_count/vdc_count dùng cùng helper.

## F008

User-controlled strings bắt đầu =/+/-/@ được ghi data_type s tại các ô được chọn. Giá trị hiển thị giữ nguyên, không thêm apostrophe. Giữ numeric thực, score, ngày/giờ và ô formula hệ thống ở cột khác.

- export_students: 3 cột text của học sinh;
- export_questions legacy: 11 cột text của câu hỏi;
- export_exam_report: summary B2/B3/B4, 5 cột text học sinh, 5 cột text phân tích câu hỏi;
- export_results: tên kỳ thi/mã/tên/lớp/thời gian; bỏ nguyên các cột STT/count/score;
- multi Excel và points export vốn đã có guard an toàn, không sửa; kiểm lại TEXT/numeric/weights.

## Bảo toàn

Chỉ PHAN_MEM/app.py và PHAN_MEM/multi_routes.py thay đổi, 60/62 file khác byte-identical R2. Không sửa UI, schema, scoring.py, question_types.py, authentication, body F001/F002/F003/F004/F007/F009/F017.
Không xử lý F010/F011/F012/F013/F014/F015/F016, không version bump, Round 4 hoặc production.
R1/R2 ZIP/source/reports/checksum nguyên vẹn, hash được kiểm lại.

## Artifact

Candidate: `ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip` — 863,183 byte, 62 file.
SHA-256: `f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a`.
4 pyc kế thừa baseline được giữ nguyên; không thêm runtime/cache/ZIP lồng. CHECKSUMS R3 riêng trong `HOTFIX_R3_HANDOFF_CONTENTS/CHECKSUMS.sha256` và HANDOFF, đường dẫn khớp bố cục gói; không ghi đè checksum R1/R2.
