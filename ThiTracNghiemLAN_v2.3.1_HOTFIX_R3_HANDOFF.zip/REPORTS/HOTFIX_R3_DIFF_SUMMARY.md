# HOTFIX R3 — DIFF SUMMARY

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R2 candidate bên trong HANDOFF người dùng gửi.
SHA-256 bắt buộc: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff` — MATCH trước patch.
Kết luận theo phạm vi yêu cầu: **HOTFIX_R3 = PASS**.

## File/function thay đổi

| File/function | Finding | Thay đổi cần thiết |
|---|---|---|
| app.py clone_question | F005 | INSERT thêm cột/value khoi_lop từ source |
| app.py exam_integer/create_exam | F006 | Shared integer/domain validation; bỏ safe_int coercion; flash+reject trước persistence |
| multi_routes.py nested mixed_exam | F006 | Duration và 20 quota fields gọi helper chung, giữ flow/template hiện tại |
| app.py excel_text_cells + export_students/questions/exam_report/results | F008 | Chọn ô user text, prefix-risk chuyển data_type s, value không đổi |

Diff đầy đủ `source.diff`; hashes/AST `scope-verification.json`.
6 app function bodies đổi, 2 helper mới; safe_int cũ bỏ theo F006. install_multi_routes chỉ nested mixed_exam thay đổi; outer AST khác vì chứa function này.

## Vì sao không sửa scoring/auth/DB

F005 cần thêm một metadata cột vào INSERT hiện có; không migration. F006 validate input form trước DB, domain có sẵn 1–180/nonnegative. F008 sửa kiểu ghi XLSX ở cột text, không sửa dữ liệu DB hay scorer, không strip/tạo apostrophe trong nội dung.

Không sanitize tràn mọi cell: summary numeric, student count/score, question statistics và result numeric giữ nguyên; chỉ summary B2–B4 và các cột text được chọn. Export points/multi đã an toàn, chỉ regression chứ không đổi source.

## Các phần giữ nguyên

Body exam/save_answer/result/validate_attempt_session/question_availability/question_classification/build_exam/edit_question/unlock_attempt/student_login/exam_topics/init_db cùng nested sampler/init/multi_excel/points giữ nguyên R2. create_exam đổi parsing đúng F006; representation comma/type quotas/availability check giữ nguyên.
60/62 file byte-identical, gồm scorer/types/templates/static/license/tests/docs/Windows scripts/Excel mẫu/pyc. Không bump version/schema hoặc production.

## Package

R3 candidate SHA-256 `f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a`; 863,183 byte, 62 members, đọc/CRC và hash từng member khớp source-manifest.
R2 candidate vẫn d89b2f...12eff. R1/R2 artifacts và checksum được đối chiếu nguyên vẹn. Checksum R3 đặt riêng theo layout HANDOFF, không overwrite bản cũ.
