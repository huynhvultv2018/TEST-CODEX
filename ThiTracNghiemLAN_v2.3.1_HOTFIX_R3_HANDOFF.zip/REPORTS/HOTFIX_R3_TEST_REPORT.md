# HOTFIX R3 — TEST REPORT

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R2 candidate bên trong HANDOFF người dùng gửi.
SHA-256 bắt buộc: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff` — MATCH trước patch.
Kết luận theo phạm vi yêu cầu: **HOTFIX_R3 = PASS**.

## Kết quả cuối cùng

| Suite | PASS | FAIL |
|---|---:|---:|
| Cùng regression R3 chạy trên baseline R2 | 3 | 12 |
| Regression R3 hoàn chỉnh trên R3 | 15 | 0 |
| R1 regression nguyên bản trên R3 | 18 | 0 |
| R2 regression nguyên bản trên R3 | 15 | 0 |
| 6 test gốc | 6 | 0 |
| Audit harness gốc | 21 | 0 |
| Legacy harness gốc | 6 | 0 |
| Race probe gốc | 1 | 0 |
| Browser harness gốc | 1 | 0 |
| Browser comma R1 nguyên bản | 1 | 0 |
| Browser normalized legacy R2 nguyên bản | 1 | 0 |

85/85 nhóm kiểm tra candidate cuối cùng PASS. Runner/harness gốc đều exit 0; không XFAIL/skip/đổi expected result. Không có PASS R2 chuyển thành FAIL.

## R3 case đối chiếu

| Case | R2 | R3 |
|---|---|---|
| F005_clone_4_grades_5_types_2_scoring_modes | FAIL | PASS |
| F005_clone_legacy_exact_metadata_no_init_db | FAIL | PASS |
| F006_invalid_time_create-exam | FAIL | PASS |
| F006_invalid_time_mixed-exam | FAIL | PASS |
| F006_invalid_counts_all_20_cells_create-exam | FAIL | PASS |
| F006_invalid_counts_all_20_cells_mixed-exam | FAIL | PASS |
| F006_invalid_legacy_counts | FAIL | PASS |
| F006_valid_boundaries_defaults_zero_shortage_legacy | PASS | PASS |
| F008_students_text_identity_5_markers | FAIL | PASS |
| F008_legacy_questions_all_text_columns | FAIL | PASS |
| F008_exam_report_all_sheets_text_and_numeric | FAIL | PASS |
| F008_results_text_numeric_and_time_identity | FAIL | PASS |
| F008_related_points_existing_guard_preserved | PASS | PASS |
| F008_related_multi_export_existing_guard_preserved | PASS | PASS |
| F008_selected_text_preserves_numeric_datetime_system_formula | FAIL | PASS |

Hai run final-focused dùng cùng hash harness. R2 FAIL với clone mất grade, invalid time/count, Excel text thành f; R3 PASS. Baseline vẫn PASS với valid inputs và 2 related exports đã có guard.

## Coverage F005

40 clone: 4 grades × 5 types × 2 scoring modes; so toàn bộ row ngoài ID/ma_cau, payload byte-identical, source unchanged, correct shuffled snapshot score 10. 6 legacy metadata cases giữ exact grade gồm blank/' 8 ', ma_cau rỗng, không init_db lại.

## Coverage F006

- 11 invalid durations × 2 routes: abc, rỗng, whitespace, 0, -1, 181, 1.5, 1e2, 1_0, NaN, 5000 decimal digits;
- 7 invalid count representations × 20 cells × 2 routes = 280 requests;
- 5 invalid representations × 4 legacy count fields = 20 requests;
- mọi rejection: HTTP không 500, bảng ky_thi trước/sau giống nhau, thông báo chỉ rõ field/ô;
- valid durations 1/180/15/whitespace/+ và omitted default; count +1/00/-0/omitted; đủ số câu build; tổng 0 và shortage vẫn reject; legacy SINGLE counts hợp lệ vẫn tạo/build.

322 request invalid có bằng chứng trong JSON final-focused-r3; không gọi DB migration hoặc update để che validation.

## Coverage F008

5 harmless markers: =1+1, +test, -test, @test, Tên bình thường. Dùng load_workbook(data_only=False) để kiểm data_type s và value chính xác. Kiểm students, 11 cột câu legacy, summary/student/question sheets, results, points, multi questions. Các XLSX response được giữ nguyên trong evidence.
Report fixtures có workflow thực create → login → autosave → submit → result, 5 types, PARTIAL/weights/max_score, stored/re-grade 4.5/10. Export giữ count/score numeric và timestamps y hệt DB. Points sum 4.5 khớp stored score.
Helper boundary giữ numeric -7.25, datetime và system formula =SUM(1,1) ở ô khác. Không thay toàn workbook thành text.

## Lần chạy đầu của harness R3 mới

`focused-r3/results.json` ghi 13 PASS/2 FAIL và exit 1; kết quả không bị xóa hoặc đổi trạng thái. Hai FAIL là lỗi instrumentation do harness mới đọc _flashes trong session sau khi mixed-exam render/consume flash. Template cũ hiển thị warning trong response HTTP 200. Main redirect giữ flash đến GET.
`r3_regression.py` ban đầu giữ nguyên. `r3_regression_ui_observer.py` quan sát warning thực trong HTML cho response render, flash session cho response redirect; giữ tất cả invariant/status/DB/message-field assertions. Không thay source để khớp test, không sửa test/harness cũ R1/R2. Giải thích/diff hành vi quan sát tại NEW_HARNESS_OBSERVATION.md; final-focused là bằng chứng hoàn chỉnh theo cơ chế hiện có.
Không có test gốc/R1/R2 bị sai; quy tắc dừng khi test cũ sai không được kích hoạt.

## Lệnh và reproducibility

Từ `/workspace/TEST-CODEX`, Python `/workspace/tnlan-audit-venv/bin/python`:

```sh
python HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py --source hotfix-r2-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/final-focused-r2
python HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/final-focused-r3
python HOTFIX_R1_EVIDENCE/hotfix_regression.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/r1-regression
python HOTFIX_R2_EVIDENCE/r2_regression.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/r2-regression
python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r3-candidate --output HOTFIX_R3_EVIDENCE/original-r3
python HOTFIX_R1_EVIDENCE/comma_browser.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/comma-browser
python HOTFIX_R2_EVIDENCE/normalized_browser.py --source hotfix-r3-candidate/PHAN_MEM --output HOTFIX_R3_EVIDENCE/normalized-browser
```

Các harness trước được lưu byte-identical trong unchanged-harnesses/ cùng recorded hashes. Runner gốc dùng context repository V2.3.1_AUDIT_EVIDENCE và tên directory baseline-v2.3.1 trong staging tạm; source bên trong staging là R3, không dùng baseline gốc để chạy.

## Môi trường/giới hạn

Python 3.12.14, Flask/SQLite, Waitress loopback, Chromium hệ thống. Mọi DB/source/LOCALAPPDATA runtime dùng copy tạm riêng. Browser không external requests/page errors, server đã đóng. Không Windows EXE, LAN vật lý hoặc production. Test source/workflow đã nêu, không kết luận F010–F016 được giải quyết.
