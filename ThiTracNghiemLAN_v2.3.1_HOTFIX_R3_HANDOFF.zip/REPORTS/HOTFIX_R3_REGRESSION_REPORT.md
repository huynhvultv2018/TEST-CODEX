# HOTFIX R3 — REGRESSION REPORT

Ngày: 02/10/2026 (Asia/Bangkok).
Baseline duy nhất: R2 candidate bên trong HANDOFF người dùng gửi.
SHA-256 bắt buộc: `d89b2f96906741e0fd593c210dcca1d5d788b2a1f0c7de611c32d18338012eff` — MATCH trước patch.
Kết luận theo phạm vi yêu cầu: **HOTFIX_R3 = PASS**.

## Invariant

| Finding | Invariant | Kết quả |
|---|---|---|
| F005 | Clone giữ nguyên khoi_lop/payload/scoring/type; source không đổi | PASS |
| F006 | Invalid time → no 500/no exam; invalid count → reject/no silent coercion | PASS |
| F008 | User text =/+/-/@ → exact value/text, numeric/time/system formula nguyên vẹn | PASS |
| F001 | Expired POST không nhận fresh answers, dùng saved theo deadline server | PASS |
| F002 | Concurrent submit single writer, stored answers re-grade = stored score | PASS |
| F003 | Comma topic round-trip/build đủ 20 cells, old representation tương thích | PASS |
| F004 | Lowercase/whitespace availability = sampler, 5×4 đủ câu | PASS |
| F007 | Result chỉ hiện cho attempt session hợp lệ; legacy policy giữ nguyên | PASS |
| F009 | INVALID legacy editor HTTP 400/DB unchanged, A/B/C/D hợp lệ | PASS |
| F017 | Unlock revoke old save/submit/result, token mới/relogin/retake hoạt động | PASS |

## R1/R2 suite

R1: 18/18 PASS, gồm deadline/1µs boundary/lock-wait, ALL/PARTIAL, weights, frozen max_score, 8 submissions đồng thời mỗi mode, queued autosave, fault rollback/retry, conditional claim thất bại, comma + 14 legacy cases.
R2: 15/15 PASS, gồm normalization 5×4 canonical/lowercase/space/Unicode, 2 create routes/3 draws, DB không rewrite, wrong/missing/empty token active/submitted, unlock/retake/legacy NULL, 2 race queued writers khi teacher unlock, legacy editor invalid/ABCD.
Race probe nguyên bản: 2 fast reads submitted_at NULL, responses 302, stored score 10=re-grade 10. Không thêm delay/sleep trong application patch.

## Scoring/type/workflow

SINGLE/MULTI/TF/MATCH/FILL, ALL/PARTIAL, weights/max_score/snapshot đều PASS qua 6 test gốc, R1 suite, audit và browser. scoring.py/question_types.py byte-identical R2.
Create/build/login/autosave/reload/submit/result, unlock/relogin và 20-cell matrix giữ nguyên. Browser gốc/canonical, comma và lowercase/whitespace legacy đều build 20/submit 10/re-grade 10.
F008 workflow thật cho 5 marker đạt 4.5; Excel points/count/score/timestamp không đổi. Clone đủ 40 typed cases giữ exact payload/scoring, không infer grade.

## So sánh trước/sau

21 audit + 6 legacy assertions được so tên/status với R2: không có PASS chuyển FAIL. Chỉ 3 FAIL R2 chuyển PASS đúng scope: invalid_duration_handled (F006), clone_preserves_grade (F005), student_excel_export_keeps_names_as_text (F008).
Các harness gốc không sửa assertion hoặc expected result. Lỗi observer của harness R3 mới được lưu và giải thích riêng, không xóa/hạ trạng thái record ban đầu.

## Source và artifact

62 file, chỉ app.py/multi_routes.py thay đổi; 60 file khác giữ nguyên. AST bảo toàn bodies các function deadline/submit/autosave/auth/result/topic/normalization/editor của R1/R2; schema giống nhau; UI/static/version không đổi. Original tests và harness hashes khớp trước/sau.
Candidate không ZIP lồng/runtime mới; 4 pyc baseline được giữ nguyên. Hash R1/R2 source/ZIP/checksum đã xác minh, không ghi đè.

## Giới hạn kết luận

Không phát hiện regression mới trong các suite bắt buộc. F010–F016 vẫn OPEN; các probe snapshot/scoring hỏng gốc vẫn chỉ ghi observation, không đồng nghĩa chúng PASS. Không mở audit/refactor/Round 4/production.
