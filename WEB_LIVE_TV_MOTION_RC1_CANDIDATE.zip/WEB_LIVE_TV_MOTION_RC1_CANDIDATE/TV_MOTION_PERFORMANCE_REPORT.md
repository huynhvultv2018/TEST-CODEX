# TV MOTION PERFORMANCE REPORT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Môi trường đo: Linux cloud, Chromium 151.0.7922.173 headless; viewport 1366×768, Playwright. Chưa chạy Chrome/Edge Windows hoặc laptop cấu hình trung bình/TV vật lý.

## Motion có giới hạn

Controller giới hạn tối đa hai nhóm nổi bật cho mỗi render; các sample clip có effectCount ≤2. Chuyển nhanh Next/Previous 12 lần: state cuối đúng 15/41, không còn active animation sau settle. Ticket generation loại callback cũ; screen change hủy class/handler trước; không queue.

Opacity/transform là thuộc tính chính; không animate width/height/top/left nội dung/ảnh. Width progress 260ms là ngoại lệ. Emphasis inset shadow và transition border/background ngắn có paint nhẹ; không tuyên bố mọi effect đều chạy riêng trên compositor. DOM observer chỉ theo dõi childList của hai SVG overlay, không polling motion. Intent chưa bắt đầu được giới hạn bằng token 360ms; sau animationstart không replay bước cũ. Animationend dọn class/handler, node bị thay được dọn khỏi active map.

## Mẫu rAF lúc có motion thật

performance-accessibility.json lấy mẫu trong lúc hint thật đang animate, không dùng số liệu rAF khi UI đã đứng yên trong motion/results.json để chứng minh hiệu năng.

| Chỉ số | Kết quả cloud |
|---|---|
| Khoảng frame đang/cạnh motion | 17 |
| Median | 16.700ms |
| P95 | 16.800ms |
| Max | 16.800ms |
| Khoảng >33.4ms | 0 |

Mẫu ngắn này cho thấy không có khoảng dài trong ca đã đo nếu count trên bằng 0; không bảo đảm 60fps hoặc xác nhận laptop trung bình. Bốn WebM là PNG timestamped encode VFR không nội suy, hữu ích xem reveal/state nhưng không thay phép đo FPS liên tục.

Resolution: 24 ca motion × state during/after tại 1920×1080, 1600×900, 1366×768, 1280×720 không overflow. Scan 342 state trên 171 màn thật và 48 ảnh regression cũng không overflow đo được.

Kết quả: cloud checks PASS. Acceptance về “1366×768 mượt trên máy cấu hình trung bình” và Chrome/Edge Windows PENDING; cần test thật trước mọi quyết định Production.
