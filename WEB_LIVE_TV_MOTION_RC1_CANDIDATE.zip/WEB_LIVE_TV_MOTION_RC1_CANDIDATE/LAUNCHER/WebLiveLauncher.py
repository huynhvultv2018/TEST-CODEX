"""WEB LIVE V1.1.5: current Teacher session with Windows TV demo handoff."""
from __future__ import annotations

import hmac
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from dataclasses import dataclass
from windows_handoff import AppWindow, Win32Desktop, choose_tv_monitor


HOST = "127.0.0.1"
PORT = 47381
MAX_BODY = 2048
COOLDOWN_SECONDS = 8
CHALLENGE_SECONDS = 20
SESSION_SECONDS = 90 * 60
WINDOW_TIMEOUT_SECONDS = 12
APP_POLICY = {
    "word": {
        "name": "Microsoft Word",
        "exe_names": frozenset({"winword.exe"}),
        "extension": ".docx",
    },
    "geogebra": {
        "name": "GeoGebra",
        "exe_names": frozenset({"geogebra.exe", "geogebra classic.exe", "geogebracalculator.exe"}),
        "extension": ".ggb",
    },
}


class LaunchError(Exception):
    def __init__(self, code: str, message: str, status: int):
        super().__init__(message)
        self.code, self.status = code, status


def load_installation(path: Path) -> tuple[str, bytes]:
    data = strict_json(path.read_bytes())
    if (not isinstance(data, dict) or set(data) != {"installationId", "installationKey"} or
            not isinstance(data["installationId"], str) or
            not re.fullmatch(r"[A-Za-z0-9_-]{16,64}", data["installationId"]) or
            not isinstance(data["installationKey"], str) or
            not re.fullmatch(r"[0-9a-f]{64}", data["installationKey"])):
        raise ValueError("LAUNCHER/launcher-config.json không hợp lệ")
    return data["installationId"], bytes.fromhex(data["installationKey"])


class Pairing:
    def __init__(self, installation_id: str, key: bytes, *, clock=None):
        self.installation_id, self.key = installation_id, key
        self.instance_id = secrets.token_urlsafe(18)
        self.clock = clock or time.monotonic
        self.lock = threading.Lock()
        self.challenges: dict[str, float] = {}
        self.session_token = ""
        self.session_expires = 0.0

    def authorized(self, candidate: str) -> bool:
        with self.lock:
            return (bool(candidate) and self.clock() < self.session_expires and
                    len(candidate) == len(self.session_token) and
                    hmac.compare_digest(candidate, self.session_token))

    def challenge(self) -> dict:
        with self.lock:
            now = self.clock()
            self.challenges = {n: expires for n, expires in self.challenges.items() if expires > now}
            # Bound memory if an unpaired local tab requests many challenges.
            while len(self.challenges) >= 64:
                self.challenges.pop(next(iter(self.challenges)))
            nonce = secrets.token_urlsafe(24)
            self.challenges[nonce] = now + CHALLENGE_SECONDS
        return {"status": "PAIR_REQUIRED", "installationId": self.installation_id,
                "instanceId": self.instance_id, "challenge": nonce}

    def pair(self, payload: object) -> str:
        if (not isinstance(payload, dict) or set(payload) != {"challenge", "proof"} or
                not isinstance(payload["challenge"], str) or
                not re.fullmatch(r"[A-Za-z0-9_-]{32}", payload["challenge"]) or
                not isinstance(payload["proof"], str) or
                not re.fullmatch(r"[0-9a-f]{64}", payload["proof"])):
            raise LaunchError("INVALID_PAIR", "Yêu cầu ghép Launcher không hợp lệ.", 400)
        nonce = payload["challenge"]
        with self.lock:
            expires = self.challenges.pop(nonce, 0.0)  # One use, including failed proof.
            if self.clock() >= expires:
                raise LaunchError("EXPIRED_CHALLENGE", "Mã ghép đã hết hạn.", 401)
            message = f"WEBLIVE-PAIR-V1.1.4\n{self.instance_id}\n{nonce}".encode("utf-8")
            expected = hmac.new(self.key, message, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(payload["proof"], expected):
                raise LaunchError("PAIR_DENIED", "Gói WEB LIVE không có khóa ghép hợp lệ.", 403)
            self.session_token = secrets.token_urlsafe(32)
            self.session_expires = self.clock() + SESSION_SECONDS
            return self.session_token


def load_registry(path: Path) -> dict[str, str]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or set(data) != set(APP_POLICY):
        raise ValueError("launcher_apps.json chỉ được khai báo word và geogebra")
    registry = {}
    for app_id, entry in data.items():
        if not isinstance(entry, dict) or set(entry) != {"exe"} or not isinstance(entry["exe"], str):
            raise ValueError(f"Cấu hình {app_id} chỉ gồm trường exe dạng chuỗi")
        registry[app_id] = entry["exe"]
    return registry


def load_display_config(path: Path) -> int | None:
    if not path.exists():
        return None
    data = strict_json(path.read_bytes())
    if not isinstance(data, dict) or set(data) != {"tvMonitorIndex"}:
        raise ValueError("launcher-display.json chỉ được khai báo tvMonitorIndex")
    index = data["tvMonitorIndex"]
    if index is not None and (type(index) is not int or index < 1 or index > 16):
        raise ValueError("tvMonitorIndex phải là số màn hình từ 1 đến 16 hoặc null")
    return index


@dataclass
class DemoSession:
    app_id: str
    relative: str
    pid: int
    before: frozenset[int]
    file_stem: str
    window: AppWindow | None = None
    state: str = "OPENING"
    cancelled: bool = False


def select_demo_window(windows: list[AppWindow], session: DemoSession,
                       descendants: set[int] | None = None) -> AppWindow | None:
    """Prefer launched PID, new window, then the opened document; never guess among old windows."""
    if not windows:
        return None
    direct = [w for w in windows if session.pid and w.pid in (descendants or {session.pid})]
    fresh = [w for w in windows if w.hwnd not in session.before]
    title = [w for w in windows if session.file_stem and session.file_stem in w.title.casefold()]
    for group in (direct, fresh, title):
        if len(group) == 1:
            return group[0]
        if len(group) > 1:
            matches = [w for w in group if w in title]
            if len(matches) == 1:
                return matches[0]
    return windows[0] if len(windows) == 1 else None


class UnavailableDesktop:
    """Only for non-Windows automated tests; the real Launcher runs on Windows."""
    def monitors(self): return []
    def windows(self, _names): return []
    def descendants(self, _pid): return set()
    def valid(self, _window, _names): return False
    def present(self, _window, _monitor): return False
    def minimize(self, _window): return False


class LauncherService:
    def __init__(self, base_dir: Path, registry: dict[str, str], *, popen=None, clock=None,
                 desktop=None, tv_monitor_index=None, sleep=None, window_timeout=WINDOW_TIMEOUT_SECONDS):
        self.base_dir = Path(base_dir).resolve()
        self.demo_dir = (self.base_dir / "demos").resolve()
        self.demo_dir.mkdir(parents=True, exist_ok=True)
        self.registry = registry
        self.popen = popen or subprocess.Popen
        self.clock = clock or time.monotonic
        self.desktop = desktop if desktop is not None else (Win32Desktop() if sys.platform == "win32" else UnavailableDesktop())
        self.tv_monitor_index = tv_monitor_index
        self.sleep = sleep or time.sleep
        self.window_timeout = window_timeout
        self.active: DemoSession | None = None
        self.last_launch: dict[tuple[str, str], float] = {}
        self.lock = threading.Lock()
        self.log_lock = threading.Lock()
        self.log_path = self.base_dir / "launcher.log"

    def _app_exe(self, app_id: str) -> Path:
        raw = self.registry.get(app_id, "")
        if not raw or not Path(raw).is_absolute():
            raise LaunchError("APP_NOT_FOUND", f"Không tìm thấy {APP_POLICY[app_id]['name']}.", 404)
        try:
            exe = Path(raw).resolve(strict=True)
        except (OSError, RuntimeError):
            raise LaunchError("APP_NOT_FOUND", f"Không tìm thấy {APP_POLICY[app_id]['name']}.", 404)
        if not exe.is_file() or exe.name.casefold() not in APP_POLICY[app_id]["exe_names"]:
            raise LaunchError("APP_NOT_FOUND", f"Không tìm thấy {APP_POLICY[app_id]['name']}.", 404)
        return exe

    def _demo_file(self, relative: str, app_id: str) -> Path:
        if not isinstance(relative, str) or not relative or len(relative) > 240:
            raise LaunchError("INVALID_FILE", "Đường dẫn tệp demo không hợp lệ.", 400)
        parts = relative.split("/")
        if (relative.startswith("/") or "\\" in relative or any(
            not part or part in (".", "..") or part[-1] in ". " or
            any(ord(char) < 32 or char in '<>:"|?*' for char in part)
            for part in parts
        )):
            raise LaunchError("INVALID_FILE", "Đường dẫn tệp demo không hợp lệ.", 400)
        if PurePosixPath(relative).suffix.casefold() != APP_POLICY[app_id]["extension"]:
            raise LaunchError("INVALID_FILE", "Định dạng tệp demo không được phép cho ứng dụng này.", 400)
        try:
            target = (self.demo_dir / relative).resolve(strict=True)
        except (OSError, RuntimeError):
            raise LaunchError("FILE_NOT_FOUND", "Không tìm thấy tệp demo.", 404)
        if not target.is_relative_to(self.demo_dir):
            raise LaunchError("INVALID_FILE", "Tệp demo nằm ngoài thư mục được phép.", 403)
        if not target.is_file():
            raise LaunchError("FILE_NOT_FOUND", "Không tìm thấy tệp demo.", 404)
        return target

    def status(self) -> dict:
        apps = {}
        for app_id, policy in APP_POLICY.items():
            try:
                self._app_exe(app_id)
                installed = True
            except LaunchError:
                installed = False
            apps[app_id] = {"name": policy["name"], "available": installed, "configured": installed}
        try:
            monitors = self.desktop.monitors()
            target, reason = choose_tv_monitor(monitors, self.tv_monitor_index)
        except OSError:
            monitors, target, reason = [], None, "MONITOR_ERROR"
        with self.lock:
            active = self.active
            demo = ({"state": active.state, "appId": active.app_id, "file": active.relative}
                    if active else {"state": "READY"})
        return {"status": "READY", "apps": apps, "monitorCount": len(monitors),
                "tvMonitorAvailable": bool(target), "monitorState": reason, "demo": demo}

    def _present_worker(self, session: DemoSession, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        allowed = APP_POLICY[session.app_id]["exe_names"]
        while time.monotonic() < deadline:
            with self.lock:
                if self.active is not session or session.cancelled:
                    return
            try:
                windows = self.desktop.windows(allowed)
                chosen = select_demo_window(windows, session, self.desktop.descendants(session.pid))
                if chosen:
                    with self.lock:
                        if self.active is not session or session.cancelled:
                            return
                        session.window = chosen
                        target, reason = choose_tv_monitor(self.desktop.monitors(), self.tv_monitor_index)
                        if target:
                            session.state = "PRESENTING" if self.desktop.present(chosen, target) else "PRESENT_FAILED"
                        else:
                            session.state = reason  # App remains on the current display.
                        self._log(session.app_id, session.relative, session.state)
                    return
            except OSError:
                with self.lock:
                    if self.active is session:
                        session.state = "PRESENT_FAILED"
                return
            self.sleep(0.25)
        with self.lock:
            if self.active is session and not session.cancelled:
                session.state = "WINDOW_NOT_FOUND"
                self._log(session.app_id, session.relative, session.state)

    def _start_present_worker(self, session: DemoSession, timeout: float) -> None:
        session.state = "OPENING"
        threading.Thread(target=self._present_worker, args=(session, timeout), daemon=True).start()

    def _show_existing_locked(self, session: DemoSession) -> None:
        try:
            target, reason = choose_tv_monitor(self.desktop.monitors(), self.tv_monitor_index)
            session.state = ("PRESENTING" if self.desktop.present(session.window, target) else "PRESENT_FAILED") if target else reason
        except OSError:
            session.state = "PRESENT_FAILED"

    def present(self, payload: object) -> dict:
        if payload != {}:
            raise LaunchError("INVALID_REQUEST", "Không nhận HWND, PID hay tọa độ từ WEB LIVE.", 400)
        with self.lock:
            session = self.active
            if not session:
                raise LaunchError("NO_DEMO", "Chưa có demo nào được giáo viên mở.", 409)
            if session.state == "OPENING":
                return {"result": "OPENING"}
            allowed = APP_POLICY[session.app_id]["exe_names"]
            try:
                valid = session.window and self.desktop.valid(session.window, allowed)
            except OSError:
                valid = False
            if valid:
                self._show_existing_locked(session)
                return {"result": session.state}
            session.window = None
            session.cancelled = False
            self._start_present_worker(session, self.window_timeout)
            return {"result": "OPENING"}

    def return_to_web(self, payload: object) -> dict:
        if payload != {}:
            raise LaunchError("INVALID_REQUEST", "Không nhận HWND, PID hay tọa độ từ WEB LIVE.", 400)
        with self.lock:
            session = self.active
            if not session:
                raise LaunchError("NO_DEMO", "Chưa có demo nào để trở lại WEB LIVE.", 409)
            session.cancelled = True
            allowed = APP_POLICY[session.app_id]["exe_names"]
            try:
                valid = session.window and self.desktop.valid(session.window, allowed)
                if valid and not self.desktop.minimize(session.window):
                    raise LaunchError("RETURN_FAILED", "Chưa thu nhỏ được cửa sổ demo; hãy thử lại.", 500)
            except OSError:
                raise LaunchError("RETURN_FAILED", "Chưa thu nhỏ được cửa sổ demo; hãy thử lại.", 500)
            session.state = "RETURNED"
            self._log(session.app_id, session.relative, "RETURNED")
            return {"result": "RETURNED"}

    def _log(self, app_id: str, relative: str, result: str) -> None:
        record = {"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                  "appId": app_id, "file": relative, "result": result}
        try:
            with self.log_lock, self.log_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            pass  # Logging must never interrupt the current lesson.

    def launch(self, payload: object) -> dict:
        try:
            return self._launch(payload)
        except LaunchError as error:
            if error.code not in ("COOLDOWN", "LAUNCH_FAILED"):
                app_id = payload.get("appId") if isinstance(payload, dict) else None
                relative = payload.get("file") if isinstance(payload, dict) else None
                safe_app = app_id if isinstance(app_id, str) and app_id in APP_POLICY else "-"
                safe_file = relative if (isinstance(relative, str) and len(relative) <= 240 and
                    not any(ord(c) < 32 for c in relative)) else "-"
                self._log(safe_app, safe_file, error.code)
            raise

    def _launch(self, payload: object) -> dict:
        if not isinstance(payload, dict) or not set(payload) <= {"appId", "file"} or "appId" not in payload:
            raise LaunchError("INVALID_REQUEST", "Chỉ chấp nhận appId và file.", 400)
        app_id = payload["appId"]
        if not isinstance(app_id, str) or app_id not in APP_POLICY:
            raise LaunchError("APP_DENIED", "Ứng dụng không nằm trong danh sách cho phép.", 403)
        relative = payload.get("file", "")
        if relative is not None and not isinstance(relative, str):
            raise LaunchError("INVALID_FILE", "Đường dẫn tệp demo không hợp lệ.", 400)
        relative = relative or ""
        if relative.startswith("demos/"):
            relative = relative[len("demos/"):]
            if not relative:
                raise LaunchError("INVALID_FILE", "Đường dẫn tệp demo không hợp lệ.", 400)
        if relative:
            # Resolve before launching; never pass paths supplied by the browser as executables.
            target = self._demo_file(relative, app_id)
        else:
            target = None
        exe = self._app_exe(app_id)
        key = (app_id, relative)
        with self.lock:
            now = self.clock()
            active = self.active
            if active and (active.app_id, active.relative) == key:
                if active.state in ("OPENING", "PRESENTING"):
                    if active.state == "PRESENTING" and active.window:
                        try:
                            valid = self.desktop.valid(active.window, APP_POLICY[app_id]["exe_names"])
                        except OSError:
                            valid = False
                        if valid:
                            self._show_existing_locked(active)
                        else:
                            active.window = None
                            self._start_present_worker(active, self.window_timeout)
                    return {"result": "REUSED", "appId": app_id}
                # Reuse the still-open application after return or a failed move.
                try:
                    valid = active.window and self.desktop.valid(active.window, APP_POLICY[app_id]["exe_names"])
                except OSError:
                    valid = False
                if valid:
                    active.cancelled = False
                    self._show_existing_locked(active)
                    return {"result": "REUSED", "appId": app_id}
                active.cancelled = False
                self._start_present_worker(active, self.window_timeout)
                return {"result": "RETRYING", "appId": app_id}
            if now - self.last_launch.get(key, float("-inf")) < COOLDOWN_SECONDS:
                self._log(app_id, relative, "COOLDOWN")
                raise LaunchError("COOLDOWN", "Demo vừa được mở; vui lòng chờ vài giây.", 429)
            try:
                before = frozenset(w.hwnd for w in self.desktop.windows(APP_POLICY[app_id]["exe_names"]))
            except OSError:
                before = frozenset()
            try:
                process = self.popen([str(exe)] + ([str(target)] if target else []), shell=False, close_fds=True)
            except OSError:
                self._log(app_id, relative, "LAUNCH_FAILED")
                raise LaunchError("LAUNCH_FAILED", f"Không mở được {APP_POLICY[app_id]['name']}.", 500)
            self.last_launch[key] = now
            if active and active.window:
                try:
                    if self.desktop.valid(active.window, APP_POLICY[active.app_id]["exe_names"]):
                        self.desktop.minimize(active.window)
                except OSError:
                    pass
            if active:
                active.cancelled = True
            session = DemoSession(app_id, relative, int(getattr(process, "pid", 0) or 0), before,
                                  target.stem.casefold() if target else "")
            self.active = session
            self._start_present_worker(session, self.window_timeout)
            self._log(app_id, relative, "SUCCESS")
        return {"result": "STARTED", "appId": app_id}


def strict_json(blob: bytes) -> object:
    def no_duplicates(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError("duplicate key")
            out[key] = value
        return out
    return json.loads(blob.decode("utf-8"), object_pairs_hook=no_duplicates)


class LauncherHandler(BaseHTTPRequestHandler):
    server_version = "WebLiveLauncher/1.1.5"
    sys_version = ""

    def log_message(self, format, *args):
        pass  # No token, lesson content, or request body in HTTP access logs.

    def _local_context(self) -> bool:
        return (self.client_address[0] == HOST and
                self.headers.get("Host") == f"{HOST}:{self.server.server_port}" and
                self.headers.get("Origin") == "null")

    def _authorized(self) -> bool:
        candidate = self.headers.get("X-WebLive-Token", "")
        return self.server.pairing.authorized(candidate)

    def _reply(self, status: int, result: dict) -> None:
        data = json.dumps(result, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        if self._local_context():
            self.send_header("Access-Control-Allow-Origin", "null")
            self.send_header("Vary", "Origin")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def _check(self) -> bool:
        if not self._local_context():
            self._reply(403, {"error": "ORIGIN_DENIED", "message": "Nguồn yêu cầu không được phép."})
            return False
        if not self._authorized():
            self._reply(401, {"error": "INVALID_TOKEN", "message": "Phiên Launcher không hợp lệ hoặc đã hết hạn."})
            return False
        return True

    def do_OPTIONS(self):
        if not self._local_context() or self.path not in ("/status", "/pair", "/launch", "/present", "/return"):
            self._reply(403, {"error": "ORIGIN_DENIED"})
            return
        wanted = "GET" if self.path == "/status" else "POST"
        method = self.headers.get("Access-Control-Request-Method", "")
        fields = {part.strip().lower() for part in self.headers.get("Access-Control-Request-Headers", "").split(",") if part.strip()}
        if method != wanted or not fields <= {"content-type", "x-weblive-token"}:
            self._reply(403, {"error": "PREFLIGHT_DENIED"})
            return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "null")
        self.send_header("Access-Control-Allow-Methods", wanted)
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-WebLive-Token")
        if self.headers.get("Access-Control-Request-Private-Network") == "true":
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "300")
        self.send_header("Vary", "Origin")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if not self._local_context():
            self._reply(403, {"error": "ORIGIN_DENIED"})
            return
        if self.path != "/status":
            self._reply(404, {"error": "NOT_FOUND"})
            return
        if self._authorized():
            self._reply(200, {**self.server.service.status(), "instanceId": self.server.pairing.instance_id})
        else:
            self._reply(200, self.server.pairing.challenge())

    def do_POST(self):
        if not self._local_context():
            self._reply(403, {"error": "ORIGIN_DENIED"})
            return
        if self.path not in ("/pair", "/launch", "/present", "/return"):
            self._reply(404, {"error": "NOT_FOUND"})
            return
        if self.path != "/pair" and not self._check():
            return
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json":
            self._reply(415, {"error": "CONTENT_TYPE_DENIED"})
            return
        try:
            length = int(self.headers.get("Content-Length", ""))
        except ValueError:
            length = -1
        if length < 1 or length > MAX_BODY or self.headers.get("Transfer-Encoding"):
            self._reply(413, {"error": "INVALID_SIZE"})
            return
        try:
            payload = strict_json(self.rfile.read(length))
        except (UnicodeError, ValueError):
            self._reply(400, {"error": "INVALID_JSON"})
            return
        try:
            if self.path == "/pair":
                token = self.server.pairing.pair(payload)
                self._reply(200, {**self.server.service.status(), "token": token,
                                  "instanceId": self.server.pairing.instance_id,
                                  "expiresInSeconds": SESSION_SECONDS})
            elif self.path == "/launch":
                self._reply(200, self.server.service.launch(payload))
            elif self.path == "/present":
                self._reply(200, self.server.service.present(payload))
            else:
                self._reply(200, self.server.service.return_to_web(payload))
        except LaunchError as error:
            self._reply(error.status, {"error": error.code, "message": str(error)})


def main() -> int:
    if sys.platform != "win32":
        print("WebLiveLauncher chỉ chạy trên Windows; unit tests chạy đa nền tảng.")
        return 2
    # Locate the package from the script/executable, never from current working directory.
    base = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent
    try:
        registry = load_registry(base / "launcher_apps.json")
        installation_id, installation_key = load_installation(base / "launcher-config.json")
        service = LauncherService(base, registry, tv_monitor_index=load_display_config(base / "launcher-display.json"))
        pairing = Pairing(installation_id, installation_key)
        server = ThreadingHTTPServer((HOST, PORT), LauncherHandler)
        server.service, server.pairing = service, pairing
    except (OSError, ValueError) as error:
        print(f"Không khởi động được Launcher: {error}")
        return 1
    print("WEB LIVE DEMO LAUNCHER")
    print(f"Đang chạy tại {HOST}:{PORT}")
    try:
        for index, monitor in enumerate(service.desktop.monitors(), 1):
            print(f"Màn hình {index}: {monitor.name} {'(chính)' if monitor.primary else '(phụ)'} {monitor.rect}")
    except OSError:
        print("Chưa đọc được danh sách màn hình; kiểm tra Windows Display Settings.")
    print("Đang chờ WEB LIVE kết nối... Ctrl+C để tắt.", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
