# TV MOTION REGRESSION REPORT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Chạy trên source Motion cuối bằng ba harness regression/extra/motion và harness performance-accessibility. External request bị chặn trong regression/motion; ghi nhận zero external và zero pageerror. Không sửa lesson ZIP; object lesson giữ nguyên qua scan.

## Gói LIVE thật

| Package | Màn | State question/full | Lesson nguyên |
|---|---|---|---|
| RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip | 41 | 82 | PASS |
| RC3_PED1_TEST_PACKAGES/TIN6_W05_LIVE_RC3_PED1.zip | 32 | 64 | PASS |
| RC3_PED1_TEST_PACKAGES/TIN8_W04_LIVE_RC3_PED1.zip | 29 | 58 | PASS |
| WEB_LIVE/HINH_HOC_8_T04_T07_LIVE_TEST.zip | 34 | 68 | PASS |
| WEB_LIVE/HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST.zip | 35 | 70 | PASS |

Tổng 171 màn / 342 state; không overflow dọc/ngang đo được. 44 ảnh regression chính và 4 ảnh all-analysis bổ sung; 24 ca motion tại bốn viewport đều đạt during/after.

## Chức năng giữ nguyên đã thực thi

- TV sync, stale-state rejection, rapid navigation và TV double-click → Teacher round-trip.
- Hint thật, Answer/full, Steps/previousStep, future step chưa disclosure không có trong DOM, knowledgeClose state.
- Computer Science Activity Cards, Algebra Reasoning Board fixture, Geometry Proof Board; router explicit/ambiguous/GENERIC và option count 2–5.
- Timing contract: MCQ thật A/B delay 80ms, C/D 128ms và finite 180ms; task/product fixture cách 100ms; progress 260ms; local reduced mode giữ answer.
- Geometry Scene giữ ảnh khi analysis/proof; Draw Board, Cover, Smart Geometry, Highlight, Focus, Pointer, zoom; overlay order giữ nguyên.
- Timer sync, whiteboard open/close, preset 70/30.
- Math Atomic toàn phương trình và bảy biểu thức yêu cầu.
- LIVE importer cho Tin6/Tin8/Hình học/demo.
- Offline Teacher→TV navigation sau khi tải local assets; không thêm CDN/dependency Internet.
- Demo gói thật import/navigation không auto-launch; explicit /launch rồi /return dùng mock UI/protocol, lesson index không đổi.

Motion harness có 18 nhóm kiểm tra:
- Review and transition: badge/main once, finite animations
- Actual MCQ C answer: unique accent/check; options stay visible
- Real pedagogy hint reveal
- Application screen steady on duplicate sync
- Algebra 1→2: only new step animated; existing step position stable
- Algebra final result static accent and single new-step reveal
- Word problem progression: one new disclosed card; no content replay
- Geometry analysis reveal: figure bounding box unchanged
- Geometry steps 0→1→2: no figure motion or resize
- Pinned 70/30 stable across proof disclosure
- New Smart/Highlight fade once; redraw and duplicate sync do not replay
- Focus activation, retarget and clear: real finite 180ms fade, target 1 / non-target .55; old step opacity restored
- Real geometry conclusion static emphasis
- Dependency tree: new disclosed node only; connector remains simple
- OS reduced motion: zero running animations, progress transition disabled, correct answer visible
- Motion OFF preserves hint/disclosure without animation
- Rapid Next/Previous: final state correct; no queued animation
- Unknown MCQ key: answer text preserved, no guessed correctness

## Phạm vi còn chờ

Đại số/word/tree là presentation fixture, không có gói Đại số thật trong baseline. Launcher files nguyên byte; UI/protocol mock không chứng minh Win32 native launch/return. Chrome/Edge Windows, TV thật và native occlusion chưa chạy. Cloud PASS không được đổi thành runtime/Production PASS.

Kết quả JSON ở TV_MOTION_EVIDENCE/regression/ và motion/. Bằng chứng baseline trước đây được giữ riêng, nguyên byte; manifest hiện hành là TV_MOTION_CHECKSUMS.sha256.
