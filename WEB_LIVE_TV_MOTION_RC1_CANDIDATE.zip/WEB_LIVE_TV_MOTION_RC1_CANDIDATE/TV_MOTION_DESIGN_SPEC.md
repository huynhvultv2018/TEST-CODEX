# TV MOTION DESIGN SPEC — RC1 CANDIDATE

Motion chỉ thuộc tầng trình bày TV. Subject Router, Activity Router, ba engine, nội dung lesson, schema, state sync, Teacher và Launcher dùng bản baseline nguyên byte. Tích hợp gồm stylesheet/script local trong `tv.html`, `TVMotion.begin()` trước render và `TVMotion.finish()` sau fitText trong `tv.js`. `tv-motion-adapter.js` đọc ngữ cảnh và đáp án đã công bố; `tv-motion.js` chỉ quản lý animation class/snapshot DOM.

## Tokens và timing

| Token | Giá trị |
|---|---|
| `--motion-fast` | 180ms |
| `--motion-normal` | 260ms |
| `--motion-slow` | 360ms |
| `--motion-distance-sm` | 6px |
| `--motion-distance-md` | 12px |
| `--motion-ease-out` | cubic-bezier(.2,.65,.3,1) |
| `--motion-ease-in-out` | cubic-bezier(.4,0,.2,1) |

Delay dùng token riêng: nhiệm vụ 80ms; hàng option sau 128ms; khoảng cách task/product 100ms. Không đặt animation inline.

| Sự kiện | Presentation |
|---|---|
| Screen vào | Badge từ -6px, 180ms; task từ +12px, 260ms, delay 80ms; hoàn tất 340ms |
| MCQ | A/B delay 80ms, C/D (và E nếu có) 128ms; 180ms, hoàn tất 308ms |
| Đáp án MCQ | Accent + nền nhẹ + ✓ tĩnh; emphasis 260ms một lần; giữ các option |
| Hint | Fade-up 6px/260ms; task neo ở đầu pane |
| Đại số/Hình học | Chỉ bước mới fade-up 6px/260ms; reveal full được nhóm một lần |
| Result/knowledge/conclusion | Accent tĩnh; text reveal nhẹ, không pulse loop |
| Application | Task bắt đầu 80ms, product 180ms, mỗi block 180ms; kết thúc 360ms |
| Smart/Classroom overlay mới | Fade 180ms, không animate figure |
| Focus | Target 1, non-target .55; opacity 180ms; khi clear trở về độ sáng baseline |
| Progress | Width transition 260ms |

## Ngân sách, state và redraw

Controller giới hạn hai nhóm hiệu ứng nổi bật cho mỗi lần áp dụng state. Entry gồm badge và nhóm nội dung/options; nhiều SVG paths của một dấu được xử lý cùng nhóm. Progress và chuyển màu Focus dùng cùng token ngắn. Không infinite iteration, bounce, spin, zoom, typewriter, flash hay hiệu ứng nền.

Screen identity gồm lesson, activation, source key, index và screen id. Ticket generation bỏ callback render đã cũ; chuyển screen hủy hiệu ứng trước. Không thêm animation state vào BroadcastChannel/postMessage. Duplicate sync không chạy lại bước/mark đã xuất hiện. Nếu DOM bị thay trước lần vẽ đầu tiên, controller chuyển reveal chưa bắt đầu sang node thay thế trong cửa sổ token ngắn; animationstart xóa intent đó. Không xếp hàng hiệu ứng.

Snapshot đọc text/region/index của bước đang được disclosure. Word/problem/tree chỉ reveal phần đã có trong state, không thêm suy luận hay nội dung tương lai. Đáp án MCQ dùng `correctOption`/`answerKey` A–E rõ ràng, nhãn trong đáp án đã hiện hoặc một option khớp text duy nhất. Khi không xác định được, vẫn giữ answer nguồn và không đoán option đúng.

## Stability và accessibility

Hình học dùng split 60/40 ổn định qua disclosure, giữ preset 70/30 của GV. Không đặt animation trên pic, figureInner, figurePane hoặc geometry scene. Dành sẵn chỗ cho connector Đại số và icon ✓; task neo phía trên thay vì recentre khi thêm hint/answer. Không animate width/height/top/left nội dung; ngoại lệ width progress. Emphasis một lần có inset shadow nhẹ.

`prefers-reduced-motion: reduce` tắt toàn bộ animation/transition TV, kể cả pseudo-element; text/state/icon/accent còn nguyên. API local `TVMotion.setMode('normal'|'reduced'|'off')` có sẵn; mặc định normal và vẫn tuân thủ OS. Không mở rộng Teacher settings trong RC1. Document hidden hủy motion và tắt CSS transition; native app phủ TV phải kiểm tra thật vì visibility API không bảo đảm phát hiện mọi dạng occlusion.

Trạng thái cuối: Candidate, chờ laptop + TV thật; không Production.
