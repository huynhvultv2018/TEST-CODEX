WEB LIVE V1.1.5 — TV DEMO HANDOFF CANDIDATE

1. Giải nén nguyên gói; Windows Display phải ở Extend mode. Mở WEB_LIVE/teacher.html trên laptop và WEB_LIVE/tv.html trên TV. Nạp LIVE.zip như bình thường.
2. Chạy START_WEB_LIVE.bat hoặc LAUNCHER/START_LAUNCHER.bat. Launcher chỉ mở dịch vụ localhost, tự ghép với tab Teacher hiện tại; không mở browser/teacher mới. Không đổi screen/lesson đang dạy.
3. Tại screen.demo, bấm ▶ DEMO TRỰC TIẾP và xác nhận. Launcher mở Word/GeoGebra và chuyển cửa sổ sang màn phụ, maximize trên TV. Trang tv.html ở dưới vẫn chạy, không bị reload.
4. Bấm ↩ TRỞ LẠI WEB LIVE trong panel Teacher để thu nhỏ ứng dụng. Bài trên TV trở lại đúng trạng thái. Có thể bấm DEMO tiếp để hiện lại cùng cửa sổ.
5. Nếu không có màn phụ, ứng dụng mở ở màn hiện tại và panel báo rõ. Nếu từ 3 màn hình, chọn tvMonitorIndex trong LAUNCHER/launcher-display.json theo danh sách màn hình in trên Launcher. Nếu app mở nhưng chưa chuyển được, bấm THỬ CHUYỂN LẠI.
6. Đặt đường dẫn Word/GeoGebra của máy trong LAUNCHER/launcher_apps.json. Tệp DOCX/GGB tin cậy đặt dưới LAUNCHER/demos/. Metadata demo trong lesson chỉ chứa appId và file tương đối.

Giữ cặp WEB_LIVE/runtime-config.js và LAUNCHER/launcher-config.json cùng gói. Không gửi khóa vào lesson, LIVE.zip hoặc TV. API chỉ nhận appId/file đã cho phép; không nhận HWND/PID/tọa độ từ browser. Kết nối offline qua 127.0.0.1:47381.

Máy Windows cần Python 3.10+ và py -3. BUILD_WINDOWS_EXE.bat chỉ là hướng dẫn build tại Windows với PyInstaller; ZIP này không chứa EXE. Bản candidate đã qua kiểm thử logic mô phỏng và hồi quy trên Linux, cần test TV/Word/GeoGebra thật trên Windows. KHÔNG NÂNG PRODUCTION.
