@echo off
cd /d "%~dp0"
if not exist "LAUNCHER\START_LAUNCHER.bat" (
  echo Khong tim thay LAUNCHER\START_LAUNCHER.bat trong goi WEB LIVE.
  pause
  exit /b 1
)
if not exist "WEB_LIVE\teacher.html" (
  echo Khong tim thay WEB_LIVE\teacher.html trong goi WEB LIVE.
  pause
  exit /b 1
)
call "LAUNCHER\START_LAUNCHER.bat"
