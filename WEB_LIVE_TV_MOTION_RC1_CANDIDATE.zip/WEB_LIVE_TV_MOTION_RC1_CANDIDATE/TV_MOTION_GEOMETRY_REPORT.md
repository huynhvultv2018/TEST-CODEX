# TV MOTION GEOMETRY REPORT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Geometry Proof Board và geometry scene/overlay source giữ nguyên byte. CSS mới cố định split 60/40 khi disclosure, giữ preset 70/30 của GV. Không animate figurePane, pic hay figureInner.

## Ảnh ổn định và reveal

Dùng HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST thật: màn index 9 “Chứng minh bằng nhau” có hai bước thực. Kiểm tra DOM lần lượt 0→1→2 proofStep, chỉ bước thứ hai có tv-motion-step trong clip; bbox ảnh trước/sau bằng nhau và mọi frame có pic/figureInner animation count 0. Analysis thật index 7 cũng giữ bbox ảnh khi thêm bước. Preset 70/30 giữ bbox qua hide/reveal.

Smart Geometry và Classroom Highlight mark mới fade 180ms. Redraw/duplicate sync không chạy lại mark đã vẽ. Node thay trước first paint giữ reveal chưa bắt đầu; geometry image không bị fade hoặc move. Không phát sinh metadata highlight đối tượng từ suy luận đoán.

Focus được kiểm tra trên proof thật hai bước: bật, đổi target, clear có animationstart 180ms; target opacity 1, non-target .55, clear khôi phục opacity bước cũ .82. Không đổi vị trí ảnh/card. Kết luận thật giữ accent tĩnh.

Dependency tree dùng fixture ghi rõ, chỉ node disclosed mới reveal và connector đơn giản; không animate cả cây. All-analysis thật gồm bốn bước + answer phù hợp cả bốn viewport. Draw Board, Cover, Pointer, Smart Geometry, zoom, overlay order, whiteboard và double-click round-trip giữ hoạt động theo regression.

Bằng chứng: 04_GEOMETRY_PROOF.webm/frame sequences, FOCUS_TARGET_0.png, GEO_PROOF/GEO_ANALYSIS bốn độ phân giải, regression results và extra-results. Hai ZIP Hình học thật được scan 69 màn, question/full không overflow.

Kết quả: cloud PASS trong ca đã chạy. Physical TV, độ rõ của fade overlay, Chrome/Edge Windows và native GeoGebra handoff/return còn chờ. Không sửa hình gốc, lesson, geometry scene hay overlay source.
