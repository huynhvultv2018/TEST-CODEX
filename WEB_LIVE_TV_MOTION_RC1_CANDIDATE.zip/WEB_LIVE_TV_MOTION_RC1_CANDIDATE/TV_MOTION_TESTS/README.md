# Tái chạy kiểm tra Motion RC1

Các harness dùng Node.js, Playwright và Chromium cài trên máy kiểm thử. Đây là dependency kiểm thử, không phải dependency chạy WEB LIVE. FFmpeg/ffprobe chỉ cần khi encode và kiểm tra WebM.

Từ thư mục Candidate, chạy server:

```sh
python -m http.server 8765 --bind 127.0.0.1 --directory .
```

Trong terminal khác:

```sh
node TV_MOTION_TESTS/rc1-regression.cjs
node TV_MOTION_TESTS/rc1-extra.cjs
node TV_MOTION_TESTS/motion.cjs
node TV_MOTION_TESTS/performance-accessibility.cjs
node TV_MOTION_TESTS/token-contract.cjs
python TV_MOTION_TESTS/encode-videos.py
```

Có thể đặt `CHROMIUM_PATH` cho binary Chromium và `WEB_LIVE_TEST_ROOT` cho thư mục Candidate. Các script ghi đè bằng chứng trong `TV_MOTION_EVIDENCE/`; không ghi vào lesson ZIP hay hồ sơ baseline. Tái chạy sau bàn giao sẽ cần tạo lại manifest checksum để xác minh bằng chứng mới.

`rc1-regression.cjs` kiểm tra năm gói thật, routing, disclosure, overlay, math, offline và bốn kích thước màn. `rc1-extra.cjs` kiểm tra schema edge cases, stale state, all-analysis và demo UI/protocol mock. `motion.cjs` kiểm tra animation events/timing, ảnh đứng yên, bước mới, duplicate sync, Focus, reduced/off, bấm chuyển nhanh và frame sequences. `performance-accessibility.cjs` lấy mẫu rAF trong lúc hint thật đang animate, lưu ảnh normal/reduced/off và mô phỏng document hidden.

Tin/Hình học dùng LIVE ZIP có sẵn. Đại số, word problem và dependency tree dùng fixture ghi rõ trong kết quả; fixture không được đóng thành lesson và không đại diện nội dung PPCT/SGK đã xác minh. token-contract.cjs xác minh timing của option thật, task/product fixture, progress và local reduced mode. Native Word/GeoGebra không được chạy trong cloud. Browser context và storage kiểm thử được cô lập.

`encode-videos.py` đọc timestamp từ kết quả motion thành FFconcat rồi encode VP9 VFR, không thêm frame nội suy; ffprobe và giải mã toàn bộ phải thành công. Video cần được encode lại sau mỗi lần tạo frame sequences mới.
