const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=process.env.WEB_LIVE_TEST_ROOT||path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 const ctx=await browser.newContext({viewport:{width:1366,height:768}}),errors=[];
 ctx.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
 await ctx.addInitScript(()=>{window.tokenEvents=[];document.addEventListener('animationstart',e=>{const s=getComputedStyle(e.target);tokenEvents.push({name:e.animationName,cls:e.target.className,text:e.target.textContent,duration:s.animationDuration,delay:s.animationDelay,iterations:s.animationIterationCount})},true)});
 const teacher=await ctx.newPage();await teacher.goto('http://127.0.0.1:8765/WEB_LIVE/teacher.html');
 const tv=await ctx.newPage();await tv.goto('http://127.0.0.1:8765/WEB_LIVE/tv.html');await tv.bringToFront();
 await teacher.locator('#zipfile').setInputFiles(root+'/RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip');await teacher.waitForFunction(()=>lesson?.subject==='Tin học 6');await teacher.evaluate(()=>go(1));await tv.waitForTimeout(450);
 await tv.evaluate(()=>tokenEvents=[]);await teacher.evaluate(()=>go(14));await tv.waitForTimeout(450);
 const options=await tv.evaluate(()=>tokenEvents.filter(e=>String(e.cls).includes('tv-motion-option')));
 assert.equal(options.length,4);for(const e of options){assert.equal(e.duration,'0.18s');assert.equal(e.iterations,'1');assert.equal(e.delay,/^[AB][.)]/u.test(e.text.trim())?'0.08s':'0.128s')}
 assert.equal(await tv.locator('#bar').evaluate(e=>getComputedStyle(e).transitionDuration),'0.26s');assert.equal(await tv.evaluate(()=>document.getAnimations().length),0);
 await tv.evaluate(()=>{tokenEvents=[];const l={id:'token-application',subject:'Tin học 6',title:'Presentation fixture',screens:[{id:'application',type:'APPLICATION',content:'Tìm thông tin về một nhân vật.\nSản phẩm: địa chỉ nguồn; ngày xem.'}]};localStorage.setItem('lesson:'+l.id,JSON.stringify(l));applyState({type:'state',lessonId:l.id,lessonActivation:l.id,stateVersion:1,index:0,total:1,lesson:l,answerMode:'hidden',viewMode:'text',classroom:{},board:{open:false,overlayScope:'token-test',whiteScope:'token-test'}})});await tv.waitForTimeout(450);
 const application=await tv.evaluate(()=>tokenEvents.filter(e=>String(e.cls).includes('tv-motion-main')));assert.equal(application.length,2);assert.deepEqual(application.map(e=>e.delay),['0.08s','0.18s']);assert(application.every(e=>e.duration==='0.18s'&&e.iterations==='1'));
 await tv.evaluate(()=>{TVMotion.setMode('reduced');tokenEvents=[]});await teacher.evaluate(()=>{go(14);toggleAnswer()});await tv.waitForTimeout(450);assert.equal(await tv.evaluate(()=>document.getAnimations().length),0);assert.equal(await tv.locator('.tv-answer-check').count(),1);assert.equal(await tv.locator('#bar').evaluate(e=>getComputedStyle(e).transitionDuration),'0s');assert.equal(errors.length,0);
 fs.writeFileSync(root+'/TV_MOTION_EVIDENCE/motion/token-contract.json',JSON.stringify({checks:['Actual MCQ A/B 80ms, C/D 128ms delay; 180ms finite reveal, total 308ms','Task/product fixture starts 100ms apart; total 360ms','Progress 260ms; local reduced mode zero animations with correct answer visible'],options,application,errors,fixtureNotice:'Task/product is presentation fixture; MCQ is actual TIN6_W04 package'},null,2));
 console.log('MCQ timing, task/product stagger, progress and local reduced mode contracts passed.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
