"""Encode timestamped browser PNG captures without interpolation or synthetic frames."""
import json
import os
from pathlib import Path
import subprocess

root = Path(os.environ.get('WEB_LIVE_TEST_ROOT', Path(__file__).resolve().parents[1]))
out = root / 'TV_MOTION_EVIDENCE' / 'motion'
results = json.loads((out / 'results.json').read_text())
metadata = []
for sequence in results['videos']:
    directory = out / sequence['name']
    samples = sequence['samples']
    lines = ['ffconcat version 1.0']
    for i, sample in enumerate(samples):
        duration = (samples[i + 1]['t'] - sample['t']) / 1000 if i + 1 < len(samples) else .5
        assert duration > 0
        lines.extend([f"file '{sample['frame']:02d}.png'", f'duration {duration:.6f}'])
    lines.append(f"file '{samples[-1]['frame']:02d}.png'")
    (directory / 'frames.ffconcat').write_text('\n'.join(lines) + '\n')
    video = out / (sequence['name'] + '.webm')
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat',
                    '-safe', '1', '-i', str(directory / 'frames.ffconcat'), '-fps_mode', 'vfr',
                    '-c:v', 'libvpx-vp9', '-crf', '36', '-b:v', '0', '-threads', '2',
                    '-pix_fmt', 'yuv420p', str(video)], check=True)
    probe = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries',
                        'format=duration,size:stream=codec_name,width,height', '-of', 'json', str(video)]))
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-i', str(video),
                    '-f', 'null', '-'], check=True)
    metadata.append({'file': video.name, 'source': sequence['source'], 'capturedFrames': len(samples),
                     'captureMethod': 'Timestamped PNG sequence, variable frame rate, no interpolation',
                     'ffprobe': probe, 'decode': 'PASS'})
(out / 'video-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))
