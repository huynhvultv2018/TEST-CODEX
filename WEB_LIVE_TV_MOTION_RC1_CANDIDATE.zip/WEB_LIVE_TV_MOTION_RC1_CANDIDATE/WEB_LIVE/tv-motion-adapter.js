/* Presentation adapter: read disclosed source answers; never solve, write or sync lessons. */
const TVMotionAdapter=(()=>{
 function context(lesson,screen,state){return{
  key:[state.lessonId,state.lessonActivation||'',state.lessonSourceKey||'',state.index,screen.id??''].join('|'),
  scope:[state.lessonId,state.lessonActivation||'',state.sceneId||state.index].join('|')
 };}
 function disclosure(screen,state){
  const cards=Array.from(document.querySelectorAll('#content .tvOptionCard'));
  const labels=cards.map((node,i)=>node.textContent.trim().match(/^([A-E])[.)]/u)?.[1]||String.fromCharCode(65+i));
  let correct=null;
  // Correctness is only presented when the teacher has disclosed the full answer.
  if(state.answerMode==='full'&&cards.length){
   for(const value of [screen.correctOption,screen.answerKey]){
    if(typeof value==='string'&&/^[A-E]$/u.test(value.trim())&&labels.includes(value.trim())){correct=value.trim();break;}
   }
   const visibleAnswer=document.getElementById('answer').textContent.trim();
   const explicit=visibleAnswer.match(/^(?:Đáp án\s*[:：]?\s*)?([A-E])(?:[.)]|\s*[:：])(?:\s|$)/iu)?.[1]?.toUpperCase();
   if(!correct&&explicit&&labels.includes(explicit))correct=explicit;
   if(!correct){
    const clean=text=>text.trim().replace(/^[A-E][.)]\s*/u,'').replace(/[.;\s]+$/gu,'').toLocaleLowerCase('vi');
    const exact=cards.map((node,i)=>clean(node.textContent)===clean(visibleAnswer)?labels[i]:null).filter(Boolean);
    if(exact.length===1)correct=exact[0];
   }
  }
  return{correctOption:correct,labels};
 }
 return {context,disclosure};
})();
