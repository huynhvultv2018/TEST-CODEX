/* Local presentation motion. No lesson routing, writes, timers or sync messages. */
const TVMotion=(()=>{
 const node=id=>document.getElementById(id),root=document.documentElement;
 const classes=['tv-motion-enter','tv-motion-badge','tv-motion-main','tv-motion-option','tv-motion-step','tv-motion-answer','tv-motion-highlight','tv-motion-focus-in','tv-motion-focus-out'];
 const active=new Map(),overlayKeys=new Map(),unpainted=new Map();
 root.dataset.tvMotionVisibility=document.visibilityState;
 const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
 let mode='normal',previous=null,context=null,generation=0,entering=false,effects=0;
 function enabled(){return mode==='normal'&&!preference.matches&&document.visibilityState!=='hidden';}
 function visible(el){return !!el&&!el.hidden&&getComputedStyle(el).display!=='none'&&!!el.getClientRects().length;}
 const text=el=>el?.textContent||'';
 function snapshot(){return{
  key:context?.key,main:visible(node('content'))?text(node('content')):'',
  hint:visible(node('hint'))?text(node('hint')):'',answer:visible(node('answer'))?text(node('answer')):'',
  steps:new Set(Array.from(document.querySelectorAll('#answer .proofStep,#analysis .analysisStep')).filter(visible).map(stepKey)),
  cards:new Set(Array.from(document.querySelectorAll('.tvWordProblemGrid .tvLabeledBlock,.tvApplicationGrid .tvLabeledBlock')).filter(visible).map(text)),
  focusKey:Array.from(document.querySelectorAll('.focusBlock.isFocused')).filter(visible).map(stepKey).sort().join('||'),
  focusStates:new Map(Array.from(document.querySelectorAll('.focusBlock')).filter(visible).map(el=>[stepKey(el),focusOpacity(el)]))
 };}
 function stepKey(el){return [el.dataset.focusRegion,el.dataset.focusIndex,text(el)].join('|');}
 function focusOpacity(el){
  if(el.closest('.hasFocus'))return el.classList.contains('isFocused')?1:.55;
  if(el.classList.contains('previous'))return el.classList.contains('analysisStep')?.84:.82;
  return 1;
 }
 function clear(el){
  el.classList.remove(...classes);const handler=active.get(el);if(handler)el.removeEventListener('animationend',handler);active.delete(el);
 }
 function cancel(){for(const el of Array.from(active.keys()))clear(el);unpainted.clear();}
 function identity(el){return [el.id,el.tagName,el.dataset.focusRegion,el.dataset.focusIndex,text(el)].join('|');}
 function animate(el,cls,record){
  if(!enabled()||!visible(el))return;
  clear(el);el.classList.add(cls);
  if(cls!=='tv-motion-highlight')unpainted.set(identity(el),record||{cls,at:performance.now()});
  const done=event=>{if(event.target===el)clear(el)};active.set(el,done);el.addEventListener('animationend',done);
 }
 function group(items){
  const targets=items.filter(item=>visible(item.el));
  if(!enabled()||effects>=2||!targets.length)return;
  effects++;targets.forEach(item=>animate(item.el,item.cls,item.record));
 }
 function begin(next){
  generation++;effects=0;entering=previous?.key!==next.key;
  if(entering)cancel();
  if(context?.scope!==next.scope)overlayKeys.clear();
  context=next;root.dataset.tvMotionMode=mode;
  // Replaced children lose their CSS animation; never replay an old step to compensate.
  for(const el of Array.from(active.keys()))if(!el.isConnected)clear(el);
  return generation;
 }
 function correctAnswer(info){
  const cards=Array.from(document.querySelectorAll('#content .tvOptionCard'));
  cards.forEach((card,index)=>{
   const correct=!!info.correctOption&&info.labels[index]===info.correctOption;
   card.classList.toggle('tv-answer-correct',correct);
   const old=card.querySelector('.tv-answer-check');
   if(!correct){old?.remove();return;}
   if(!old){const check=document.createElement('span');check.className='tv-answer-check';check.textContent='✓';check.setAttribute('aria-label','Đáp án đúng');card.appendChild(check);}
  });
 }
 function finish(ticket,info={labels:[],correctOption:null}){
  if(ticket!==generation)return;
  for(const el of Array.from(active.keys()))if(!el.isConnected)clear(el);
  correctAnswer(info);
  const current=snapshot(),old=previous;
  if(entering){
   const pane=document.querySelector('.textPane');pane?.classList.add('tv-motion-enter');
   group([{el:node('activityBadge'),cls:'tv-motion-badge'}]);
   const options=Array.from(document.querySelectorAll('#content .tvOptionCard'));
   if(options.length&&visible(node('content'))){
    options.forEach((card,i)=>{card.dataset.tvMotionRow=i>=2?'later':'first'});
    group([{el:document.querySelector('.tvQuestion'),cls:'tv-motion-main'},...options.map(el=>({el,cls:'tv-motion-option'}))]);
   }else{
    const products=Array.from(document.querySelectorAll('.tvApplicationGrid .tvLabeledBlock'));
    if(products.length>1){products.forEach((card,i)=>{card.dataset.tvMotionOrder=i?'product':'task'});group(products.map(el=>({el,cls:'tv-motion-main'})));}
    else group([{el:node('content'),cls:'tv-motion-main'}]);
   }
  }else{
   if(current.main&&!old?.main)group([{el:node('content'),cls:'tv-motion-main'}]);
   if(current.hint&&current.hint!==old?.hint)group([{el:node('hint'),cls:'tv-motion-main'}]);
   const newSteps=Array.from(document.querySelectorAll('#answer .proofStep,#analysis .analysisStep')).filter(el=>visible(el)&&!old?.steps.has(stepKey(el)));
   if(newSteps.length){
    // A full reveal is one grouped event; progressive reveal targets only the newly added step.
    if(newSteps.length===1)group([{el:newSteps[0],cls:'tv-motion-step'}]);
    else group([{el:newSteps[0].parentElement,cls:'tv-motion-answer'}]);
   }else if(current.answer&&current.answer!==old?.answer){
    const selected=document.querySelector('.tv-answer-correct');group([{el:selected||node('answer'),cls:'tv-motion-answer'}]);
   }
   const newCards=Array.from(document.querySelectorAll('.tvWordProblemGrid .tvLabeledBlock,.tvApplicationGrid .tvLabeledBlock')).filter(el=>visible(el)&&!old?.cards.has(text(el)));
   group(newCards.map(el=>({el,cls:'tv-motion-main'})));
   if(current.focusKey!==old?.focusKey){
    const changed=Array.from(document.querySelectorAll('.focusBlock')).filter(el=>{
     const key=stepKey(el);return visible(el)&&old?.focusStates.has(key)&&old.focusStates.get(key)!==current.focusStates.get(key);
    });
    group(changed.map(el=>({el,cls:focusOpacity(el)===.55?'tv-motion-focus-out':'tv-motion-focus-in'})));
   }
  }
  // A duplicate render can replace new content before its first paint. Carry
  // only that unstarted reveal to the replacement; never replay a painted step.
  const windowMs=parseFloat(getComputedStyle(root).getPropertyValue('--motion-slow'))||0;
  for(const [key,record] of unpainted)if(performance.now()-record.at>=windowMs)unpainted.delete(key);
  const replacements=Array.from(document.querySelectorAll('#activityBadge,#content,#hint,#answer,.tvQuestion,.tvOptionCard,.proofStep,.analysisStep,.tvLabeledBlock,.focusBlock')).map(el=>({el,record:unpainted.get(identity(el))})).filter(item=>item.record&&visible(item.el)&&!item.el.classList.contains(item.record.cls)).map(item=>({...item,cls:item.record.cls}));
  group(replacements);
  if(current.answer){node('answer').classList.add('tv-result-emphasis');}else node('answer').classList.remove('tv-result-emphasis');
  previous=current;entering=false;
 }
 function overlayKey(el,index,svg){
  const id=el.getAttribute('data-smart-id');
  if(id)return id+'|'+el.tagName+'|'+index;
  const box=svg.viewBox.baseVal,w=box.width||1,h=box.height||1;
  const attrs=Array.from(el.attributes).filter(a=>['class','points','x1','x2','y1','y2','cx','cy','d'].includes(a.name)).map(a=>{
   if(a.name==='class')return a.value.split(' ').filter(c=>!c.startsWith('tv-motion')).join(' ');
   if(['x1','x2','cx'].includes(a.name))return a.name+':'+(Number(a.value)/w).toFixed(5);
   if(['y1','y2','cy'].includes(a.name))return a.name+':'+(Number(a.value)/h).toFixed(5);
   if(a.name==='points')return a.value.trim().split(/\s+/u).map(pair=>pair.split(',').map((n,i)=>(Number(n)/(i?h:w)).toFixed(5)).join(',')).join(' ');
   return a.name+':'+a.value;
  });return el.tagName+'|'+attrs.join('|');
 }
 function overlays(svg){
  const children=Array.from(svg.children),keys=children.map((el,i)=>overlayKey(el,i,svg));
  const old=overlayKeys.get(svg)||new Map(),records=new Map(),targets=[];
  const budget=parseFloat(getComputedStyle(root).getPropertyValue('--motion-fast'))||0;
  children.forEach((el,i)=>{
   const rec=old.get(keys[i])||{started:entering,authorized:false,at:performance.now()};records.set(keys[i],rec);
   if(!entering&&!rec.started&&performance.now()-rec.at<budget){
    const started=()=>{rec.started=true;el.removeEventListener('animationstart',started)};
    el.addEventListener('animationstart',started);
    if(rec.authorized)animate(el,'tv-motion-highlight');else targets.push({el,cls:'tv-motion-highlight'});
   }
  });
  // Retag only a replacement that has not reached its first paint. Once started,
  // an existing mark remains static on redraw; it never replays its reveal.
  group(targets);
  for(const item of targets){const rec=records.get(overlayKey(item.el,children.indexOf(item.el),svg));rec.authorized=item.el.classList.contains('tv-motion-highlight');if(!rec.authorized)rec.started=true;}
  overlayKeys.set(svg,records);
 }
 for(const id of ['smartLayer','classroomHighlight']){
  const svg=node(id);if(svg)new MutationObserver(()=>overlays(svg)).observe(svg,{childList:true});
 }
 document.addEventListener('animationstart',event=>{const key=identity(event.target),record=unpainted.get(key);if(record&&event.target.classList.contains(record.cls))unpainted.delete(key);},true);
 function setMode(value){if(!['normal','reduced','off'].includes(value))return;mode=value;root.dataset.tvMotionMode=value;if(!enabled())cancel();}
 preference.addEventListener('change',()=>{if(!enabled())cancel()});
 document.addEventListener('visibilitychange',()=>{root.dataset.tvMotionVisibility=document.visibilityState;if(!enabled())cancel()});
 node('bar')?.classList.add('tv-motion-progress');
 return {begin,finish,cancel,setMode,get mode(){return mode},get effectCount(){return effects}};
})();
