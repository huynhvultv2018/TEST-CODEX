# TV MOTION ALGEBRA REPORT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Math Reasoning Board và Math Atomic nguyên source. Baseline không cung cấp gói LIVE Đại số thực; tất cả nội dung Đại số trong evidence được ghi là fixture kiểm thử presentation, không là bài học/SGK được xác minh.

## Ca chuyển bước

Fixture equation dùng 2x - 5 = 9 → 2x = 14 → x = 7. Khi state từ một bước sang hai rồi ba bước, chỉ một node mới có animation 260ms/6px. Bbox của card bước cũ trước/sau bằng nhau. Chỗ connector ↓ được dành sẵn từ bước đầu để card cũ không đổi chiều cao khi có bước tiếp theo. Result có accent tĩnh, không pulse loop.

Word problem fixture có progression Đặt ẩn/Điều kiện/Biểu diễn/Phương trình. Chỉ phần đã disclosure được render; update một bước không replay các card đã hiện. Full answer có thể reveal nhóm một lần; future step không có trong DOM ở state một bước. Dependency/word progression không tạo nội dung hay suy luận mới.

## Regression và evidence

- 03_ALGEBRA_STEP.webm + chín PNG timestamped; events xác nhận một tv-motion-step mới.
- Equation/word motion ở bốn độ phân giải: không overflow khi đang và sau reveal.
- Regression fixture expression, equation, system, word problem, identity, table, graph, practice; routing factorization/statistics/probability/proof đạt.
- Bảy biểu thức atomic AB > BC, AB = CD, AB ∥ CD, AH ⟂ BD, △ABC ≅ △DEF, x = 2, 2x + 3 = 7 giữ nguyên một expression trong kiểm tra.
- Reduced/off dùng chung controller/CSS, giữ disclosure và accent; không thêm state sync.

Kết quả: presentation cloud PASS trên fixture; lesson Đại số thực và runtime Chrome/Edge Windows/TV PENDING. Không sửa Math Atomic, engine, lesson schema hay nội dung nguồn.
