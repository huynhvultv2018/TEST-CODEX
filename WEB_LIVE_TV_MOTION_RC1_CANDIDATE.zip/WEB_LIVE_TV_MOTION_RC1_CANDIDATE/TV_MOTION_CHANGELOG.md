# TV MOTION CHANGELOG — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Baseline: WEB LIVE TV MULTI ENGINE RC1 CANDIDATE, SHA-256 2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c. Không quay lại RC4/RC3 để phát triển.

## Source thay đổi

- WEB_LIVE/tv.html: nạp ba file motion local, stylesheet sau tv-ui và script trước tv.js.
- WEB_LIVE/tv.js: thêm begin trước render và finish sau fitText bằng generation ticket; không thay business routing/sync.
- WEB_LIVE/tv-motion.css (mới): shared tokens, semantic finite animations, progress/Focus, reduced/off/hidden, fixed geometry split, task anchor, connector/check space.
- WEB_LIVE/tv-motion.js (mới): DOM snapshot/diff, chỉ bước/card mới, hai nhóm budget, cancel rapid nav, unpainted-reveal carry qua duplicate render, SVG mark fade một lần, local motion modes.
- WEB_LIVE/tv-motion-adapter.js (mới): đọc screen identity và đáp án MCQ đã disclosure từ nguồn rõ ràng; không giải bài/ghi lesson/gửi sync.

## Vấn đề phát hiện và đã sửa

- Connector Đại số mới làm card cũ đổi chiều cao: dành sẵn chỗ từ bước đầu.
- Proof disclosure đổi split làm ảnh resize: giữ 60/40 hoặc preset 70/30 ổn định.
- Redraw trước first paint làm mất reveal: chuyển intent chưa bắt đầu sang node thay thế, không replay phần đã vẽ.
- Focus CSS transition mất khi thay DOM: trigger opacity animation ngắn khi bật/đổi/clear; duplicate sync không bỏ first reveal.
- Check icon có nguy cơ đổi layout: đặt absolute và dành padding từ đầu.
- MCQ answer trước đó ẩn option: giữ option để đối chiếu, đã kiểm tra overflow với answer/hint.

## Bàn giao

Thêm README Motion, chín báo cáo, test harness, 112 PNG, bốn WebM từ 36 frame thật, events/timing/bbox JSON, baseline hash audit và checksum hiện hành. WebM đã ffprobe/giải mã toàn bộ thành công. Candidate không có thay đổi trong source engine/Teacher/Launcher/pedagogy/math/lesson ZIP hoặc hồ sơ Multi Engine lịch sử.

Cloud: 171 màn thật, 342 state, 24 ca motion ở bốn viewport, reduced/off/visibility mock, UI demo mock đạt. Dừng ở WEB LIVE TV MOTION SYSTEM RC1 CANDIDATE; runtime Windows + TV thật, native demo và lesson Đại số thật còn chờ. Không Production.
