# TV MOTION ACCESSIBILITY REPORT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Bắt buộc prefers-reduced-motion: reduce đã tích hợp. Rule tắt animation và transition trên toàn bộ TV, cả ::before/::after. Mode local reduced/off có cùng hành vi; mặc định normal vẫn tôn trọng OS. Không bổ sung Teacher settings trong phạm vi RC1.

## Kết quả đã kiểm tra

- OS reduced: không running animation; progress transitionDuration 0s; đáp án đúng C và ✓ vẫn rõ.
- Motion off: hint/disclosure còn hiện, không motion; accent/check không phụ thuộc animation.
- Local mode reduced cũng được kiểm tra trực tiếp: không animation, progress 0s và ✓ còn hiện.
- ACCESS_NORMAL.png, ACCESS_REDUCED.png, ACCESS_OFF.png đối chiếu cùng đáp án thật.
- Focus: target 1, non-target .55, finite 180ms, không blur; clear phục hồi state/baseline opacity.
- Các animationstart ghi trong clips/Focus có iterations 1, duration tối đa 260ms; CSS không có infinite, flash, bounce hoặc spin.
- Document visibility hidden được mô phỏng: CSS animations/transitions 0; sync state vẫn áp dụng. Native window phủ TV không được coi là đã kiểm tra thật.

State được truyền bằng text, icon ✓ có aria-label “Đáp án đúng”, border/nền accent và disclosure hiện có. Không dùng motion làm nguồn thông tin duy nhất; khi không có đáp án xác định thì không đoán highlight. Không thay nội dung lesson hay tương tác Teacher.

Kết quả cloud PASS cho reduced/off/state retention. Đây không phải audit accessibility toàn diện hay chứng nhận WCAG. Độ dễ đọc từ lớp học, cảm nhận distraction và native occlusion cần runtime laptop/TV thật.
