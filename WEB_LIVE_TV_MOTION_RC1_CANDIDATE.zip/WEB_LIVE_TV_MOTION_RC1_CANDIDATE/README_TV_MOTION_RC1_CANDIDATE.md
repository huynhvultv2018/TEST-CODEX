# WEB LIVE TV MOTION SYSTEM RC1 CANDIDATE

Trạng thái: **CANDIDATE — chờ runtime test trên laptop Windows + TV thật. Không nâng Production.**

Bản này phát triển duy nhất từ `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`, SHA-256:

`2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`

TV có motion nhẹ cho badge, nhiệm vụ, lựa chọn, đáp án, gợi ý và bước suy luận. Hình hình học giữ nguyên vị trí khi hiện bước; overlay mới fade một lần. Reduced motion theo cài đặt hệ điều hành giữ nguyên trạng thái đáp án/gợi ý.

## Chạy thử

Giải nén toàn bộ thư mục. Dùng `START_WEB_LIVE.bat` và cách mở Teacher/TV của baseline. Import các LIVE ZIP có sẵn; thao tác Hint, Answer, Bước + và Next/Previous như trước. Không cần dịch vụ motion hoặc tài nguyên Internet mới.

## Hồ sơ hiện tại

- Chín báo cáo `TV_MOTION_*.md` ở thư mục gốc.
- `TV_MOTION_EVIDENCE/index.html`: gallery ảnh và bốn WebM, mở bằng trình duyệt.
- `TV_MOTION_EVIDENCE/motion/results.json`: timing, animation events, kích thước hình, 24 ca kiểm tra motion ở bốn độ phân giải.
- `TV_MOTION_EVIDENCE/regression/`: kết quả 171 màn từ năm gói LIVE và ảnh regression.
- `TV_MOTION_EVIDENCE/baseline-audit.json`: đối chiếu byte với baseline; 142/144 file giữ nguyên, chỉ hai file tích hợp TV có delta.
- `TV_MOTION_TESTS/`: harness kiểm tra và script encode WebM.
- `TV_MOTION_CHECKSUMS.sha256`: manifest xác minh **bản Motion hiện tại**. Các manifest, README và báo cáo RC3/RC4/Multi Engine được giữ nguyên làm hồ sơ lịch sử; không dùng chúng để xác minh source Motion đã thay đổi.

WebM được encode từ frame PNG chụp trình duyệt có timestamp; không nội suy frame. Đây là bằng chứng reveal/state, không phải đo video liên tục 60fps.

## Runtime test còn chờ

Chạy Chrome và Edge trên laptop Windows cấu hình trung bình, nối TV thật; kiểm tra độ mượt và độ dễ đọc ở bốn độ phân giải, reduced motion, bấm chuyển nhanh, ảnh hình học, demo Word/GeoGebra và trở về WEB. Cloud chỉ kiểm tra hợp đồng UI/protocol demo bằng mock và mô phỏng visibility; chưa xác minh native handoff/occlusion thực tế. Baseline không có gói LIVE Đại số thực, nên các ca Đại số trong hồ sơ là fixture trình bày, cần kiểm tra thêm bằng lesson thật.

Dừng ở Candidate sau bàn giao.
