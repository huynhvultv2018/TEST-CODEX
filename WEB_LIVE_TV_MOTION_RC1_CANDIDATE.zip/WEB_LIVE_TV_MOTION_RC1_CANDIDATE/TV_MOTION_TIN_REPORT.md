# TV MOTION TIN REPORT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Tin học dùng COMPUTER_SCIENCE Activity Cards nguyên source. Màn review/intro vào có badge một lần, task sau 80ms. Option A/B rồi C/D dùng delay 80/128ms, mỗi hàng 180ms; tổng 308ms. Các card giữ nguyên sau ĐÁP ÁN để học sinh đối chiếu.

Kiểm tra thật trên TIN6_W04: màn index 14, đáp án nguồn C được đánh dấu đúng duy nhất bằng border/nền accent và ✓; answer text vẫn giữ nguyên. Adapter chỉ dùng metadata A–E rõ ràng, nhãn đáp án đã hiện hoặc khớp text option duy nhất. Ca nguồn mơ hồ không đánh dấu đoán. Chỉ full answer mới đánh dấu, không tiết lộ khi hidden/hint/steps.

Hint pedagogy thật reveal 260ms; Main task neo ở đầu pane. Application có product dùng task trước product 100ms, mỗi reveal 180ms; timing được kiểm tra bằng fixture có nhãn Sản phẩm. Màn Application thật không thêm product do nguồn không cung cấp; duplicate sync không replay. Knowledge chỉ reveal khi state cho phép, không đưa nội dung đóng vào DOM. Practical/demo fixture giữ semantics routing; demo instruction dùng reveal chung của TV.

## Bằng chứng

- Clip 01_SCREEN_TRANSITION và 02_MCQ_ANSWER; mỗi clip có chín PNG kèm timestamp/events.
- MCQ_ANSWER và HINT tại 1920×1080, 1600×900, 1366×768, 1280×720: không overflow khi đang/đã reveal.
- TIN6_W04 (41 màn), TIN6_W05 (32 màn), TIN8_W04 (29 màn) được scan question/full.
- Các option count 2–5, application task/product, knowledge disclosure, hint toggle, demo import và stale-state rejection đạt.
- token-contract.json ghi bốn animationstart option thật, duration 180ms/delay 80–128ms; fixture application delay 80/180ms; local mode reduced giữ đáp án/✓.
- Normal, OS reduced và off vẫn giữ ✓/đáp án thật; không truyền thông tin chỉ qua animation.

Kết quả: cloud PASS trong các ca đã chạy. Subject/activity router, pedagogy, PPCT/SGK, nội dung ZIP và Teacher nguyên byte. Độ mượt và độ dễ đọc trên TV lớp học, Chrome/Edge Windows, Word native demo còn chờ runtime test.
