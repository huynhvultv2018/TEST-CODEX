# TV MOTION AUDIT — RC1

Ngày kiểm tra cloud: 2026-10-02 UTC. Chromium 151.0.7922.173 / Linux headless / Playwright.

**Trạng thái: CANDIDATE; cloud checks PASS, chờ laptop Windows + TV thật. Không Production.**

Baseline duy nhất: WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip; SHA-256 2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c. ZIP gốc được giữ nguyên. Đối chiếu từng file trong baseline: 144 file, 142 file nguyên byte, chỉ WEB_LIVE/tv.html và WEB_LIVE/tv.js thay đổi để nối motion. Source ba engine, router, Teacher, Launcher, importer, sync, pedagogy, math và toàn bộ lesson ZIP giữ nguyên byte. Chi tiết hash từng file: TV_MOTION_EVIDENCE/baseline-audit.json; delta tích hợp: source-diff.patch.

Thêm ba module local: tv-motion.css (tokens/stability), tv-motion.js (controller presentation) và tv-motion-adapter.js (đọc đáp án/ngữ cảnh đã công bố). Không viết lesson, thay schema hoặc gửi motion state qua sync. Hồ sơ Multi Engine và bằng chứng cũ được giữ nguyên riêng; hồ sơ Motion là kết quả hiện tại.

## Acceptance

| # | Tiêu chí | Kết quả và phạm vi |
|---|---|---|
| 1 | Chuyển màn nhẹ | Cloud: badge 180ms, main 260ms + delay 80ms; clip 01 |
| 2 | Main reveal | Cloud: fade-up 12px khi vào; hint/step 6px |
| 3 | MCQ đúng | Cloud: đáp án C từ nguồn thật, accent/✓; không đoán nguồn mơ hồ |
| 4 | Hint | Cloud: hint thật reveal 260ms, task neo trên |
| 5 | Algebra chỉ bước mới | Cloud: fixture 1→2→3; một animation mới, card cũ giữ bbox |
| 6 | Hình đứng yên | Cloud: proof thật hai bước, bbox ảnh bằng nhau; không animation pic/figureInner |
| 7 | Geometry highlight | Cloud: mark mới fade 180ms một lần; duplicate redraw không replay |
| 8 | Conclusion/knowledge | Cloud: reveal nhẹ và accent tĩnh, không pulse |
| 9 | Progress | Cloud: width transition 260ms; reduced/off tắt transition |
| 10 | Reduced motion | Cloud: OS reduced và off không chạy animation, disclosure/✓ còn nguyên |
| 11 | Stability | Cloud: bbox card Đại số cũ và ảnh Hình học ổn định trong ca chuyển bước |
| 12 | Không scrollbar mới | Cloud: 342 trạng thái thật và 24 ca motion không overflow đo được |
| 13 | 1366×768 mượt trên máy trung bình | Mẫu rAF cloud có motion đạt; laptop Windows/TV thật PENDING |
| 14 | TV sync | Cloud: Teacher→TV, stale-state rejection và navigation/offline đạt |
| 15 | Demo Handoff | Cloud: import/navigation/UI launch-return mock đạt; Win32/native PENDING |
| 16 | Lesson không đổi | ZIP lesson nguyên byte; object lesson giữ nguyên qua scan năm gói |
| 17 | Offline | Cloud: tài nguyên local, ngoại mạng bị chặn; navigation sau load đạt |

Đã lưu 112 PNG mới, bốn WebM giải mã thành công và JSON events/timing/bbox. Không coi ảnh tĩnh hoặc video frame sequence là chứng minh 60fps. Đại số/word/tree dùng fixture trình bày ghi rõ, chưa có gói LIVE Đại số thật trong baseline.

## Điều kiện trước khi kết luận runtime PASS

Kiểm tra Chrome/Edge Windows trên laptop cấu hình trung bình + TV thật, cả bốn độ phân giải; độ mượt, đọc từ cuối lớp, thao tác nhanh, reduced motion, các lesson Đại số thật và native Word/GeoGebra handoff/return/occlusion. Dừng ở Candidate; không nâng Production.
