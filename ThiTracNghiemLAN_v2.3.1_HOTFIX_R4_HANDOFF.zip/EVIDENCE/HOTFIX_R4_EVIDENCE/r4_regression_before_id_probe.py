"""Raw CSRF negatives, semantic restore/scoring corruption and historical contract A."""
import copy,hashlib,importlib.util,json,math,re,shutil,sqlite3,traceback
from io import BytesIO
from pathlib import Path
from flask import template_rendered
from openpyxl import load_workbook
from r4_support import arguments,runtime,sql,dump,seed,attempt,form_answers,token,ValidClient

def main():
    args=arguments();results=[];evidence={}
    def check(name,fn):
        try:results.append(dict(name=name,status='PASS',detail=fn()))
        except Exception:results.append(dict(name=name,status='FAIL',traceback=traceback.format_exc()))
        print(name,results[-1]['status'],flush=True)
    with runtime(args.source,args.output) as (m,teacher,root):
        from scoring import grade,total_score,config
        from snapshot_validation import SnapshotValidationError
        definitions={}
        for k in ('SINGLE','MULTI','TF','MATCH','FILL'):
            row,f=seed(m,teacher,'VALID_'+k,k,subject='BASE_'+k,weights='1,3' if k in ('TF','MATCH','FILL') else '')
            definitions[k]=(row,f)
        clean=root/'clean.db';m.create_sqlite_backup(clean);clean_hash=hashlib.sha256(clean.read_bytes()).hexdigest()

        def unchanged_scoring():
            path=Path('/workspace/preprod-r3-baseline/PHAN_MEM/scoring.py');spec=importlib.util.spec_from_file_location('r3_reference_scoring',path);reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
            values={'SINGLE':[0,1,None,'0',False],'MULTI':[[0],[0,2],[0,1,2],[],[0,0],None,[-1],[99]],'TF':[['D','S'],['D',''],['','S'],['',''],None],'MATCH':[[1,0],[1,None],[None,0],[],None],'FILL':[[' HAI ','ba'],['2',''],['','3'],['',''],None]}
            answers={'SINGLE':0,'MULTI':[0,2],'TF':['D','S'],'MATCH':[1,0],'FILL':[['hai','2'],['ba','3']]};count=0
            for kind in values:
                for mode in ('all','partial'):
                    for points in (.001,1,4,1000):
                        for weights in ([],[1,3]) if kind in ('TF','MATCH','FILL') else ([],):
                            item=dict(type=kind,options=['A','B','C'] if kind in ('SINGLE','MULTI') else ['A','B'],answer=answers[kind],scoring=config(dict(points=points,scoring_mode=mode,weights=','.join(map(str,weights))),kind,2))
                            for value in values[kind]:
                                a,b=grade(item,value);assert (a,b)==reference.grade(item,value);assert math.isfinite(a) and 0<=a<=b
                                assert total_score([item],{0:value})==reference.total_score([item],{0:value});count+=1
            assert grade(dict(type='SINGLE',answer=0),0)==(1,1)
            assert grade(dict(type='TF',answer=['D','S'],scoring=dict(points=4,mode='partial')),['D',''])==(2,4)
            return dict(reference_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),equal_cases=count,legacy_defaults_preserved=True)
        check('F010_valid_formula_equal_to_locked_R3',unchanged_scoring)

        malformed=[]
        for name,kind,answer,rule in [
            ('MULTI_empty','MULTI',[],dict(points=1,mode='partial')),
            ('zero_weights','TF',['D','S'],dict(points=1,mode='partial',weights=[0,0])),
            ('negative_weights','TF',['D','S'],dict(points=1,mode='partial',weights=[-1,2])),
            ('negative_points','SINGLE',0,dict(points=-1)),
            ('NaN_points','SINGLE',0,dict(points=float('nan'))),
            ('Infinity_points','SINGLE',0,dict(points=float('inf'))),
            ('missing_points','TF',['D','S'],dict(mode='partial')),
            ('wrong_mode','SINGLE',0,dict(points=1,mode='bad')),
            ('version1_missing_mode','SINGLE',0,dict(version=1,points=1,weights=[])),
            ('version1_missing_weights','SINGLE',0,dict(version=1,points=1,mode='all')),
            ('bad_weight_shape','TF',['D','S'],dict(points=1,mode='partial',weights=[1])),
            ('bad_answer','SINGLE',{},dict(points=1)),
            ('bad_FILL','FILL',[[],['yes']],dict(points=1)),
            ('huge_integer','SINGLE',0,dict(points=10**500))]:
            malformed.append((name,dict(type=kind,options=['A','B'],answer=answer,scoring=rule)))
        def pure_rejects():
            rows=[]
            for name,item in malformed+[('non_mapping','bad'),('missing_answer',dict(type='SINGLE',scoring=dict(points=1)))]:
                for scorer in (grade,total_score):
                    try:scorer(item,[]) if scorer is grade else scorer([item],{0:[]})
                    except SnapshotValidationError as error:rows.append(dict(name=name,scorer=scorer.__name__,controlled_error=str(error)))
                    else:raise AssertionError((name,scorer.__name__))
            return rows
        check('F010_pure_corruption_controlled_rejection',pure_rejects)

        def corrupted_runtime():
            rows=[]
            cases=malformed+[('not_json','{broken'),('not_list',dict(type='SINGLE')),('deep_json','['*2000+']'*2000)]
            for i,(name,item) in enumerate(cases):
                student,aid,eid,data=attempt(m,teacher,'CORRUPT_'+str(i),subject='BASE_SINGLE')
                if name=='not_list':text=json.dumps(item)
                elif isinstance(item,str):text=item
                else:text=json.dumps([{**data[0],**item}])
                sql(m,'UPDATE bai_thi SET de_json=? WHERE id=?',(text,aid))
                before=[dict(r) for r in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))]
                bt=dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0])
                statuses=[student.get('/exam').status_code,student.post('/api/save-answer',json={'index':0,'choice':0}).status_code,student.post('/exam',data={'q_0':'0'}).status_code]
                assert statuses==[400,400,400],(name,statuses)
                assert [dict(r) for r in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))]==before
                assert dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0])==bt
                sql(m,'UPDATE bai_thi SET submitted_at=?,diem=10 WHERE id=?',(m.now_text(),aid))
                exports=[teacher.get(f'/teacher/report/{eid}/points').status_code,teacher.get(f'/teacher/report/{eid}').status_code,teacher.get(f'/teacher/report/{eid}/export').status_code,teacher.get(f'/teacher/api/monitor/{eid}').status_code]
                assert exports==[400]*4,(name,exports)
                rows.append(dict(name=name,GET_save_submit=statuses,points_report_export_monitor=exports,attempt_and_answers_not_changed=True))
            return rows
        check('F010_runtime_no_500_no_commit_on_invalid_snapshot',corrupted_runtime)

        def db_dump():
            c=m.db()
            try:return '\n'.join(c.iterdump())
            finally:c.close()
        def restore_semantics():
            rows=[]
            for i,(name,item) in enumerate(malformed):
                source=root/('bad_'+name+'.db');shutil.copyfile(clean,source)
                c=sqlite3.connect(source);qid=definitions['SINGLE'][0]['id'];payload={k:v for k,v in item.items() if k!='type'}
                c.execute('UPDATE cau_hoi SET question_type=?,payload=? WHERE id=?',(item['type'],json.dumps(payload),qid));c.commit();assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close()
                source_hash=hashlib.sha256(source.read_bytes()).hexdigest();nonce=token(teacher.raw);before=db_dump()
                r=teacher.raw.post('/teacher/restore',headers={'X-CSRF-Token':nonce},data={'file':(BytesIO(source.read_bytes()),source.name)},content_type='multipart/form-data')
                assert r.status_code==302 and db_dump()==before
                with teacher.session_transaction() as s:messages=s.get('_flashes',[])
                assert any('Không khôi phục' in message for _,message in messages)
                assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
                rows.append(dict(name=name,SQLite_integrity='ok',response=302,active_DB_unchanged=True,source_DB_unchanged=True))
            # Snapshot semantic corruption in a structurally sound backup must also reject.
            for label,text in [('malformed_snapshot','{bad'),('deep_snapshot','['*2000+']'*2000),('non_mapping_snapshot','[null]')]:
                source=root/(label+'.db');shutil.copyfile(clean,source);c=sqlite3.connect(source)
                c.execute('INSERT INTO bai_thi(ky_thi_id,ma_hs,ho_ten,lop,started_at,deadline_at,de_json) VALUES(1,?,?,?,?,?,?)',('RESTORE_BAD','Fixture','8A',m.now_text(),m.now_text(),text));c.commit();assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';c.close()
                nonce=token(teacher.raw);before=db_dump();digest=hashlib.sha256(source.read_bytes()).hexdigest()
                response=teacher.raw.post('/teacher/restore',headers={'X-CSRF-Token':nonce},data={'file':(BytesIO(source.read_bytes()),source.name)},content_type='multipart/form-data')
                assert response.status_code==302 and db_dump()==before and hashlib.sha256(source.read_bytes()).hexdigest()==digest
                rows.append(dict(name=label,SQLite_integrity='ok',active_DB_unchanged=True,source_DB_unchanged=True))
            # Saved backup route uses the same preflight and preserves its source.
            saved=m.BACKUP_DIR/'bad_saved.db';shutil.copyfile(root/'bad_zero_weights.db',saved);before=db_dump();source_hash=hashlib.sha256(saved.read_bytes()).hexdigest()
            assert teacher.post('/teacher/backup/restore/bad_saved.db').status_code==302 and db_dump()==before and hashlib.sha256(saved.read_bytes()).hexdigest()==source_hash
            # Valid backup still activates normally; no invalid-data repair was applied.
            assert teacher.post('/teacher/restore',data={'file':(BytesIO(clean.read_bytes()),'valid.db')},content_type='multipart/form-data').status_code==302
            assert not sql(m,"SELECT id FROM hoc_sinh WHERE ma_hs LIKE 'CORRUPT_%'")
            assert hashlib.sha256(clean.read_bytes()).hexdigest()==clean_hash
            rows.append(dict(name='valid_restore',accepted=True,original_backup_unchanged=True));return rows
        check('F010_restore_integrity_pass_semantics_fail_preserves_active_DB',restore_semantics)
        def legacy_restore():
            source=root/'legacy.db';shutil.copyfile(clean,source);c=sqlite3.connect(source)
            qid=definitions['MULTI'][0]['id'];payload=json.loads(c.execute('SELECT payload FROM cau_hoi WHERE id=?',(qid,)).fetchone()[0]);payload.pop('scoring');c.execute('UPDATE cau_hoi SET payload=? WHERE id=?',(json.dumps(payload),qid));c.commit();c.close()
            source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
            assert teacher.post('/teacher/restore',data={'file':(BytesIO(source.read_bytes()),'legacy.db')},content_type='multipart/form-data').status_code==302
            student,aid,eid,data=attempt(m,teacher,'LEGACY_RESTORE',subject='BASE_MULTI',kind='MULTI')
            assert 'scoring' not in data[0] and student.post('/exam',data=form_answers(data,{0:data[0]['answer']})).status_code==302
            assert sql(m,'SELECT diem FROM bai_thi WHERE id=?',(aid,))[0][0]==10
            assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
            return dict(valid_legacy_restore=True,no_rule_default_1_all_score=10,no_backup_mutation=True)
        check('F010_legacy_restore_no_scoring_rule_remains_valid',legacy_restore)


        def csrf_route_matrix():
            student,aid,eid,data=attempt(m,teacher,'CSRF_STUDENT',subject='BASE_SINGLE');inventory=[]
            paths=[]
            for rule in sorted(m.app.url_map.iter_rules(),key=lambda r:r.rule):
                methods=sorted(set(rule.methods)&{'POST','PUT','PATCH','DELETE'})
                if methods:
                    path=re.sub(r'<(?:int:)?(?:eid|qid|sid|uid|attempt_id)>','999999',rule.rule);path=path.replace('<path:name>','missing.db')
                    paths.append((path,methods));inventory.append(dict(path=rule.rule,methods=methods,csrf_guard='global protect_csrf; no exclusions'))
            assert len(paths)==35,len(paths) # R3 34 plus POST logout replacing its old GET.
            rows=[]
            for path,methods in paths:
                client=student.raw if path.startswith('/api/') or path=='/exam' or path=='/' else teacher.raw
                nonce=token(client);before=db_dump()
                for method in methods:
                    for scenario,headers in [('missing',{}),('wrong',{'X-CSRF-Token':'wrong'}),('unicode_wrong',{'X-CSRF-Token':'sai dấu'}),('foreign_valid_token',{'X-CSRF-Token':nonce,'Origin':'http://foreign.invalid'}),('foreign_referer_valid_token',{'X-CSRF-Token':nonce,'Referer':'http://foreign.invalid/page'})]:
                        r=client.open(path,method=method,headers=headers)
                        assert r.status_code==403,(path,scenario,r.status_code)
                        assert db_dump()==before,(path,scenario,'database changed')
                    rows.append(dict(path=path,method=method,missing_wrong_unicode_foreign_rejected=403,no_database_change=True))
            evidence['route_inventory']=inventory
            before=db_dump();assert teacher.get('/teacher/logout').status_code==405 and db_dump()==before
            with teacher.session_transaction() as s:assert s['teacher_logged_in']
            assert student.raw.post('/exam',data={'q_0':'0'}).status_code==403 and sql(m,'SELECT submitted_at FROM bai_thi WHERE id=?',(aid,))[0][0] is None
            assert student.post('/api/save-answer',json={'index':0,'choice':data[0]['answer']}).status_code==200
            assert student.post('/api/ping').status_code==200
            assert student.post('/exam',data=form_answers(data,{0:data[0]['answer']})).status_code==302
            assert sql(m,'SELECT diem FROM bai_thi WHERE id=?',(aid,))[0][0]==10 and '10.0/10' in student.get('/result').get_data(as_text=True)
            # Form-field transport and pre-auth login are protected too, with rotation.
            anonymous=m.app.test_client();preauth=token(anonymous)
            assert anonymous.post('/teacher/login',data={'username':'admin','password':'123456'}).status_code==403
            assert anonymous.post('/teacher/login',data={'username':'admin','password':'123456','csrf_token':preauth}).status_code==302
            after=token(anonymous);assert preauth!=after
            assert anonymous.post('/teacher/student/add',data={'ma_hs':'OLD_NONCE','ho_ten':'Test','lop':'8A','csrf_token':preauth}).status_code==403
            assert anonymous.post('/teacher/student/add',data={'ma_hs':'FORM_NONCE','ho_ten':'Test','lop':'8A','csrf_token':after}).status_code==302
            assert anonymous.post('/teacher/logout',data={'csrf_token':after}).status_code==302
            with anonymous.session_transaction() as s:assert not s.get('teacher_logged_in') and not s.get('_csrf_token')
            return dict(routes=rows,teacher_login_rotation=True,HTML_field_transport=True,student_save_ping_submit_result=10,GET_logout_no_longer_mutates=True)
        check('F011_all_35_routes_missing_wrong_foreign_nonce_rejected',csrf_route_matrix)

        def historical_contract():
            row,form=seed(m,teacher,'HISTORY','SINGLE',subject='HISTORY',text='BEFORE_NB',points='4',mode='all')
            student,aid,eid,data=attempt(m,teacher,'HISTORY_OLD',subject='HISTORY')
            assert student.post('/exam',data=form_answers(data,{0:data[0]['answer']})).status_code==302
            def capture(label):
                captured={}
                def receiver(sender,template,context,**kw):
                    if template.name=='report.html':captured.update(context)
                template_rendered.connect(receiver,m.app)
                try:r=teacher.get(f'/teacher/report/{eid}')
                finally:template_rendered.disconnect(receiver,m.app)
                assert r.status_code==200;(args.output/(label+'.html')).write_bytes(r.data)
                r=teacher.get(f'/teacher/report/{eid}/export');assert r.status_code==200;(args.output/(label+'.xlsx')).write_bytes(r.data)
                wb=load_workbook(BytesIO(r.data),data_only=False);sheets={ws.title:[list(x) for x in ws.iter_rows(values_only=True)] for ws in wb};wb.close()
                return dict(qstats=captured['qstats'],levels=captured['levels'],avg=captured['avg'],legacy_count=captured['historical_missing'],sheets=sheets)
            before=capture('history_before');bt=dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0]);answers=[dict(x) for x in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))]
            edit={**form,'ma_cau':'CHANGED','mon':'OTHER','chu_de':'OTHER_TOPIC','muc_do':'VD','noi_dung':'AFTER_VD','points':'9'}
            assert teacher.post(f"/teacher/multi/edit/{row['id']}",data=edit).status_code==302
            after=capture('history_after');assert before==after
            assert dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0])==bt and [dict(x) for x in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))]==answers
            assert before['qstats'][0]['text']=='BEFORE_NB' and before['qstats'][0]['cognitive']=='NB' and before['legacy_count']==0
            assert before['sheets']['PhanTichCauHoi'][1][:5]==['HISTORY','HISTORY','Chủ đề, có dấu phẩy','NB','BEFORE_NB']
            # Same exam and question ID, later login after editing: separate historical groups.
            assert teacher.post('/teacher/student/add',data={'ma_hs':'HISTORY_NEW','ho_ten':'New','lop':'8A'}).status_code==302
            # Exam subject must match bank to admit the later attempt; do not change older metadata.
            sql(m,'UPDATE ky_thi SET mon=?,nb_count=0,vd_count=1 WHERE id=?',('OTHER',eid))
            quotas=json.loads(sql(m,'SELECT type_quotas FROM ky_thi WHERE id=?',(eid,))[0][0]);quotas['SINGLE']={'VD':1};sql(m,'UPDATE ky_thi SET type_quotas=? WHERE id=?',(json.dumps(quotas),eid))
            second=ValidClient(m.app.test_client());assert second.post('/',data={'ma_hs':'HISTORY_NEW','ky_thi_id':str(eid)}).location.endswith('/exam')
            with second.session_transaction() as s:second_id=s['attempt_id']
            newer=json.loads(sql(m,'SELECT de_json FROM bai_thi WHERE id=?',(second_id,))[0][0]);assert second.post('/exam',data=form_answers(newer,{0:newer[0]['answer']})).status_code==302
            mixed=capture('history_two_versions');assert len(mixed['qstats'])==2 and {x['text'] for x in mixed['qstats']}=={'BEFORE_NB','AFTER_VD'} and mixed['levels']['NB']['attempts']==mixed['levels']['VD']['attempts']==1
            # Legacy: delete only new metadata in test fixture, never consult current bank.
            legacy=copy.deepcopy(data);legacy[0].pop('history');sql(m,'UPDATE bai_thi SET de_json=? WHERE id=?',(json.dumps(legacy),aid));legacy_text=sql(m,'SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0]
            known_score=sql(m,'SELECT diem FROM bai_thi WHERE id=?',(aid,))[0][0];old=capture('history_legacy');legacy_rows=[x for x in old['qstats'] if x['history_missing']]
            assert len(legacy_rows)==1 and legacy_rows[0]['text']=='BEFORE_NB' and legacy_rows[0]['cognitive']=='Không rõ (legacy)' and legacy_rows[0]['code']=='Không rõ (legacy)'
            assert old['legacy_count']==1 and 'thiếu phân loại tại thời điểm thi' in (args.output/'history_legacy.html').read_text()
            assert sql(m,'SELECT de_json,diem FROM bai_thi WHERE id=?',(aid,))[0][:]==(legacy_text,known_score)
            assert any(r[0]=='Không rõ (legacy)' for r in old['sheets']['TheoMucDo'])
            return dict(before=before,after=after,byte_metadata_equal=True,stored_score_snapshot_answers_unchanged=True,two_versions=mixed,legacy=old,legacy_not_backfilled=True)
        check('F012_snapshot_UI_Excel_versions_and_legacy_unknown',historical_contract)
    dump(args.output/'results.json',dict(results=results,evidence=evidence));return int(any(x['status']!='PASS' for x in results))

if __name__=='__main__':raise SystemExit(main())
