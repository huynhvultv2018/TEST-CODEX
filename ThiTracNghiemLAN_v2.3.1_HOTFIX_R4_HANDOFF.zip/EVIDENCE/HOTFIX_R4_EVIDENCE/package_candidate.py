"""Lock final source/test provenance and create the R4 source archive once."""
import ast
import difflib
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path('/workspace/TEST-CODEX')
E = ROOT / 'HOTFIX_R4_EVIDENCE'
SOURCE = ROOT / 'hotfix-r4-candidate'
BASELINE = ROOT / 'ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip'
EXPECTED = 'f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a'
CANDIDATE = ROOT / 'ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, obj):
    (E / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

assert sha(BASELINE.read_bytes()) == EXPECTED, 'BASELINE_MISMATCH'
assert not CANDIDATE.exists(), 'Do not overwrite an existing candidate'
with zipfile.ZipFile(BASELINE) as z:
    assert z.testzip() is None
    original = {n: z.read(n) for n in z.namelist() if not n.endswith('/')}
current = {p.relative_to(SOURCE).as_posix(): p.read_bytes() for p in SOURCE.rglob('*') if p.is_file()}
assert not (original.keys() - current.keys())
changed = [n for n in sorted(current) if original.get(n) != current[n]]
assert changed == json.loads((E / 'changed-files.json').read_text())
patch = []
for name in changed:
    patch.extend(difflib.unified_diff(original.get(name, b'').decode().splitlines(True), current[name].decode().splitlines(True), fromfile='R3/' + name, tofile='R4/' + name))
(E / 'R3_to_R4.patch').write_text(''.join(patch))
tests = [n for n in original if n.startswith('PHAN_MEM/kiem_tra_') and n.endswith('.py')]
assert len(tests) == 6 and all(original[n] == current[n] for n in tests)
write('final-source-provenance.json', dict(baseline_sha256=EXPECTED, baseline_files=len(original), working_tree_files=len(current), changed_files=changed, original_tests=[dict(path=n, sha256=sha(current[n]), byte_identical=True) for n in tests], file_hashes={n:sha(b) for n,b in sorted(current.items())}))

# Preserve byte-identical upstream harnesses in the handoff for review/reproduction.
upstream = ['HOTFIX_R1_EVIDENCE/hotfix_regression.py', 'HOTFIX_R1_EVIDENCE/run_original_checks.py', 'HOTFIX_R1_EVIDENCE/comma_browser.py', 'HOTFIX_R2_EVIDENCE/r2_regression.py', 'HOTFIX_R2_EVIDENCE/normalized_browser.py', 'HOTFIX_R3_EVIDENCE/r3_regression_ui_observer.py']
upstream += ['V2.3.1_AUDIT_EVIDENCE/' + n for n in ['audit_checks.py', 'legacy_checks.py', 'race_probe.py', 'browser_checks.py']]
record = []
for name in upstream:
    target = E / 'upstream-harnesses' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
    assert (ROOT / name).read_bytes() == target.read_bytes()
    record.append(dict(path=name, sha256=sha(target.read_bytes()), byte_identical=True))
write('upstream-harness-provenance.json', record)

summary = []
for name in ['r1-final/results.json','r2-final/results.json','r3-verified/results.json','r4-verified/results.json','original-final/audit-checks.json','original-final/legacy-checks.json']:
    rows = json.loads((E / name).read_text())['results']
    assert rows and all(x['status'] == 'PASS' for x in rows), name
    summary.append(dict(evidence=name, groups=len(rows), status='PASS'))
rows = json.loads((E / 'original-final/runner-results.json').read_text())['results']
assert len(rows) == 10 and all(x['exit_code'] == 0 for x in rows)
for row in rows:
    if row['kind'] == 'original_test':
        name = 'PHAN_MEM/' + row['script']
        assert row['source_sha256'] == sha(original[name]) == sha(current[name])
    else:
        assert row['unchanged'] and row['source_sha256'] == sha((ROOT / 'V2.3.1_AUDIT_EVIDENCE' / row['script']).read_bytes())
summary.append(dict(evidence='original-final/runner-results.json', groups=6, status='PASS', note='Six original scripts; four audit harness outcomes counted separately.'))
for name in ['original-final/race-probe.json','original-final/browser-checks.json','browser-csrf-final/results.json','comma-browser/results.json','normalized-browser/results.json']:
    assert json.loads((E / name).read_text())['status'] == 'PASS'
    summary.append(dict(evidence=name, groups=1, status='PASS'))
assert sum(x['groups'] for x in summary) == 93
raw = json.loads((E / 'r3-initial/results.json').read_text())['results']
assert sum(x['status'] == 'FAIL' for x in raw) == 1
adapt = json.loads((E / 'r3-fixture-adaptation.json').read_text())
def assertions(path):
    return [ast.dump(n, include_attributes=False) for n in ast.walk(ast.parse(path.read_text())) if isinstance(n, ast.Assert)]
assert assertions(ROOT / adapt['original']) == assertions(ROOT / adapt['adapted'])
write('final-verification-summary.json', dict(final_groups=93, final_summary=summary, raw_original_R3=dict(PASS=14, FAIL=1, evidence='r3-initial/results.json', reason='F008 fixture expects post-exam bank edits in historical report; conflicts with explicitly selected contract A.'), R3_contract_A_fixture=dict(PASS=15, FAIL=0, assertion_count=61, assertions_unchanged=True, original_test_file_unchanged=True), no_skips_or_xfails=True))

# Four inherited compiled caches belong to the modified modules. Keep originals
# on disk; omit obsolete bytecode from the new source package only.
excluded = sorted(n for n in current if '__pycache__' in Path(n).parts or n.endswith('.pyc'))
assert len(excluded) == 4 and all(original[n] == current[n] for n in excluded)
members = sorted(current.keys() - set(excluded))
assert len(members) == 59
assert not any(n.endswith('.zip') or Path(n).name in ('.session_secret','thi_trac_nghiem.db') for n in members)
with zipfile.ZipFile(CANDIDATE, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in members:
        z.write(SOURCE / name, name)
with zipfile.ZipFile(CANDIDATE) as z:
    assert z.testzip() is None and z.namelist() == members
    assert all(z.read(n) == current[n] for n in members)
assert sha(BASELINE.read_bytes()) == EXPECTED
assert sha((ROOT / 'CHECKSUMS.sha256').read_bytes()) == '5164dd12b8e9c405e52039763f4668f0951a27b76f4dbaa84148cf878704056a'
data = dict(path=str(CANDIDATE), bytes=CANDIDATE.stat().st_size, sha256=sha(CANDIDATE.read_bytes()), member_count=len(members), members=members, excluded_inherited_bytecode=excluded, excluded_files_not_deleted=True, all_members_match_verified_source=True, CRC='PASS', no_nested_baseline_or_runtime_data=True, baseline_sha256=EXPECTED, original_R1_checksum_file_unchanged=True)
write('candidate-package-validation.json', data)
print(json.dumps({k:v for k,v in data.items() if k not in ('members','excluded_inherited_bytecode')}, indent=2))
