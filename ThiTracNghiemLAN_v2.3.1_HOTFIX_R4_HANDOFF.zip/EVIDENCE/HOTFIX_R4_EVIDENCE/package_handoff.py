"""Package existing candidate, reports and complete R4 evidence without overwrite."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path('/workspace/TEST-CODEX')
E = ROOT / 'HOTFIX_R4_EVIDENCE'
SOURCE = ROOT / 'hotfix-r4-candidate'
STAGE = ROOT / 'HOTFIX_R4_HANDOFF_CONTENTS'
NAME = 'ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_HANDOFF.zip'
REPORTS = ['CHANGELOG','TEST_REPORT','REGRESSION_REPORT','SECURITY_REPORT','HISTORY_REPORT','DIFF_SUMMARY','FINDINGS']
REPORTS = ['HOTFIX_R4_' + n + '.md' for n in REPORTS]

def sha(data):
    return hashlib.sha256(data).hexdigest()

candidate = json.loads((E / 'candidate-package-validation.json').read_text())
zip_candidate = Path(candidate['path'])
assert sha(zip_candidate.read_bytes()) == candidate['sha256']
assert not (ROOT / NAME).exists() and not STAGE.exists(), 'Do not overwrite a handoff'
provenance = json.loads((E / 'final-source-provenance.json').read_text())
assert all(sha((SOURCE / name).read_bytes()) == expected for name,expected in provenance['file_hashes'].items())

rows = []
for name in provenance['changed_files']:
    if name.endswith('/app.py'):
        finding, detail = 'F010/F011/F012', 'Runtime/restore validation; global CSRF/session nonce; POST logout; historical report aggregation.'
    elif name.endswith('/multi_routes.py'):
        finding, detail = 'F010', 'Read stored payload through question_data before editor/export.'
    elif name.endswith('/question_types.py'):
        finding, detail = 'F010/F012', 'Validate bank source before snapshot; append only four historical metadata fields.'
    elif name.endswith('/scoring.py'):
        finding, detail = 'F010', 'Validate stored input and finite result bounds; preserve existing formula/config/rounding.'
    elif name.endswith('/snapshot_validation.py'):
        finding, detail = 'F010/F012', 'New shared semantic validator, controlled exception; validate optional historical metadata shape.'
    elif name.endswith('/templates/report.html'):
        finding, detail = 'F012', 'Small legacy metadata warning and unknown-level row.'
    elif name.endswith('/templates/base.html'):
        finding, detail = 'F011', 'Expose current nonce in HTML meta for fetch clients.'
    elif name.endswith('/templates/exam.html'):
        finding, detail = 'F011', 'Hidden submit token and CSRF headers on autosave/ping.'
    elif name.endswith('/templates/monitor.html'):
        finding, detail = 'F011', 'Hidden nonce in JavaScript-created unlock POST form.'
    elif name.endswith('/templates/teacher.html') or name.endswith('/templates/license.html'):
        finding, detail = 'F011', 'Nonce in POST forms; change logout link to POST form.'
    else:
        finding, detail = 'F011', 'Hidden nonce in existing POST forms only.'
    rows.append('| `' + name + '` | ' + finding + ' | ' + detail + ' |')
diff = '''# HOTFIX ROUND 4 — DIFF SUMMARY

HOTFIX_R4 = PASS. So sánh trực tiếp với ZIP R3 khóa hash, không lấy audit source làm baseline.

- Baseline SHA-256: `''' + candidate['baseline_sha256'] + '''`.
- R4 candidate SHA-256: `''' + candidate['sha256'] + '''`.
- Candidate: ''' + str(candidate['bytes']) + ''' byte, ''' + str(candidate['member_count']) + ''' file, CRC PASS, tất cả member byte-identical với source đã kiểm.
- 23 file hiện có được sửa (4 Python, 19 template), thêm 1 module validation: tổng 24 file. Không sửa test gốc, cấu hình, schema, version, công thức hoặc các module khác.

## Truy nguyên thay đổi

| File | Finding | Lý do |
|---|---|---|
''' + '\n'.join(rows) + '''

Patch chính xác: `EVIDENCE/HOTFIX_R4_EVIDENCE/R3_to_R4.patch`; hash từng file trước/sau trong `baseline-lock.json` và `final-source-provenance.json`. `preserved-invariants.json` ghi các hàm/schema/scoring config giữ AST. Không có thay đổi tracked source ngoài artifact commit.

## Đóng gói

R3 có 62 file gồm bốn `.pyc` kế thừa; working tree R4 có 63 file. Candidate R4 chỉ chứa 59 file source/tài nguyên/test cần chạy: bỏ khỏi ZIP mới bốn cache của app/multi_routes/question_types/scoring đã sửa, giữ nguyên file gốc trên disk. Không xử lý finding LOW/INFO nào từ việc này. ZIP mới không có baseline ZIP lồng, database runtime, secret, file test tạm hoặc cache.

Checksum của candidate cùng mọi báo cáo/bằng chứng nằm ở `CHECKSUMS.sha256` gốc HANDOFF, theo đúng đường dẫn CANDIDATE/REPORTS/EVIDENCE. Không ghi đè manifest R1 ở workspace. Handoff hash được cung cấp riêng vì không thể đưa hash của chính ZIP vào chính ZIP đó.

## Test provenance

Sáu test gốc và upstream harness byte-identical. Adapter positive-client chỉ gửi nonce thực, không miễn CSRF. R3 gốc raw 14 PASS/1 FAIL được giữ; scenario fixture chuẩn bị marker trước lúc thi PASS 15/15 với 61 assertion không đổi. Đọc TEST_REPORT trước khi diễn giải trạng thái regression.

Chưa triển khai Production, không bump version, không làm R5.
'''
(ROOT / 'HOTFIX_R4_DIFF_SUMMARY.md').write_text(diff)

shutil.copyfile('/workspace/attachments/e5981466-89c9-4ae3-bcad-3606ce4882b1/Văn bản đã dán.txt', E / 'USER_REQUEST.txt')
(E / 'packaging-preflight-note.json').write_text(json.dumps(dict(initial_error='KeyError: unchanged', stage='package_candidate.py provenance preflight, before candidate creation', cause='Original test runner records source_sha256 for six scripts, whereas only four audit harness rows have an unchanged key.', correction='Compare all original script hashes against both locked baseline bytes and final source; retain explicit unchanged check for audit harnesses.', source_or_test_result_changed=False, final_candidate_validation='PASS'), indent=2)+'\n')

files_evidence = sorted(p for p in E.rglob('*') if p.is_file())
assert not any('__pycache__' in p.parts or p.suffix == '.pyc' for p in files_evidence)
planned = ['CANDIDATE/' + zip_candidate.name] + ['REPORTS/' + n for n in REPORTS] + ['EVIDENCE/HOTFIX_R4_EVIDENCE/' + p.relative_to(E).as_posix() for p in files_evidence]
assert len(planned) == len(set(planned))
STAGE.mkdir()
(STAGE / 'CANDIDATE').mkdir()
(STAGE / 'REPORTS').mkdir()
shutil.copyfile(zip_candidate, STAGE / 'CANDIDATE' / zip_candidate.name)
for name in REPORTS:
    assert (ROOT / name).is_file() and (ROOT / name).stat().st_size > 0
    shutil.copyfile(ROOT / name, STAGE / 'REPORTS' / name)
shutil.copytree(E, STAGE / 'EVIDENCE' / 'HOTFIX_R4_EVIDENCE')
assert sorted(p.relative_to(STAGE).as_posix() for p in STAGE.rglob('*') if p.is_file()) == sorted(planned)
manifest = {name:sha((STAGE / name).read_bytes()) for name in sorted(planned)}
(STAGE / 'CHECKSUMS.sha256').write_text(''.join(value + '  ' + name + '\n' for name,value in manifest.items()))

with zipfile.ZipFile(ROOT / NAME, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(STAGE.rglob('*')):
        if p.is_file():
            z.write(p, p.relative_to(STAGE).as_posix())
with zipfile.ZipFile(ROOT / NAME) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(manifest) + 1
    assert set(z.namelist()) == set(manifest) | {'CHECKSUMS.sha256'}
    assert all(sha(z.read(name)) == expected for name,expected in manifest.items())
    assert sha(z.read('CANDIDATE/' + zip_candidate.name)) == candidate['sha256']
    assert z.read('CHECKSUMS.sha256') == (STAGE / 'CHECKSUMS.sha256').read_bytes()
    assert all(z.read(n) == (STAGE / n).read_bytes() for n in z.namelist())

assert sha((ROOT / 'ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip').read_bytes()) == candidate['baseline_sha256']
assert sha((ROOT / 'CHECKSUMS.sha256').read_bytes()) == '5164dd12b8e9c405e52039763f4668f0951a27b76f4dbaa84148cf878704056a'
output = dict(status='PASS', path=str(ROOT / NAME), bytes=(ROOT / NAME).stat().st_size, sha256=sha((ROOT / NAME).read_bytes()), file_count=len(manifest)+1, candidate_sha256=candidate['sha256'], candidate_bytes=candidate['bytes'], report_count=len(REPORTS), evidence_files=len(files_evidence), checksum_entries=len(manifest), all_checksums_match=True, all_zip_members_match_staging=True, CRC='PASS', existing_R3_candidate_and_R1_checksums_unchanged=True)
(ROOT / 'HOTFIX_R4_PACKAGE_VALIDATION.json').write_text(json.dumps(output, indent=2)+'\n')
print(json.dumps(output, indent=2))
