"""Opt-in client transport for unchanged pre-CSRF regression scripts.

It fetches the real HTML nonce and sends it as a header. The application guard
is never changed/disabled, and original assertions/tests remain byte-identical.
Negative/security probes run without this opt-in module.
"""
import os
if os.environ.get('TNLAN_R4_VALID_CLIENT') == '1':
    import re
    from flask.testing import FlaskClient
    from werkzeug.datastructures import Headers
    original_open = FlaskClient.open

    def nonce(text):
        match = re.search(r'<meta name="csrf-token" content="([^"]+)"', text)
        if not match:
            raise AssertionError('Valid-client transport could not obtain the application nonce.')
        return match.group(1)

    def valid_open(self, *args, **kwargs):
        if kwargs.get('method','GET').upper() in ('POST','PUT','PATCH','DELETE'):
            headers=Headers(kwargs.get('headers'))
            if 'X-CSRF-Token' not in headers:
                page=original_open(self,'/teacher/login',method='GET')
                headers['X-CSRF-Token']=nonce(page.get_data(as_text=True))
            kwargs['headers']=headers
        return original_open(self,*args,**kwargs)

    FlaskClient.open=valid_open
    try:
        from playwright.sync_api import APIRequestContext
        from urllib.parse import urlsplit
        original_post=APIRequestContext.post

        def valid_post(self,url,**kwargs):
            headers=dict(kwargs.get('headers') or {})
            if not any(k.lower()=='x-csrf-token' for k in headers):
                address=urlsplit(url)
                page=self.get(address.scheme+'://'+address.netloc+'/teacher/login')
                headers['X-CSRF-Token']=nonce(page.text())
            kwargs['headers']=headers
            return original_post(self,url,**kwargs)

        APIRequestContext.post=valid_post
    except ImportError:
        pass
