"""New R2 browser scenario: normalized legacy metadata plus comma topic; original browser harness remains untouched."""
import os,sys,tempfile,shutil,json,threading,traceback,argparse
from pathlib import Path
from playwright.sync_api import sync_playwright
from waitress import create_server

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True);out={'status':'FAIL','checks':[],'errors':[],'external_requests':[]}
    topic='Chủ đề, có dấu phẩy'
    with tempfile.TemporaryDirectory(prefix='tnlan_r1_comma_browser_') as tmp:
        p=Path(tmp);shutil.copytree(args.source,p/'app',ignore=shutil.ignore_patterns('__pycache__'))
        os.environ['LOCALAPPDATA']=str(p/'localappdata');sys.path.insert(0,str(p/'app'))
        import app as m
        m.init_db();server=create_server(m.app,host='127.0.0.1',port=0,threads=12);threading.Thread(target=server.run,daemon=True).start();url=f'http://127.0.0.1:{server.effective_port}'
        try:
            with sync_playwright() as pw:
                browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);context=browser.new_context(viewport={'width':1440,'height':1000})
                def local_only(route):
                    if route.request.url.startswith(url):route.continue_()
                    else:out['external_requests'].append(route.request.url);route.abort()
                context.route('**/*',local_only);page=context.new_page();page.on('pageerror',lambda e:out['errors'].append(str(e)))
                page.goto(url+'/teacher/login');page.fill('[name=username]','admin');page.fill('[name=password]','123456');page.click('button');page.wait_for_url(url+'/teacher')
                defs={'SINGLE':('Hai\nBa\nBốn','1'),'MULTI':('Hai\nBa\nBốn','1,3'),'TF':('Hai chẵn\nBa chẵn','D\nS'),'MATCH':('Một cộng một\nHai cộng hai','Hai\nBốn'),'FILL':('Một cộng một\nMột cộng hai','2|hai\n3|ba')}
                for mon,tp in [('Toán',topic),('Toán','Chủ đề khác'),('Tin học',topic)]:
                    for k,(items,answers) in defs.items():
                        for lv in ['NB','TH','VD','VDC']:
                            r=context.request.post(url+'/teacher/multi/new',form=dict(ma_cau=k+lv+mon+tp,khoi_lop='8',mon=mon,chu_de=tp,muc_do=lv,question_type=k,noi_dung=r'Tính $x^2$',items=items,answers=answers,points='4',scoring_mode='partial',weights='1,3' if k in ('TF','MATCH','FILL') else ''))
                            assert r.status==200
                # R2 fixture: persisted legacy whitespace/lowercase metadata, no source/DB migration.
                c=m.db();legacy_rows=c.execute('SELECT id,question_type,muc_do FROM cau_hoi').fetchall()
                c.executemany('UPDATE cau_hoi SET question_type=?,muc_do=? WHERE id=?', [('\t\u00a0'+row['question_type'].lower()+'\n', ' '+row['muc_do'].lower()+'\t', row['id']) for row in legacy_rows]);c.commit();c.close()
                context.request.post(url+'/teacher/student/add',form=dict(ma_hs='COMMA_BROWSER',ho_ten='Học sinh chủ đề dấu phẩy',lop='8A'))
                page.goto(url+'/teacher');page.select_option('#exam_mon',label='Toán');page.check('input[name=chu_de][value="'+topic+'"]')
                page.wait_for_function("document.getElementById('availability_box').textContent.includes('20') && document.getElementById('av_SINGLE_NB').textContent==='1'")
                for k in defs:
                    for lv in ['NB','TH','VD','VDC']:
                        assert page.locator(f'#av_{k}_{lv}').inner_text()=='1';page.fill(f'#q_{k}_{lv}','1')
                    assert page.locator('#row_total_'+k).inner_text()=='4'
                assert page.locator('#requested_total').inner_text()=='20'
                for lv in ['NB','TH','VD','VDC']:assert page.locator('#level_total_'+lv).inner_text()=='5'
                page.fill('form[action="/teacher/create-exam"] [name=ten]','Hotfix comma browser');page.select_option('form[action="/teacher/create-exam"] [name=lop]','8A')
                assert not page.locator('#create_exam_btn').is_disabled();page.screenshot(path=str(args.output/'F003_teacher_comma_matrix.png'),full_page=True)
                page.click('#create_exam_btn');page.wait_for_load_state('networkidle')
                c=m.db();kt=c.execute('SELECT * FROM ky_thi ORDER BY id DESC').fetchone();c.close()
                quotas=json.loads(kt['type_quotas']);assert json.loads(kt['chu_de'])==[topic] and quotas['_topics_format']=={'version':1}
                assert all(quotas[k][lv]==1 for k in defs for lv in ['NB','TH','VD','VDC']) and kt['so_cau']==20
                out['stored_topics']=kt['chu_de'];out['metadata']=quotas['_topics_format'];out['checks'].append('DOM_comma_selection_availability_20_cells_create_DB_reload')
                student=browser.new_context(viewport={'width':1280,'height':1000});student.route('**/*',local_only);exam=student.new_page();exam.on('pageerror',lambda e:out['errors'].append(str(e)))
                exam.goto(url);exam.fill('[name=ma_hs]','COMMA_BROWSER');exam.select_option('[name=ky_thi_id]',str(kt['id']));exam.click('button');exam.wait_for_url(url+'/exam')
                c=m.db();bt=c.execute('SELECT * FROM bai_thi WHERE ma_hs="COMMA_BROWSER"').fetchone();data=json.loads(bt['de_json']);rows={r['id']:dict(r) for r in c.execute('SELECT * FROM cau_hoi')};c.close()
                assert len(data)==20 and len({q['id'] for q in data})==20 and all(rows[q['id']]['chu_de']==topic and rows[q['id']]['mon']=='Toán' for q in data)
                assert exam.locator('.question').count()==20
                for i,q in enumerate(data):
                    if q['type']=='SINGLE':exam.check(f'input[name="q_{i}"][value="{q["answer"]}"]')
                    elif q['type']=='MULTI':
                        for a in q['answer']:exam.check(f'input[name="q_{i}"][value="{a}"]')
                    else:
                        for j,a in enumerate(q['answer']):
                            if q['type']=='FILL':exam.fill(f'[name="q_{i}_{j}"]',a[0])
                            else:exam.select_option(f'[name="q_{i}_{j}"]',str(a))
                exam.wait_for_function("Array.from(document.querySelectorAll('.question small[id]')).every(x=>x.textContent==='Đã lưu')");exam.reload();exam.wait_for_load_state('networkidle')
                exam.screenshot(path=str(args.output/'F003_exam_five_types.png'),full_page=True)
                exam.on('dialog',lambda d:d.accept());exam.click('form#form > button');exam.wait_for_url(url+'/result');assert '10.0/10' in exam.inner_text('body')
                c=m.db();stored=c.execute('SELECT * FROM bai_thi WHERE id=?',(bt['id'],)).fetchone();choices={r['vi_tri_cau']:r['lua_chon'] for r in c.execute('SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(bt['id'],))};c.close()
                from scoring import total_score
                assert len(choices)==20 and stored['diem']==total_score(data,choices)==10
                out.update(score=stored['diem'],answer_rows=len(choices),question_count=len(data));out['checks'].append('student_real_login_build20_save_reload_submit_regrade_result10')
                assert not out['errors'] and not out['external_requests'];out['status']='PASS';browser.close()
        except Exception:out['traceback']=traceback.format_exc()
        finally:
            server.close();server.task_dispatcher.shutdown()
            import logging
            logging.shutdown();shutil.copyfile(p/'app/logs/app.log',args.output/'runtime.log')
    (args.output/'results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if out['status']=='PASS' else 1
if __name__=='__main__':sys.exit(main())
