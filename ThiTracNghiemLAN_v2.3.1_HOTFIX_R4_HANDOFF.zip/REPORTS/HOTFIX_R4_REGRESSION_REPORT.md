# HOTFIX ROUND 4 — REGRESSION REPORT

HOTFIX_R4 = PASS. Các invariant sản phẩm được bảo toàn theo bằng chứng dưới đây; đọc TEST_REPORT để thấy đầy đủ raw failure R3 do fixture trái contract A.

| Finding | Kết quả | Bằng chứng chính |
|---|---|---|
| F001 | PASS | r1-final: expired POST cả 5 loại, dữ liệu autosave đã lưu, đúng deadline, chờ lock rồi kiểm lại deadline |
| F002 | PASS | r1-final: 8 submit đồng thời, autosave xếp hàng, rollback; original-final/race-probe.json |
| F003 | PASS | r1-final: comma topic round-trip 20 ô, 14 legacy cases; comma-browser |
| F004 | PASS | r2-final: canonical/lowercase/spaces/Unicode whitespace và fallback legacy; normalized-browser |
| F005 | PASS | r3-verified: clone 4 khối × 5 loại × 2 cách chấm và legacy metadata |
| F006 | PASS | r3-verified: thời gian/count hỏng, 20 ô và biên hợp lệ |
| F007 | PASS | r2-final: result/session token in-progress/submitted và token cũ bị từ chối |
| F008 | PASS | 7 nhóm Excel trong r3-verified, text không thành formula; fixture lịch sử trước thi, giữ 61 assertion của suite R3 |
| F009 | PASS | r2-final: invalid legacy editor reject trước commit; ABCD hợp lệ/scoring |
| F017 | PASS | r2-final: unlock/relogin/retake, NULL legacy token và request đang chờ lock |

Race probe cuối: stored score 10.0, re-grade stored answers 10.0; hai request đều có response kiểm soát, request thua không ghi đè. Deadline/claim `submitted_at` và transaction R1 vẫn được giữ, CSRF là bước kiểm trước chúng.

## Semantics và schema

SINGLE/MULTI/TF/MATCH/FILL; ALL/PARTIAL; weights; points/max_score; snapshot scoring và làm tròn giữ kết quả hợp lệ. 344 trường hợp chấm khớp scorer R3. `scoring.config` không đổi AST; tất cả hàm question_types ngoài snapshot không đổi AST. Snapshot chỉ thay đọc dữ liệu có validation và thêm history.

`init_db`, `validate_attempt_session`, `unlock_attempt`, `exam_topics`, `question_classification`, `question_availability`, `create_exam`, `edit_question`, `clone_question`, `exam_integer` không đổi AST. `app.env`, sáu test gốc và schema không đổi; không migration. Bằng chứng: `preserved-invariants.json`, `final-source-provenance.json`, `r2-final/schema.json`, `r3-verified/schema.json`.

Browser gốc và hai browser R1/R2 kiểm create/build/login, ma trận 5 × 4, chọn đáp án năm loại, autosave/reload/submit/result. Test/harness giữ nguyên được cung cấp dưới `upstream-harnesses/` với SHA-256.

## Thay đổi contract cần ghi nhận

Report cũ dùng live bank JOIN; R4 bắt buộc snapshot lịch sử. Suite R3 nguyên bản 14/15, một assertion không khớp vì fixture sửa marker sau thi. Không kết luận nguyên bản PASS, không hạ severity F008. Bản fixture đúng thời điểm thi 15/15 và scenario F012 BEFORE==AFTER chứng minh cả Excel safety và contract A. Số lần trả HTTP 403 khi thiếu CSRF và GET logout 405 là hành vi F011 chủ động yêu cầu; client hợp lệ gửi nonce thật tiếp tục hoạt động.

Không phát hiện regression ngoài các thay đổi contract đã yêu cầu. Không đánh giá hoặc sửa LOW/INFO, không bump version, không Production.
