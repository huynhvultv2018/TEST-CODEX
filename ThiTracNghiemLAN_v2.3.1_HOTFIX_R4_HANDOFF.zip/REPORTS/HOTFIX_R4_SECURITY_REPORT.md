# HOTFIX ROUND 4 — SECURITY & DATA INTEGRITY

F010 = PASS. F011 = PASS. Chỉ kiểm trong runtime tạm và dữ liệu fixture, không Production.

## F010: boundary và miền dữ liệu

`snapshot_validation.py` bảo vệ bank payload/legacy, snapshot đọc để build/chấm/xem/export và restore. Points và weights là int/float, không bool, hữu hạn, `0 < value <= 1000` đúng miền form v2.3. Weight không âm/không zero, đủ số ý và chỉ dùng cho TF/MATCH/FILL; tổng phải hữu hạn, dương. Mode all/partial; version nếu có là 1. Rule version 1 phải có points/mode/weights; legacy không rule hoặc rule rỗng giữ default 1/all, rule versionless giữ default mode/weights cũ.

Answer SINGLE là index hợp lệ; MULTI không rỗng/không trùng/index đúng miền; TF D/S; MATCH permutation/cột phải đúng cấu trúc; FILL danh sách đáp án không rỗng. Full snapshot cần id SQLite-int dương và nội dung chuỗi, loại/mục đúng miền. JSON hỏng, lồng quá sâu, sai shape và id vượt miền được từ chối bằng `SnapshotValidationError` trước ghi đáp án/chốt điểm.

Scorer giữ công thức v2.3, kiểm invariant hữu hạn `0 <= earned <= maximum` và tổng điểm `0..10`. Chỉ exception validation có handler HTTP 400; không catch-all trả 0, không clamp score, không sửa payload. Snapshot legacy danh sách rỗng giữ hành vi cũ, không tự tạo câu.

344 cases hợp lệ chấm giống R3. 32 calls pure-corruption bị từ chối kiểm soát. 18 snapshot corruption cases: mở bài, autosave, submit, points, report, Excel, monitor đều 400; attempt/answers không đổi. Chi tiết ở `r4-verified/results.json`.

## Restore an toàn

Source DB mở SQLite URI `mode=ro`, integrity `ok` và required tables chưa đủ để kích hoạt: phải validate từng bank question, từng de_json và score đã lưu hữu hạn trong `0..10`. Validation chạy trước tạo before_restore backup/thay active DB. Semantic FAIL có flash rõ ràng qua route restore.

17 bản DB lỗi ngữ nghĩa vẫn SQLite integrity `ok` đều bị từ chối; active DB logical dump và hash source DB không đổi. Saved-backup hỏng cũng bị từ chối, file backup giữ hash. Restore sạch và legacy missing scoring hoạt động, legacy submit vẫn 10. Không tự làm sạch DB lỗi.

## F011: contract CSRF

Nonce `secrets.token_urlsafe(32)` gắn signed session, lazy cấp từ HTML trước login, rotate khi teacher/student login thành công. Server kiểm mọi POST/PUT/PATCH/DELETE trước license/maintenance/business handlers, không exemption. Token gửi hidden field `csrf_token` hoặc header `X-CSRF-Token`; thiếu/sai/Unicode sai trả 403. Compare digest dùng UTF-8 bytes để token sai không tạo TypeError.

Origin nếu có, hoặc Referer nếu không có Origin, phải khớp scheme/host/port ứng dụng. Request không có hai header vẫn phải có nonce hợp lệ; không dựa riêng SameSite hoặc CORS. Token giữ theo session hiện hành, không thêm cơ chế hết hạn auth mới. Phiên đã mở trước R4 cần mở lại HTML để nhận nonce. Cookie/SameSite/Secure và hạ tầng không đổi.

Inventory runtime có 35 route POST: login teacher/student, CRUD, exam, import, unlock, admin accounts, settings, backup/restore, license, autosave/ping, submit và logout. Không có route khai báo PUT/PATCH/DELETE; guard vẫn bao phủ các method đó. 31 vị trí form POST gồm unlock động có nonce, hai fetch state-changing autosave/ping gửi header. Inventory ở `form-nonce-inventory.json` và `r4-verified/results.json`.

Mỗi route kiểm năm request âm tính: thiếu token, sai token, Unicode sai, đúng nonce nhưng foreign Origin, đúng nonce nhưng foreign Referer. 175/175 trả 403, DB không đổi. Với route có path parameter, probe dùng ID/backup giả để xác minh guard chạy trước business handler; không tuyên bố 35 thao tác hợp lệ đều đã thực hiện riêng. Positive flows được kiểm bởi regression gốc/R1–R3 cùng probe nonce hợp lệ/rotation/login/HTML-field/API/save/submit/result/restore. Không disable CSRF trong test.

Logout dùng POST có nonce và clear session; GET 405 giữ session. Không còn GET logout gây state change qua form foreign. Login teacher và student đều được bảo vệ nonce trước xác thực, không bỏ qua login CSRF.

## Browser runtime thật

Chromium 151, hai HTTP server loopback khác origin, cookie thật; observer passive, không route/intercept request. Teacher login DOM hợp lệ hoạt động. Same-site khác port và cross-site localhost gửi cookie thật nhưng forged HTML POST nhận 403, không tạo học sinh. Foreign GET logout 405 và vẫn đăng nhập. Forged student HTML submit không đổi submitted_at/diem, response 403. Cross-origin JSON chỉ tới wire OPTIONS, CORS chặn POST và không lưu đáp án; kết quả này riêng nó không được dùng thay bằng chứng CSRF HTML.

`browser-csrf-final/results.json`, `runtime.log` và ba ảnh chụp giữ đầy đủ origin/referer/cookie-attached/status. Không có request external trong probe. Các probe này chạy không adapter positive-client.

F001/F002 vẫn PASS: CSRF không thay deadline/transaction; stored answers re-grade khớp stored score. Không có security exemption, token hard-coded hoặc thay config môi trường.
