# HOTFIX ROUND 4 — TEST REPORT

HOTFIX_R4 = PASS trong phạm vi được yêu cầu. F010/F011/F012 PASS; các finding R1–R3 tiếp tục có bằng chứng PASS. Không phát hiện regression sản phẩm mới ngoài hành vi báo cáo được chủ động đổi theo quyết định A.

## Môi trường và phương pháp

Python 3.12.14, Flask 3.1.3, Waitress 3.0.2, openpyxl 3.1.5; Playwright 1.62 với Chromium 151.0.7922.173. Runtime dùng bản copy tạm và SQLite fixture riêng, không chạy Production. Tất cả log dùng UTC. Hash source cuối được ghi ở `final-source-provenance.json`.

Các test cũ chưa biết CSRF được chạy với adapter client opt-in `transport/sitecustomize.py`: GET HTML thật của ứng dụng để nhận nonce của chính session, rồi gửi header token. Guard production luôn chạy. Không hard-code token, không sửa assertion/status expected, không bật exemption/test mode. Probe âm tính R4 và browser CSRF chạy không bật adapter. DOM browser dùng token từ form ứng dụng.

## Kết quả cuối

| Suite | Nhóm PASS | Bằng chứng dưới HOTFIX_R4_EVIDENCE/ |
|---|---:|---|
| R1 gốc | 18/18 | r1-final/results.json |
| R2 gốc | 15/15 | r2-final/results.json |
| R3 theo fixture thời điểm thi, xem giải thích dưới | 15/15 | r3-verified/results.json |
| Probe R4 | 7/7 | r4-verified/results.json |
| Sáu script test gốc, byte-identical | 6/6 | original-final/runner-results.json |
| Audit harness gốc | 21/21 | original-final/audit-checks.json |
| Legacy harness gốc | 6/6 | original-final/legacy-checks.json |
| Race probe gốc | 1/1 | original-final/race-probe.json |
| Browser gốc, năm loại và ma trận | 1/1 | original-final/browser-checks.json |
| Browser chủ đề dấu phẩy | 1/1 | comma-browser/results.json |
| Browser normalization | 1/1 | normalized-browser/results.json |
| Browser CSRF thật | 1/1 | browser-csrf-final/results.json |

Tổng 93 nhóm PASS trong các lần xác minh cuối; không cộng các lần chạy trước vào tổng. Bốn audit harness được runner chạy thành công, số nhóm của chúng được tính ở các hàng riêng.

Sáu script gồm `kiem_tra_v23.py`, `kiem_tra_v23_integration.py`, `kiem_tra_v22.py`, `kiem_tra_v221.py`, `kiem_tra_v222.py`, `kiem_tra_mathjax.py`; tất cả exit 0, checksum giống baseline R3.

## Kết quả gốc không được che

Suite R3 nguyên bản chạy trên R4 cho **14 PASS / 1 FAIL**, không phải 15/15. Raw failure `r3-initial/results.json`: `F008_exam_report_all_sheets_text_and_numeric` kỳ vọng marker được sửa vào ngân hàng sau khi học sinh thi xuất hiện trong report cũ. Quyết định A bắt buộc report giữ snapshot lúc thi, nên không thể đáp ứng cả hai kỳ vọng về nguồn dữ liệu.

Giữ nguyên harness gốc. Bản scenario bổ sung `r3_fixture_at_exam_time.py` chỉ chuẩn bị marker ngân hàng và môn kỳ thi khớp nhau trước login học sinh; vẫn giữ thao tác sửa ngân hàng sau thi, mọi expected và **61 assertion AST-identical**. Kết quả 15/15 chứng minh guard F008 vẫn bảo vệ chính dữ liệu lịch sử xuất Excel, không đưa nội dung ngân hàng mới vào report để làm test cũ PASS. Hash/đối chiếu tại `r3-fixture-adaptation.json`, bản gốc có trong `upstream-harnesses/`.

Lần chuẩn bị đầu của fixture bổ sung thiếu đổi môn kỳ thi, login không build được bài; log `r3-fixture.log` và script `r3_fixture_first_attempt.py` được giữ. Probe R4 đầu 5 PASS/1 FAIL do fixture SQL dùng tên cột `nb` thay vì `nb_count`; `r4-initial/` cùng script lúc đó được giữ. Sau sửa fixture, bổ sung probe và hoàn thiện patch đúng phạm vi, chạy lại cuối 7/7. Không xóa log lỗi hay gán XFAIL. Preflight đóng gói từng gặp KeyError do đọc cột provenance chỉ có ở audit harness; đã kiểm hash riêng cho sáu test gốc, không thay kết quả test.

## Độ sâu probe R4

344 so sánh scoring hợp lệ với scorer R3 khóa hash; 32 lời gọi scorer từ chối dữ liệu hỏng bằng exception miền riêng; 18 snapshot hỏng kiểm HTTP 400 ở mở bài/autosave/submit/points/report/Excel/monitor và kiểm attempt/answers không đổi. Restore kiểm 17 dữ liệu hỏng dù integrity `ok`, một restore hợp lệ, thêm saved-backup và legacy thiếu scoring hợp lệ.

35 route POST × 5 dạng request CSRF không hợp lệ = 175 lần từ chối HTTP 403 với DB không đổi; kiểm token hợp lệ, xoay token sau login, nonce cũ bị chặn, autosave/ping/submit/result và logout. Browser thật chứng minh cookie vẫn gửi nhưng foreign POST bị chặn. F012 có HTML/XLSX BEFORE/AFTER, hai phiên bản và legacy.

## Chạy lại độc lập

Các script và hash nằm trong EVIDENCE; bản upstream giữ byte-identical. Ví dụ trong workspace hiện tại:

```bash
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R4_EVIDENCE/r4_regression.py --source hotfix-r4-candidate/PHAN_MEM --output /tmp/r4-review
PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R4_EVIDENCE/r4_browser_csrf.py --source hotfix-r4-candidate/PHAN_MEM --output /tmp/r4-browser-review
TNLAN_R4_VALID_CLIENT=1 PYTHONPATH=/workspace/TEST-CODEX/HOTFIX_R4_EVIDENCE/transport PYTHONDONTWRITEBYTECODE=1 /workspace/tnlan-audit-venv/bin/python HOTFIX_R1_EVIDENCE/run_original_checks.py --source hotfix-r4-candidate --output /tmp/r4-original-review
```

Harness có một số đường dẫn workspace cố định: probe so sánh scoring cần bản R3 đã giải nén ở `/workspace/preprod-r3-baseline`; runner upstream cần thư mục harness như đường dẫn gốc. Người kiểm chứng phải bố trí đúng các bản hash-identical đó; candidate không chứa baseline/audit source thay thế. Các lệnh trên là hướng dẫn, không phải triển khai Production.
