# HOTFIX ROUND 4 — CHANGELOG

HOTFIX_R4 = PASS. ThiTracNghiemLAN vẫn là v2.3.1; phạm vi chỉ F010, F011, F012. Chưa nâng Production.

## Baseline

Kế thừa trực tiếp `ThiTracNghiemLAN_v2.3.1_HOTFIX_R3_CANDIDATE.zip`, SHA-256 `f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a`. Hash được kiểm trước patch và sau đóng candidate. PREPROD audit chỉ cung cấp tình huống tái hiện.

## F010 — dữ liệu scoring/snapshot

Thêm `PHAN_MEM/snapshot_validation.py`: kiểm JSON, cấu trúc câu/đáp án, points/weights hữu hạn trong miền hiện hành, mode, version và trường bắt buộc. Dữ liệu legacy thiếu toàn bộ scoring giữ mặc định 1/all; rule versionless giữ các default cũ. Rule version 1 phải đủ points/mode/weights. Không sửa dữ liệu hỏng hoặc đổi lỗi thành điểm 0.

Áp dụng validation khi đọc ngân hàng, build snapshot, mở bài, autosave, submit, monitor, báo cáo/export và chấm. Lỗi miền dữ liệu trả HTTP 400 có thông báo; không bắt chung mọi exception của scoring. Công thức và làm tròn v2.3 giữ nguyên.

Restore mở source DB read-only, kiểm SQLite integrity và toàn bộ payload/snapshot/điểm đã lưu trước khi backup/thay DB đang dùng. Semantic FAIL bị từ chối, giữ DB hiện tại và backup/source nguyên vẹn.

## F011 — CSRF

Thêm guard chung cho POST/PUT/PATCH/DELETE, không có route exemption. Nonce ngẫu nhiên gắn signed session, nhận qua hidden field hoặc `X-CSRF-Token`, so sánh phía server. Origin/Referer ngoại lai nếu có bị từ chối. Token được cấp trước login và đổi khi login thành công.

31 vị trí form POST, gồm form unlock dựng bằng JavaScript, gửi token. Autosave và ping gửi header token. Logout chuyển GET sang POST có token; GET trả 405. Đây là thay đổi UI tối thiểu cần cho F011, không redesign authentication hoặc cấu hình cookie.

## F012 — lịch sử theo quyết định A

Snapshot mới giữ thêm `history` với mã câu, môn, chủ đề, mức độ; nội dung `q` đã có được giữ. Báo cáo UI và Excel dùng snapshot của attempt đã nộp thay cho JOIN ngân hàng hiện tại. Các phiên bản cùng ID nhưng khác metadata/nội dung được thống kê riêng.

Snapshot legacy thiếu history giữ nguyên nội dung/điểm và hiển thị `Không rõ (legacy)` cho phân loại chưa được lưu. UI có cảnh báo nhỏ, Excel có hàng thống kê legacy. Không backfill hoặc đoán metadata cũ; không đổi schema.

## Kiểm thử và đóng gói

93 nhóm xác minh cuối PASS; chi tiết và ngoại lệ fixture R3 bắt buộc đọc trong TEST_REPORT. Giữ raw R3 14 PASS/1 FAIL do kỳ vọng metadata sau thi trái quyết định A; scenario tương ứng 15/15 PASS với 61 assertion nguyên vẹn, dữ liệu marker được chuẩn bị trước thi. Không sửa file test R3 gốc, expected result, bỏ assertion, skip hoặc XFAIL.

Candidate mới có 59 file, gồm toàn bộ source/tài nguyên/test gốc. Chỉ bỏ khỏi ZIP mới bốn `.pyc` kế thừa của chính các module đã sửa để tránh đóng bytecode cũ; không xóa chúng trên disk và không thay ZIP R3. Không có ZIP baseline lồng, DB runtime, secret hay cache trong candidate.

CHECKSUMS mới nằm ở gốc HANDOFF; manifest R1 đang có trong workspace được giữ nguyên.
