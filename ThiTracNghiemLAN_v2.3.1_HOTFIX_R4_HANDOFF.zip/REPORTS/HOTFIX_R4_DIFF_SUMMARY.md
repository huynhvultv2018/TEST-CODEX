# HOTFIX ROUND 4 — DIFF SUMMARY

HOTFIX_R4 = PASS. So sánh trực tiếp với ZIP R3 khóa hash, không lấy audit source làm baseline.

- Baseline SHA-256: `f6e2e027f8a8296136741b5c05714645bee533a93da50fdc55a35b7f3fe5e52a`.
- R4 candidate SHA-256: `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
- Candidate: 785622 byte, 59 file, CRC PASS, tất cả member byte-identical với source đã kiểm.
- 23 file hiện có được sửa (4 Python, 19 template), thêm 1 module validation: tổng 24 file. Không sửa test gốc, cấu hình, schema, version, công thức hoặc các module khác.

## Truy nguyên thay đổi

| File | Finding | Lý do |
|---|---|---|
| `PHAN_MEM/app.py` | F010/F011/F012 | Runtime/restore validation; global CSRF/session nonce; POST logout; historical report aggregation. |
| `PHAN_MEM/multi_routes.py` | F010 | Read stored payload through question_data before editor/export. |
| `PHAN_MEM/question_types.py` | F010/F012 | Validate bank source before snapshot; append only four historical metadata fields. |
| `PHAN_MEM/scoring.py` | F010 | Validate stored input and finite result bounds; preserve existing formula/config/rounding. |
| `PHAN_MEM/snapshot_validation.py` | F010/F012 | New shared semantic validator, controlled exception; validate optional historical metadata shape. |
| `PHAN_MEM/templates/accounts.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/backups.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/base.html` | F011 | Expose current nonce in HTML meta for fetch clients. |
| `PHAN_MEM/templates/change_password.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/edit_question.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/exam.html` | F011 | Hidden submit token and CSRF headers on autosave/ping. |
| `PHAN_MEM/templates/license.html` | F011 | Nonce in POST forms; change logout link to POST form. |
| `PHAN_MEM/templates/login.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/mixed_exam.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/monitor.html` | F011 | Hidden nonce in JavaScript-created unlock POST form. |
| `PHAN_MEM/templates/multi_bank.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/multi_editor.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/question_bank.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/report.html` | F012 | Small legacy metadata warning and unknown-level row. |
| `PHAN_MEM/templates/settings.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/students.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/students_import_preview.html` | F011 | Hidden nonce in existing POST forms only. |
| `PHAN_MEM/templates/teacher.html` | F011 | Nonce in POST forms; change logout link to POST form. |
| `PHAN_MEM/templates/teacher_login.html` | F011 | Hidden nonce in existing POST forms only. |

Patch chính xác: `EVIDENCE/HOTFIX_R4_EVIDENCE/R3_to_R4.patch`; hash từng file trước/sau trong `baseline-lock.json` và `final-source-provenance.json`. `preserved-invariants.json` ghi các hàm/schema/scoring config giữ AST. Không có thay đổi tracked source ngoài artifact commit.

## Đóng gói

R3 có 62 file gồm bốn `.pyc` kế thừa; working tree R4 có 63 file. Candidate R4 chỉ chứa 59 file source/tài nguyên/test cần chạy: bỏ khỏi ZIP mới bốn cache của app/multi_routes/question_types/scoring đã sửa, giữ nguyên file gốc trên disk. Không xử lý finding LOW/INFO nào từ việc này. ZIP mới không có baseline ZIP lồng, database runtime, secret, file test tạm hoặc cache.

Checksum của candidate cùng mọi báo cáo/bằng chứng nằm ở `CHECKSUMS.sha256` gốc HANDOFF, theo đúng đường dẫn CANDIDATE/REPORTS/EVIDENCE. Không ghi đè manifest R1 ở workspace. Handoff hash được cung cấp riêng vì không thể đưa hash của chính ZIP vào chính ZIP đó.

## Test provenance

Sáu test gốc và upstream harness byte-identical. Adapter positive-client chỉ gửi nonce thực, không miễn CSRF. R3 gốc raw 14 PASS/1 FAIL được giữ; scenario fixture chuẩn bị marker trước lúc thi PASS 15/15 với 61 assertion không đổi. Đọc TEST_REPORT trước khi diễn giải trạng thái regression.

Chưa triển khai Production, không bump version, không làm R5.
