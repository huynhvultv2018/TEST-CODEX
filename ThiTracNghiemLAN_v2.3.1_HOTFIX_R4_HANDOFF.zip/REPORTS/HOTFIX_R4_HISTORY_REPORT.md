# HOTFIX ROUND 4 — HISTORY REPORT

F012 = PASS. Contract A: nội dung và phân loại dùng dữ liệu trong snapshot khi học sinh nhận bài, không dùng ngân hàng hiện tại để mô tả attempt cũ.

## Representation

Giữ nguyên `bai_thi.de_json`, `q`, đáp án và scoring trong mỗi item; thêm `history: {ma_cau, mon, chu_de, muc_do}` khi build snapshot mới. Đây là bốn trường report cần nhưng snapshot R3 chưa giữ. Không đổi schema hoặc version scoring, không lưu bản sao toàn ngân hàng.

`historical_question_stats` đọc snapshot của attempt submitted và answer theo vị trí. UI/Excel thống nhất nguồn. Group gồm question ID, metadata, nội dung và trạng thái thiếu history: hai phiên bản khác nhau cùng ID không bị trộn. Chỉ thống kê những lượt đáp án đã lưu như luồng report trước đó; không phát sinh answer hoặc re-grade/lưu lại score.

## Runtime scenario chính: BEFORE == AFTER

Tạo câu SINGLE NB bằng form thật, tạo kỳ thi, student login/submit score 10. Capture UI context/HTML và Excel bốn sheet. Sửa ngân hàng bằng editor thật: mã/môn/chủ đề đổi, NB → VD, nội dung BEFORE_NB → AFTER_VD, points 4 → 9. Mở lại UI/Excel:

| Giá trị historical | BEFORE | AFTER |
|---|---|---|
| Mã câu | HISTORY | HISTORY |
| Môn | HISTORY | HISTORY |
| Chủ đề | Chủ đề, có dấu phẩy | Chủ đề, có dấu phẩy |
| Mức độ | NB | NB |
| Nội dung | BEFORE_NB | BEFORE_NB |
| Lượt NB / đúng | 1 / 1 | 1 / 1 |
| Lượt VD | 0 | 0 |
| Điểm / trung bình | 10 / 10 | 10 / 10 |

Metadata/content/levels và giá trị cả bốn sheet BEFORE == AFTER; toàn bộ row attempt và answers không đổi. So sánh workbook theo values vì container XLSX có timestamp, không đòi ZIP XLSX byte-identical. Bằng chứng `r4-verified/results.json`, `history_before.html`, `history_after.html`, `history_before.xlsx`, `history_after.xlsx`.

## Hai phiên bản cùng câu và legacy

Scenario bổ sung điều chỉnh riêng fixture SQL của kỳ thi (môn/quota NB→VD) để học sinh thứ hai nhận câu đã sửa; app không có UI edit exam tương ứng. Login/submit vẫn qua route thật. Report sau đó có hai nhóm cùng ID: HISTORY/NB/BEFORE_NB và CHANGED/VD/AFTER_VD, mỗi nhóm một lượt, score hai bài đều 10. Không tuyên bố bước đổi exam fixture này là thao tác UI sản phẩm.

Fixture legacy loại bỏ duy nhất history khỏi một snapshot để mô phỏng R3. UI hiển thị cảnh báo có lượt thiếu phân loại tại thời điểm thi; bốn trường phân loại là `Không rõ (legacy)`, nội dung vẫn BEFORE_NB. Excel PhanTichCauHoi/TheoMucDo cũng đánh dấu legacy. Score, answers và de_json legacy giữ nguyên qua mở báo cáo, không backfill từ bank mới. History thiếu hoàn toàn được hỗ trợ; history có nhưng hỏng cấu trúc bị controlled rejection F010 để tránh tự suy đoán.

Ảnh chụp dữ liệu HTML/XLSX cho hai phiên bản và legacy ở `r4-verified/history_two_versions.*`, `history_legacy.*`. Điểm/snapshot vẫn đóng băng; không làm metadata mới xuất hiện trong bài R3 đã có.

## Tương tác regression F008

Suite R3 nguyên bản kỳ vọng marker sửa sau thi xuất hiện trong báo cáo, nên raw 14 PASS/1 FAIL được giữ. Fixture F008 bổ sung đặt marker trước thi, giữ mọi assertion, PASS 15/15. Literal Excel protection vẫn xử lý =/+/−/@ và giữ numeric/datetime như R3; không dùng bank hiện tại để đạt PASS. Xem TEST_REPORT và `r3-fixture-adaptation.json`.
