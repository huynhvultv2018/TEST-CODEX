# HOTFIX ROUND 4 — FINDINGS

HOTFIX_R4 = PASS cho candidate R4, chưa phải chấp thuận hoặc triển khai Production.

| Finding | Trạng thái | Kết luận có bằng chứng |
|---|---|---|
| F010 | PASS | Dữ liệu hỏng bị reject kiểm soát tại restore/runtime; dữ liệu hợp lệ khớp scoring R3; không tự sửa dữ liệu |
| F011 | PASS | Guard session nonce cho mọi unsafe request; 175 negative route probes, browser cookie thật reject forged POST; valid flows hoạt động |
| F012 | PASS | UI/Excel giữ snapshot khi NB/content ngân hàng đổi; legacy unknown rõ ràng, không backfill |
| F001/F002/F003 | PASS | R1 18/18, race re-grade == stored score, comma browser |
| F004/F007/F009/F017 | PASS | R2 15/15, normalized browser |
| F005/F006/F008 | PASS | R3 contract A fixture 15/15, clone/input/Excel assertions giữ nguyên |

## Điểm phải đọc khi duyệt

R3 nguyên bản **14 PASS / 1 FAIL**, không ghi lại thành PASS. Failure F008 mong metadata được sửa sau thi xuất hiện trong report lịch sử, trái product decision A. Bản fixture bổ sung đặt marker trước thi, giữ toàn bộ 61 assertion/expected và vẫn sửa bank sau thi, cuối 15/15. Raw failure, script gốc hash-identical và proof assertion được bàn giao. Đây là đối chiếu contract, không hạ severity hoặc bỏ test.

93 nhóm xác minh cuối PASS, sáu test gốc/audit harness byte-identical, F010/F011/F012 runtime evidence đầy đủ, candidate CRC/member/hash PASS. Không phát hiện regression mới trong các luồng đã kiểm. Không tuyên bố đã kiểm mọi dữ liệu legacy tồn tại ngoài fixture hoặc mọi triển khai proxy; phạm vi runtime kiểm được mô tả trong TEST/SECURITY_REPORT.

Không sửa finding khác, không đổi scoring formula/năm loại/ma trận/schema/version; không R5 và không Production. Chờ người dùng kiểm chứng candidate và quyết định bước sau.
