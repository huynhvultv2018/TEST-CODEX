# Visual report

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

48 PNG thật từ Chromium 151.0.7922.173, không dùng ảnh dựng để thay screenshot runtime. 24 ảnh loại màn theo yêu cầu tại 1366×768; 20 ảnh responsive cho Tin MCQ / equation / word problem / proof / analysis; 4 ảnh stress case mở toàn bộ phân tích. Fixture chỉ là dữ liệu test presentation, không phải package hoặc bằng chứng SGK.

Mỗi ca kiểm tra overflow dọc/ngang của textPane. Không ca đo nào tràn. Đây là kiểm tra hình học DOM trong browser, không xác nhận độ đọc ở khoảng cách ngồi lớp/TV thật.

Đã xem trực tiếp các screenshot đại diện MCQ, word problem, analysis 1280×720, full analysis 1280×720, equation và dependency tree; giữ hình, khoảng trắng và toán tử. Mở `TV_MULTI_ENGINE_EVIDENCE/index.html` để duyệt toàn bộ.

| Ảnh PNG | Nguồn | Viewport | Overflow |
|---|---|---|---|
| TIN_01_REVIEW | TIN6_W04 real package | 1366×768 | PASS |
| TIN_02_INTRO | TIN6_W04 real package | 1366×768 | PASS |
| TIN_03_MCQ | TIN6_W04 real package | 1366×768 | PASS |
| TIN_04_OBSERVE | TIN6_W04 real package | 1366×768 | PASS |
| TIN_05_KNOWLEDGE | TIN6_W04 real package | 1366×768 | PASS |
| TIN_06_PRACTICE | TIN6_W04 real package | 1366×768 | PASS |
| TIN_07_APPLICATION | TIN6_W04 real package | 1366×768 | PASS |
| GEO_01_STATEMENT | HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST real package | 1366×768 | PASS |
| GEO_02_OBSERVE | HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST real package | 1366×768 | PASS |
| GEO_03_ANALYSIS | HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST real package | 1366×768 | PASS |
| GEO_05_PROOF_STEP_1 | HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST real package | 1366×768 | PASS |
| GEO_06_PROOF_STEP_2 | HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST real package | 1366×768 | PASS |
| GEO_07_CONCLUSION | HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST real package | 1366×768 | PASS |
| TIN_08_PRACTICAL | Presentation fixture; not a real package | 1366×768 | PASS |
| TIN_09_DEMO | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_01_EXPRESSION | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_02_EQUATION | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_03_SYSTEM | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_04_WORD_PROBLEM | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_05_IDENTITY | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_06_TABLE | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_07_GRAPH | Presentation fixture; not a real package | 1366×768 | PASS |
| ALG_08_PRACTICE | Presentation fixture; not a real package | 1366×768 | PASS |
| GEO_04_DEPENDENCY_TREE | Presentation fixture; not a real package | 1366×768 | PASS |
| TIN_MCQ_1920x1080 | Real package | 1920×1080 | PASS |
| ALG_EQUATION_1920x1080 | Presentation fixture | 1920×1080 | PASS |
| ALG_WORD_PROBLEM_1920x1080 | Presentation fixture | 1920×1080 | PASS |
| GEO_PROOF_1920x1080 | Real package | 1920×1080 | PASS |
| GEO_ANALYSIS_1920x1080 | Real package | 1920×1080 | PASS |
| TIN_MCQ_1600x900 | Real package | 1600×900 | PASS |
| ALG_EQUATION_1600x900 | Presentation fixture | 1600×900 | PASS |
| ALG_WORD_PROBLEM_1600x900 | Presentation fixture | 1600×900 | PASS |
| GEO_PROOF_1600x900 | Real package | 1600×900 | PASS |
| GEO_ANALYSIS_1600x900 | Real package | 1600×900 | PASS |
| TIN_MCQ_1366x768 | Real package | 1366×768 | PASS |
| ALG_EQUATION_1366x768 | Presentation fixture | 1366×768 | PASS |
| ALG_WORD_PROBLEM_1366x768 | Presentation fixture | 1366×768 | PASS |
| GEO_PROOF_1366x768 | Real package | 1366×768 | PASS |
| GEO_ANALYSIS_1366x768 | Real package | 1366×768 | PASS |
| TIN_MCQ_1280x720 | Real package | 1280×720 | PASS |
| ALG_EQUATION_1280x720 | Presentation fixture | 1280×720 | PASS |
| ALG_WORD_PROBLEM_1280x720 | Presentation fixture | 1280×720 | PASS |
| GEO_PROOF_1280x720 | Real package | 1280×720 | PASS |
| GEO_ANALYSIS_1280x720 | Real package | 1280×720 | PASS |
| GEO_ANALYSIS_FULL_1920x1080 | DUAL_VISUAL_TEST thật, 4 bước + đáp án | 1920×1080 | PASS |
| GEO_ANALYSIS_FULL_1600x900 | DUAL_VISUAL_TEST thật, 4 bước + đáp án | 1600×900 | PASS |
| GEO_ANALYSIS_FULL_1366x768 | DUAL_VISUAL_TEST thật, 4 bước + đáp án | 1366×768 | PASS |
| GEO_ANALYSIS_FULL_1280x720 | DUAL_VISUAL_TEST thật, 4 bước + đáp án | 1280×720 | PASS |

Kết quả JSON: `results.json`, `extra-results.json`. Không thay screenshot bằng SVG minh họa. Một PNG RC3 cũ trong TV_LAYOUT_REPORTS chỉ là artifact lịch sử, không tính trong 48 PNG này.
