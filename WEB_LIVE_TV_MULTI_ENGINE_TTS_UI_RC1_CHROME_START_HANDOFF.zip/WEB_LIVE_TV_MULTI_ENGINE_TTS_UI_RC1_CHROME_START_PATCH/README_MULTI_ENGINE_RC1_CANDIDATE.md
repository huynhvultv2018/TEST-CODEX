# WEB LIVE TV MULTI-ENGINE RC1 CANDIDATE

Kế thừa duy nhất RC4. Ba main stage: Computer Science Activity Cards, Algebra Math Reasoning Board, Geometry Proof Board. Design system navy chung, chạy offline.

Trên Windows, giải nén toàn bộ và chạy START_WEB_LIVE.bat như RC4; không tách WEB_LIVE khỏi LAUNCHER. Nhập gói LIVE bằng Teacher rồi mở TV. Các gói thật gốc được giữ nguyên.

Cloud: PASS các kiểm tra browser đã chạy; **chưa production**. Không có gói Đại số thật. Demo handoff thực cần laptop Windows + TV, Word/GeoGebra và cấu hình Launcher sẵn có. Không dùng mock làm chứng nhận handoff vật lý.

Xem TV_MULTI_ENGINE_AUDIT.md và REGRESSION_REPORT.md trước thử lớp. Gallery và 48 screenshot tại TV_MULTI_ENGINE_EVIDENCE/index.html. Checksum tại TV_MULTI_ENGINE_CHECKSUMS.sha256; chạy từ thư mục candidate: `sha256sum -c TV_MULTI_ENGINE_CHECKSUMS.sha256`.

## Checklist runtime trên máy thật

1. Nhập Tin 6, Tin 8 và Hình học 8; kiểm tra MCQ, ảnh, Hint/Answer/Steps, knowledge close và sync.
2. Cung cấp LIVE.zip Đại số thật rồi thử equation, system, word problem, table/graph; không đổi nội dung để hợp layout.
3. Trên TV 1920×1080 và scaling thực tế, thử proof/analysis, fullscreen, 70/30, Draw/Cover/Smart/Highlight/Focus/Pointer/Timer.
4. Demo Word/GeoGebra: chỉ mở khi GV bấm và xác nhận; chuyển TV; quay lại đúng màn; kiểm tra Launcher monitor selection và Alt+Tab.
5. Ngắt Internet; mở lại bài đã nhập và thử sync bằng các asset local.

Chờ runtime test laptop + TV thật. Không nâng production.
