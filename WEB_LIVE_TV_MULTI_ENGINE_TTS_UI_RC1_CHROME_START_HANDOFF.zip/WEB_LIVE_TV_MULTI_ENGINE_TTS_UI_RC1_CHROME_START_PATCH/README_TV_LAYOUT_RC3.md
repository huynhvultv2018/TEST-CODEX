# WEB LIVE TV LAYOUT RC3 CANDIDATE — MẪU 4

PARTIAL — CHỜ DUYỆT BỐ CỤC + RUNTIME LAPTOP/TV. KHÔNG PRODUCTION.

Baseline: WEB_LIVE_PEDAGOGY_RC3_CANDIDATE.zip SHA 3fd02a31e11689ada8f615f31bc6745e70321f96d3ec9239cb4206dadde3713e. Nhãn version HTML cũ của baseline được giữ; không gán release mới.

Giải nén nguyên thư mục, chạy START_WEB_LIVE.bat như baseline. Import RC3_PED1_TEST_PACKAGES/TIN8_W04_LIVE_RC3_PED1.zip; đến màn5 T8W4_THINK để xem Mẫu4: tên mục/hoạt động trên; Hình2.3 trái; câu hỏi phải. Source/geometry scene không đổi.

Hint do GV reveal dưới câu hỏi; Answer thay vùng câu hỏi theo state; Knowledge Close vẫn cần GV chốt. Nhiều câu ở block riêng: một đơn vị tại một thời điểm, GV dùng Focus Line có sẵn để chọn. Không auto skip hoặc auto launch app.

Resource ngữ cảnh từ màn quan sát trước cùng SGK trace không tạo geometry scene mới hoặc overlay của task khác. ResourceFocus văn bản nhấn khung quan sát; không tự suy ra crop/coordinates. Hình2.3 gốc147×105, độ rõ cần kiểm thật.

Báo cáo tại TV_LAYOUT_REPORTS. Minh họa là SVG/PNG mã nguồn, không screenshot browser. Baseline RC3 còn thiếu full exporter source PPCT/SGK và runtime acceptance; layout patch không nâng các gap này thành PASS.
