# Control panel UI report

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


## Thay đổi

Giữ navy theme, preview bên trái, panel bên phải, top bar MỞ TV/TOÀN MÀN HÌNH. Chỉ di chuyển nhóm control sẵn có và thêm giọng đọc; 113 ID và 61 onclick gốc vẫn hiện diện. Hành vi điều khiển bài giữ nguyên.

- **🎓 DẠY HỌC** mở và ưu tiên trên cùng, primary controls sticky: Trước/Tiếp, Gợi ý, Đáp án, Ẩn gợi ý, Chốt kiến thức. Jump và Bước giải/Ẩn lời giải ở phần đầu sideBody; không cần mở tầng accordion để truy cập. Thông tin/ghi chú riêng GV thu gọn mặc định.
- **🔊 GIỌNG ĐỌC** dùng một nút chính theo state, Stop và icon Replay nhỏ. Select phần đọc, giọng, tốc độ compact; gender/highlight/volume ở tùy chọn nhỏ. Group mở mặc định và tự mở khi đang đọc.
- **🛠 HIỂN THỊ & CÔNG CỤ** thu gọn mặc định; giữ các control layout, Focus, Phóng chữ, pointer/nhãn, Draw/Cover/Smart/Highlight và Timer. Tool đang mở tự mở group. Không xóa chức năng.

Thu gọn panel vẫn giữ teaching controls dạng hai cột và cho mở lại các công cụ cũ. Body panel cuộn dọc theo kiến trúc cũ; ở 720/768 px chiều cao, phần giọng/công cụ có thể cần cuộn sideBody. Điều khiển Trước/Tiếp/Gợi ý/Đáp án/Chốt vẫn ở vùng sticky.

## CSS width và kết quả runtime

Một stylesheet mới sau CSS cũ: expanded `clamp(300px, 18.75vw, 380px)`, compact 288px; desktop hẹp có minimum 300px, breakpoint nhỏ kế thừa bố cục stacked. CHỐT span hết hàng và nowrap, không đổi handler.

Full HD expanded panel **360px = 18.75% viewport**, preview **1524px = 79.38%**; phần còn lại là padding/gap/border. Trong hai cột nội dung, preview chiếm 80.89%. Label CHỐT/ẨN CHỐT rộng 334 px, cao 42 px, một dòng. Compact panel 288 px, preview 1596 px.

Số đo sau đây lấy từ browser không thay Web Speech API (`native-probe.json`, bounding rect gồm border):

| Viewport | Panel | Rộng panel px | Preview px | Nút chốt px | Scroll ngang |
|---|---|---:|---:|---:|---|
| 1920×1080 | Mở rộng | 360 | 1524 | 334×42 | Không |
| 1920×1080 | Thu gọn | 288 | 1596 | 262×42 | Không |
| 1366×768 | Mở rộng | 300 | 1030 | 274×42 | Không |
| 1366×768 | Thu gọn | 288 | 1042 | 262×42 | Không |
| 1280×720 | Mở rộng | 300 | 944 | 274×42 | Không |
| 1280×720 | Thu gọn | 288 | 956 | 262×42 | Không |
| 1024×768 | Mở rộng | 300 | 700 | 274×42 | Không |
| 1024×768 | Thu gọn | 288 | 712 | 262×42 | Không |

Runtime speech mô phỏng kiểm thêm 1600×900, panel không tràn ngang; số đo clientWidth nhỏ hơn bounding rect 2px do border. Browser fullscreen thực, popup TV thực, 70/30, 60/40, Hình toàn màn, Focus, Phóng chữ đều đạt trong ca runtime. Scaling/DPI và fullscreen trên Windows/TV thật chưa thử.

## Evidence và kết luận

Ảnh `REAL_UI_*` chụp UI với Speech API nguyên bản: expanded/compact tại 1920×1080, 1366×768, 1280×720, 1024×768; knowledge và tools group. `MOCK_UI_*` thêm 1600×900 và fullscreen; provider mô phỏng không tạo audio. `MOCK_TEACHER_SPEAKING/PAUSED` là bằng chứng state UI tích hợp, không phải giọng thật.

CONTROL PANEL **PASS trong cloud**: ba nhóm rõ, teaching dễ truy cập, giọng đọc compact, CHỐT một dòng tại các viewport đã thử, preview vẫn chính, control cũ được giữ và chạy runtime. Windows physical vẫn PENDING.
