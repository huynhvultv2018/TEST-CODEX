# Changed files

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


## Bốn tệp gốc sửa

| Tệp | Thay đổi | Mục đích |
|---|---|---|
| `WEB_LIVE/teacher.html` | Di chuyển fragment control sẵn có vào ba nhóm, thêm compact TTS controls và nạp stylesheet/module mới ở cuối. | Bố cục panel và điều khiển speech. |
| `WEB_LIVE/teacher.js` | Hook cancel đầu start/go/showImporter; refresh TTS sau render. | Dừng tiếng cũ trước đổi màn/bài, cập nhật block. |
| `WEB_LIVE/tv.html` | Thêm CSS highlight và module presentation/TV trước tv.js. | TV nhận registry/highlight, không phát speech. |
| `WEB_LIVE/tv.js` | Sau fitText gọi TTSTVPresentation.refresh(d). | Thu block thật sau render/fit, đồng bộ text đang hiện. |

113 ID và 61 onclick của teacher.html gốc được bảo toàn (Counter kiểm tra, không chỉ đếm tổng). Top bar và handler bài/công cụ gốc giữ nguyên. Không thay lesson schema, engine hay content.

## Bảy tệp runtime mới

| Tệp | Vai trò |
|---|---|
| `WEB_LIVE/math-speech.js` | MathSpeechPreprocessor, parser/dictionary và chuyển text speech. |
| `WEB_LIVE/tts-controller.js` | TTSController, voice/settings/state/queue/error/single-owner. |
| `WEB_LIVE/tts-presentation.js` | Packet riêng, context, hash text, visibility và transport. |
| `WEB_LIVE/tts-teacher.js` | Whitelist block, compact UI, icon và auto-cancel lifecycle. |
| `WEB_LIVE/tts-tv.js` | Registry block TV hiện hữu và highlight ổn định. |
| `WEB_LIVE/tts-ui.css` | Minimal grouping/width/compact CSS và icon/outline preview. |
| `WEB_LIVE/tts-highlight.css` | Outline/inset shadow trên TV, không reflow. |

TTS không phụ thuộc package/network/service mới; Web Speech API của trình duyệt. Test provider chỉ ở `TTS_UI_TESTS`, không được teacher.html/tv.html nạp.

## Tệp bàn giao/kiểm thử mới

Sáu báo cáo yêu cầu, README hiện hành, `SHA256SUMS.txt`; scripts và README tại `TTS_UI_TESTS`; JSON/log/gallery/screenshot tại `TTS_UI_EVIDENCE`. Các harness regression mới là bản sao để giữ baseline history nguyên trạng. Đây là file kiểm thử/bàn giao, không được runtime nạp.

## Khóa baseline

Audit trực tiếp ZIP gốc có 144 tệp: 140 tệp không đổi, 4 tệp ở bảng trên đổi, 0 missing. Hash cũ/mới và hash bảy module mới trong `TTS_UI_EVIDENCE/baseline-integrity.json`. ZIP baseline vẫn SHA-256 `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`. ZIP Motion đính kèm vẫn `3cac206b5189007bd35bf8cb40ead0777932105ff827a20d9fd66e66197355ab`.

Mọi tệp lịch sử/report/screenshot/checksum baseline giữ nguyên; manifest cũ không được cập nhật. `SHA256SUMS.txt` mới là manifest candidate TTS/UI. Không thay source trong repository GitHub, không commit/merge production, không bump version production, không xóa baseline.
