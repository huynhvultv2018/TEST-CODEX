@echo off
setlocal
cd /d "%~dp0"
if not exist "LAUNCHER\START_LAUNCHER.bat" (
  echo Khong tim thay LAUNCHER\START_LAUNCHER.bat trong goi WEB LIVE.
  pause
  exit /b 1
)
if not exist "WEB_LIVE\teacher.html" (
  echo Khong tim thay WEB_LIVE\teacher.html trong goi WEB LIVE.
  pause
  exit /b 1
)
if not exist "LAUNCHER\start_web_live.py" (
  echo Khong tim thay LAUNCHER\start_web_live.py trong goi WEB LIVE.
  pause
  exit /b 1
)
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 -B "LAUNCHER\start_web_live.py"
  if errorlevel 1 goto :failed
  exit /b 0
)
python --version >nul 2>&1
if not errorlevel 1 (
  python -B "LAUNCHER\start_web_live.py"
  if errorlevel 1 goto :failed
  exit /b 0
)
echo Can Python 3.10+ de chay WEB LIVE qua HTTP va Local Launcher.
:failed
pause
exit /b 1
