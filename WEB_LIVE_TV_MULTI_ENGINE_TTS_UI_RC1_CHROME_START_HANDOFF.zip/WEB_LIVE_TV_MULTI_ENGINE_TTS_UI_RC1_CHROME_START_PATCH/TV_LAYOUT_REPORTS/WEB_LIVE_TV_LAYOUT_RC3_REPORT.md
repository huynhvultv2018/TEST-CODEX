# WEB LIVE — TV LAYOUT RC3 / MẪU 4

**OVERALL = PARTIAL — CHỜ DUYỆT BỐ CỤC VÀ RUNTIME TV THẬT. KHÔNG PRODUCTION.**

Ngày: 2026-10-01. Phạm vi: presentation layer TV, không redesign.

## Baseline lock

`BASELINE_LOCK = PASS`.

| File | Identity | Dung lượng | SHA-256 |
|---|---|---|---|
| WEB_LIVE_PEDAGOGY_RC3_CANDIDATE.zip | RC3_PED1 contract adaptation trên WEB LIVE V1.1.5; candidate mới nhất trong phiên, trạng thái runtime PARTIAL | 2251662 byte | `3fd02a31e11689ada8f615f31bc6745e70321f96d3ec9239cb4206dadde3713e` |

Archive gốc không sửa. Tạo snapshot chỉ đọc và working copy mới. File list/hash gốc: evidence/BASELINE_LOCK.json. Không tự chọn baseline khác và không coi bản RC3 trước là Production/acceptance mới.

## Patch

Chỉ sửa `WEB_LIVE/tv.html`, `tv.js`, `tv-ui.css`; thêm helper `tv-layout.js`. Không sửa Teacher, common.js/image resolver, zip.js/importer, pedagogy.js/pedagogy-teacher.js, navigation, bất kỳ nội dung SOẠN_TRƯỚC/LIVE JSON, SGK/PPCT, hint/answer/probe/flow/core hoặc Demo/Launcher. Chứng cứ diff và hash trước/sau kèm theo. README/report/checksum là metadata đóng gói riêng.

- Header TV tách tên mục và tên hoạt động từ sgkTrace.path / tiêu đề gốc; không viết lại title. Tên mục lớn hơn rõ rệt, dùng vùng đầu gọn theo chiều cao viewport.
- OBSERVE/DISCOVER/QUESTION/PREDICT RC3 ưu tiên hình trái, nhiệm vụ phải. Mặc định 60/40; câu dài chuyển 55/45. Layout GV đã pin vẫn được tôn trọng, gồm 70/30 và Full Figure ở screen có geometry thật. Không cố áp Mẫu 4 cho lesson legacy.
- Không hình: câu hỏi đơn mở rộng; nếu có prose dẫn tình huống trước câu hỏi, prefix giữ nguyên sang vùng tình huống trái. Không sinh tình huống, không tự tóm tắt.
- Có nhiều dấu hỏi ở các block riêng: mặc định focus đơn vị đầu, toàn bộ source vẫn trong DOM; GV dùng Focus Line hiện có để chọn đơn vị khác. Nội dung sau một dấu hỏi vẫn đi cùng nhóm đến câu hỏi tiếp theo. Không thay thứ tự/nav hoặc tạo task mới.
- Hint hiện dưới câu hỏi theo disclosure RC3 cũ. Khi Answer được reveal, presentation thay vùng question/hint bằng answer để tránh nhồi ba khối cùng lúc; back/next vẫn reset theo Teacher. Knowledge Close và Quick Check có variant riêng. TV không render probe/expected response/common error hoặc cảnh báo offline chi tiết.
- Hình object-fit contain, không crop/đổi pixel. Hai tài nguyên geometry + analysis hiện có giữ đúng role; không thêm images[] hay đổi schema. SVG overlays vẫn dùng figureInner/transform cũ ở hình geometry thực.

## Màn thực Tin 8 — Hoạt động 3: Tin giả

Task `T8W4_THINK` (màn 5/29), question nguyên văn:

> Từ ví dụ và Hình 2.3, em nghĩ vì sao cần xem lại trước khi chia sẻ nội dung này?

Header dòng 1: `2. THÔNG TIN ĐÁNG TIN CẬY`. Dòng 2: `Hoạt động 3. Tin giả`.

Source task này khai báo imageMode:none, sceneStart:true, resourceRequired:true và SGK trace hd3; không gắn ảnh riêng. TV lấy lại resource **đã xuất hiện trước** tại `T8W4_01`, chỉ khi cùng lesson đang active, cùng sgkTrace.unitId, sourceRef.path/SHA/book_page và không là analysis screen. Không dùng ảnh tương lai, không lấy từ lesson khác. `resolveScreenVisuals(lesson,4).geometry` vẫn null trước/sau. Đây là resource ngữ cảnh hiển thị, không trở thành currentGeometryImage hay cache inheritance.

Không đưa Board/Cover/Smart/Pointer của scene khác lên resource ngữ cảnh. Double-click ở resource ngữ cảnh không gửi geometry-toggle request sai scope. Fullscreen toàn TV vẫn là API cũ. Giáo viên không có thêm công cụ/mode mới; geometry thật giữ các overlay và thao tác cũ. Đây là giới hạn presentation-only có chủ đích, không mở rộng Teacher.

`resourceFocus` trong bài thật là văn bản, không có vùng tọa độ: nhấn khung tài nguyên quan sát, giữ hướng dẫn công khai trong caption khi không trùng câu hỏi, không đoán crop/point/cạnh. Nếu cần chỉ vùng chi tiết trên resource ngữ cảnh thì còn cần GV hướng dẫn trực tiếp; hotfix này không bịa geometry metadata. resourceLocation=SGK giữ nguyên.

Hình 2.3 gốc chỉ **147×105 pixel**; phóng lớn giữ đúng ảnh/tỉ lệ nhưng có thể mờ. Không tự tạo lại/khử mờ ảnh SGK. Readability cần acceptance thật.

## Case kiểm thử

| Case | Logic / DOM doubles đã kiểm | Browser thực |
|---|---|---|
| 01 — Hình + câu ngắn | Mẫu 4, 60/40, nguồn hình giữ nguyên | PENDING |
| 02 — Hình + câu dài | 55/45; không viết lại/cắt câu | PENDING overflow |
| 03 — Hai hình | Geometry + analysis có hai vùng nguồn; analysis không trở thành geometry; helper đặt tài nguyên thứ hai bên trái | PENDING DOM/CSS thực |
| 04 — Không hình | Câu đơn mở rộng vùng đọc; prose trước dấu hỏi có thể thành tình huống trái nguyên văn | PENDING |
| 05 — resourceFocus | Khung tài nguyên được nhấn; chỉ dẫn khác câu hỏi giữ trong caption; không suy đoán tọa độ/crop | PENDING quan sát lớp |
| 06 — Hint | Hint1/2 thủ công, giữ ảnh và layout; nằm dưới câu hỏi | PENDING fit |
| 07 — Answer | Chỉ reveal theo state GV; CSS thay vùng question/hint khi answer hiện | PENDING CSS thực |
| 08 — Knowledge Close | Variant riêng, content rỗng khi chưa GV chốt; reveal vẫn dùng lock RC3 | PENDING |
| 09 — Quick Check | Variant tập trung nhiệm vụ, không ép 60/40 khi không hình | PENDING |
| 10 — Back/Next sau reveal | Reset Hint/Answer/Knowledge; state truyền vào TV đúng | PENDING navigation/sync thật |

## Responsive và minh họa

| Độ phân giải | Minh họa SVG/font metrics | Browser/CSS viewport |
|---|---|---|
| 1366×768 | Câu hỏi 4 dòng, font mô hình ~36.9 px; nằm trong khung mô hình | NOT RUN |
| 1600×900 | 4 dòng, ~43.2 px | NOT RUN |
| 1920×1080 | 4 dòng, ~51.8 px | NOT RUN |
| 3840×2160 | 4 dòng, ~98 px | NOT RUN |

PNG/SVG ghi rõ MINH HỌA BỐ CỤC, KHÔNG PHẢI ẢNH CHỤP RUNTIME. Font metrics mô hình không xác nhận CSS browser, font-weight, scrollHeight, overlay, latency hay việc đọc cuối lớp. Không dùng minh họa để chứng nhận responsive PASS.

CSS dùng minmax(0,...), min-width/min-height:0, contain, overflow-x:hidden và font có sàn. Với source quá dài chưa fit, fallback đọc dọc giữ chữ thay vì clip/thu nhỏ vô hạn; **nếu fallback này xuất hiện trong acceptance thì chưa đạt tiêu chí không overflow của thầy**. Chưa chứng nhận không scroll/không cắt ở browser.

## Kết quả và gaps

19 kiểm tra layout/render/role/state trong Node VM + 266 checks contract/state trên 3 lesson PASS. 11 suite hồi quy kế thừa PASS, gồm scene/image/analysis, draw/cover/smart, Math Atomic, focus/highlight/pointer/timer, Demo mock/API. Không có lỗi assertion source mở trong phần đã kiểm.

Browser audit trước từ chối file: trước navigation; không dùng HTTP/alternate browser để vượt. Chưa có screenshot DOM thật của candidate. Vì vậy Điều kiện PASS 1–10 về cảm nhận/cỡ chữ/overflow/sync/Windows thực là PENDING, không tuyên bố PASS tổng. Điều kiện 11–14 (không sửa Soạn/SGK/flow/redesign) đã audit hash/source.

RC3 baseline còn gap upstream EXPORT thiếu PPCT/SGK và chưa acceptance; nâng layout không giải quyết hay xóa gap đó. Candidate mới không nâng version/Production, không thay acceptance baseline. Dừng sau patch/test/evidence/package/checksum.
