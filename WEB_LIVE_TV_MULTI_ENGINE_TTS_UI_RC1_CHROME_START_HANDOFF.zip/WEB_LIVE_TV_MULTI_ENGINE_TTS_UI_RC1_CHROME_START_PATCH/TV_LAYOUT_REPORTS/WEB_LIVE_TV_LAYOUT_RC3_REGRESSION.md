# WEB LIVE — TV LAYOUT RC3 REGRESSION

**OVERALL = PARTIAL — CHỜ DUYỆT BỐ CỤC VÀ RUNTIME TV THẬT. KHÔNG PRODUCTION.**

## Ba bài bắt buộc

| Bài | Screen | Contract/render/state checks | Navigation stress |
|---|---|---|---|
| Tin6 Tuần4 RC3_PED1 | 41 | 95 PASS | 300 thao tác VM |
| Tin6 Tuần5 RC3_PED1 | 32 | 95 PASS | 300 thao tác VM |
| Tin8 Tuần4 RC3_PED1 | 29 | 76 PASS | 300 thao tác VM |

102 screen giữ id/content/answer/guidance/flow/core/time/resource/online metadata. Hint1 → Hint2 → Answer, Back/Next, Knowledge Close, Teacher khởi tạo lại ở task đang lưu, TV đọc lại state/storage đều được kiểm bằng actual JS trong VM với DOM doubles. Teacher file không đổi; UI CSS thay cách trình bày trên TV.

19 checks riêng cho layout, màn Tin giả, resource lấy đúng hd3, không pollution resolver, 10 case, default hidden Answer/Hint, nhóm nhiều câu qua Focus; file layout_results.json. Case03 đã kiểm plan giữ hai role, chưa đủ DOM/CSS runtime. Không biến test fixture thành lesson production.

## Hồi quy baseline

| Suite | Kết quả | Giới hạn |
|---|---|---|
| `test_math_atomic.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `test_classroom.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `stress_rc.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `ui_test_draw_board_regression.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `ui_test_lesson_switch.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `ui_test_v050_regression.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `test_tv_presentation.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `test_current_session.cjs` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `test_ui_structure.py` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `test_tv_handoff.py` | PASS | NON-BROWSER; DOM/Windows mocks khi có |
| `test_launcher.py` | PASS | NON-BROWSER; DOM/Windows mocks khi có |

Các script giữ assertion lịch sử V1.1.5; cập nhật path tới candidate và preload pedagogy.js/tv-layout.js theo dependency HTML. Wrapper chỉ nạp dependency, không đổi renderer/expectation. Log có chữ GV/TV/PASS từ harness upstream nhưng đều là Node VM, không bằng chứng browser/TV vật lý. Launcher API Python test local; Windows handoff mock, không mở Word/GeoGebra thật.

Stress legacy harness: 300 navigation, 210 layout, 150 zoom, 50 focus, 31 highlight, 76 fullscreen mô phỏng, 60 timer actions, 12 lesson activations, TV reload. Stress RC3 bổ sung 900 navigation. Không đo FPS/heap/memory leak hoặc latency truyền tab thật.

## Integrity

Chỉ 3 file TV sửa và 1 helper mới trước metadata đóng gói. Baseline archive SHA còn `3fd02a31e11689ada8f615f31bc6745e70321f96d3ec9239cb4206dadde3713e`; snapshot file hash giữ nguyên. Teacher/pedagogy/importer/nav/Launcher toàn bộ byte-identical. 3 LIVE package và 6 Soạn JSON/MD trong locked_inputs khớp hash bản đã khóa, không sửa lesson content hoặc SGK mapping.

CSS/static HTML: ID cũ giữ nguyên, script/link assets còn đủ, không CDN/API ngoài mới. Hình/diagram trong LIVE ZIP nguyên byte. Renderer không ghi localStorage/cache của geometry để lấy resource; current geometry null tại T8W4_THINK vẫn null. Private fields không có component TV.

## Chưa đạt chứng nhận runtime

| Hạng mục | Trạng thái |
|---|---|
| Responsive actual browser 1366/1600/1920/4K | NOT RUN |
| Horizontal scroll/overflow/clip/ảnh đè chữ | PENDING kiểm browser |
| Teacher–TV sync BroadcastChannel/window, F5, fullscreen thật | PENDING |
| Cỡ chữ/độ rõ Hình 2.3 và khoảng cách lớp | PENDING; nguồn 147×105 |
| Overlay drag/zoom/font metrics thật | PENDING |
| Word/GeoGebra/TV Windows thật | PENDING; code không đổi |

Acceptance: chạy START_WEB_LIVE.bat từ candidate; nạp Tin8 W4 RC3_PED1 ở RC3_PED1_TEST_PACKAGES. Mở TV, đến T8W4_THINK; đối chiếu header/hình/câu hỏi với bản minh họa nhưng đo DOM scrollWidth/clientWidth, scrollHeight/clientHeight thực. Kiểm Hint1/2 và Answer thay vùng question; Back/Next trở lại không lộ. Đổi đủ ba bài; Knowledge Close/Quick Check; focus nhóm câu; zoom/fullscreen trên geometry thật, sync/F5 và đóng/mở TV. Tại màn nhiều câu hỏi, dùng Focus Line ở Teacher chọn block cần hiện. Không sửa Soạn nếu chưa fit, báo đúng screen/viewport/state để sửa presentation trong lượt được duyệt sau.

Không tự chạy thêm feature, không Production. Dừng chờ thầy duyệt bố cục và runtime.
