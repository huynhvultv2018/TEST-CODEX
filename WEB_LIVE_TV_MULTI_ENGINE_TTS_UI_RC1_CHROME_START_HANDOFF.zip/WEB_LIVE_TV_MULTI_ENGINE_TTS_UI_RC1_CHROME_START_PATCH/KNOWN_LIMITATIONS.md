# Known limitations

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


## Gate còn PENDING

1. **Giọng Việt/Nam và audio thật:** cloud Chromium có SpeechSynthesis nhưng 0 voices. Chưa phát/ghi âm/đánh giá tiếng Việt. Kiểm Nam/voice selection trong mock chỉ là logic. Windows cần có giọng Việt thực sự được Chrome cung cấp; không bảo đảm mọi giọng cài trong Windows xuất hiện trong browser.
2. **Pause/Resume native:** voice/browser/OS có khác biệt. Events mock không chứng minh pause/resume của Windows voice. Phải nghe tiếng tạm dừng/tiếp tục thật, không chỉ nhìn label.
3. **Thiết bị TV/loa:** output là thiết bị Windows/Chrome đang dùng; SpeechSynthesis không có setSinkId trong patch. HDMI/loa/Bluetooth, volume và routing vật lý cần thử tại máy GV.
4. **Windows/TV:** chưa thử monitor Extend, DPI/fullscreen driver/Launcher/Word/GeoGebra physical handoff. Không thay Launcher/cấu hình để giả lập gate này.
5. **Đại số thực:** baseline không có LIVE.zip Đại số thật. Coverage cloud dùng fixture presentation; cần nạp gói thật do SOẠN_TRƯỚC xuất và thử trên máy GV.

## Giới hạn kỹ thuật có chủ đích

- Web Speech API chuẩn không có gender. Chỉ dùng gender metadata nếu được cung cấp hoặc voice do GV nghe và xác nhận; nếu unknown UI báo rõ, không suy từ tên. Voice đổi danh sách/URI theo môi trường sẽ fallback giọng Việt, không chắc giữ được exact voice giữa các máy.
- Giọng remote cần mạng; ưu tiên local trong locale, nhưng không chứng nhận offline nếu máy GV chỉ có giọng remote.
- Parser là tập toán cơ bản, không bao phủ toàn bộ LaTeX/MathML, ma trận, integral hay mọi dạng phân số lồng phức tạp. Không suy/giải toán khi parse không chắc; giữ/đọc token đã biết. Chữ x/AB/ABC được giữ trong speech text, cách voice phát âm nhãn cần nghe. Nội dung toán chỉ nằm trong ảnh/SVG/canvas không được đọc; cần text description hiện hữu.
- Block highlight được dùng thay word-level để tránh boundary không ổn định. Chỉ một presentation context được điều khiển trong luồng Teacher→TV hiện hành; patch không mở rộng thành hệ thống nhiều TV độc lập.
- LocalStorage là điều kiện để persist và giữ speech owner. Nếu storage bị chặn, TTS từ chối đọc với lỗi rõ, teaching còn dùng được. Profile/incognito/origin khác không chia sẻ settings/lease. Trường hợp crash/kill không gửi lifecycle, owner lease hết hạn 20 giây, TV highlight hết hạn nếu không heartbeat; đóng cửa sổ bình thường đã kiểm runtime qua beforeunload/pagehide. Không chứng nhận đồng bộ speech owner giữa các profile/origin khác nhau.
- Ở desktop 720/768 px cao, sideBody cần cuộn để tới giọng/công cụ; teaching primary vẫn sticky. Full HD mở rộng đủ ba heading, CHỐT một dòng. Các size/DPI chưa thử không được suy là PASS.

## Lỗi ngoài phạm vi

Không phát hiện lỗi cũ mới đủ bằng chứng trong các ca đã chạy để lập issue riêng. Các gate thiếu voice/gói thật/Windows ở trên là hạn chế môi trường hoặc coverage, không được gọi là lỗi source baseline. Không opportunistic fix. Nếu vòng physical phát hiện lỗi cũ, ghi FILE/FUNCTION/SYMPTOM/SEVERITY/EVIDENCE/RECOMMENDATION và tách khỏi patch.

## Checklist máy thật để đóng PENDING

1. Giải nén toàn bộ; Windows Extend, Chrome, máy GV + TV 1920×1080. Dùng cách mở baseline và START_WEB_LIVE.bat. Import Tin 6/Tin 8/Hình 8 và LIVE.zip Đại số thật, mở TV, kiểm preview/sync.
2. Chọn output Windows là loa/HDMI dự kiến; kiểm Chrome cung cấp giọng Việt. Nghe từng giọng; nếu metadata không rõ thì xác nhận Nam/Nữ trong tùy chọn, chọn Nam. Giữ rate 0.95 lần đầu; thử 6 rates/volume rồi reload kiểm settings.
3. Nghe câu hỏi/gợi ý/chốt và block answer đã reveal; bảo đảm không đọc menu/note/future answer/image. Nghe toàn bộ MathSpeech examples, x/AB/ABC và phân số tử/mẫu; đánh giá dễ hiểu, không đổi nghĩa.
4. Đang nghe thử Pause→Resume, Stop, Replay, block mới; NEXT/PREV, jump, load lesson, đóng Teacher. Xác nhận tiếng cũ dừng ngay, không queue, cửa sổ TV không đọc trùng. Mở Teacher thứ hai cùng profile/origin kiểm owner và TV context.
5. Kiểm highlight đúng block, không rung/reflow/đổi Focus; 70/30, 60/40, Hình toàn màn, Phóng chữ, Drawing/Label, Timer, fullscreen và panel compact/expanded ở DPI thực. Trên màn hẹp cuộn sideBody kiểm đủ controls.
6. Ghi browser/OS/voice URI + locale/output device + gender confirmed, artifact SHA, ngày, ảnh/video/audio và PASS/FAIL theo từng ca. Chỉ sau bằng chứng nghe/thiết bị mới đánh giá lại TTS và WINDOWS PHYSICAL.

**Dừng ở Candidate + HANDOFF. Không nâng production ở vòng này.**
