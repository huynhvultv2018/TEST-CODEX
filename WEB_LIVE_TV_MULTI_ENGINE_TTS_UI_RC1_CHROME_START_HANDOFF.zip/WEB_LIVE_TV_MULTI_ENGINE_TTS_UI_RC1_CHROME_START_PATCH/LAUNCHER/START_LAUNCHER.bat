@echo off
cd /d "%~dp0"
if exist "WebLiveLauncher.py" (
  py -3 --version >nul 2>&1
  if not errorlevel 1 (
    py -3 "WebLiveLauncher.py"
    goto :finished
  )
)
if exist "WebLiveLauncher.exe" (
  "WebLiveLauncher.exe"
  goto :finished
)
echo Khong tim thay Launcher co the chay. Can Python 3 hoac WebLiveLauncher.exe.
:finished
echo.
echo Launcher da dung. Kiem tra Python 3 va launcher_apps.json neu co loi.
pause
