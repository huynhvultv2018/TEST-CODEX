"""Loopback-only static WEB LIVE server; separate from the demo Launcher API."""
from __future__ import annotations

import hashlib
import json
import mimetypes
from pathlib import Path
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit

BIND_HOST = "127.0.0.1"
WEB_PORT = 47382
LAUNCHER_PORT = 47381
ALLOWED_WEB_ORIGINS = frozenset({
    f"http://127.0.0.1:{WEB_PORT}",
    f"http://localhost:{WEB_PORT}",
})
TEACHER_URL = f"http://127.0.0.1:{WEB_PORT}/WEB_LIVE/teacher.html"
HEALTH_PATH = "/__web_live_health__"
SERVICE_ID = "WEBLIVE_LOCAL_HTTP"


def package_fingerprint(package_root: Path) -> str:
    return hashlib.sha256(str(package_root.resolve()).encode("utf-8")).hexdigest()


class WebLiveHTTPHandler(BaseHTTPRequestHandler):
    server_version = "WebLiveLocalHTTP"
    sys_version = ""

    def log_message(self, *args):
        pass  # Do not print installation data, local paths, or request bodies.

    def _context_allowed(self) -> bool:
        document_navigation = (self.headers.get("Sec-Fetch-Mode") == "navigate"
                               and self.headers.get("Sec-Fetch-Dest") == "document")
        return (
            self.client_address[0] == BIND_HOST
            and self.headers.get("Host") in {f"127.0.0.1:{WEB_PORT}", f"localhost:{WEB_PORT}"}
            and (self.headers.get("Origin") is None or self.headers.get("Origin") in ALLOWED_WEB_ORIGINS)
            and (self.headers.get("Sec-Fetch-Site") != "cross-site" or document_navigation)
        )

    def _respond(self, status: int, data: bytes, content_type: str, *, head=False, location=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if location:
            self.send_header("Location", location)
        self.end_headers()
        if not head:
            self.wfile.write(data)

    def _serve(self, *, head=False):
        if not self._context_allowed():
            self._respond(403, b"Local WEB LIVE host/origin denied.", "text/plain", head=head)
            return
        path = unquote(urlsplit(self.path).path)
        if path == "/favicon.ico":
            self._respond(204, b"", "image/x-icon", head=head)
            return
        if path == HEALTH_PATH:
            data = json.dumps({"service": SERVICE_ID, "webPort": WEB_PORT,
                               "packageFingerprint": package_fingerprint(self.server.package_root)}).encode()
            self._respond(200, data, "application/json", head=head)
            return
        if path == "/":
            self._respond(302, b"", "text/plain", head=head, location="/WEB_LIVE/teacher.html")
            return
        if not path.startswith("/WEB_LIVE/") or "\\" in path or "\x00" in path:
            self._respond(404, b"Not found.", "text/plain", head=head)
            return
        try:
            file = (self.server.package_root / path.lstrip("/")).resolve()
            file.relative_to(self.server.web_root)
            if not file.is_file():
                raise OSError("not a file")
            data = file.read_bytes()
        except (OSError, ValueError):
            self._respond(404, b"Not found.", "text/plain", head=head)
            return
        content_type = {".js": "text/javascript; charset=utf-8", ".html": "text/html; charset=utf-8",
                        ".css": "text/css; charset=utf-8"}.get(file.suffix.lower())
        if not content_type:
            content_type = mimetypes.guess_type(file.name)[0] or "application/octet-stream"
        self._respond(200, data, content_type, head=head)

    def do_GET(self):
        self._serve()

    def do_HEAD(self):
        self._serve(head=True)


def create_web_server(package_root: Path) -> ThreadingHTTPServer:
    package_root = package_root.resolve()
    if not (package_root / "WEB_LIVE" / "teacher.html").is_file():
        raise ValueError("Khong tim thay WEB_LIVE/teacher.html trong goi.")
    server = ThreadingHTTPServer((BIND_HOST, WEB_PORT), WebLiveHTTPHandler)
    server.daemon_threads = True
    server.package_root = package_root
    server.web_root = (package_root / "WEB_LIVE").resolve()
    return server


def main() -> int:
    package_root = Path(__file__).resolve().parent.parent
    try:
        server = create_web_server(package_root)
    except (OSError, ValueError) as error:
        print(f"Khong khoi dong duoc WEB LIVE HTTP: {error}", flush=True)
        return 1
    print("WEB LIVE HTTP SERVER", flush=True)
    print(TEACHER_URL, flush=True)
    print("Ctrl+C de tat WEB server.", flush=True)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
