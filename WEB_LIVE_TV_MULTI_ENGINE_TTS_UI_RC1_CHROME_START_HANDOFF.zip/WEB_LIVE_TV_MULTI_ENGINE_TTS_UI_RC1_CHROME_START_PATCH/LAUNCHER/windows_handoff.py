"""Win32 desktop handoff for an already approved Word/GeoGebra launch.

No web request supplies a window handle, process ID, executable or coordinates.
The launcher enumerates and verifies native top-level application windows.
"""
from __future__ import annotations

from dataclasses import dataclass
import ctypes
from ctypes import wintypes
import sys


@dataclass(frozen=True)
class Monitor:
    name: str
    rect: tuple[int, int, int, int]
    work: tuple[int, int, int, int]
    primary: bool


@dataclass(frozen=True)
class AppWindow:
    hwnd: int
    pid: int
    exe_name: str
    title: str
    class_name: str


def choose_tv_monitor(monitors: list[Monitor], index: int | None) -> tuple[Monitor | None, str]:
    """Index is 1-based in device-name order; never guess among 3+ screens."""
    monitors = sorted(monitors, key=lambda m: m.name.casefold())
    if len(monitors) < 2:
        return None, 'NO_TV'
    if index is not None:
        if 1 <= index <= len(monitors) and not monitors[index - 1].primary:
            return monitors[index - 1], 'READY'
        return None, 'MONITOR_SELECTION_REQUIRED'
    if len(monitors) == 2:
        secondary = [m for m in monitors if not m.primary]
        if len(secondary) == 1:
            return secondary[0], 'READY'
    return None, 'MONITOR_SELECTION_REQUIRED'


class Win32Desktop:
    MONITORINFOF_PRIMARY = 1
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    TH32CS_SNAPPROCESS = 0x2
    GW_OWNER = 4
    GWL_EXSTYLE = -20
    WS_EX_TOOLWINDOW = 0x80
    WS_EX_TOPMOST = 0x8
    SW_RESTORE = 9
    SW_MAXIMIZE = 3
    SW_MINIMIZE = 6
    SWP_NOMOVE = 0x2
    SWP_NOSIZE = 0x1
    SWP_NOACTIVATE = 0x10
    SWP_SHOWWINDOW = 0x40
    HWND_TOPMOST = -1
    HWND_NOTOPMOST = -2

    def __init__(self):
        if sys.platform != 'win32':
            raise RuntimeError('Windows API chỉ có trên Windows')
        self.user32 = ctypes.WinDLL('user32', use_last_error=True)
        self.kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        # Use virtual-desktop physical coordinates on mixed-DPI displays when supported.
        try:
            awareness = self.user32.SetProcessDpiAwarenessContext
            awareness.argtypes, awareness.restype = [ctypes.c_void_p], wintypes.BOOL
            awareness(ctypes.c_void_p(-4))  # PER_MONITOR_AWARE_V2; existing app manifest may win.
        except AttributeError:
            pass
        self._original_topmost: dict[int, bool] = {}
        H = wintypes.HANDLE
        L = ctypes.c_ssize_t
        self._monitor_callback = ctypes.WINFUNCTYPE(wintypes.BOOL, H, H, ctypes.POINTER(wintypes.RECT), L)
        self._window_callback = ctypes.WINFUNCTYPE(wintypes.BOOL, H, L)
        self._signature(self.user32.EnumDisplayMonitors, [H, ctypes.POINTER(wintypes.RECT), self._monitor_callback, L], wintypes.BOOL)
        self._signature(self.user32.GetMonitorInfoW, [H, ctypes.c_void_p], wintypes.BOOL)
        self._signature(self.user32.EnumWindows, [self._window_callback, L], wintypes.BOOL)
        for method in ('IsWindow', 'IsWindowVisible', 'IsIconic'):
            self._signature(getattr(self.user32, method), [H], wintypes.BOOL)
        self._signature(self.user32.GetWindow, [H, wintypes.UINT], H)
        self._signature(self.user32.GetWindowRect, [H, ctypes.POINTER(wintypes.RECT)], wintypes.BOOL)
        self._signature(self.user32.GetWindowThreadProcessId, [H, ctypes.POINTER(wintypes.DWORD)], wintypes.DWORD)
        self._signature(self.user32.GetWindowTextW, [H, wintypes.LPWSTR, ctypes.c_int], ctypes.c_int)
        self._signature(self.user32.GetClassNameW, [H, wintypes.LPWSTR, ctypes.c_int], ctypes.c_int)
        self._signature(self.user32.ShowWindow, [H, ctypes.c_int], wintypes.BOOL)
        self._signature(self.user32.SetWindowPos, [H, H, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT], wintypes.BOOL)
        self._signature(self.user32.SetForegroundWindow, [H], wintypes.BOOL)
        self._signature(self.user32.MonitorFromWindow, [H, wintypes.DWORD], H)
        get_style = getattr(self.user32, 'GetWindowLongPtrW', self.user32.GetWindowLongW)
        self._signature(get_style, [H, ctypes.c_int], L)
        self.get_style = get_style
        self._signature(self.kernel32.OpenProcess, [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], H)
        self._signature(self.kernel32.QueryFullProcessImageNameW, [H, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL)
        self._signature(self.kernel32.CloseHandle, [H], wintypes.BOOL)
        self._signature(self.kernel32.CreateToolhelp32Snapshot, [wintypes.DWORD, wintypes.DWORD], H)
        self._signature(self.kernel32.Process32FirstW, [H, ctypes.c_void_p], wintypes.BOOL)
        self._signature(self.kernel32.Process32NextW, [H, ctypes.c_void_p], wintypes.BOOL)

    @staticmethod
    def _signature(func, args, result):
        func.argtypes, func.restype = args, result

    def monitors(self) -> list[Monitor]:
        class MONITORINFOEXW(ctypes.Structure):
            _fields_ = [('cbSize', wintypes.DWORD), ('rcMonitor', wintypes.RECT),
                        ('rcWork', wintypes.RECT), ('dwFlags', wintypes.DWORD),
                        ('szDevice', wintypes.WCHAR * 32)]

        def coords(rect):
            return rect.left, rect.top, rect.right, rect.bottom

        found = []
        def add(handle, _dc, _rect, _data):
            info = MONITORINFOEXW()
            info.cbSize = ctypes.sizeof(info)
            if self.user32.GetMonitorInfoW(handle, ctypes.byref(info)):
                found.append(Monitor(info.szDevice, coords(info.rcMonitor), coords(info.rcWork),
                                     bool(info.dwFlags & self.MONITORINFOF_PRIMARY)))
            return True

        callback = self._monitor_callback(add)
        if not self.user32.EnumDisplayMonitors(None, None, callback, 0):
            raise OSError('Không liệt kê được màn hình Windows')
        return sorted(found, key=lambda m: m.name.casefold())

    def _exe_name(self, pid: int) -> str:
        process = self.kernel32.OpenProcess(self.PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not process:
            return ''
        try:
            buffer = ctypes.create_unicode_buffer(32768)
            size = wintypes.DWORD(len(buffer))
            if not self.kernel32.QueryFullProcessImageNameW(process, 0, buffer, ctypes.byref(size)):
                return ''
            return buffer.value.replace('/', '\\').rsplit('\\', 1)[-1].casefold()
        finally:
            self.kernel32.CloseHandle(process)

    def descendants(self, pid: int) -> set[int]:
        if not pid:
            return set()
        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [('dwSize', wintypes.DWORD), ('cntUsage', wintypes.DWORD),
                        ('th32ProcessID', wintypes.DWORD), ('th32DefaultHeapID', ctypes.c_size_t),
                        ('th32ModuleID', wintypes.DWORD), ('cntThreads', wintypes.DWORD),
                        ('th32ParentProcessID', wintypes.DWORD), ('pcPriClassBase', wintypes.LONG),
                        ('dwFlags', wintypes.DWORD), ('szExeFile', wintypes.WCHAR * 260)]
        snapshot = self.kernel32.CreateToolhelp32Snapshot(self.TH32CS_SNAPPROCESS, 0)
        if not snapshot or snapshot == ctypes.c_void_p(-1).value:
            return set()
        try:
            entry = PROCESSENTRY32W(); entry.dwSize = ctypes.sizeof(entry)
            parents = {}
            if self.kernel32.Process32FirstW(snapshot, ctypes.byref(entry)):
                while True:
                    parents[entry.th32ProcessID] = entry.th32ParentProcessID
                    if not self.kernel32.Process32NextW(snapshot, ctypes.byref(entry)):
                        break
            found = {pid}
            for _ in range(8):  # Bounded depth; Windows app launch trees are short.
                next_set = found | {child for child, parent in parents.items() if parent in found}
                if next_set == found:
                    break
                found = next_set
            return found
        finally:
            self.kernel32.CloseHandle(snapshot)

    def windows(self, allowed_names: frozenset[str]) -> list[AppWindow]:
        found = []
        pid_names: dict[int, str] = {}
        def add(hwnd, _data):
            if not self.user32.IsWindowVisible(hwnd) or self.user32.GetWindow(hwnd, self.GW_OWNER):
                return True
            if self.get_style(hwnd, self.GWL_EXSTYLE) & self.WS_EX_TOOLWINDOW:
                return True
            rect = wintypes.RECT()
            if not self.user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                return True
            if (rect.right - rect.left < 160 or rect.bottom - rect.top < 100) and not self.user32.IsIconic(hwnd):
                return True
            pid = wintypes.DWORD()
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if not pid.value:
                return True
            name = pid_names.setdefault(pid.value, self._exe_name(pid.value))
            if name not in allowed_names:
                return True
            title = ctypes.create_unicode_buffer(512)
            klass = ctypes.create_unicode_buffer(256)
            self.user32.GetWindowTextW(hwnd, title, len(title))
            self.user32.GetClassNameW(hwnd, klass, len(klass))
            if not title.value:  # Skip hidden/splash/background host windows with no title.
                return True
            found.append(AppWindow(int(hwnd), pid.value, name, title.value, klass.value))
            return True
        callback = self._window_callback(add)
        if not self.user32.EnumWindows(callback, 0):
            raise OSError('Không liệt kê được cửa sổ ứng dụng')
        return found

    def valid(self, window: AppWindow, allowed_names: frozenset[str]) -> bool:
        if not self.user32.IsWindow(window.hwnd):
            return False
        return any(w.hwnd == window.hwnd and w.pid == window.pid for w in self.windows(allowed_names))

    def present(self, window: AppWindow, monitor: Monitor) -> bool:
        hwnd = window.hwnd
        if not self.user32.IsWindow(hwnd):
            return False
        if hwnd not in self._original_topmost:
            self._original_topmost[hwnd] = bool(self.get_style(hwnd, self.GWL_EXSTYLE) & self.WS_EX_TOPMOST)
        self.user32.ShowWindow(hwnd, self.SW_RESTORE)
        left, top, right, bottom = monitor.work
        if not self.user32.SetWindowPos(hwnd, self.HWND_TOPMOST, left, top, right - left, bottom - top,
                                         self.SWP_SHOWWINDOW):
            return False
        self.user32.ShowWindow(hwnd, self.SW_MAXIMIZE)
        self.user32.SetForegroundWindow(hwnd)  # Windows may deny focus stealing; topmost still covers TV.
        rect = wintypes.RECT()
        return bool(self.user32.GetWindowRect(hwnd, ctypes.byref(rect)) and
                    self.user32.MonitorFromWindow(hwnd, 0) == self._monitor_handle(monitor.name))

    def _monitor_handle(self, name: str):
        found = []
        class INFO(ctypes.Structure):
            _fields_ = [('cbSize', wintypes.DWORD), ('rect', wintypes.RECT),
                        ('work', wintypes.RECT), ('flags', wintypes.DWORD),
                        ('device', wintypes.WCHAR * 32)]
        def check(handle, _dc, _rect, _data):
            info = INFO(); info.cbSize = ctypes.sizeof(info)
            if self.user32.GetMonitorInfoW(handle, ctypes.byref(info)) and info.device == name:
                found.append(handle)
            return True
        callback = self._monitor_callback(check)
        self.user32.EnumDisplayMonitors(None, None, callback, 0)
        return found[0] if found else None

    def minimize(self, window: AppWindow) -> bool:
        hwnd = window.hwnd
        if not self.user32.IsWindow(hwnd):
            return False
        if not self._original_topmost.pop(hwnd, False):
            self.user32.SetWindowPos(hwnd, self.HWND_NOTOPMOST, 0, 0, 0, 0,
                                     self.SWP_NOMOVE | self.SWP_NOSIZE | self.SWP_NOACTIVATE)
        self.user32.ShowWindow(hwnd, self.SW_MINIMIZE)
        return bool(self.user32.IsIconic(hwnd))
