WEB LIVE V1.1.5 — DEMO TRỰC TIẾP TRÊN TV (CANDIDATE)

Đặt Windows Display ở chế độ Extend. Chạy START_WEB_LIVE.bat ở thư mục gốc: bật WEB HTTP server 127.0.0.1:47382, bật Local Launcher API 127.0.0.1:47381 và mở http://127.0.0.1:47382/WEB_LIVE/teacher.html. Nhập bài rồi bấm MỞ TV; TV cũng chạy HTTP cùng origin. Không mở HTML bằng file://. Cần Python 3.10+ cho cách khởi động HTTP này.

Launcher chỉ nhận đúng http://127.0.0.1:47382 và http://localhost:47382; không nhận Origin:null hay wildcard. 47381 chỉ là API, không phải trang Teacher; truy cập trực tiếp API bằng thanh địa chỉ có thể báo ORIGIN_DENIED vì không có Origin. Kết nối được kiểm qua Teacher tới /status và /pair. Nếu bản Launcher cũ đang chạy, đóng cửa sổ đó bằng Ctrl+C rồi chạy START_WEB_LIVE.bat mới; không chạy song song hai bản trên cùng port. Script giữ nguyên port, không tự chuyển port hoặc tắt dịch vụ không thuộc nó.

GV bấm DEMO TRỰC TIẾP và xác nhận: Word/GeoGebra mở đúng file, Launcher tìm cửa sổ tối đa 12 giây, chuyển lên TV và maximize. GV bấm TRỞ LẠI WEB LIVE trên laptop: cửa sổ ứng dụng được thu nhỏ, tv.html hiện lại với state cũ. Ứng dụng và file không bị đóng. Bấm DEMO lần nữa sẽ dùng cửa sổ đang mở nếu còn.

Mặc định đúng 2 màn hình: dùng monitor không phải Primary, dù TV nằm trái/phải/trên/dưới. Một màn hình: ứng dụng vẫn mở ở màn hiện tại và Teacher báo không có TV. Từ 3 màn hình: chỉnh LAUNCHER/launcher-display.json với tvMonitorIndex tương ứng số thứ tự màn hình Launcher in khi khởi động (tên thiết bị sắp xếp, bắt đầu từ 1). Chỉ chọn monitor không phải Primary. Khởi động lại Launcher sau khi đổi config. Không cần cấu hình pixel hay đường dẫn màn hình.

Nếu ứng dụng mở nhưng không tìm được cửa sổ, bấm THỬ CHUYỂN LẠI để tìm lại mà không tạo process mới. Nếu Windows không cho đưa focus lên trước, chọn ứng dụng trên Taskbar để thao tác. Nếu TV trình chiếu ở Duplicate mode thì không hỗ trợ handoff hai màn hình độc lập.

launcher-config.json giữ installationId/installationKey tương ứng WEB_LIVE/runtime-config.js. Không sửa, tách lẻ hoặc gửi khóa vào lesson. Session token chỉ ở bộ nhớ tab GV; Launcher restart sẽ ghép phiên mới. TV không tải khóa, không gọi Launcher.

launcher_apps.json chỉ ánh xạ Word/GeoGebra tới EXE đã cài. Tệp demo đặt trong LAUNCHER/demos/; metadata file demo_word.docx hoặc demos/demo_word.docx đều hợp lệ. Launcher kiểm tra whitelist, phần mở rộng, traversal và symlink; không chạy lệnh shell.

Candidate nguồn cần Python 3.10+ (py -3). Có thể build WebLiveLauncher.exe trên Windows bằng BUILD_WINDOWS_EXE.bat sau khi cài PyInstaller, đặt EXE cạnh launcher_apps.json, launcher-config.json, launcher-display.json và demos. Gói chưa kèm EXE; cần runtime test trên Windows laptop + TV thật trước khi nâng Production.
