@echo off
cd /d "%~dp0"
rem Chay thu cong tren Windows sau khi da cai san Python 3 va PyInstaller.
py -3 -m PyInstaller --onefile --name WebLiveLauncher WebLiveLauncher.py
echo EXE nam trong dist\WebLiveLauncher.exe; copy vao thu muc nay cung launcher_apps.json, launcher-config.json va demos.
pause
