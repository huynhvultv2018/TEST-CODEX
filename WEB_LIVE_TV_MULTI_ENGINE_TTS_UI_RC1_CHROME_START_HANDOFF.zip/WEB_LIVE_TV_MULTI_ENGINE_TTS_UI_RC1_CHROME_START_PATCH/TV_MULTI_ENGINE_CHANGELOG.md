# RC1 Changelog

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

- Thêm subject router conservative, intermediate view model và component presentation chung.
- Thêm Activity Cards, option grids 2–5 lựa chọn, observe image-first và task/product split.
- Thêm Math Reasoning Board: expression/system atomic, equation transformation, word problem grid, identity steps, table và graph.
- Thêm Geometry Proof Board: split figure-first, statement/goal/clues, dependency branches chỉ từ bước GV đã mở.
- Giữ source hierarchy và Teacher focus index theo Classroom.parts.
- Bổ sung whole-expression nowrap bên ngoài math-atomic.js; không thay thuật toán toán học.
- Fit theo DOM: spacing → layout cho phân tích dài → font → last-resort scrollbar.
- Nạp module local từ tv.html; không CDN hoặc đổi Teacher/Launcher.
- Bổ sung 48 PNG, JSON kết quả, gallery offline, hai harness Playwright và tám báo cáo.
- Tạo checksum candidate mới; các báo cáo/checksum RC4 là lịch sử nguồn.

DỪNG TẠI CANDIDATE, không nâng production.
