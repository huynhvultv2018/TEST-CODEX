# TV LAYOUT RC4 — REGRESSION

**PARTIAL — CHỜ RUNTIME TEST TRÊN LAPTOP + TV THẬT. KHÔNG PRODUCTION.**

## RC3_PED1 thực

| Package | Screens | Contract/render/state checks | Stress navigation |
|---|---|---|---|
| Tin6 W4 | 41 | 95 PASS | 300 VM actions |
| Tin6 W5 | 32 | 95 PASS | 300 VM actions |
| Tin8 W4 | 29 | 76 PASS | 300 VM actions |

266 checks, 900 navigation actions chạy lại trên source RC4. Dùng actual importer, Teacher/TV JS và DOM doubles trong Node VM; không phải Teacher/TV browser. Hint1→Hint2→Answer, Next/Back, Close gating, state/storage khởi tạo lại, private fields, core/resource/online metadata và exact source mapping được kiểm. Không suy ra tab sync thật từ truyền state trong harness.

19 kiểm tra Model4 RC3 chạy lại; thêm 25 Student UI checks (all 102 source screen text không đổi, default không hint/answer, intro hierarchy, subtitle exact source, application hai block, profile complexity, badge/demo, info fields, fit re-measure và floor).

7 package/fixture producer: 198 screens cho baseline RC3 và RC4; importer/source trace/scene role/hidden answer đều PASS. 3 LIVE cũ: 39+27+27=93 screens, import/hidden answer/legacy text PASS. 8 PNG resource: SHA khớp evidence khóa upstream, decode được, không sửa ảnh.

## A–L coverage

| Case | Dữ liệu/test | Mức evidence |
|---|---|---|
| A Review | T8W4_OPEN_02 + cả 3 bài | DOM double, source exact |
| B Intro | T8W4_OPEN_03 + cả 3 bài | 3 lớp emphasis, source exact |
| C Discover | OBSERVE/DISCOVER/THINK trong 3 bài | Model4 plan/apply |
| D Knowledge | 3 bài, knowledgeCloseVisible | Gating và manual reveal |
| E Practice | T8W4_14 và 3 bài | Subtitle/task giữ text |
| F Application | T8W4_18 và 3 bài | Hai source block, không thêm instruction |
| G Hint | Hint1/Hint2 của 3 bài | Teacher/TV JS trạng thái bằng harness |
| H Answer | Manual reveal, Back/Next | Không tự reveal |
| I Steps | Historical proof/analysis harness | Progressive count/DOM mock; không thêm steps vào RC3 source |
| J Image+text | Hình2.3 contextual + geometry fixtures | Image-role/scene logic, chưa đo CSS overlay thật |
| K Demo | Sample DEMO_TRUC_TIEP_SAMPLE_LIVE.zip kế thừa + handoff test | 3 bài RC3_PED1 không có demo; sample không làm điều kiện kích hoạt. TV không client launch; Windows mock |
| L Long | Màn dài trong native fixtures + complexity/floor test | Không clip/delete source trong code; fit browser PENDING |

Node demo ZIP fixture cần adapter deflate-raw bằng zlib để tương đương stream giải nén browser; lần thử đầu thiếu adapter là lỗi harness, không sửa importer/ZIP. Không dùng adapter đó trong candidate.

## Toàn bộ suite lịch sử kế thừa từ các report RC3

| Suite | Kết quả | Scope |
|---|---|---|
| `test_math_atomic.cjs` | PASS | NON-BROWSER; mocks khi có |
| `test_classroom.cjs` | PASS | NON-BROWSER; mocks khi có |
| `stress_rc.cjs` | PASS | NON-BROWSER; mocks khi có |
| `ui_test_draw_board_regression.cjs` | PASS | NON-BROWSER; mocks khi có |
| `ui_test_lesson_switch.cjs` | PASS | NON-BROWSER; mocks khi có |
| `ui_test_v050_regression.cjs` | PASS | NON-BROWSER; mocks khi có |
| `test_tv_presentation.cjs` | PASS | NON-BROWSER; mocks khi có |
| `test_current_session.cjs` | PASS | NON-BROWSER; mocks khi có |
| `test_ui_structure.py` | PASS | NON-BROWSER; mocks khi có |
| `test_tv_handoff.py` | PASS | NON-BROWSER; mocks khi có |
| `test_launcher.py` | PASS | NON-BROWSER; mocks khi có |

Các harness giữ assertion cũ; chỉ cập nhật path đến RC4 và preload dependencies theo HTML. Tên/alias version cũ trong log không phải baseline được chọn. Suite UI structure kiểm ID/assets và cấu trúc CSS tĩnh, không computed layout. Launcher test dùng API Python local; monitor/Windows handoff mock; không Word/GeoGebra thật.

Mixed stress: 300 navigation, 210 layout, 150 zoom, 50 focus,31 highlight,76 fullscreen mô phỏng,60 timer,12 lesson activation và TV reload; cộng 900 navigation contract mới. Không đo frame rate, heap hoặc network latency browser.

## Integrity và locks

Baseline ZIP SHA `daf2d1f30bdbbf0081ae28c6edd19e9bdf85152d583a5bf40e210e445fa31cc1` vẫn khớp. Chỉ 4 TV runtime files thay đổi. Teacher, Launcher/handoff, engine, importer, pedagogy và 3 LIVE ZIP/6 Soạn JSON/MD giữ byte. Root README_RC4_CANDIDATE, RC4_REPORTS và checksums là metadata đóng gói mới, không runtime feature.

Math Atomic engine/normalizer giữ nguyên; main sourceprefix được render lại bằng cùng renderMathAtomic, không nowrap toàn prose. Geometry image/analysis/cache unchanged; overlay coordinates vẫn trên figureInner. Timer chỉ chuyển DOM location, clock engine unchanged.

## Chưa chứng nhận

Responsive/screenshot/fullscreen browser, navigation/cross-window sync thật, overlay drag/resize/zoom thật, distance readability, Windows native Demo/return, offline ngắt Internet đều PENDING. Local code/assets không thêm dependency Internet; không chứng nhận hoàn tất hoạt động offline có app thật.

GAP upstream RC3: exporter reproduction vẫn thiếu PPCT_TIN_6.docx và SGK_TIN_6.pdf ở producer snapshot. Không thay/sửa source hoặc bỏ guard để chạy; đây là gap kế thừa, ngoài patch TV.

Không có failure assertion còn mở trong các lần test cuối. Candidate vẫn PARTIAL vì chưa đủ visual/runtime evidence.
