# TV LAYOUT RC4 — CHANGELOG

2026-10-02 — WEB LIVE TV LAYOUT RC4 CANDIDATE. Candidate only, overall PARTIAL.

- Kế thừa duy nhất ZIP RC3 SHA-256 `daf2d1f30bdbbf0081ae28c6edd19e9bdf85152d583a5bf40e210e445fa31cc1`; baseline gốc giữ read-only.
- Bổ sung TV info bar khoảng 6.5vh với metadata thực, counter và cùng Timer id.
- Bổ sung activity badge nhất quán theo type hiện có.
- Main task lớn hơn title/support. Intro có lớp context/question/instruction; prefix source bài tập giữ nguyên ở subtitle nhỏ.
- Text-only card 90vw auto-height; token navy/system fonts; responsive clamp và profile dựa trên source đang hiện + complexity.
- Fit đo lại sau giảm spacing, giảm font có giới hạn, vertical fallback minh bạch khi không fit.
- Giữ Model4/Think, geometry/analysis image roles, reveal, Teacher Focus, resource, TV state/sync và Demo Handoff.
- Chỉ sửa tv-layout.js, tv-ui.css, tv.html, một nhánh fitText của tv.js. Không sửa lesson, SOẠN_TRƯỚC, Teacher/Launcher/engines/schema.
- Rerun toàn bộ regression sẵn có và bổ sung UI helper tests. Logic PASS; screenshot/visual/runtime Windows NOT RUN.

Không phát hành Production. Dừng chờ runtime acceptance RC4 trên laptop + TV thật.
