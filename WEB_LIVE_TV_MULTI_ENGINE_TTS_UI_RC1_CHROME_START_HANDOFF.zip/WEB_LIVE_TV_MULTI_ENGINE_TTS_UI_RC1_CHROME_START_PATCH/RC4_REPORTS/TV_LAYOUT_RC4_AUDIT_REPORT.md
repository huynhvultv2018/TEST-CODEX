# TV LAYOUT RC4 — AUDIT

**PARTIAL — CHỜ RUNTIME TEST TRÊN LAPTOP + TV THẬT. KHÔNG PRODUCTION.**

Ngày: 2026-10-02. Baseline duy nhất là ZIP RC3 vừa được người dùng cung cấp. Nhánh V1.1.6 đã tạo trước yêu cầu mới chưa được patch và không dùng trong RC4.

## Baseline lock

| Mục | Giá trị |
|---|---|
| File thực nhận | WEB_LIVE_TV_LAYOUT_RC3_CANDIDATE(1).zip |
| Identity | WEB LIVE TV LAYOUT RC3 trên pedagogy RC3_PED1 |
| Dung lượng | 2.969.972 byte |
| SHA-256 | `daf2d1f30bdbbf0081ae28c6edd19e9bdf85152d583a5bf40e210e445fa31cc1` |
| Trạng thái upstream | Candidate; báo cáo RC3 ghi runtime PARTIAL |
| Khóa | BASELINE_LOCK = PASS; bản giải nén gốc READ ONLY |
| Working copy | WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE/ |

Hash file gốc được kiểm trước patch và kiểm lại sau patch. 70 file baseline giữ nguyên ở snapshot read-only. Không chọn V1.1.5 hoặc candidate khác làm baseline.

## Audit trực tiếp

Đã đọc tv-layout.js, tv-ui.css, tv.js, tv.html, pedagogy.js, TV_LAYOUT_REPORTS và RC3_REPORTS của chính ZIP RC3.

| Thành phần RC3 đã có | Phần giữ / phần còn thiếu |
|---|---|
| TVLayout.kind/plan/contextResource/primaryTask | Giữ nguyên phân loại Model 4/Quick/Knowledge, ảnh theo source trace, nhóm câu hỏi bằng Focus |
| Model 4 | Giữ hình/tình huống trái, câu hỏi phải, ratio 60/40 hoặc 55/45, layout GV pin 70/30 |
| Header hai tầng | Giữ section/activity; giảm chiều cao để có chỗ cho info bar |
| Reveal | Giữ toàn bộ quyết định Teacher; TV chỉ trình bày trạng thái nhận được |
| Adaptive cũ | Có clamp, spacing, font floor, scroll cuối cùng; còn thiếu phân cấp review/intro/practice/application và complexity profile |
| Breakpoint | max-aspect-ratio 4/3, max-width 900px, min-width 2560px; RC4 thêm max-height 780px |
| Tools/scene/cache/sync | Giữ engine và protocol; không tạo trạng thái lesson mới |
| RC3 evidence | Logic có kết quả; hình Model4 là minh họa có watermark, không phải screenshot browser thật |

## Phạm vi patch

Chỉ bốn file runtime thay đổi:

- WEB_LIVE/tv-layout.js: thêm mapping badge, info bar, emphasis source blocks, profile SHORT/MEDIUM/LONG/EXTRA_LONG, fit có re-measure.
- WEB_LIVE/tv-ui.css: thêm token navy, card text-only auto-height, hierarchy và thanh thông tin.
- WEB_LIVE/tv.html: thêm markup info bar/badge, chuyển cùng id Timer vào bar, cập nhật title TV.
- WEB_LIVE/tv.js: một nhánh gọi helper fit RC4 rồi fitFigure; giữ nhánh legacy cho tương thích harness.

Không sửa Teacher, Launcher/handoff, pedagogy.js/pedagogy-teacher.js, importer, navigation, geometry/Draw/Cover/Smart, Math Atomic, Focus/Highlight/Pointer/Timer engine, START scripts, lesson/schema/SGK/PPCT/SOẠN_TRƯỚC. Đối chiếu từng byte: integrity_results.json và minimal_tv_patch.diff.

## Quyết định

Không phát hiện cần đổi schema, nội dung, Launcher hoặc rewrite renderer. Các yêu cầu cần browser/Windows thật chưa được chứng nhận. Không có cơ sở ghi RC4 PASS toàn bộ hoặc nâng Production.
