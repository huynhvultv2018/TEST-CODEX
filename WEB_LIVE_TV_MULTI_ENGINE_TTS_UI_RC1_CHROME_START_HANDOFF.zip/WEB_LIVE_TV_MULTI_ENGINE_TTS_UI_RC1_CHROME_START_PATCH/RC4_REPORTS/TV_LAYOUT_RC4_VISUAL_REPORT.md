# TV LAYOUT RC4 — VISUAL

**VISUAL_ACCEPTANCE = PARTIAL / NOT RUN. Không có screenshot thật RC4.**

## Hạn chế môi trường

Lần mở teacher.html local trước đó bị CUA từ chối trước navigation: “The requested URL protocol is not allowed. Allowed protocols: http:, https:. Do not attempt workaround.” Bằng chứng giữ nguyên ở browser_block_prior_attempt.json. Không đổi sang browser khác, raw CDP, Playwright hoặc HTTP server để đi vòng. Đây là hạn chế audit, không phải lỗi sản phẩm được tái hiện.

Sáu screenshot bắt buộc sau chưa được tạo. Không dùng ảnh minh họa/mockup giả làm screenshot candidate.

| File cần có | Trạng thái |
|---|---|
| `01_REVIEW_1920x1080.png` | BLOCKED; chưa tạo |
| `02_INTRO_1920x1080.png` | BLOCKED; chưa tạo |
| `03_PRACTICE_1920x1080.png` | BLOCKED; chưa tạo |
| `04_APPLICATION_1920x1080.png` | BLOCKED; chưa tạo |
| `05_REVIEW_1366x768.png` | BLOCKED; chưa tạo |
| `06_APPLICATION_1366x768.png` | BLOCKED; chưa tạo |

## Responsive — phần kiểm tĩnh

Bảng dưới chỉ tính giá trị CSS token; không phải font đo sau render hoặc test wrap/overflow browser.

| Viewport | Info bar px | SHORT px | MEDIUM px | LONG px | EXTRA_LONG px | Render thật |
|---|---|---|---|---|---|---|
| 1920x1080 | 70.2 | 76 | 65.28 | 53.76 | 49.92 | NOT RUN |
| 1600x900 | 58.5 | 64.0 | 54.4 | 44.8 | 41.6 | NOT RUN |
| 1366x768 | 49.92 | 54.64 | 46.44 | 38.25 | 35.52 | NOT RUN |
| 1280x720 | 46.8 | 51.2 | 43.52 | 35.84 | 34 | NOT RUN |

Các clamp/auto-height/max-width, minmax(0,...) và max-height breakpoint đã có trong candidate; fit có test re-measure/floor bằng DOM double. Không kết luận từ tính toán đó rằng không scroll ngang, không clip, card đẹp hoặc hình không đè chữ ở viewport thật.

## Reference RC3

Giữ nguyên và đối chiếu file TV_LAYOUT_REPORTS/MODEL4_TIN8_THINK_1366x768.png và .svg. PNG SHA-256 cf91b62083ad22f4541088376a10aef8dfe2b5e6ca85b9c1e791b20ba621a175; SVG b391bd4d105be85e1830179e37756bf82e17b61544ce1ae2d5a06547c6e42da2. Đây là minh họa RC3 có watermark, không phải screenshot RC4. Regression logic xác minh exact question, header, image data và geometry resolver null không bị đổi; chưa có pixel comparison browser.

Hình2.3 nguyên bản trong package chỉ 147×105px; không sửa/upscale file ảnh. Độ rõ cuối lớp cần acceptance thực tế.

## Checklist acceptance thật

1. Chạy START_WEB_LIVE.bat từ thư mục candidate trên Windows; mở Teacher và TV theo quy trình hiện có.
2. Nạp TIN8_W04_LIVE_RC3_PED1.zip; mở OPEN_02, OPEN_03, T8W4_14, T8W4_18. Chụp bốn màn 1920×1080 và hai màn 1366×768 đúng tên ở bảng.
3. Đo thêm 1600×900 và 1280×720: scrollWidth ≤ clientWidth, không chữ cắt/đè hình; kiểm height thực trước/sau Hint/Answer.
4. Kiểm T8W4_THINK: trái Hình2.3, phải câu hỏi; Hint không mất hình; Answer reveal đúng; Back/Next reset như RC3.
5. Nạp Tin6 W4/W5; Knowledge Close, Quick Check, màn dài, Focus; Teacher/TV refresh, fullscreen/zoom/overlay, sync hai cửa sổ.
6. Demo → app → LIVE trên Windows thật; không auto launch khi navigation.
7. Tại 5m,6m,7m đánh giá main task, badge, instruction, progress. Chưa biết kích thước vật lý TV nên không quy đổi px thành khả năng đọc hoặc giả lập PASS khoảng cách.

| Hạng mục | Kết luận hiện tại |
|---|---|
| Hierarchy code + source integrity | PASS ở kiểm logic/tĩnh |
| Bố cục đẹp/ít dead space/line wrap thật | PENDING |
| Horizontal scroll/overflow/clip tại 4 viewport | PENDING |
| Fullscreen browser và Teacher–TV sync thật | PENDING |
| Classroom distance 5–7m | PENDING |

Dừng tại RC4 candidate. Không Production; không acceptance giả.
