# TV LAYOUT RC4 — DESIGN

**PRESENTATION PATCH; OVERALL PARTIAL.**

## Luồng nhìn

Info bar nhỏ → section/activity nếu màn RC3 có header → badge → nhiệm vụ chính → support/reveal → progress mảnh. Không thêm sidebar hoặc Teacher controls.

Info bar lấy subject từ lesson; “Bài n” từ title thực có; “Mục n” từ sgkTrace.path hiện tại hoặc title có Mục n. Field thiếu được bỏ, không suy từ màn trước. Counter dùng index/total hiện tại. Timer giữ cùng id và clock logic, chuyển vị trí vào bar. Bar cao clamp(44px,6.5vh,100px).

Badge map type hiện có thành nhãn học sinh: Kiểm tra bài cũ, Dẫn vào bài, Khám phá, Hình thành kiến thức, Thực hành (PRACTICAL), Luyện tập (PRACTICE), Vận dụng, Củng cố, Demo trực tiếp. Không map lại CORE/OPTIONAL hoặc pedagogyFlow. Type chưa biết không hiển thị nhãn debug.

## Bốn màn thực của Tin8 W4

| Màn | Cách trình bày | Source bảo toàn |
|---|---|---|
| T8W4_OPEN_02 | Badge nhỏ; câu hỏi lớn nhất; title trùng badge ẩn bằng CSS | Không thêm “Suy nghĩ 30 giây”; source không có câu đó |
| T8W4_OPEN_03 | Context medium; câu có dấu hỏi dominant; instruction source phía sau nhỏ hơn | Giữ đúng 3 block và mọi dấu câu/khoảng trắng |
| T8W4_14 | Badge nhỏ; “Luyện tập 1:” subtitle; nội dung nhiệm vụ lớn | Prefix không bị xóa; exact textContent giữ nguyên |
| T8W4_18 | “Vận dụng 1:” subtitle; hai block nhiệm vụ có khoảng cách | Giữ cả tìm thông tin và ghi nguồn/ngày |

Chỉ thay lớp CSS/markup cho các block Classroom đã tạo. Không chèn newline để canh đẹp; normalizeLiveText và renderMathAtomic giữ nguyên. Separator vẫn tồn tại trong DOM; Classroom quyết định semantic split như baseline.

## Typography và card

Dùng Segoe UI/Arial/sans-serif local, theme navy và các token --tv-bg/card/card-border/text/muted/accent/radius/gap/main-size/support-size.

Text-only card rộng min(90vw,100%), height auto, max-height theo vùng sẵn có, align-self center; không min-height ép một câu thành card cao nửa màn. Main text max-width 48ch; card vẫn chiếm chiều ngang an toàn. Model 4 hai panel giữ engine cũ, main task bên phải, caption/focus source không crop suy đoán.

Profile tính từ title đang hiện, các source block đang hiện, hint/answer/analysis được reveal, newline, toán tử, image và số step. Ngưỡng complexity ≤150 SHORT, ≤300 MEDIUM, ≤600 LONG, còn lại EXTRA_LONG. Đây là heuristic hiển thị, không reclassify nội dung hoặc activity. CSS clamp tương ứng: SHORT 44px/4vw/76px; MEDIUM 40px/3.4vw/66px; LONG 34px/2.8vw/54px; EXTRA_LONG 34px/2.6vw/50px. Font Boost được giữ. Model4 split giữ clamp riêng để kế thừa tỉ lệ cột.

Fit: đo overflow → giảm padding/gap → đo lại → bounded reduction 96/92/88% nếu cần, floor main 34px và reveal 28px → trường hợp nguồn quá dài dùng vertical scroll có cờ rõ. Không chứng nhận mọi màn không overflow khi chưa đo DOM browser. Hình không bị ẩn để nhường chữ.

## Disclosure

Không đổi showHint, answerMode, hintLevel, knowledgeCloseVisible hoặc step count. Hint ở block phụ dưới question; Answer ở block riêng. Với RC3 nonlegacy, Answer thay vùng câu hỏi như RC3; legacy vẫn giữ semantics cũ. Knowledge Close vẫn chờ Teacher. Teacher-only data không được đọc bởi helper mới. Không thêm instruction, answer, fallback hoặc lời dẫn mới.

## Model 4 và Demo

Giữ contextResource theo cùng sourceRef/unit, không ghi resolver cache; T8W4_THINK dùng Hình2.3 phía trái và câu hỏi nguyên văn phía phải. Giữ role geometry/analysis riêng, phân nhóm nhiều câu qua Teacher Focus, ratio pin, Full Figure và geometry overlay engines.

Demo badge dùng metadata hiện có; TV không tải launcher client/demo teacher, không gọi /launch. App chỉ mở qua Teacher và confirmation sẵn có. Handoff/Launcher byte-identical.
