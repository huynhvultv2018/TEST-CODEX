# WEB LIVE MULTI ENGINE TTS UI RC1 — CANDIDATE

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


Giải nén toàn bộ HANDOFF. Đọc sáu báo cáo TTS/UI ở thư mục gốc trước khi thử. Giữ `WEB_LIVE` và `LAUNCHER` cùng cấu trúc. Trên Windows dùng `START_WEB_LIVE.bat` và cách khởi động baseline; không cần build lại hay thay cấu hình Launcher cho patch này.

TTS điều khiển từ Teacher, ưu tiên giọng Việt, ưu tiên Nam khi có metadata đáng tin hoặc GV xác nhận. Tốc độ mặc định 0.95×. Âm thanh đi theo thiết bị đầu ra mặc định của Windows/Chrome. TV chỉ nhận highlight. Nếu thiếu giọng Việt, Teacher báo rõ và vẫn dạy/chuyển màn bình thường.

Các báo cáo hiện hành:

- `TTS_UPGRADE_REPORT.md`: controller, đọc block, MathSpeech và bằng chứng giọng thực còn thiếu.
- `CONTROL_PANEL_UI_REPORT.md`: ba nhóm điều khiển, width, responsive và screenshot.
- `RUNTIME_TEST_REPORT.md`: đầy đủ 30 ca và phân biệt mock/real.
- `REGRESSION_TEST_REPORT.md`: bài thật, fixture, tools và giới hạn Windows.
- `CHANGED_FILES.md`: bốn tệp gốc sửa, bảy module/style thêm và kiểm tra byte.
- `KNOWN_LIMITATIONS.md`: việc cần kiểm thử vật lý và giới hạn còn lại.

Mở `TTS_UI_EVIDENCE/index.html` để xem gallery. `REAL_` dùng Web Speech API nguyên bản; `MOCK_` dùng speech provider kiểm thử, không tạo âm thanh. Các báo cáo, screenshot và checksum cũ được giữ nguyên như lịch sử baseline; kết luận cũ không thay cho vòng TTS/UI này.

Manifest hiện hành: `SHA256SUMS.txt`; chạy `sha256sum -c SHA256SUMS.txt` từ thư mục candidate. Manifest này phủ toàn bộ tệp trừ chính nó. Các manifest cũ chỉ mô tả baseline, nên không dùng để xác nhận bốn tệp tích hợp đã sửa.

Kết thúc ở Candidate + runtime evidence. Chờ máy GV/Chrome/TV/loa thật; không nâng production.
