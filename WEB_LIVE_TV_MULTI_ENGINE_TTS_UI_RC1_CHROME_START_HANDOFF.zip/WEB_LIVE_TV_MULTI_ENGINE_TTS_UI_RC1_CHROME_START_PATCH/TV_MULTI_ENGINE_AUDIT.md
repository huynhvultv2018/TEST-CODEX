# TV MULTI-ENGINE RC1 — Audit

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

## Phạm vi và nguồn

SHA-256 ZIP baseline: `8e520e45874402401e48ccdc2fbb477eb320476158602b28fe1d103732d8bfb9`.
Toàn bộ checksum baseline đã được xác minh trước phát triển. Các báo cáo RC3/RC4 trong ZIP được giữ làm lịch sử; không dùng các candidate đó làm baseline.
Văn bản đã dán là yêu cầu người dùng. Tài liệu trong ZIP được đọc để hiểu hợp đồng runtime, không được dùng để thay thế yêu cầu này.

Chỉ sửa mã trình bày TV:

- `WEB_LIVE/tv-layout.js`
- `WEB_LIVE/tv.html`
- `WEB_LIVE/tv.js`
- `WEB_LIVE/tv-ui.css`

Bổ sung bốn module:

- `WEB_LIVE/tv-layout-model.js`
- `WEB_LIVE/tv-layout-computer.js`
- `WEB_LIVE/tv-layout-algebra.js`
- `WEB_LIVE/tv-layout-geometry.js`

Teacher, Launcher, common/pedagogy/math-atomic, importer, các lớp overlay và toàn bộ LIVE.zip giữ nguyên từng byte. Không thay lesson schema, nội dung sư phạm, PPCT/SGK. Kho TEST-CODEX vẫn sạch; kết quả nằm trong thư mục candidate riêng.
Checksum của candidate được tạo mới; không sử dụng manifest RC4 cũ để kiểm tra mã đã sửa.

## Bằng chứng tự động

Chromium 151.0.7922.173, Playwright, Linux headless. Kiểm tra 171 màn từ năm gói thật, mỗi màn ở trạng thái câu hỏi và mở đáp án/phân tích: 342 trạng thái. Không lỗi JavaScript; không request tới CDN hoặc dịch vụ bên ngoài trong bài kiểm tra chính. 48 PNG được chụp từ trình duyệt: 24 ca theo môn, 20 ca responsive và 4 ca mở toàn bộ phân tích.
Các assertion chi tiết ở `TV_MULTI_ENGINE_EVIDENCE/results.json` và `extra-results.json`.

## Kết luận acceptance

PASS các kiểm tra trình bày và runtime đã thực thi trong cloud. Chưa đánh dấu PASS toàn bộ acceptance triển khai thực tế: thiếu gói Đại số thật; Windows Launcher/Word/GeoGebra/TV vật lý chưa được chạy trong Linux. Demo launch/return chỉ được kiểm tra hợp đồng UI bằng mock, đồng thời xác minh file Launcher không đổi.

Giới hạn sẵn có: nhập tích lũy nhiều gói ảnh vào cùng origin có thể hết quota localStorage. Harness xóa riêng storage của context kiểm thử giữa các gói; không sửa importer để né lỗi và không xóa dữ liệu người dùng.

DỪNG TẠI WEB LIVE TV MULTI-ENGINE RC1 CANDIDATE — chờ runtime test trên laptop + TV thật.
