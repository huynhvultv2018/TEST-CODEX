# Kiến trúc TV MULTI-ENGINE

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

## Luồng trình bày

`tv.js applyState` → runtime RC4 (pedagogy/disclosure/scene/focus) → `TVLayout.plan/apply` → `TVMultiEngine.model/apply` → renderer theo môn → `TVLayout.fit` + `fitFigure`.

| Thành phần | Trách nhiệm |
|---|---|
| tv-layout.js | Hợp đồng RC4, tài nguyên contextual, thông tin chung, hierarchy, đo overflow |
| tv-layout-model.js | resolveSubjectLayout(screen, lesson), parser chắc chắn, view model và component chung |
| tv-layout-computer.js | COMPUTER_SCIENCE_ENGINE — Activity Cards |
| tv-layout-algebra.js | ALGEBRA_ENGINE — Math Reasoning Board |
| tv-layout-geometry.js | GEOMETRY_ENGINE — Geometry Proof Board |
| tv-ui.css | Design tokens, safe area, chữ, badge, responsive và main stage |

## Router

Ưu tiên subjectMode/layoutEngine explicit ở screen, presentation hoặc lesson. Sau đó đọc subject, section, lesson title và screen title. Geometry image/visualRole explicit là bằng chứng hình học; các type chuyên biệt và tên bài toán toán học chắc chắn là fallback. Một công thức `x = 2` đơn lẻ trong môn “Toán 8” không đủ để đoán Đại số. Explicit GENERIC luôn được tôn trọng.

## Activity View Model

`subjectMode, activityType, context, source, title, prompt, question, options[], mathBlocks[], proofSteps[], bodyBlocks[], instruction, image, resolvedImage, state`.

Model đọc nội dung đã được pedagogy runtime cho phép. proofSteps chỉ chứa bước GV đã mở. Không tính toán lời giải, suy đoán đáp án hoặc ghi lại dữ liệu vào lesson.

Parser MCQ nhận chuỗi A./A) liên tiếp, hoặc options[] explicit dạng string/{label,text}; hỗ trợ 2–5 lựa chọn. Không gán đáp án đúng. Parser heading yêu cầu nhãn đầu dòng và dấu hai chấm; nguồn mơ hồ giữ nguyên văn bản. Hệ chỉ nhóm khi có đúng hai phương trình kề nhau. Bảng chỉ chuyển khi các hàng Markdown/tab đủ chắc và cùng số cột.

## Quyền sở hữu runtime

Không tạo stage DOM thay thế figureInner. Thứ tự giữ nguyên: pic → Cover → Smart Geometry → Draw Board → Highlight → Pointer. Scene index, current image, analysis diagram, zoom/pan, scopes/version, storage và các receiver vẫn là RC4.

Proof/analysis dùng liveAnswerText/liveAnalysisText và bước đã mở. Dependency tree chỉ kích hoạt với type/layoutType PROOF_DEPENDENCY_TREE, lấy các nhánh ` + ` từ bước phân tích đã công bố; không dựng thêm quan hệ. Mỗi nhánh giữ nguyên toán tử/nguồn. Đây là cây phân tích được tác giả cung cấp, không phải bộ giải tự động hoặc trình đọc graph tùy ý.

## Layout và fit

Tin/graph có hình: 65/35. Hình mặc định 68/32; proof/analysis 60/40; preset GV 70/30 vẫn hoạt động. Text/figure-only theo lựa chọn GV được giữ.

Fit đo chiều cao thật, giảm spacing trước rồi đổi phân tích Hình học dài thành các ô đánh số theo thứ tự đọc, sau đó giảm font có giới hạn. Dependency tree không bị đổi thành bảng bước. Scroll chỉ là fallback cho nguồn bất thường vượt giới hạn; không dùng để tuyên bố các ca bình thường đã đạt.

Không CDN, webfont, thư viện toán ngoài hoặc dịch vụ AI. Các module mới dùng DOM/textContent và CSS local. Không sửa Teacher/Launcher để hỗ trợ layout.
