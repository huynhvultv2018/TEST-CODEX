# Đại số — Math Reasoning Board

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

PASS các fixture giao diện: expression, equation, system, word_problem, identity, table, graph, practice. Có kiểm tra bổ sung classification factorization/statistics/probability/proof.

Equation hiển thị transformation cards theo chiều dọc; cả mode steps và full đều dùng các bước có sẵn. Bước chưa mở không xuất hiện trong DOM. System giữ hai phương trình kề nhau trong một block. Word problem có ô Đặt ẩn/Điều kiện/Biểu diễn/Phương trình khi nhãn tồn tại trong nguồn. Identity giữ biểu thức nguồn phía trên, biến đổi giữa và bước cuối phía dưới. Bảng Markdown/tab được render table, graph/image giữ vai trò trung tâm.

Math Atomic kiểm tra đủ AB > BC, AB = CD, AB ∥ CD, AH ⟂ BD, △ABC ≅ △DEF, x = 2, 2x + 3 = 7. Dùng wrapper trình bày cho biểu thức ngắn; không thay math-atomic.js.

**THIẾU NGUỒN RUNTIME:** baseline không có LIVE.zip Đại số 8. Các ca ALG là fixture rõ nhãn, dùng ví dụ giao diện trong yêu cầu; không tự tạo gói bài học, không suy diễn nội dung SGK/PPCT. Chưa thể xác nhận compatibility với gói Đại số thật chưa cung cấp. Chưa đánh dấu PASS runtime môn Đại số trên lớp.
