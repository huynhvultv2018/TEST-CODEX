"""Controlled browser dispatch tests; not a physical Windows acceptance test."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import contextlib
import io
import json
import os
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "LAUNCHER"))
import start_web_live as startup

class BrowserStartTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.env = {key: str(self.base / key) for key in
                    ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData")}
        self.addCleanup(patch.stopall)
        patch.dict(os.environ, self.env).start()
        patch('sys.stdout', new=io.StringIO()).start()
        self.chrome_process = Mock()
        self.chrome_process.poll.return_value = None
        self.spawn = patch.object(startup.subprocess, 'Popen', return_value=self.chrome_process).start()
        self.default = patch.object(startup.webbrowser, 'open', return_value=True).start()
        self.status = (200, {}, {"instanceId": "session-one"})
        self.probe = patch.object(startup, 'probe', return_value=self.status).start()

    def chrome(self, variable):
        p = Path(self.env[variable]) / 'Google/Chrome/Application/chrome.exe'
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b'controlled test fixture, not an executable')
        return p

    def test_all_three_windows_locations(self):
        for variable in self.env:
            with self.subTest(variable=variable):
                executable = self.chrome(variable)
                self.assertTrue(startup.open_teacher())
                self.spawn.assert_called_with([str(executable), startup.TEACHER_URL], shell=False)
                self.default.assert_not_called()
                executable.unlink()

    def test_priority_programfiles_then_x86_then_localappdata(self):
        paths = [self.chrome(v) for v in self.env]
        for executable in paths:
            self.assertEqual(startup.find_chrome(), executable)
            executable.unlink()
        self.assertIsNone(startup.find_chrome())

    def test_spaces_in_path_are_single_argument(self):
        os.environ['ProgramFiles'] = str(self.base / 'Program Files with spaces')
        self.env['ProgramFiles'] = os.environ['ProgramFiles']
        executable = self.chrome('ProgramFiles')
        self.assertTrue(startup.open_teacher())
        self.spawn.assert_called_once_with([str(executable), startup.TEACHER_URL], shell=False)

    def test_chrome_successful_handoff_exit_zero(self):
        self.chrome('ProgramFiles')
        self.chrome_process.poll.return_value = 0
        self.assertTrue(startup.open_teacher())
        self.default.assert_not_called()

    def test_missing_chrome_falls_back_to_exact_http_url(self):
        self.assertTrue(startup.open_teacher())
        self.default.assert_called_once_with('http://127.0.0.1:47382/WEB_LIVE/teacher.html', new=2)
        self.spawn.assert_not_called()

    def test_chrome_spawn_failure_does_not_open_edge(self):
        self.chrome('ProgramFiles')
        self.spawn.side_effect = OSError('controlled launch failure')
        self.assertFalse(startup.open_teacher())
        self.default.assert_not_called()

    def test_chrome_error_exit_does_not_open_edge(self):
        self.chrome('ProgramFiles')
        self.chrome_process.poll.return_value = 1
        self.assertFalse(startup.open_teacher())
        self.default.assert_not_called()

    def test_default_browser_failure_is_nonfatal(self):
        self.default.side_effect = OSError('controlled default failure')
        startup.open_teacher_once(ROOT)
        self.assertEqual(self.default.call_count, 1)

    def test_repeat_start_opens_only_once(self):
        self.chrome('ProgramFiles')
        startup.open_teacher_once(ROOT)
        startup.open_teacher_once(ROOT)
        self.spawn.assert_called_once()
        self.default.assert_not_called()

    def test_repeat_fallback_opens_only_once(self):
        startup.open_teacher_once(ROOT)
        startup.open_teacher_once(ROOT)
        self.default.assert_called_once()

    def test_new_launcher_instance_allows_new_open(self):
        self.chrome('ProgramFiles')
        startup.open_teacher_once(ROOT)
        self.probe.return_value = (200, {}, {'instanceId': 'session-two'})
        startup.open_teacher_once(ROOT)
        self.assertEqual(self.spawn.call_count, 2)

    def test_failed_open_can_be_retried(self):
        self.default.return_value = False
        startup.open_teacher_once(ROOT)
        self.default.return_value = True
        startup.open_teacher_once(ROOT)
        startup.open_teacher_once(ROOT)
        self.assertEqual(self.default.call_count, 2)

    def test_concurrent_start_opens_only_once(self):
        self.chrome('ProgramFiles')
        def slow_spawn(*args, **kwargs):
            time.sleep(.08)
            return self.chrome_process
        self.spawn.side_effect = slow_spawn
        errors = []
        def worker():
            try: startup.open_teacher_once(ROOT)
            except BaseException as error: errors.append(error)
        threads = [threading.Thread(target=worker) for _ in range(6)]
        for thread in threads: thread.start()
        for thread in threads: thread.join(timeout=5)
        self.assertFalse(errors)
        self.assertFalse(any(thread.is_alive() for thread in threads))
        self.spawn.assert_called_once()

    def test_unknown_instance_does_not_create_duplicate_tab(self):
        self.probe.return_value = None
        startup.open_teacher_once(ROOT)
        self.spawn.assert_not_called()
        self.default.assert_not_called()

    def test_unwritable_state_is_nonfatal_no_duplicate(self):
        Path(self.env['LocalAppData']).write_text('not a directory')
        startup.open_teacher_once(ROOT)
        self.spawn.assert_not_called()
        self.default.assert_not_called()

    def test_startup_keeps_web_launcher_readiness_browser_order(self):
        order = []
        def service(script, url, check, label):
            order.extend([label, label + ' READY'])
        patch.object(startup, 'ensure_service', side_effect=service).start()
        patch.object(startup, 'open_teacher_once', side_effect=lambda root: order.append('BROWSER')).start()
        patch.object(startup.sys, 'platform', 'win32').start()
        self.assertEqual(startup.main(), 0)
        self.assertEqual(order, ['WEB SERVER', 'WEB SERVER READY', 'LOCAL LAUNCHER', 'LOCAL LAUNCHER READY', 'BROWSER'])

    def test_service_failure_never_opens_browser(self):
        patch.object(startup, 'start_services', side_effect=startup.StartupError('controlled')).start()
        open_once = patch.object(startup, 'open_teacher_once').start()
        patch.object(startup.sys, 'platform', 'win32').start()
        self.assertEqual(startup.main(), 1)
        open_once.assert_not_called()

    def test_fallback_failure_does_not_fail_main(self):
        self.default.return_value = False
        patch.object(startup, 'start_services', return_value=[]).start()
        patch.object(startup.sys, 'platform', 'win32').start()
        self.assertEqual(startup.main(), 0)

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(BrowserStartTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    evidence = ROOT / 'CHROME_START_EVIDENCE'
    evidence.mkdir(exist_ok=True)
    (evidence / 'browser-dispatch-tests.json').write_text(json.dumps({
        'environment': 'Linux cloud; Windows executable paths and process dispatch controlled; real filesystem locks on Linux',
        'testsRun': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'WindowsChromePhysical': 'PENDING', 'result': 'PASS' if result.wasSuccessful() else 'FAIL'
    }, indent=2) + '\n')
    sys.exit(0 if result.wasSuccessful() else 1)
