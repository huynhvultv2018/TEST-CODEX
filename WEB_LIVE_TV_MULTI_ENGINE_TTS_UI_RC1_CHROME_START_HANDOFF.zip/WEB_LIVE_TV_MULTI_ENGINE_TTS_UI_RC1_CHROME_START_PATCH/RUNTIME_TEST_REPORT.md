# Runtime test report

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


## Phương pháp

Chromium thực + Playwright, server local127.0.0.1:8765, Teacher/TV thật, nhập gói LIVE ZIP gốc. UI click/pointer/dialog thực cho navigation, disclosure, drawing point/label và fullscreen. Một số API control cũ dùng trực tiếp để đặt Timer/Focus/reveal state; chi tiết có ở script. Pageerrors và request ngoài local được thu; runtime chính có0 lỗi và0 request ngoài.

Hai luồng bằng chứng:

1. `native-probe.cjs` **không thay Speech API**: API tồn tại, voice list rỗng, TTS báo thiếu Việt, teaching vẫn chạy. Chụp 12 ảnh REAL_ ở 4 viewport.
2. `runtime.cjs`/`edge-cases.cjs` inject `test-speech-provider.js` vào browser test, **không nạp vào product**. Fake có vi-VN/metadata giới tính/event/queue, không phát audio. PASS_TEST_DOUBLE chỉ chứng minh tích hợp và xử lý event.

## 30 ca yêu cầu

| Ca | Nội dung đã chạy | Kết quả runtime |
|---|---|---|
| TEST01 | Teacher UI load | PASS |
| TEST02 | Mở TV thật bằng window.open; TV không có speech controller | PASS |
| TEST03 | TRƯỚC / TIẾP và TV sync | PASS |
| TEST04 | GỢI Ý thật | PASS |
| TEST05 | ĐÁP ÁN thật | PASS |
| TEST06 | CHỐT KIẾN THỨC thật; label không ép nhiều dòng | PASS |
| TEST07 | Collapse/expand giọng, tools và panel; teaching luôn truy cập được | PASS |
| TEST08 | 70/30 | PASS |
| TEST09 | 60/40 | PASS |
| TEST10 | Hình toàn màn và trở lại | PASS |
| TEST11 | Phóng chữ | PASS |
| TEST12 | Focus actual click → TV | PASS |
| TEST13 | Drawing point + Label qua pointer/dialog thật | PASS |
| TEST14 | Timer sync | PASS |
| TEST15 | TTS tiếng Việt integration: speak vi-VN + rate 0.95 | PASS_TEST_DOUBLE |
| TEST16 | Ưu tiên Nam chỉ khi metadata giới tính rõ ràng | PASS_TEST_DOUBLE |
| TEST17 | Fallback Việt; không suy giới tính từ tên; thiếu Việt không phá navigation | PASS_TEST_DOUBLE |
| TEST18 | Pause state phản ánh onpause/paused | PASS_TEST_DOUBLE |
| TEST19 | Resume state phản ánh onresume | PASS_TEST_DOUBLE |
| TEST20 | Stop clears native + planned queue and highlight | PASS_TEST_DOUBLE |
| TEST21 | Replay phần hiện tại | PASS_TEST_DOUBLE |
| TEST22 | Auto-cancel NEXT kể cả callback canceled đến muộn | PASS_TEST_DOUBLE |
| TEST23 | Auto-cancel PREVIOUS | PASS_TEST_DOUBLE |
| TEST24 | Auto-cancel chọn màn bằng select | PASS_TEST_DOUBLE |
| TEST25 | Auto-cancel bắt đầu nhập và load lesson mới | PASS_TEST_DOUBLE |
| TEST26 | Block highlight TV stable; Focus/figure bbox unchanged; off/on | PASS_TEST_DOUBLE |
| TEST27 | Tin block icon đọc hint thật; không đọc menu/note/hidden answer | PASS_TEST_DOUBLE |
| TEST28 | Đại số + MathSpeech; display/future step unchanged | PASS_TEST_DOUBLE |
| TEST29 | Hình học MathSpeech từ text; không đọc SVG/image/labels | PASS_TEST_DOUBLE |
| TEST30 | Reload restore voice/gender map/rate/highlight/volume | PASS_TEST_DOUBLE |

TEST28 dùng fixture trình chiếu Đại số, không có LIVE.zip Đại số thật trong baseline. TEST29 dùng text của gói Hình học thật. TEST15/16/18/19 không chứng minh chất lượng tiếng Việt/Nam/Pause/Resume của native voice. Audio thật vẫn PENDING.

## Ca bổ sung

Các ca sau đều đạt với speech test double, 0 pageerrors:

- Natural onend walks one utterance at a time, finishes IDLE and clears lease/highlight.
- Speech failure + stale end callback cannot break navigation or leave a queue.
- Second controller cannot steal active speech; lease can transfer after Stop.
- Blocked storage fails TTS safely, instead of allowing competing speech owners.
- Other Teacher changes TV: cancels old speech, blocks stale preview reading; closing owner releases speech.
- BroadcastChannel unavailable: registry/highlight/cancel work over storage/postMessage.
- Web Speech API absent: explicit status and normal lesson navigation.

Đóng Teacher kiểm bằng browser lifecycle (`close` có chạy beforeunload), owner được giải phóng. Trường hợp kill/crash mất lifecycle dựa lease expiry; không gọi đó là kiểm thử đóng cửa sổ Windows vật lý. Transport fallback tắt BroadcastChannel, giữ đường storage/postMessage.

## UI/TV

Main runtime thử 1920×1080, 1600×900, 1366×768, 1280×720, mỗi size expanded/compact; thêm native UI 1024×768. Không scroll ngang. Fullscreen API thực vào/ra; TV mở từ nút MỞ TV. Highlight block trên TV giữ nguyên bbox hình và opacity Focus, clear khi stop/change, settings restore sau reload. TV không có controller, 0 speak calls; max native outstanding trong mock = 1.

## Tệp evidence / tái chạy

JSON: `native-probe.json`, `runtime.json`, `edge-cases.json`, `math-speech.json`, `regression/results.json`, `regression/extra-results.json`, `baseline-integrity.json`. Log tương ứng nằm trong evidence. Gallery `index.html`; ảnh REAL_/MOCK_ được ghi nhãn. Script và hướng dẫn tại `TTS_UI_TESTS/README.md`.

Runtime cloud đã hoàn tất. TTS/Windows physical **PENDING** cho đến khi nghe và thao tác trên máy GV + Chrome + TV/loa thật.
