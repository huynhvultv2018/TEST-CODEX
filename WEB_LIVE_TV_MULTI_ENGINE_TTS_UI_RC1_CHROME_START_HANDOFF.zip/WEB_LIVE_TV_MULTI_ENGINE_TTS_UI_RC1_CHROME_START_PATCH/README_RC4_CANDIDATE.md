# WEB LIVE TV LAYOUT RC4 CANDIDATE

**PARTIAL — CHỜ RUNTIME TEST TRÊN LAPTOP + TV THẬT. KHÔNG PRODUCTION.**

Baseline duy nhất: TV LAYOUT RC3; SHA-256 `daf2d1f30bdbbf0081ae28c6edd19e9bdf85152d583a5bf40e210e445fa31cc1`. Các report và minh họa RC3 giữ nguyên để traceability, không phải kết quả mới hoặc screenshot thật RC4.

Chạy START_WEB_LIVE.bat trên Windows theo quy trình hiện có. Dùng RC3_PED1_TEST_PACKAGES cho Tin6 W4/W5 và Tin8 W4. Không cần đổi lesson/schema hoặc Launcher config vì patch này.

Đọc RC4_REPORTS/TV_LAYOUT_RC4_VISUAL_REPORT.md trước acceptance: sáu screenshot bắt buộc chưa có. Không đánh dấu Production hoặc thay baseline acceptance.
