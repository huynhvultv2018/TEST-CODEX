const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=process.env.WEB_LIVE_TEST_ROOT||path.resolve(__dirname,'..');
(async()=>{
 const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox']});
 const c=await b.newContext({viewport:{width:1920,height:1080}}),errors=[];
 c.on('page',p=>p.on('pageerror',e=>errors.push(e.message)));
 const teacher=await c.newPage();await teacher.goto('http://127.0.0.1:8765/WEB_LIVE/teacher.html');
 await teacher.locator('#zipfile').setInputFiles(root+'/RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip');await teacher.waitForFunction(()=>lesson?.subject==='Tin học 6');
 await teacher.evaluate(()=>go(5));await teacher.waitForTimeout(400);
 const popupPromise=teacher.waitForEvent('popup');await teacher.getByRole('button',{name:'📺 MỞ TV',exact:true}).click();const tv=await popupPromise;await tv.waitForLoadState();await teacher.waitForTimeout(1200);
 const probe=await teacher.evaluate(()=>({speechAPI:typeof speechSynthesis!=='undefined',utteranceAPI:typeof SpeechSynthesisUtterance!=='undefined',voices:speechSynthesis.getVoices().map(v=>({name:v.name,lang:v.lang,localService:v.localService})),ttsState:ttsUI.controller.state,ttsStatus:document.getElementById('ttsStatus').textContent,rate:ttsUI.controller.settings.rate,genderPreference:ttsUI.controller.settings.preferredGender,blocks:ttsUI.blocks.map(b=>({label:b.label,text:b.text})),panelWidth:document.querySelector('.side').getBoundingClientRect().width,previewWidth:document.querySelector('.preview').getBoundingClientRect().width,horizontal:document.documentElement.scrollWidth>innerWidth,knowledgeButtonWidth:document.getElementById('closeKnowledgeBtn').getBoundingClientRect().width}));
 await teacher.screenshot({path:root+'/TTS_UI_EVIDENCE/REAL_UI_1920x1080_VOICE_PROBE.png'});
 await teacher.locator('#closeKnowledgeBtn').click();await teacher.waitForTimeout(300);await teacher.screenshot({path:root+'/TTS_UI_EVIDENCE/REAL_UI_KNOWLEDGE_1920x1080.png'});
 await teacher.locator('#compactBtn').click();await teacher.screenshot({path:root+'/TTS_UI_EVIDENCE/REAL_UI_COMPACT_1920x1080.png'});
 await teacher.locator('#compactBtn').click();await teacher.locator('#displayToolsGroup>summary').click();await teacher.screenshot({path:root+'/TTS_UI_EVIDENCE/REAL_UI_TOOLS_1920x1080.png'});
 await teacher.locator('#displayToolsGroup>summary').click();
 const responsive=[];
 for(const [width,height] of [[1920,1080],[1366,768],[1280,720],[1024,768]]){
  await teacher.setViewportSize({width,height});
  for(const compact of [false,true]){
   if(await teacher.evaluate(()=>document.body.classList.contains('compactUI'))!==compact)await teacher.locator('#compactBtn').click();
   await teacher.waitForTimeout(100);
   const metrics=await teacher.evaluate(()=>({panel:document.querySelector('.side').getBoundingClientRect().width,preview:document.querySelector('.preview').getBoundingClientRect().width,horizontal:document.documentElement.scrollWidth>innerWidth,knowledge:{width:document.getElementById('closeKnowledgeBtn').getBoundingClientRect().width,height:document.getElementById('closeKnowledgeBtn').getBoundingClientRect().height},state:ttsUI.controller.state,status:document.getElementById('ttsStatus').textContent}));
   assert(!metrics.horizontal);assert(metrics.knowledge.width>=240&&metrics.knowledge.height<48);
   responsive.push({width,height,compact,...metrics});
   await teacher.screenshot({path:root+'/TTS_UI_EVIDENCE/REAL_UI_'+width+'x'+height+'_'+(compact?'COMPACT':'EXPANDED')+'.png'});
  }
 }
 assert.equal(errors.length,0);
 fs.writeFileSync(root+'/TTS_UI_EVIDENCE/native-probe.json',JSON.stringify({browser:b.version(),probe,responsive,errors,audioNotice:'Unmodified Web Speech API; no synthetic voice/audio mock; physical Windows/TV/audio not run'},null,2));console.log(JSON.stringify({probe,responsive,errors},null,2));await b.close();
})().catch(e=>{console.error(e);process.exit(1)});
