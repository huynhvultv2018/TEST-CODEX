/* Deterministic test double only. Not loaded by the product; produces no audio. */
(()=>{
 const listeners=new Map();
 const fake={voices:[{name:'Voice beta',voiceURI:'test-female',lang:'vi-VN',localService:true,gender:'female'},{name:'Voice alpha',voiceURI:'test-male',lang:'vi-VN',localService:true,gender:'male'},{name:'English only',voiceURI:'test-en',lang:'en-US',localService:true}],calls:[],active:null,speaking:false,paused:false,pending:false,maxOutstanding:0,
  addEventListener(type,fn){if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn)},
  removeEventListener(type,fn){listeners.get(type)?.delete(fn)},
  getVoices(){this.calls.push({event:'getVoices'});return this.voices},
  replaceVoices(voices){this.voices=voices;for(const fn of listeners.get('voiceschanged')||[])fn()},
  speak(u){this.calls.push({event:'speak',text:u.text,voice:u.voice?.voiceURI,lang:u.lang,rate:u.rate,volume:u.volume});this.maxOutstanding=Math.max(this.maxOutstanding,this.active?2:1);this.active=u;this.pending=true;setTimeout(()=>{if(this.active!==u)return;this.pending=false;this.speaking=true;u.onstart?.({})},10)},
  cancel(){this.calls.push({event:'cancel'});const old=this.active;this.active=null;this.pending=false;this.speaking=false;this.paused=false;if(old)setTimeout(()=>old.onerror?.({error:'canceled'}),25)},
  pause(){this.calls.push({event:'pause'});if(this.active){this.paused=true;this.active.onpause?.({})}},
  resume(){this.calls.push({event:'resume'});if(this.active){this.paused=false;this.speaking=true;this.active.onresume?.({})}},
  complete(){const old=this.active;this.active=null;this.pending=false;this.speaking=false;this.paused=false;old?.onend?.({})},
  fail(code='synthesis-failed'){const old=this.active;this.active=null;this.pending=false;this.speaking=false;this.paused=false;old?.onerror?.({error:code})}
 };
 Object.defineProperty(window,'speechSynthesis',{value:fake,configurable:true});
 window.SpeechSynthesisUtterance=class{constructor(text){this.text=text}};
 window.__ttsTest=fake;
})();
