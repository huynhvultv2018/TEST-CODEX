# TTS/UI runtime tests

Các script dùng Node.js, Playwright và Chromium. Product không phụ thuộc Playwright/test provider. Cloud đã có Playwright trên global module path và `/usr/bin/chromium`. Máy khác cần cấu hình môi trường kiểm thử tương ứng; không sửa source để chạy harness.

Từ thư mục candidate, mở server ở terminal riêng:

```sh
python -m http.server 8765 --bind 127.0.0.1
```

Ở terminal thứ hai, cũng từ thư mục candidate:

```sh
node TTS_UI_TESTS/math-speech.cjs
node TTS_UI_TESTS/native-probe.cjs
node TTS_UI_TESTS/runtime.cjs
node TTS_UI_TESTS/edge-cases.cjs
node TTS_UI_TESTS/regression.cjs
node TTS_UI_TESTS/regression-extra.cjs
```

`CHROMIUM_PATH` đổi executable nếu cần. `WEB_LIVE_TEST_ROOT` đổi absolute root; port mặc định8765. Script ghi đè evidence của chính candidate nên hãy chạy trên bản sao kiểm thử nếu muốn giữ artifact/checksum đã bàn giao.

- native-probe: Web Speech API nguyên bản, không mock; kết quả 0 voices của cloud không suy ra kết quả trên Windows.
- runtime/edge-cases: inject test-speech-provider; **không phát audio**. PASS_TEST_DOUBLE khác PASS tiếngViệt thật.
- math-speech: textoutput parser, không nghevoice.
- regression: import 5 gói thật, 171 màn, fixture presentation, runtime controls và offline.
- regression-extra: routing/atomic/demoUIprotocolmock/stalestate/fullanalysis.

Nếu node chưa thấy Playwright global, cấu hình NODE_PATH tới module cài cho môi trường. Native demo Windows/loa/HDMI/giọng không được các harness cloud chứng nhận.
