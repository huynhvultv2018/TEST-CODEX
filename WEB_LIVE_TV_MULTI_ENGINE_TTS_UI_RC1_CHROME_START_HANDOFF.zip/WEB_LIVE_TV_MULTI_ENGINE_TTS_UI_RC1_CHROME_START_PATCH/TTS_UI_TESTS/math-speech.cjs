const assert=require('assert'),fs=require('fs'),path=require('path');
const root=process.env.WEB_LIVE_TEST_ROOT||path.resolve(__dirname,'..'),p=require(root+'/WEB_LIVE/math-speech.js');
const cases=[
 ['x²','x bình phương'],['x³','x lập phương'],['√25','căn bậc hai của hai mươi lăm'],['3/4','ba phần tư'],['3/5','ba phần năm'],['x² + 2x = 3','x bình phương cộng hai x bằng ba'],
 ['AB ⟂ CD','AB vuông góc với CD'],['AB ∥ CD','AB song song với CD'],['∠ABC = 60°','góc ABC bằng sáu mươi độ'],['a ≠ b','a khác b'],['a ≥ b','a lớn hơn hoặc bằng b'],['a ≤ b','a nhỏ hơn hoặc bằng b'],
 ['(x+1)/(x-2)','phân số có tử số là x cộng một, mẫu số là x trừ hai'],['(x+1)/((x-2)/(x+3))','phân số có tử số là x cộng một, mẫu số là phân số có tử số là x trừ hai, mẫu số là x cộng ba'],
 ['-2x + 5 = 9','âm hai x cộng năm bằng chín'],['△ABC ≅ △DEF','tam giác ABC bằng nhau tam giác DEF'],
 ['ngày 3/4/2026 và tệp lesson.json','ngày 3/4/2026 và tệp lesson.json'],['3/4/2026','3/4/2026'],
 ['https://example.test/a/3/4','https://example.test/a/3/4'],['x ? y','x ? y'],
 ['Trong bài này, x² + 2x = 3.','Trong bài này, x bình phương cộng hai x bằng ba.']
];
for(const [display,expected] of cases){assert.equal(p.preprocess(display),expected,display)}
assert.equal(p.parse('(x+1)/(x-2'),null);assert.equal(p.parse('x ? y'),null);
fs.writeFileSync(root+'/TTS_UI_EVIDENCE/math-speech.json',JSON.stringify({cases:cases.map(([display,expected])=>({display,speech:expected,result:'PASS'})),uncertainStructure:'No inferred AST for malformed/unknown syntax; URLs, dates and filenames preserved',audioNotice:'Text conversion tests; actual Vietnamese pronunciation requires physical voice test'},null,2));
console.log(cases.length+' MathSpeech examples passed.');
