# START_WEB_LIVE — ưu tiên Google Chrome

## Phạm vi và nguyên nhân

Bản patch riêng của WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_LOCAL_HTTP_PATCH. Không bump version.
Chỉ một file chương trình hiện có thay đổi: `LAUNCHER/start_web_live.py`.
`START_WEB_LIVE.bat` giữ nguyên vì đã gọi đúng helper này.
Nguyên nhân mở Edge: helper cũ gọi `webbrowser.open(TEACHER_URL, new=2)`, nên dùng trình duyệt mặc định Windows.

## Hành vi sau patch

Dò `chrome.exe` theo thứ tự:

1. `%ProgramFiles%\Google\Chrome\Application\chrome.exe`
2. `%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe`
3. `%LocalAppData%\Google\Chrome\Application\chrome.exe`

Nếu tìm thấy, gọi trực tiếp executable với URL HTTP bằng danh sách argument, `shell=False`.
Đường dẫn có dấu cách được giữ nguyên. Dùng profile Chrome thông thường; không thêm remote debugging.
Không tìm thấy Chrome: fallback `webbrowser.open` dùng trình duyệt mặc định, URL HTTP giống nhau.
Nếu Chrome tồn tại nhưng không khởi chạy được, không tự chuyển sang Edge; in hướng dẫn mở URL thủ công. Lỗi mở trình duyệt không làm START thất bại.

URL chính xác: `http://127.0.0.1:47382/WEB_LIVE/teacher.html`.
WEB HTTP: `127.0.0.1:47382`. Local Launcher: `127.0.0.1:47381`.
Allowed origins giữ nguyên: `http://127.0.0.1:47382`, `http://localhost:47382`.
Thứ tự giữ nguyên: START WEB HTTP → xác nhận WEB sẵn sàng → START LOCAL LAUNCHER → xác nhận Launcher sẵn sàng → mở Chrome/fallback.
Không dùng `file://`, không đổi UI, TTS, MathSpeech, LIVE, TV, lesson, engine, HTTP server, Local Launcher hay CORS.

## Chống mở tab lặp

Trạng thái mở trình duyệt nằm ngoài candidate, tại `%LocalAppData%\WEB_LIVE\browser-start\<packageFingerprint>.state`.
Thiếu LocalAppData thì dùng thư mục tạm hệ thống. File không chứa token, credential hay challenge.
Dùng khóa file Windows `msvcrt.locking` để các lần START đồng thời chỉ gửi một yêu cầu mở.
Trạng thái gắn với `instanceId` có sẵn của Launcher. Chỉ ghi sau khi hệ điều hành chấp nhận gọi Chrome hoặc fallback báo thành công.
Chạy lại START trong cùng phiên Launcher không mở thêm tab; yêu cầu mở thất bại được phép thử lại.
Launcher khởi động lại có instanceId mới, nên cho phép mở một lần mới.
Không truy vấn/đóng tab do GV mở thủ công hoặc tab tồn tại từ trước patch. Không suy ra trang đã render chỉ từ việc tạo process.
Nếu GV đóng tab sau lần mở đã ghi nhận, mở lại URL thủ công hoặc khởi động lại Local Launcher.
Nếu không đọc được instanceId hoặc không khóa/ghi được state, in URL để mở thủ công và không tạo tab có nguy cơ lặp; các dịch vụ vẫn hoạt động.

## Bằng chứng đã chạy

- `CHROME_START_EVIDENCE/browser-dispatch-tests.json`: 18 test PASS trên Linux. Windows paths/process dispatch được kiểm soát; khóa Linux thật; không phải kiểm thử Windows vật lý.
- `CHROME_START_EVIDENCE/HTTP_RUNTIME/http-api-checks.json`: 16 nhóm HTTP/API PASS, server và API production thật trên 47382/47381.
- `CHROME_START_EVIDENCE/HTTP_RUNTIME/browser-runtime.json`: Chromium thực, hai origin, teacher.html HTTP 200, HMAC pairing/status READY, TV next/previous đồng bộ, zero JS/console errors, zero file requests, không CORS wildcard.
- Screenshot runtime trong `CHROME_START_EVIDENCE/HTTP_RUNTIME/`.
- `CHROME_START_EVIDENCE/preservation-checks.json`: 270 file baseline còn nguyên; 269 file giống từng byte, chỉ helper browser thay đổi. Candidate gốc và ZIP gốc không sửa.
- `CHROME_START_EVIDENCE/start_web_live.patch`: diff duy nhất của chương trình.

| Yêu cầu | Kiểm tra cloud | Windows vật lý sau patch |
|---|---|---|
| WEB HTTP 47382 | PASS — server thật | PENDING |
| Launcher 47381 | PASS — API thật, desktop Windows không chạy | PENDING |
| Chrome opened | PASS — dispatch được kiểm soát, không phải chrome.exe thật | PENDING |
| teacher.html HTTP | PASS — Chromium thật, HTTP 200 | PENDING |
| file:// | NONE — request runtime thật | PENDING |
| Edge auto-open khi Chrome tồn tại | NONE — kiểm tra nhánh dispatch có kiểm soát | PENDING |

Môi trường hiện có chỉ là Linux; không có máy GV Windows hoặc remote desktop để thực hiện các mục Windows vật lý. Không tuyên bố Windows PASS.

## Áp dụng và kiểm thử trên máy GV

Candidate gốc được giữ nguyên. Có thể giải nén bản bàn giao thành thư mục riêng.
Nếu chuyển sang thư mục mới, dừng WEB HTTP cũ bằng Ctrl+C trước khi chạy START vì kiểm tra fingerprint cố ý từ chối server của thư mục khác.
Hoặc tạo bản sao/backup của thư mục đang dùng, rồi thay duy nhất `LAUNCHER/start_web_live.py` từ bản patch; START_WEB_LIVE.bat và các file khác giữ nguyên.

1. Chạy `START_WEB_LIVE.bat`; xác nhận hai port, Chrome mở đúng URL trên.
2. Chrome phải xuất hiện với teacher.html qua HTTP; không có tab Edge mới do START mở nếu tìm thấy Chrome.
3. Chạy lại START hai lần; số tab WEB LIVE không tăng.
4. Chờ Launcher READY và kiểm tra Teacher/TV như hiện tại.
5. Nếu không cài Chrome ở ba vị trí: START mở trình duyệt mặc định, vẫn HTTP, không thất bại.
6. Ghi PASS/FAIL cho sáu mục Windows vật lý trong bảng; mục nào chưa chạy tiếp tục là PENDING.

Không xử lý giọng Việt/TTS ở vòng này.
