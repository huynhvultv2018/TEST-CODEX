# Reproduce browser checks (Linux)

Cần Node, Playwright và Chromium đã cài. Đây là dependency của harness phát triển, không phải dependency runtime của WEB LIVE.
Dùng checkout/thư mục hiện có trong môi trường cô lập; không tạo Git worktree.

Từ root candidate, terminal 1:

```sh
python -m http.server 8765 --bind 127.0.0.1 --directory .
```

Terminal 2:

```sh
node TV_MULTI_ENGINE_TESTS/run.cjs
node TV_MULTI_ENGINE_TESTS/extra.cjs
```

Chromium mặc định /usr/bin/chromium; đặt CHROMIUM_PATH nếu cần. Có thể đặt WEB_LIVE_TEST_ROOT để chọn root khác. Require playwright qua cài đặt Node của máy; nếu tự cài hãy dùng thư mục tool ngoài candidate. Không sửa package/lockfile của ứng dụng.

Harness chỉ dùng browser context kiểm thử riêng, xóa storage của context giữa lần nhập để không chạm dữ liệu người dùng. Demo extra dùng mock cho request/refresh, không mở ứng dụng OS. PNG/JSON được ghi vào TV_MULTI_ENGINE_EVIDENCE. Main harness gồm 171 màn × 2 trạng thái, 44 PNG; extra thêm 4 PNG và các contract checks. Lệnh trả exit code khác 0 khi assertion không đạt. Kết quả không thay thế test TV thật.
