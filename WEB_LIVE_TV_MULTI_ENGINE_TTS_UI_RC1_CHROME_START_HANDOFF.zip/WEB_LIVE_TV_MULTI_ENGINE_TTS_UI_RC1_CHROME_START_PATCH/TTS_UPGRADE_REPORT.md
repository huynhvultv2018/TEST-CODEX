# TTS upgrade report

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


## Kết quả và kiến trúc

Thêm `TTSController` độc lập, dùng chung cho Tin học, Đại số và Hình học. Chỉ Teacher nạp và khởi tạo controller/SpeechSynthesis. TV không nạp controller hay MathSpeech, không gọi speak; runtime ghi nhận TV speak calls = 0. Cơ chế lease localStorage ngăn cửa sổ GV thứ hai nhận quyền đọc khi owner còn hiệu lực; heartbeat 4 giây, expiry 20 giây. Storage không dùng được thì TTS báo lỗi quyền đọc, WEB LIVE vẫn hoạt động.

Teacher chọn text từ registry các block **đang hiển thị trên TV**, hoặc preview khi không có registry TV. Nếu TV đã biết đang chiếu context khác, nút đọc bị khóa cho đến khi đồng bộ. Chỉ whitelist content/hint/analysis/answer; bước giải tương lai, ghi chú GV, menu, metadata, SVG/canvas/ảnh và nút không vào speech source. Không suy diễn hình. Icon đọc ở preview hoặc select phần đọc cho phép đọc riêng block; câu hỏi trắc nghiệm trên TV được chia theo semantic question/option card. Gợi ý, phân tích, đáp án và chốt kiến thức chỉ có thể đọc khi đã hiển thị.

Registry và highlight là packet riêng (`ttsProtocol:1`) qua BroadcastChannel, postMessage cùng origin và localStorage; không thêm trường vào lesson schema. Registry gắn lesson identity/activation/source/index và hash text; highlight kiểm tra block/context/hash/owner/sequence, có TTL khi owner mất. Các handler đồng bộ bài cũ được giữ nguyên.

## Giọng, tốc độ và thiết bị

Locale ưu tiên vi-VN; chỉ chọn giọng Việt, fallback locale Việt khác với thông báo. Ưu tiên Nam khi có thuộc tính gender đáng tin hoặc GV đã nghe và xác nhận cho voice được chọn. Web Speech API chuẩn không có gender; không đoán Nam/Nữ từ tên. Khi chưa xác định, UI báo rõ thay vì tự tuyên bố Nam. Có select giọng và xác nhận giới tính trong tùy chọn nhỏ.

Rate mặc định **0.95×**; sáu mức 0.75/0.85/0.95/1.00/1.10/1.20. Persist voice URI + locale, gender preference, xác nhận gender từng voice, rate, highlight, volume qua `WEB_LIVE_TTS_SETTINGS_V1`. Đổi voice/rate/volume lúc đọc sẽ dừng lượt cũ. Giọng local được ưu tiên trong locale; giọng remote được ghi cần mạng.

Web Speech không cung cấp lựa chọn sink âm thanh: output theo Windows/Chrome. GV cần chọn loa/HDMI TV làm output hệ thống trước khi đọc. Âm thanh, giới tính thực tế và phát âm phải nghe trên máy thật.

## State, queue và highlight

IDLE / SPEAKING / PAUSED / STOPPED / ERROR, thêm STARTING trong lúc chờ native onstart. Nút chính đổi ĐỌC → TẠM DỪNG → TIẾP TỤC theo state; Stop và Replay nhỏ riêng. Không báo SPEAKING trước onstart. Theo dõi native event/property; timeout nếu giọng không khởi động; lỗi speech chỉ hiện ở TTS.

Chỉ một utterance native tại một thời điểm. Chia text dài thành đoạn khoảng 240 ký tự; không enqueue toàn bộ vào native engine. Stop, new read, Trước/Tiếp, jump, mở thư viện, import/load/start lesson, beforeunload/pagehide hủy native và queue nội bộ. Token bỏ qua callback cũ. Nội dung đang đọc bị thay/ẩn thì dừng; cửa sổ GV khác đổi trình chiếu cũng dừng. Runtime kiểm tra max outstanding = 1; onend tự chuyển block và kết thúc IDLE.

Highlight theo block bằng outline/inset shadow, không đổi kích thước, opacity Focus hay hình. Không thử word boundary phụ thuộc voice. Runtime xác nhận figure bbox và opacity của Focus không đổi khi highlight; bật/tắt và pause/resume hoạt động trong test double.

## MathSpeechPreprocessor

Chỉ chuyển text dành cho speech; không ghi ngược DOM/dữ liệu bài. Parser đọc toán cơ bản, phép toán, lũy thừa, căn, phân số, quan hệ, nhãn hình và độ. Phân số hợp chỉ rõ tử/mẫu; không giải, rút gọn hay suy đoán cấu trúc chưa parse được. Dictionary có điểm/đoạn/đường/tia/góc/tam giác/tứ giác/đường tròn/bán kính/đường kính/trung điểm/giao điểm/song song/vuông góc/bằng nhau/độ. Từ Việt giữ nguyên; symbol đã biết đổi sang ngữ nghĩa. URL, ngày và filename/code được bảo vệ trong các ca đã kiểm tra.

| Display | Speech text | Test text |
|---|---|---|
| `x²` | x bình phương | PASS |
| `x³` | x lập phương | PASS |
| `√25` | căn bậc hai của hai mươi lăm | PASS |
| `3/4` | ba phần tư | PASS |
| `3/5` | ba phần năm | PASS |
| `x² + 2x = 3` | x bình phương cộng hai x bằng ba | PASS |
| `AB ⟂ CD` | AB vuông góc với CD | PASS |
| `AB ∥ CD` | AB song song với CD | PASS |
| `∠ABC = 60°` | góc ABC bằng sáu mươi độ | PASS |
| `a ≠ b` | a khác b | PASS |
| `a ≥ b` | a lớn hơn hoặc bằng b | PASS |
| `a ≤ b` | a nhỏ hơn hoặc bằng b | PASS |
| `(x+1)/(x-2)` | phân số có tử số là x cộng một, mẫu số là x trừ hai | PASS |
| `(x+1)/((x-2)/(x+3))` | phân số có tử số là x cộng một, mẫu số là phân số có tử số là x trừ hai, mẫu số là x cộng ba | PASS |
| `-2x + 5 = 9` | âm hai x cộng năm bằng chín | PASS |
| `△ABC ≅ △DEF` | tam giác ABC bằng nhau tam giác DEF | PASS |
| `ngày 3/4/2026 và tệp lesson.json` | ngày 3/4/2026 và tệp lesson.json | PASS |
| `3/4/2026` | 3/4/2026 | PASS |
| `https://example.test/a/3/4` | https://example.test/a/3/4 | PASS |
| `x ? y` | x ? y | PASS |
| `Trong bài này, x² + 2x = 3.` | Trong bài này, x bình phương cộng hai x bằng ba. | PASS |

21 ca text đạt. Nhãn như x, AB, ABC giữ trong speech text; cách voice phát âm chữ cái thực tế chưa xác nhận. Parser không bao phủ toàn bộ LaTeX/MathML hay mọi ký hiệu toán; xem KNOWN_LIMITATIONS.

## Bằng chứng và điều kiện còn thiếu

`runtime.json`: TEST15–30 là **PASS_TEST_DOUBLE**, không có âm thanh. `edge-cases.json`: 7 ca onend/error/owner/storage/close/transport/unsupported. `math-speech.json`: chuyển text. `native-probe.json`: API nguyên bản tồn tại nhưng **0 voices**, UI ERROR “Chưa có giọng tiếng Việt trên máy GV.” Navigation/UI vẫn hoạt động, không có pageerror.

Do chưa phát được giọng Việt thật, **TTS tổng thể PENDING**. Pause/resume/giọng Nam/đường âm thanh và phát âm toán trên Windows chưa PASS. Không dùng speech mô phỏng để chứng nhận tiêu chí âm thanh.
