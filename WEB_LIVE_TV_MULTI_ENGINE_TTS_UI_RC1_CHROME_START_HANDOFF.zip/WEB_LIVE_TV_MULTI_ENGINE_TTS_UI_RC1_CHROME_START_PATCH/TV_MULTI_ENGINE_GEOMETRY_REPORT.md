# Hình học — Geometry Proof Board

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

PASS cloud với hai gói thật: HINH_HOC_8_T04_T07_LIVE_TEST (34 màn) và DUAL_VISUAL_TEST (35 màn). 138 trạng thái câu hỏi/đáp án-phân tích đã kiểm tra không tràn.

Hình ưu tiên 68/32; analysis/proof 60/40; giữ preset 70/30 và phóng toàn hình qua double-click hai chiều GV–TV. Hình scene của Ví dụ 2 vẫn liên tục trong phân tích index 7 và chứng minh tiếp theo. Sơ đồ phân tích vẫn theo resolver RC4, không thay ảnh hình học.

GT/KL và Goal/Clues tách ô khi có heading explicit. Proof step 1/2 dùng đáp án thật của package; trước/bớt bước hoạt động. Kết luận không tự thêm hay tạo lại toàn bộ chứng minh.

PROOF_DEPENDENCY_TREE kiểm tra bằng fixture type explicit sử dụng ảnh hình thật. Nhánh hiển thị dấu cộng và các quan hệ toán; node tương lai vắng khỏi DOM. Baseline chưa có screen mang type này; chưa tuyên bố cây đã chạy trong package thật.

Ca mở bốn bước phân tích và đáp án được kiểm tra riêng cả 1920×1080, 1600×900, 1366×768, 1280×720. Khi cần, dùng ô đánh số hai cột; giữ toàn bộ văn bản và số bước. Không chuyển dependency tree sang kiểu này.

Draw Board, Cover, Smart Geometry, Highlight, Focus, Pointer, Timer, Whiteboard, thứ tự layer và image scene đã được xác minh qua runtime browser.
