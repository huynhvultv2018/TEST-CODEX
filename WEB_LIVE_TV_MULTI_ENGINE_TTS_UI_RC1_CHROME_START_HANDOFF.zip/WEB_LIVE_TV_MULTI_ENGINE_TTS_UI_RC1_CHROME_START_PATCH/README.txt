WEB LIVE V1.1.5 — TV DEMO HANDOFF CANDIDATE

1. Giải nén nguyên gói; Windows Display phải ở Extend mode. Chạy START_WEB_LIVE.bat ở thư mục gốc để bật WEB server 127.0.0.1:47382, bật Local Launcher API 127.0.0.1:47381 và mở http://127.0.0.1:47382/WEB_LIVE/teacher.html. Nhập LIVE.zip rồi bấm MỞ TV; không mở HTML bằng file://.
2. Nếu Launcher cũ đang chạy, đóng cửa sổ cũ bằng Ctrl+C rồi dùng START_WEB_LIVE.bat mới. Launcher chỉ cho phép http://127.0.0.1:47382 và http://localhost:47382. LAUNCHER/START_LAUNCHER.bat chỉ bật API, không thay thế quy trình khởi động chung. Không mở port API 47381 như trang Teacher.
3. Tại screen.demo, bấm ▶ DEMO TRỰC TIẾP và xác nhận. Launcher mở Word/GeoGebra và chuyển cửa sổ sang màn phụ, maximize trên TV. Trang tv.html ở dưới vẫn chạy, không bị reload.
4. Bấm ↩ TRỞ LẠI WEB LIVE trong panel Teacher để thu nhỏ ứng dụng. Bài trên TV trở lại đúng trạng thái. Có thể bấm DEMO tiếp để hiện lại cùng cửa sổ.
5. Nếu không có màn phụ, ứng dụng mở ở màn hiện tại và panel báo rõ. Nếu từ 3 màn hình, chọn tvMonitorIndex trong LAUNCHER/launcher-display.json theo danh sách màn hình in trên Launcher. Nếu app mở nhưng chưa chuyển được, bấm THỬ CHUYỂN LẠI.
6. Đặt đường dẫn Word/GeoGebra của máy trong LAUNCHER/launcher_apps.json. Tệp DOCX/GGB tin cậy đặt dưới LAUNCHER/demos/. Metadata demo trong lesson chỉ chứa appId và file tương đối.

Giữ cặp WEB_LIVE/runtime-config.js và LAUNCHER/launcher-config.json cùng gói. Không gửi khóa vào lesson, LIVE.zip hoặc TV. API chỉ nhận appId/file đã cho phép; không nhận HWND/PID/tọa độ từ browser. Kết nối offline qua 127.0.0.1:47381.

Máy Windows cần Python 3.10+ và py -3. BUILD_WINDOWS_EXE.bat chỉ là hướng dẫn build tại Windows với PyInstaller; ZIP này không chứa EXE. Bản candidate đã qua kiểm thử logic mô phỏng và hồi quy trên Linux, cần test TV/Word/GeoGebra thật trên Windows. KHÔNG NÂNG PRODUCTION.
