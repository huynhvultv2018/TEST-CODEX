# WEB LIVE — LOCAL HTTP / LAUNCHER / ORIGIN REPORT

Ngày: 02/10/2026 23:52:22 GMT+7. Baseline: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.
Bản sao patch: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_LOCAL_HTTP_PATCH`. Không bump version sản phẩm.

## Kết quả

**Tầng WEB LIVE HTTP → Local Launcher đã PASS trong runtime cloud thực**: static HTTP server thật, production LauncherHandler/Pairing/LauncherService thật và Chromium fetch/CORS/Web Crypto thật; không mock API. Windows desktop không khả dụng trong cloud, nên .bat, monitor và native Word/GeoGebra trên máy GV chưa được chứng nhận.

| Gate | Kết quả | Evidence |
|---|---|---|
| WEB LIVE HTTP | PASS | Teacher HTTP200, script/assets nạp từ port 47382. |
| LAUNCHER RUNNING | PASS | API thực bind 127.0.0.1:47381, /status và /pair hoạt động. |
| ORIGIN ALLOWED | PASS | Hai origin chính xác; origin lạ/null/sai port bị 403. |
| WEB LIVE → LAUNCHER | PASS | Teacher HMAC pair thật, token và authenticated /status200 READY. |
| file:// dependency | NONE | Teacher, TV và requests đều HTTP; không file:// request. |
| CORS wildcard | NONE | ACAO chỉ trả đúng origin được whitelist, không *. |
| Windows START_WEB_LIVE.bat physical | PENDING | Chưa có Windows để chạy .bat tại máy GV. |

TTS, MathSpeech, UI, Teacher/TV source, lesson và engine giữ nguyên byte. Không xử lý giọng đọc trong vòng này. Gói gốc và HANDOFF TTS/UI đã phát hành giữ nguyên.

## Nguyên nhân gốc

1. **47381 là API Launcher, không phải static web server.** Handler chỉ có /status, /pair, /launch, /present, /return. Nó không phục vụ teacher.html hay các asset WEB_LIVE. START_WEB_LIVE.bat cũ chỉ gọi START_LAUNCHER.bat; không bật web server và không mở browser HTTP.
2. **Origin policy cũ chỉ nhận literal `null`.** Teacher chuyển sang HTTP có origin như http://127.0.0.1:47382 nên API cũ từ chối. Allow localhost chỉ theo IP client chưa đủ: scheme + hostname + port phải khớp whitelist.
3. **Truy cập API bằng thanh địa chỉ không có Origin header.** Vì vậy http://127.0.0.1:47381 trả ORIGIN_DENIED là hành vi bảo vệ hiện hữu, không chứng minh Launcher đã dừng. Sau patch, truy cập trực tiếp API vẫn có thể bị 403; URL cần mở là Teacher tại 47382.
4. **file:// không tạo origin HTTP ổn định cho quy trình này.** Người dùng bổ sung rằng Teacher trước đó mở file:// và có Console error về origin/postMessage. Chưa có exact Console stack cũ để quy một lỗi postMessage cụ thể về dòng source; không tự sửa messaging/TTS. Sau patch, Teacher và TV cùng HTTP origin đã sync với 0 pageerrors/console errors trong browser thực.

Đã tái hiện baseline bằng LauncherHandler nguyên bản trên HTTP thật (Linux, không mở ứng dụng native), không chỉ đọc source:

| Origin | Route | HTTP | Body status/error |
|---|---|---:|---|
| Không có header Origin | `/` | 403 | ORIGIN_DENIED |
| `null` | `/` | 404 | NOT_FOUND |
| `null` | `/status` | 200 | PAIR_REQUIRED |
| `http://127.0.0.1:47382` | `/status` | 403 | ORIGIN_DENIED |
| `http://localhost:47382` | `/status` | 403 | ORIGIN_DENIED |

Evidence: [baseline-api-reproduction.json](LOCAL_HTTP_EVIDENCE/baseline-api-reproduction.json).

## Kiến trúc sau patch / URL chính xác

```text
START_WEB_LIVE.bat
  → Python startup helper
  → WEB HTTP server       127.0.0.1:47382
  → Local Launcher API    127.0.0.1:47381
  → mở browser            http://127.0.0.1:47382/WEB_LIVE/teacher.html

Teacher → MỞ TV           http://127.0.0.1:47382/WEB_LIVE/tv.html
Teacher → /status /pair   http://127.0.0.1:47381
```

Port WEB: **47382**. Port Launcher: **47381**. Cả hai chỉ bind 127.0.0.1, không bind 0.0.0.0/LAN.

Allowed origins duy nhất:

```text
http://127.0.0.1:47382
http://localhost:47382
```

127.0.0.1 là URL chính; localhost được whitelist chính xác để hỗ trợ alias đã được dùng trong phiên này. CORS không wildcard, không cho origin tùy ý, không cho Origin:null. Host API vẫn phải 127.0.0.1:47381; endpoint của Teacher giữ nguyên.

Static server chỉ phục vụ dưới /WEB_LIVE/, không directory listing, không phục vụ LAUNCHER/config/key hay đường traversal/symlink ra ngoài WEB_LIVE. API vẫn giữ challenge một lần, HMAC proof, session token và checks cũ; không bỏ xác thực để làm origin pass.

## File sửa / thêm

| Tệp | Thay đổi |
|---|---|
| START_WEB_LIVE.bat | Gọi startup helper qua Python 3, bật hai dịch vụ rồi mở đúng HTTP Teacher. Báo lỗi nếu thiếu Python 3.10+. |
| LAUNCHER/WebLiveLauncher.py | Import whitelist cố định; thay điều kiện Origin:null bằng membership whitelist; ACAO echo đúng origin đã kiểm trong reply và preflight. Không refactor service/pair/launch/Win32. |
| LAUNCHER/README_WINDOWS.txt | Cập nhật cách mở HTTP, hai port và cách đóng bản Launcher cũ. |
| README.txt | Thay hướng dẫn mở HTML trực tiếp bằng khởi động HTTP. |
| **Mới:** LAUNCHER/web_live_http.py | Static server loopback, constants/whitelist, exact Host, redirect Teacher, assets và health marker. |
| **Mới:** LAUNCHER/start_web_live.py | Khởi động/reuse đúng dịch vụ, kiểm readiness/package, không chọn port tùy ý, mở browser. |

File bàn giao mới: báo cáo này, README_LOCAL_HTTP_PATCH.md, LOCAL_HTTP_TESTS, LOCAL_HTTP_EVIDENCE và LOCAL_HTTP_SHA256SUMS.txt.

Không sửa bất kỳ tệp nào trong WEB_LIVE/. Không đổi installation credential pair, launcher_apps.json, launcher-display.json, lesson package, engine, UI hoặc version.

## Quy trình một thao tác trên Windows

1. Giải nén toàn bộ bản patch trong thư mục riêng; giữ nguyên candidate cũ. Giữ cấu hình app/monitor hiện dùng trên máy nếu đã tùy chỉnh. Cần Python 3.10+ như source Launcher baseline.
2. **Lần đầu chuyển từ Launcher cũ đang chạy:** Ctrl+C trong CMD Launcher cũ. Origin policy được nạp vào process; đổi source không cập nhật process cũ đang giữ 47381.
3. Chạy **START_WEB_LIVE.bat** ở thư mục gốc. Helper bật web server và Launcher ở hai console, đợi readiness rồi mở đúng Teacher HTTP. Nếu browser mặc định chưa là Chrome, mở URL chính trong Chrome.
4. Nhập bài, bấm MỞ TV. Tới màn có demo, Teacher ghép Launcher và hiện “Launcher: ● SẴN SÀNG” theo kiến trúc demo hiện hữu. Việc import/chuyển màn không tự launch Word/GeoGebra.
5. Cuối buổi, Ctrl+C ở hai cửa sổ dịch vụ để dừng. Browser/lesson đóng theo thao tác GV.

Nếu dịch vụ mới đúng gói đã chạy, helper reuse. Nếu port có dịch vụ khác/bản cũ, helper báo lỗi và dừng, không auto-pick port khác, không kill dịch vụ đang chạy. Nếu helper vừa tạo child mà bước sau thất bại, nó dừng child do chính nó tạo. Không tự mở file:// khi HTTP thất bại.

Phân biệt quy trình: START_LAUNCHER.bat chỉ bật API. START_WEB_LIVE.bat mới là điểm khởi động chung. Teacher chỉ ghép API khi tới demo/active demo theo code cũ; không sửa frontend để ghép ngay khi còn ở màn import rỗng.

## Runtime browser evidence

| Teacher origin | Teacher GET | Authenticated API | Native response ACAO | Pageerror / Console error |
|---|---:|---|---|---|
| `http://127.0.0.1:47382` | 200 | 200 / READY | `http://127.0.0.1:47382` | 0 / 0 |
| `http://localhost:47382` | 200 | 200 / READY | `http://localhost:47382` | 0 / 0 |

Chromium 151.0.7922.173; hai context riêng, không mock fetch hay HMAC. Nạp DEMO_TRUC_TIEP_SAMPLE_LIVE.zip thật, đến màn Word, pair qua Web Crypto, API /status READY với token. TV popup thực cùng origin, Next/Previous đồng bộ. 0 file://requests, 0 native app launch; launcherStatus hiển thị SẴN SÀNG. Không dùng giọng mô phỏng để làm HTTP pass.

Evidence: [browser-runtime.json](LOCAL_HTTP_EVIDENCE/browser-runtime.json), [http-api-checks.json](LOCAL_HTTP_EVIDENCE/http-api-checks.json), [runtime.log](LOCAL_HTTP_EVIDENCE/runtime.log), [gallery](LOCAL_HTTP_EVIDENCE/index.html).

16 nhóm kiểm tra API/startup/security đã đạt:

- Exact origin, preflight/PNA, HMAC pair, authenticated status, one-use challenge, token protection — `http://127.0.0.1:47382`.
- Exact origin, preflight/PNA, HMAC pair, authenticated status, one-use challenge, token protection — `http://localhost:47382`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `None`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `null`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `*`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `http://127.0.0.1:47383`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `http://localhost:8765`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `https://127.0.0.1:47382`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `http://127.0.0.1:47382.evil.example`.
- Untrusted origin GET/OPTIONS/POST denied with no ACAO — `https://evil.example`.
- Direct API address bar/no Origin is not the Teacher site.
- Wrong Host and wrong preflight method denied.
- Static WEB root/redirect/HEAD and exact Host; no config/directory/traversal/cross-site subresource exposure; ordinary document navigation allowed.
- Bootstrap readiness and reuse; occupied/legacy endpoint rejected without kill or port fallback.
- Symlink outside WEB_LIVE is denied.
- Bootstrap starts real web_live_http.py subprocess at fixed port and reuses production API; second invocation reuses both.

Đã chạy thật web_live_http.py trong subprocess qua startup helper tại 47382; API production hiện hữu được reuse, lần gọi tiếp reuse cả hai. .bat và CREATE_NEW_CONSOLE trên Windows vẫn PENDING. HTTP/API proof không chứng nhận Windows monitor/Word/GeoGebra handoff.

## Integrity / checksum / giới hạn

Baseline 252 tệp: 248 tệp không đổi; 4 tệp gốc sửa ở bảng trên (hai code entry/policy, hai hướng dẫn). Tất cả WEB_LIVE/TTS/UI/MathSpeech/engine/lesson byte nguyên trạng. Bản candidate gốc vẫn 252 tệp không đổi; HANDOFF gốc SHA-256 `a5d269fe1ba471a9dd33c37b6aca0f2f8850846257a15f5f62974fbbb9bb3802`.

Manifest hiện hành cho bản patch: **LOCAL_HTTP_SHA256SUMS.txt**, phủ mọi tệp trừ chính manifest. Các manifest/report TTS/UI và multi-engine kế thừa là lịch sử baseline; không dùng manifest cũ để kiểm bốn tệp đã patch. Evidence integrity: [integrity.json](LOCAL_HTTP_EVIDENCE/integrity.json).

Không có quyền điều khiển máy GV Windows trong cloud. Cần chạy START_WEB_LIVE.bat trên máy đó và xác nhận URL/status tương ứng trước khi chứng nhận physical startup. Nếu Windows gặp browser policy/local network permission/proxy khác, ghi Console/Network cụ thể; không mở rộng CORS để né lỗi.

Kết thúc ở bản patch localhost + evidence. **Không xử lý TTS, không nâng production.**
