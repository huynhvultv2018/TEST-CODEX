class DrawBoardTeacher{
 constructor(){
  this.open=false;this.mode='overlay';this.tool='point';this.pending=null;this.draft=null;this.dragging=null;this.dragFrame=0;
  this.models=new Map();this.overlay=document.getElementById('drawOverlay');this.white=document.getElementById('drawWhite');
  for(const svg of [this.overlay,this.white]){
   svg.addEventListener('pointerdown',e=>this.pointerDown(e,svg));
   svg.addEventListener('pointermove',e=>this.pointerMove(e,svg));
   svg.addEventListener('pointerup',e=>this.pointerUp(e,svg));
   svg.addEventListener('pointercancel',()=>this.cancelPending());
  }
  document.getElementById('drawControls').addEventListener('click',e=>{
   const button=e.target.closest('button');if(!button)return;
   if(button.dataset.boardTool)this.selectTool(button.dataset.boardTool);
   else if(button.dataset.boardMode)this.selectMode(button.dataset.boardMode);
  });
  document.addEventListener('keydown',e=>{
   if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
   if(e.key==='Escape'){
    if(this.open&&this.hasPending())this.cancelPending();
    else if(coverController?.hasPending()||smartController?.hasPending()||classroomController?.pending?.length)return;
    else if(pointer)clearPointer();
    else return;
    e.preventDefault();e.stopImmediatePropagation();return;
   }
   if(!this.open)return;
   const k=e.key.toLowerCase();
   if((e.ctrlKey||e.metaKey)&&k==='z'){e.preventDefault();e.stopImmediatePropagation();this.undo();return}
   if((e.ctrlKey||e.metaKey)&&k==='y'){e.preventDefault();e.stopImmediatePropagation();this.redo();return}
   if(e.ctrlKey||e.metaKey||e.altKey)return;
   const keys={v:'point',l:'segment',r:'line',c:'circle',n:'label',m:'marker',e:'eraser',x:'move'};
   if(keys[k]){e.preventDefault();e.stopImmediatePropagation();this.selectTool(keys[k])}
  },true);
  window.addEventListener('resize',()=>this.render());
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.renderOverlay()).observe(document.getElementById('figureInner'));
  this.render();
 }
 lessonChanged(){this.cancelPending();this.open=false;this.models.clear();this.render()}
 screenChanged(){
  this.cancelPending();
  if(this.open&&this.mode==='overlay'&&!currentImage())this.open=false;
  if(this.open&&this.mode==='overlay'&&viewMode==='text')viewMode='split';
  this.render();
 }
 editingOverlay(){return this.open&&this.mode==='overlay'}
 hasPending(){return !!(this.pending||this.draft||this.dragging)}
 toolState(){
  if(!this.open||this.tool==='idle')return'idle';
  if(this.tool==='segment'||this.tool==='line')return this.tool+(this.pending?'_wait_end':'_wait_start');
  if(this.tool==='circle')return this.pending?'circle_wait_radius':'circle_wait_center';
  return this.tool==='label'?'label_select':this.tool;
 }
 overlayKey(){return lesson?DrawBoard.overlayScope(lesson,i):''}
 whiteKey(){return lesson?DrawBoard.whiteScope(lesson,i):''}
 activeKey(){return this.mode==='whiteboard'?this.whiteKey():this.overlayKey()}
 model(scope){if(!lesson)return null;const key=DrawBoard.storageKey(currentLessonId,scope);if(!this.models.has(key))this.models.set(key,new DrawBoard.Model(currentLessonId,scope));return this.models.get(key)}
 summary(){
  if(!lesson)return null;
  const overlay=this.overlayKey(),white=this.whiteKey();
  return{open:this.open,mode:this.mode,overlayScope:overlay,whiteScope:white,
   overlayVersion:this.model(overlay).revision,whiteVersion:this.model(white).revision};
 }
 toggle(){if(!lesson)return;if(!this.open){coverController?.close();smartController?.close()}this.open=!this.open;if(this.open)this.mode=currentImage()?'overlay':'whiteboard';this.cancelPending();if(this.open&&this.mode==='overlay'&&viewMode==='text')viewMode='split';render();sync()}
 close(){if(!this.open)return;this.open=false;this.cancelPending();render();sync()}
 selectMode(mode){
  if(!lesson||!['overlay','whiteboard'].includes(mode)||mode==='overlay'&&!currentImage())return;
  coverController?.close();
  smartController?.close();
  this.open=true;this.mode=mode;this.cancelPending();
  if(mode==='overlay'&&viewMode==='text')viewMode='split';
  render();sync();
 }
 selectTool(tool){
  if(!['move','point','segment','line','circle','label','marker','eraser'].includes(tool))return;
  this.cancelPending();this.tool=tool;this.updateControls();
 }
 cancelPending(){
  const drag=this.dragging;this.pending=this.draft=this.dragging=null;
  if(this.dragFrame&&typeof cancelAnimationFrame==='function')cancelAnimationFrame(this.dragFrame);
  this.dragFrame=0;
  if(drag)this.endPreview(drag.scope,drag.lessonId);
  this.renderActive();
 }
 status(){
  if(!this.open)return 'Bảng vẽ đang đóng';
  if(this.pending)return this.tool==='circle'?'Chọn điểm trên đường tròn':'Chọn điểm thứ hai';
  return({move:'Kéo điểm hoặc kéo chữ nhãn để di chuyển',point:'Click để đặt điểm',segment:'Chọn điểm đầu đoạn',line:'Chọn điểm đầu đường thẳng',circle:'Chọn tâm đường tròn',label:'Chọn điểm rồi nhập nhãn',marker:'Kéo để đánh dấu',eraser:'Click object để xóa',idle:'Chọn công cụ'})[this.tool];
 }
 updateControls(){
  const box=document.getElementById('drawControls');box.hidden=!this.open;
  document.getElementById('drawOpenBtn').classList.toggle('active',this.open);
  document.getElementById('drawOverlayBtn').disabled=!currentImage();
  box.querySelectorAll('[data-board-mode]').forEach(b=>b.classList.toggle('active',b.dataset.boardMode===this.mode));
  box.querySelectorAll('[data-board-tool]').forEach(b=>b.classList.toggle('active',b.dataset.boardTool===this.tool));
  document.getElementById('drawStatus').textContent=this.status();box.dataset.toolState=this.toolState();
  const m=lesson?this.model(this.activeKey()):null;
  document.getElementById('drawUndo').disabled=!m?.undoStack.length;
  document.getElementById('drawRedo').disabled=!m?.redoStack.length;
  document.getElementById('drawClear').disabled=!m?.objects.length;
 }
 render(){
  const whiteVisible=this.open&&this.mode==='whiteboard';
  document.getElementById('screen').hidden=whiteVisible;
  document.getElementById('whiteBoardPane').hidden=!whiteVisible;
  this.overlay.style.pointerEvents=this.editingOverlay()?'auto':'none';
  this.renderOverlay();
  if(whiteVisible)this.renderActive();
  this.updateControls();
 }
 renderOverlay(){
  const m=lesson&&currentImage()?this.model(this.overlayKey()):null;
  DrawBoard.render(this.overlay,m?.objects||[],{editable:this.editingOverlay()});
  if(this.editingOverlay())this.renderActive();
  smartController?.render();
 }
 renderActive(){
  if(!this.open)return;
  const svg=this.mode==='whiteboard'?this.white:this.overlay;
  const m=this.model(this.activeKey()),objects=m?.objects||[];
  const moved=this.dragging?.labelId?DrawBoard.previewLabel(objects,this.dragging.labelId,this.dragging.dx,this.dragging.dy):
   this.dragging?DrawBoard.previewPoint(objects,this.dragging.pointId,this.dragging.x,this.dragging.y):objects;
  DrawBoard.render(svg,this.draft?[...moved,this.draft]:moved,{editable:true});
  if(this.mode==='overlay')smartController?.render();
  this.updateControls();
 }
 publish(scope){
  this.renderOverlay();if(this.open&&this.mode==='whiteboard')this.renderActive();
  this.updateControls();const m=this.model(scope);
  const event={type:'drawBoard',lessonId:currentLessonId,scope,revision:m.revision};
  send(event);try{if(tvWindow&&!tvWindow.closed)tvWindow.postMessage(event,'*')}catch(_){}
  sync();
 }
 publishPreview(){
  if(!this.dragging)return;
  const {pointId,labelId,x,y,dx,dy,scope,lessonId,revision}=this.dragging;
  const event={type:'drawBoardPreview',lessonId,scope,baseRevision:revision,
   ...(labelId?{labelId,dx,dy}:{pointId,x,y})};
  send(event);try{if(tvWindow&&!tvWindow.closed)tvWindow.postMessage(event,'*')}catch(_){}
 }
 endPreview(scope,lessonId=currentLessonId){
  const event={type:'drawBoardPreviewEnd',lessonId,scope};
  send(event);try{if(tvWindow&&!tvWindow.closed)tvWindow.postMessage(event,'*')}catch(_){}
 }
 changed(result){if(result)this.publish(this.activeKey());else this.updateControls()}
 undo(){this.cancelPending();this.changed(this.model(this.activeKey())?.undo())}
 redo(){this.cancelPending();this.changed(this.model(this.activeKey())?.redo())}
 clear(){
  const m=this.model(this.activeKey());if(!m?.objects.length)return;
  if(confirm('Xóa toàn bộ hình đang vẽ?'))this.changed(m.clear());
 }
 point(svg,e){return DrawBoard.at(svg,e)}
 pointerDown(e,svg){
  if(!this.open||svg!==(this.mode==='whiteboard'?this.white:this.overlay))return;
  e.stopPropagation();e.preventDefault();
  const m=this.model(this.activeKey()),p=this.point(svg,e);
  if(e.shiftKey&&this.mode==='overlay'){pointer={x:p.x,y:p.y};renderPointer();sync();return}
  if(this.tool==='move'){
   const id=e.target.closest('[data-object-id]')?.getAttribute('data-object-id');
   const hit=m.objects.find(o=>o.id===id);
   if(hit?.type==='label'){
    this.dragging={labelId:hit.id,startX:p.x,startY:p.y,startDx:Number(hit.dx)||0,startDy:Number(hit.dy)||0,
     dx:Number(hit.dx)||0,dy:Number(hit.dy)||0,scope:this.activeKey(),lessonId:currentLessonId,revision:m.revision};
    svg.setPointerCapture?.(e.pointerId);this.updateControls();return;
   }
   const point=hit?.type==='point'?hit:DrawBoard.snap(m.objects,p,svg).point;
   if(!point)return;
   this.dragging={pointId:point.id,x:point.x,y:point.y,scope:this.activeKey(),lessonId:currentLessonId,revision:m.revision};
   svg.setPointerCapture?.(e.pointerId);this.updateControls();return;
  }
  if(this.tool==='idle')return;
  if(this.tool==='eraser'){
   const near=DrawBoard.snap(m.objects,p,svg).point;
   const rect=svg.getBoundingClientRect();
   const veryNear=near&&Math.hypot((near.x-p.x)*rect.width,(near.y-p.y)*rect.height)<9;
   const id=veryNear?near.id:e.target.closest('[data-object-id]')?.getAttribute('data-object-id');
   if(id)this.changed(m.remove(id));
   return;
  }
  if(this.tool==='label'){
   let point=m.objects.find(o=>o.id===e.target.closest('[data-object-id]')?.getAttribute('data-object-id')&&o.type==='point');
   point=point||DrawBoard.snap(m.objects,p,svg).point;
   if(!point){document.getElementById('drawStatus').textContent='Hãy chọn một điểm đã vẽ';return}
   const old=m.objects.find(o=>o.type==='label'&&o.targetId===point.id);
   const input=prompt('Nhãn điểm',old?.text||'');
   if(input!==null){const value=input.trim().slice(0,12);if(value)this.changed(m.label(point,value))}
   return;
  }
  if(this.tool==='marker'){
   this.draft={type:'marker',id:'draft',points:[p]};svg.setPointerCapture?.(e.pointerId);this.renderActive();return;
  }
  if(this.tool==='point'){this.changed(m.add({type:'point',x:p.x,y:p.y}));return}
  const snapped=DrawBoard.snap(m.objects,p,svg);
  if(!this.pending){this.pending={x:snapped.x,y:snapped.y,pointId:snapped.point?.id};this.updateControls();return}
  const a=this.pending,b={x:snapped.x,y:snapped.y,pointId:snapped.point?.id};this.pending=null;this.draft=null;
  const size=svg.getBoundingClientRect(),distance=Math.hypot((b.x-a.x)*size.width,(b.y-a.y)*size.height);
  if(distance<2){this.updateControls();return}
  if(this.tool==='circle')this.changed(m.add({type:'circle',cx:a.x,cy:a.y,r:distance/Math.min(size.width,size.height),centerPointId:a.pointId,radiusPointId:b.pointId}));
  else this.changed(m.add({type:this.tool,x1:a.x,y1:a.y,x2:b.x,y2:b.y,startPointId:a.pointId,endPointId:b.pointId}));
 }
 pointerMove(e,svg){
  if(!this.open||svg!==(this.mode==='whiteboard'?this.white:this.overlay))return;
  if(this.tool==='move'&&this.dragging){
   e.stopPropagation();e.preventDefault();
   const p=this.point(svg,e);
   if(this.dragging.labelId){
    this.dragging.dx=this.dragging.startDx+(p.x-this.dragging.startX);
    this.dragging.dy=this.dragging.startDy+(p.y-this.dragging.startY);
   }else{this.dragging.x=p.x;this.dragging.y=p.y}
   if(!this.dragFrame)this.dragFrame=requestAnimationFrame(()=>{
    this.dragFrame=0;if(!this.dragging)return;
    this.renderActive();this.publishPreview();
   });
  }else if(this.tool==='marker'&&this.draft){
   e.stopPropagation();const p=this.point(svg,e),last=this.draft.points.at(-1),r=svg.getBoundingClientRect();
   if(Math.hypot((p.x-last.x)*r.width,(p.y-last.y)*r.height)>2&&this.draft.points.length<1000){
    this.draft.points.push(p);this.renderActive();
   }
  }else if(this.pending&&['segment','line','circle'].includes(this.tool)){
   e.stopPropagation();const p=DrawBoard.snap(this.model(this.activeKey()).objects,this.point(svg,e),svg);
   const a=this.pending,b=p,r=svg.getBoundingClientRect();
   this.draft=this.tool==='circle'?{type:'circle',id:'draft',cx:a.x,cy:a.y,r:Math.hypot((b.x-a.x)*r.width,(b.y-a.y)*r.height)/Math.min(r.width,r.height)}:
    {type:this.tool,id:'draft',x1:a.x,y1:a.y,x2:b.x,y2:b.y};
   this.renderActive();
  }
 }
 pointerUp(e,svg){
  if(this.dragging&&this.tool==='move'&&svg===(this.mode==='whiteboard'?this.white:this.overlay)){
   e.stopPropagation();e.preventDefault();
   const drag=this.dragging,p=this.point(svg,e),size={w:svg.clientWidth||svg.getBoundingClientRect().width,h:svg.clientHeight||svg.getBoundingClientRect().height};
   this.dragging=null;
   if(this.dragFrame&&typeof cancelAnimationFrame==='function')cancelAnimationFrame(this.dragFrame);
   this.dragFrame=0;
   const changed=drag.labelId?
    this.model(drag.scope).moveLabel(drag.labelId,drag.startDx+(p.x-drag.startX),drag.startDy+(p.y-drag.startY)):
    this.model(drag.scope).movePoint(drag.pointId,p.x,p.y,size);
   this.endPreview(drag.scope,drag.lessonId);
   if(changed)this.publish(drag.scope);else this.renderActive();
   return;
  }
  if(!this.draft||this.tool!=='marker'||svg!==(this.mode==='whiteboard'?this.white:this.overlay))return;
  e.stopPropagation();e.preventDefault();
  const stroke=this.draft;this.draft=null;
  if(stroke.points.length>1){delete stroke.id;this.changed(this.model(this.activeKey()).add(stroke))}
  else this.renderActive();
 }
 snapshot(scope,source){
  if(!lesson||!scope||![this.overlayKey(),this.whiteKey()].includes(scope))return;
  const message={type:'drawBoardSnapshot',lessonId:currentLessonId,scope,record:this.model(scope).record()};
  if(source?.postMessage)source.postMessage(message,'*');else send(message);
 }
}
