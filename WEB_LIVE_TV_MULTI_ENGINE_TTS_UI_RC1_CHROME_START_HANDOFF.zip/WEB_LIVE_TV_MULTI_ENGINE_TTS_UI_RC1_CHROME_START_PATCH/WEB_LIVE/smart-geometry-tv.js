class SmartGeometryTV{
 constructor(){
  this.overlay=document.getElementById('smartLayer');this.state=null;this.scope=null;this.revision=0;
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.fit()).observe(document.getElementById('figureInner'));
  window.addEventListener('resize',()=>this.fit());
 }
 apply(state,hasGeometry){
  this.state=state;this.scope=state.smart?.scope||null;this.revision=state.smart?.revision||0;
  this.hasGeometry=hasGeometry;this.fit();
 }
 boardObjects(){
  if(!this.state||!this.hasGeometry)return[];
  const board=this.state.board||{},scope=board.overlayScope;
  if(!scope)return[];
  let objects=boardViewer?.board(scope,board.overlayVersion||0)||DrawBoard.read(this.state.lessonId,scope).objects;
  const preview=boardViewer?.preview;
  if(preview?.pointId&&preview.scope===scope&&DrawBoard.read(this.state.lessonId,scope).revision===preview.baseRevision)
   objects=DrawBoard.previewPoint(objects,preview.pointId,preview.x,preview.y);
  return objects;
 }
 fit(){
  if(!this.state||!this.hasGeometry){SmartGeometry.render(this.overlay,[],[]);return}
  const record=SmartGeometry.read(this.state.lessonId,this.scope);
  if(record.revision<this.revision){
   const ask={type:'needSmartGeometry',lessonId:this.state.lessonId,scope:this.scope};
   send(ask);try{window.opener?.postMessage(ask,'*')}catch(_){}
  }
  SmartGeometry.render(this.overlay,record.objects,this.boardObjects());
 }
 refresh(event){
  if(!this.state||event.lessonId!==this.state.lessonId||event.scope!==this.scope)return;
  this.revision=Math.max(this.revision,event.revision||0);this.fit();
 }
 snapshot(event){
  if(!this.state||event.lessonId!==this.state.lessonId||event.scope!==this.scope||!Array.isArray(event.record?.objects))return;
  SmartGeometry.write(event.lessonId,event.scope,event.record);
  this.refresh({lessonId:event.lessonId,scope:event.scope,revision:event.record.revision});
 }
 storage(event){
  if(!this.state)return;
  const own=event.key===SmartGeometry.storageKey(this.state.lessonId,this.scope);
  const boardKey=DrawBoard.storageKey(this.state.lessonId,this.state.board?.overlayScope);
  if(own||event.key===boardKey)this.fit();
 }
}
