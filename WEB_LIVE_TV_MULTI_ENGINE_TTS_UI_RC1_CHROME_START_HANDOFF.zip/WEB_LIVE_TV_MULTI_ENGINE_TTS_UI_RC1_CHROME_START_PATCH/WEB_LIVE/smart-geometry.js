// Geometry marks are runtime SVG annotations. No image pixel or lesson data is edited.
const SmartGeometry=(()=>{
 const NS='http://www.w3.org/2000/svg',LIMIT=80,COLOR='#6b36c9';
 const copy=x=>JSON.parse(JSON.stringify(x));
 const clamp=x=>Math.max(0,Math.min(1,Number(x)||0));
 const scope=(lesson,index)=>DrawBoard.overlayScope(lesson,index).replace(/^overlay:/,'smart:');
 const storageKey=(lessonId,scene)=>'smartGeometry:'+encodeURIComponent(String(lessonId))+':'+encodeURIComponent(scene);
 const types=new Set(['parallelMark','perpendicularMark','equalSegmentMark','angleMark','equalAngleMark','midpointMark']);
 function read(lessonId,scene){
  try{
   const d=JSON.parse(localStorage.getItem(storageKey(lessonId,scene))||'null');
   if(d&&Array.isArray(d.objects))return{version:1,revision:Math.max(0,Number(d.revision)||0),objects:d.objects.filter(o=>o&&types.has(o.type)).slice(0,2000)};
  }catch(_){}
  return{version:1,revision:0,objects:[]};
 }
 function write(lessonId,scene,record){try{localStorage.setItem(storageKey(lessonId,scene),JSON.stringify(record));return true}catch(_){return false}}
 let sequence=0;
 const uid=()=>globalThis.crypto?.randomUUID?.()||'smart'+Date.now().toString(36)+'_'+(++sequence).toString(36);
 class Model{
  constructor(lessonId,scene){this.lessonId=lessonId;this.scene=scene;this.data=read(lessonId,scene);this.undoStack=[];this.redoStack=[]}
  get objects(){return this.data.objects}
  get revision(){return this.data.revision}
  record(){return copy(this.data)}
  change(next){
   if(JSON.stringify(next)===JSON.stringify(this.objects))return false;
   this.undoStack.push(copy(this.objects));if(this.undoStack.length>LIMIT)this.undoStack.shift();
   this.redoStack=[];this.data.objects=copy(next);this.data.revision++;
   return write(this.lessonId,this.scene,this.data);
  }
  add(object){return this.change([...this.objects,{...object,id:uid()}])}
  remove(id){return this.change(this.objects.filter(o=>o.id!==id))}
  undo(){if(!this.undoStack.length)return false;this.redoStack.push(copy(this.objects));this.data.objects=this.undoStack.pop();this.data.revision++;return write(this.lessonId,this.scene,this.data)}
  redo(){if(!this.redoStack.length)return false;this.undoStack.push(copy(this.objects));this.data.objects=this.redoStack.pop();this.data.revision++;return write(this.lessonId,this.scene,this.data)}
 }
 const size=svg=>{const r=svg.getBoundingClientRect();return{w:svg.clientWidth||r.width||1000,h:svg.clientHeight||r.height||1000}};
 const pointMap=board=>new Map((board||[]).filter(o=>o?.type==='point').map(o=>[o.id,o]));
 function anchor(p,board,svg){
  const snapped=DrawBoard.snap(board,p,svg);
  if(snapped.point)return{x:snapped.x,y:snapped.y,pointId:snapped.point.id};
  const {w,h}=size(svg),lines=(board||[]).filter(o=>o?.type==='line'||o?.type==='segment').slice(0,80);
  let best=null,distance=14;
  for(let a=0;a<lines.length;a++)for(let b=a+1;b<lines.length;b++){
   const p1=resolveLine({kind:'boardLine',id:lines[a].id},board,w,h),p2=resolveLine({kind:'boardLine',id:lines[b].id},board,w,h);
   const cross=intersection(p1,p2,w,h);if(!cross)continue;
   const d=Math.hypot((cross.x-p.x)*w,(cross.y-p.y)*h);
   if(d<distance){best=cross;distance=d}
  }
  return best?{x:best.x,y:best.y}: {x:clamp(p.x),y:clamp(p.y)};
 }
 function resolveAnchor(a,points){
  if(!a)return null;
  const p=points.get(a.pointId);return{x:clamp(p?.x??a.x),y:clamp(p?.y??a.y)};
 }
 function resolveLine(ref,board,w=1000,h=600){
  if(!ref)return null;
  const points=pointMap(board);let a,b,kind=ref.kind;
  if(kind==='boardLine'){
   const obj=(board||[]).find(o=>o.id===ref.id&&(o.type==='segment'||o.type==='line'));
   if(obj){a=resolveAnchor({pointId:obj.startPointId,x:obj.x1,y:obj.y1},points);b=resolveAnchor({pointId:obj.endPointId,x:obj.x2,y:obj.y2},points);kind=obj.type}
   else if(ref.fallback){a=resolveAnchor(ref.fallback.a,points);b=resolveAnchor(ref.fallback.b,points);kind=ref.fallback.kind||'segment'}
  }else if(kind==='anchors'){
   a=resolveAnchor(ref.a,points);b=resolveAnchor(ref.b,points);kind='segment';
  }
  if(!a||!b||Math.hypot((a.x-b.x)*w,(a.y-b.y)*h)<2)return null;
  const ext=kind==='line'?DrawBoard.extent(a.x,a.y,b.x,b.y):{x1:a.x,y1:a.y,x2:b.x,y2:b.y};
  if(!ext)return null;
  return{a,b,kind,visibleA:{x:ext.x1,y:ext.y1},visibleB:{x:ext.x2,y:ext.y2}};
 }
 function lineRef(object,board){
  const points=pointMap(board);
  return{kind:'boardLine',id:object.id,fallback:{kind:object.type,
   a:{x:object.x1,y:object.y1,pointId:points.has(object.startPointId)?object.startPointId:undefined},
   b:{x:object.x2,y:object.y2,pointId:points.has(object.endPointId)?object.endPointId:undefined}}};
 }
 function distanceToLine(p,line,w,h){
  const a=line.visibleA,b=line.visibleB,dx=(b.x-a.x)*w,dy=(b.y-a.y)*h;
  const t=Math.max(0,Math.min(1,((p.x-a.x)*w*dx+(p.y-a.y)*h*dy)/(dx*dx+dy*dy)));
  return Math.hypot((p.x-a.x)*w-t*dx,(p.y-a.y)*h-t*dy);
 }
 function hitLine(board,p,svg){
  const {w,h}=size(svg);let nearest=null,distance=14;
  for(const o of board||[])if(o?.type==='segment'||o?.type==='line'){
   const ref=lineRef(o,board),line=resolveLine(ref,board,w,h);if(!line)continue;
   const d=distanceToLine(p,line,w,h);
   if(d<distance){nearest=ref;distance=d}
  }
  return nearest;
 }
 function intersection(a,b,w=1000,h=600){
  if(!a||!b)return null;
  const p={x:a.a.x*w,y:a.a.y*h},r={x:(a.b.x-a.a.x)*w,y:(a.b.y-a.a.y)*h};
  const q={x:b.a.x*w,y:b.a.y*h},s={x:(b.b.x-b.a.x)*w,y:(b.b.y-b.a.y)*h};
  const cross=(u,v)=>u.x*v.y-u.y*v.x,denom=cross(r,s);
  if(Math.abs(denom)<1e-6)return null;
  const qp={x:q.x-p.x,y:q.y-p.y},t=cross(qp,s)/denom,u=cross(qp,r)/denom;
  // A hand-picked endpoint on a raster image can miss the printed junction by
  // a few pixels. Accept at most 8 px beyond a finite segment, never a remote crossing.
  const outside=(parameter,length)=>parameter<0?-parameter*length:parameter>1?(parameter-1)*length:0;
  if(a.kind!=='line'&&outside(t,Math.hypot(r.x,r.y))>8||b.kind!=='line'&&outside(u,Math.hypot(s.x,s.y))>8)return null;
  const x=(p.x+t*r.x)/w,y=(p.y+t*r.y)/h;
  return x>=0&&x<=1&&y>=0&&y<=1?{x,y}:null;
 }
 function perpendicular(lines,board,w,h){
  const a=resolveLine(lines?.[0],board,w,h),b=resolveLine(lines?.[1],board,w,h),hit=intersection(a,b,w,h);
  if(!hit)return null;
  const va={x:(a.b.x-a.a.x)*w,y:(a.b.y-a.a.y)*h},vb={x:(b.b.x-b.a.x)*w,y:(b.b.y-b.a.y)*h};
  const na=Math.hypot(va.x,va.y),nb=Math.hypot(vb.x,vb.y);
  if(!na||!nb||Math.abs((va.x*vb.x+va.y*vb.y)/(na*nb))>.22)return null;
  const toward=line=>{
   const pa={x:(line.a.x-hit.x)*w,y:(line.a.y-hit.y)*h},pb={x:(line.b.x-hit.x)*w,y:(line.b.y-hit.y)*h};
   const v=Math.hypot(pa.x,pa.y)>Math.hypot(pb.x,pb.y)?pa:pb,n=Math.hypot(v.x,v.y);
   return n?{x:v.x/n,y:v.y/n,length:n}:null;
  };
  return{x:hit.x*w,y:hit.y*h,u:toward(a),v:toward(b)};
 }
 function nextStyle(objects,type,max){
  const current=objects.filter(o=>o.type===type),used=new Set(current.map(o=>o.styleIndex));
  for(let index=1;index<=max;index++)if(!used.has(index))return index;
  return 1+(current.length%max);
 }
 function node(tag,attrs={}){const n=document.createElementNS(NS,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,String(v));return n}
 function render(svg,objects,board,options={}){
  if(!svg)return;
  const {w,h}=size(svg);svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('preserveAspectRatio','none');
  const nodes=options.editable?[node('rect',{x:0,y:0,width:w,height:h,fill:'transparent','pointer-events':'all'})]:[];
  const points=pointMap(board);
  for(const mark of objects||[]){
   if(!mark||!types.has(mark.type))continue;
   const id=mark.id||'',color=id===options.selectedId?'#e35a1b':COLOR;
   const add=(tag,attrs)=>{const n=node(tag,attrs);n.setAttribute('data-smart-id',id);nodes.push(n);return n};
   const stroke=d=>{
    add('path',{d,fill:'none',stroke:'#fff','stroke-width':7,'stroke-linecap':'round','stroke-linejoin':'round'});
    add('path',{d,fill:'none',stroke:color,'stroke-width':3.2,'stroke-linecap':'round','stroke-linejoin':'round'});
    if(options.editable)add('path',{d,fill:'none',stroke:'transparent','stroke-width':18,'pointer-events':'stroke'});
   };
   const ticks=(ref,count,offset,slanted)=>{
    const line=resolveLine(ref,board,w,h);if(!line)return;
    const a=line.visibleA,b=line.visibleB,dx=(b.x-a.x)*w,dy=(b.y-a.y)*h,len=Math.hypot(dx,dy);
    const tx=dx/len,ty=dy/len,nx=-ty,ny=tx;
    const center={x:(a.x+b.x)*w/2+nx*offset,y:(a.y+b.y)*h/2+ny*offset};
    const vx=slanted?(nx*.88+tx*.47):nx,vy=slanted?(ny*.88+ty*.47):ny;
    for(let i=0;i<count;i++){
     const cx=center.x+tx*(i-(count-1)/2)*9,cy=center.y+ty*(i-(count-1)/2)*9;
     stroke(`M${cx-vx*7} ${cy-vy*7} L${cx+vx*7} ${cy+vy*7}`);
    }
   };
   const arc=(angle,count)=>{
    const a=resolveAnchor(angle?.p1,points),v=resolveAnchor(angle?.vertex,points),b=resolveAnchor(angle?.p2,points);
    if(!a||!v||!b)return;
    const vx=v.x*w,vy=v.y*h,alpha=Math.atan2((a.y-v.y)*h,(a.x-v.x)*w),beta=Math.atan2((b.y-v.y)*h,(b.x-v.x)*w);
    const left=Math.hypot((a.x-v.x)*w,(a.y-v.y)*h),right=Math.hypot((b.x-v.x)*w,(b.y-v.y)*h);
    let delta=beta-alpha;while(delta>Math.PI)delta-=2*Math.PI;while(delta< -Math.PI)delta+=2*Math.PI;
    if(left<8||right<8||Math.abs(delta)<.08)return;
    for(let i=0;i<count;i++){
     const r=Math.min(27+i*9,left*.42,right*.42),x1=vx+r*Math.cos(alpha),y1=vy+r*Math.sin(alpha),x2=vx+r*Math.cos(beta),y2=vy+r*Math.sin(beta);
     stroke(`M${x1} ${y1} A${r} ${r} 0 0 ${delta>=0?1:0} ${x2} ${y2}`);
    }
   };
   if(mark.type==='parallelMark')for(const ref of mark.lines||[])ticks(ref,Math.min(2,mark.styleIndex||1),7,true);
   else if(mark.type==='equalSegmentMark')for(const ref of mark.targets||[])ticks(ref,Math.min(3,mark.styleIndex||1),0,false);
   else if(mark.type==='perpendicularMark'){
    const g=perpendicular(mark.lines,board,w,h);if(!g)continue;
    if(g.u?.length>=14&&g.v?.length>=14){
     const s=Math.min(16,g.u.length*.35,g.v.length*.35),a={x:g.x+g.u.x*s,y:g.y+g.u.y*s},b={x:g.x+g.v.x*s,y:g.y+g.v.y*s};
     stroke(`M${a.x} ${a.y} L${a.x+g.v.x*s} ${a.y+g.v.y*s} L${b.x} ${b.y}`);
    }else{
     const text=add('text',{x:g.x+7,y:g.y-7,fill:color,'font-size':22,stroke:'#fff','stroke-width':3,'paint-order':'stroke'});text.textContent='⊥';
    }
   }else if(mark.type==='angleMark')arc(mark.angle,Math.min(2,mark.styleIndex||1));
   else if(mark.type==='equalAngleMark')for(const angle of mark.angles||[])arc(angle,Math.min(2,mark.styleIndex||1));
   else if(mark.type==='midpointMark'){
    const line=resolveLine(mark.source,board,w,h);if(!line)continue;
    const x=(line.a.x+line.b.x)*w/2,y=(line.a.y+line.b.y)*h/2;
    add('circle',{cx:x,cy:y,r:5,fill:color,stroke:'#fff','stroke-width':2});
    if(options.editable)add('circle',{cx:x,cy:y,r:16,fill:'transparent','pointer-events':'all'});
    if(mark.label){const text=add('text',{x:x+11,y:y-11,fill:color,'font-size':20,'font-weight':700,stroke:'#fff','stroke-width':3,'paint-order':'stroke'});text.textContent=String(mark.label).slice(0,8)}
   }
  }
  if(options.editable)for(const ref of options.pendingLines||[]){
   const line=resolveLine(ref,board,w,h);if(!line)continue;
   const d=`M${line.visibleA.x*w} ${line.visibleA.y*h} L${line.visibleB.x*w} ${line.visibleB.y*h}`;
   nodes.push(node('path',{d,fill:'none',stroke:'#f97316','stroke-width':3,'stroke-dasharray':'7 5','pointer-events':'none'}));
  }
  if(options.editable)for(const p of options.pendingAnchors||[]){
   const a=resolveAnchor(p,points);if(a)nodes.push(node('circle',{cx:a.x*w,cy:a.y*h,r:5,fill:'#f97316',stroke:'#fff','stroke-width':2,'pointer-events':'none'}));
  }
  svg.replaceChildren(...nodes);
 }
 return{Model,scope,storageKey,read,write,render,at:DrawBoard.at,anchor,resolveAnchor,resolveLine,lineRef,hitLine,intersection,perpendicular,nextStyle,size};
})();
