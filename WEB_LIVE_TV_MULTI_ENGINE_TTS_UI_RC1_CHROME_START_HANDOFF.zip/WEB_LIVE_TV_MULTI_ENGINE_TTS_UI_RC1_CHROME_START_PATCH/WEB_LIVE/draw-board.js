// Runtime annotations. This module never changes a LIVE lesson or its images.
const DrawBoard=(()=>{
 const NS='http://www.w3.org/2000/svg',LIMIT=80;
 const copy=x=>JSON.parse(JSON.stringify(x));
 const clamp=x=>Math.max(0,Math.min(1,Number(x)||0));
 function sceneScope(lesson,index){
  if(!lesson?.screens?.[index])return 'screen:'+index;
  let key=null,start=0,ended=false;
  for(let n=0;n<=index;n++){
   const s=lesson.screens[n],next=sceneKeyForScreen(s,key,ended,n,lesson);
   if(n===0||ended||next!==key||s.sceneStart===true)start=n;
   key=next;ended=s.sceneEnd===true;
  }
  return key?key+':'+start:'screen:'+(lesson.screens[index].id??index)+':'+index;
 }
 const overlayScope=(lesson,index)=>'overlay:'+sceneScope(lesson,index);
 const whiteScope=(lesson,index)=>'white:'+String(lesson?.screens?.[index]?.id??index)+':'+index;
 const storageKey=(lessonId,scope)=>'drawBoard:'+encodeURIComponent(String(lessonId))+':'+encodeURIComponent(scope);
 function inferReferences(objects){
  const points=objects.filter(o=>o?.type==='point');
  const exact=(x,y)=>points.find(p=>Math.abs(Number(p.x)-Number(x))<1e-7&&Math.abs(Number(p.y)-Number(y))<1e-7)?.id;
  return objects.map(o=>{
   if(o?.type==='segment'||o?.type==='line')return{...o,startPointId:o.startPointId||exact(o.x1,o.y1),endPointId:o.endPointId||exact(o.x2,o.y2)};
   if(o?.type==='circle')return{...o,centerPointId:o.centerPointId||exact(o.cx,o.cy)};
   return o;
  });
 }
 function read(lessonId,scope){
  try{
   const x=JSON.parse(localStorage.getItem(storageKey(lessonId,scope))||'null');
   if(x&&Array.isArray(x.objects))return{version:1,revision:Math.max(0,Number(x.revision)||0),objects:inferReferences(x.objects.slice(0,2000))};
  }catch(_){}
  return{version:1,revision:0,objects:[]};
 }
 function write(lessonId,scope,record){
  try{localStorage.setItem(storageKey(lessonId,scope),JSON.stringify(record));return true}catch(_){return false}
 }
 let sequence=0;
 const uid=()=>globalThis.crypto?.randomUUID?.()||'d'+Date.now().toString(36)+'_'+(++sequence).toString(36);
 class Model{
  constructor(lessonId,scope){this.lessonId=lessonId;this.scope=scope;this.data=read(lessonId,scope);this.undoStack=[];this.redoStack=[]}
  get objects(){return this.data.objects}
  get revision(){return this.data.revision}
  record(){return copy(this.data)}
  save(){return write(this.lessonId,this.scope,this.data)}
  change(next){
   if(JSON.stringify(next)===JSON.stringify(this.objects))return false;
   this.undoStack.push(copy(this.objects));if(this.undoStack.length>LIMIT)this.undoStack.shift();
   this.redoStack=[];this.data.objects=copy(next);this.data.revision++;return this.save();
  }
  add(object){return this.change([...this.objects,{id:uid(),...object}])}
  remove(id){return this.change(this.objects.filter(x=>x.id!==id))}
  label(point,text){
   let old=this.objects.find(x=>x.type==='label'&&x.targetId===point.id),next=copy(this.objects);
   if(old)Object.assign(next.find(x=>x.id===old.id),{text,x:point.x,y:point.y});
   else next.push({type:'label',id:uid(),targetId:point.id,text,x:point.x,y:point.y,dx:.018,dy:-.022});
   return this.change(next);
  }
  movePoint(id,x,y,size={w:1,h:1}){
   const next=copy(this.objects),point=next.find(o=>o.type==='point'&&o.id===id);
   if(!point)return false;
   point.x=clamp(x);point.y=clamp(y);
   const points=new Map(next.filter(o=>o.type==='point').map(o=>[o.id,o]));
   const w=Math.max(1,Number(size.w)||1),h=Math.max(1,Number(size.h)||1);
   for(const o of next){
    if(o.type==='segment'||o.type==='line'){
     if(o.startPointId===id){o.x1=point.x;o.y1=point.y}
     if(o.endPointId===id){o.x2=point.x;o.y2=point.y}
    }else if(o.type==='circle'){
     if(o.centerPointId===id){o.cx=point.x;o.cy=point.y}
     if(o.centerPointId===id||o.radiusPointId===id){
      const center=points.get(o.centerPointId)||{x:o.cx,y:o.cy},radius=points.get(o.radiusPointId);
      if(radius)o.r=Math.hypot((radius.x-center.x)*w,(radius.y-center.y)*h)/Math.min(w,h);
     }
    }else if(o.type==='label'&&o.targetId===id){o.x=point.x;o.y=point.y}
   }
   return this.change(next);
  }
  moveLabel(id,dx,dy){
   const old=this.objects.find(o=>o.type==='label'&&o.id===id);
   if(!old||Math.abs((Number(old.dx)||0)-dx)<1e-10&&Math.abs((Number(old.dy)||0)-dy)<1e-10)return false;
   const next=previewLabel(this.objects,id,dx,dy);
   return this.change(next);
  }
  clear(){return this.change([])}
  undo(){if(!this.undoStack.length)return false;this.redoStack.push(copy(this.objects));this.data.objects=this.undoStack.pop();this.data.revision++;return this.save()}
  redo(){if(!this.redoStack.length)return false;this.undoStack.push(copy(this.objects));this.data.objects=this.redoStack.pop();this.data.revision++;return this.save()}
 }
 function extent(x1,y1,x2,y2){
  const dx=x2-x1,dy=y2-y1;if(Math.abs(dx)+Math.abs(dy)<1e-8)return null;
  let a=-Infinity,b=Infinity;
  for(const [p,d] of [[x1,dx],[y1,dy]]){
   if(Math.abs(d)<1e-10){if(p<0||p>1)return null;continue}
   const t0=(0-p)/d,t1=(1-p)/d;a=Math.max(a,Math.min(t0,t1));b=Math.min(b,Math.max(t0,t1));
  }
  return a<=b?{x1:x1+a*dx,y1:y1+a*dy,x2:x1+b*dx,y2:y1+b*dy}:null;
 }
 function svgNode(tag,attrs={}){const n=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));return n}
 function svgSize(svg){const r=svg.getBoundingClientRect(),w=svg.clientWidth||r.width||1000,h=svg.clientHeight||r.height||1000;return{w,h}}
 function resolveObject(o,points,w,h){
  if(o.type==='label'){
   const point=points.get(o.targetId);return point?{...o,x:point.x,y:point.y}:o;
  }
  if(o.type==='segment'||o.type==='line'){
   const a=points.get(o.startPointId),b=points.get(o.endPointId);
   return a||b?{...o,x1:a?.x??o.x1,y1:a?.y??o.y1,x2:b?.x??o.x2,y2:b?.y??o.y2}:o;
  }
  if(o.type==='circle'){
   const center=points.get(o.centerPointId),radius=points.get(o.radiusPointId),cx=center?.x??o.cx,cy=center?.y??o.cy;
   return center||radius?{...o,cx,cy,r:radius?Math.hypot((radius.x-cx)*w,(radius.y-cy)*h)/Math.min(w,h):o.r}:o;
  }
  return o;
 }
 function previewPoint(objects,id,x,y){return objects.map(o=>o?.type==='point'&&o.id===id?{...o,x:clamp(x),y:clamp(y)}:o)}
 function previewLabel(objects,id,dx,dy){
  const label=objects.find(o=>o?.type==='label'&&o.id===id);
  if(!label)return objects;
  const point=objects.find(o=>o?.type==='point'&&o.id===label.targetId);
  const x=Number(point?.x??label.x)||0,y=Number(point?.y??label.y)||0;
  const offsetX=clamp(x+Number(dx||0))-x,offsetY=clamp(y+Number(dy||0))-y;
  return objects.map(o=>o===label?{...o,dx:offsetX,dy:offsetY}:o);
 }
 function render(svg,objects,options={}){
  if(!svg)return;
  const {w,h}=svgSize(svg),min=Math.min(w,h);svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('preserveAspectRatio','none');
  const nodes=options.editable?[svgNode('rect',{x:0,y:0,width:w,height:h,fill:'transparent','pointer-events':'all'})]:[];
  const points=new Map((objects||[]).filter(o=>o?.type==='point').map(o=>[o.id,o]));
  for(const raw of objects||[]){
   if(!raw||typeof raw!=='object')continue;
   const o=resolveObject(raw,points,w,h);
   let n=null,hit=null,attrs={};
   const x=v=>clamp(v)*w,y=v=>clamp(v)*h;
   if(o.type==='point'){
    n=svgNode('circle',{cx:x(o.x),cy:y(o.y),r:5,fill:'#d32432',stroke:'#fff','stroke-width':1.8});
    hit=svgNode('circle',{cx:x(o.x),cy:y(o.y),r:16,fill:'transparent'});
   }else if(o.type==='segment'||o.type==='line'){
    const v=o.type==='line'?extent(o.x1,o.y1,o.x2,o.y2):o;
    if(!v)continue;attrs={x1:x(v.x1),y1:y(v.y1),x2:x(v.x2),y2:y(v.y2)};
    n=svgNode('line',{...attrs,stroke:'#17609b','stroke-width':3,'stroke-linecap':'round'});
    hit=svgNode('line',{...attrs,stroke:'transparent','stroke-width':18});
   }else if(o.type==='circle'){
    attrs={cx:x(o.cx),cy:y(o.cy),r:Math.max(0,Number(o.r)||0)*min,fill:'none'};
    n=svgNode('circle',{...attrs,stroke:'#17609b','stroke-width':3});
    hit=svgNode('circle',{...attrs,stroke:'transparent','stroke-width':18});
   }else if(o.type==='marker'){
    if(!Array.isArray(o.points)||!o.points.length)continue;
    const d=o.points.slice(0,1000).map((p,j)=>(j?'L':'M')+x(p.x)+' '+y(p.y)).join(' ');
    n=svgNode('path',{d,fill:'none',stroke:'#ec7316','stroke-width':7,'stroke-linecap':'round','stroke-linejoin':'round',opacity:.8});
    hit=svgNode('path',{d,fill:'none',stroke:'transparent','stroke-width':19});
   }else if(o.type==='label'){
    n=svgNode('text',{x:x(Number(o.x)+Number(o.dx||0)),y:y(Number(o.y)+Number(o.dy||0)),fill:'#0b2747','font-size':24,'font-weight':700,stroke:'#fff','stroke-width':3,'paint-order':'stroke'});
    n.textContent=String(o.text||'').slice(0,12);
    if(options.editable){
     hit=svgNode('text',{x:n.getAttribute('x'),y:n.getAttribute('y'),fill:'transparent',stroke:'transparent','stroke-width':12,'font-size':24,'font-weight':700,'pointer-events':'all',cursor:'grab'});
     hit.textContent=n.textContent;
    }
   }
   if(n){n.setAttribute('data-object-id',o.id||'');nodes.push(n)}
   if(hit&&options.editable){hit.setAttribute('data-object-id',o.id||'');nodes.push(hit)}
  }
  svg.replaceChildren(...nodes);
 }
 function at(svg,event){
  try{
   const matrix=svg.getScreenCTM?.(),box=svg.viewBox?.baseVal;
   if(matrix&&box?.width&&box?.height&&svg.createSVGPoint){
    const point=svg.createSVGPoint();point.x=event.clientX;point.y=event.clientY;
    const local=point.matrixTransform(matrix.inverse());
    return{x:clamp((local.x-box.x)/box.width),y:clamp((local.y-box.y)/box.height)};
   }
  }catch(_){}
  // The current figure uses translation and uniform scale, so its transformed
  // rectangle is an exact inverse mapping when SVG CTM is unavailable.
  const r=svg.getBoundingClientRect();
  return{x:clamp((event.clientX-r.left)/(r.width||1)),y:clamp((event.clientY-r.top)/(r.height||1))};
 }
 function snap(objects,p,svg){
  const r=svg.getBoundingClientRect();let nearest=null,distance=16;
  for(const o of objects)if(o.type==='point'){
   const d=Math.hypot((o.x-p.x)*r.width,(o.y-p.y)*r.height);
   if(d<distance){nearest=o;distance=d}
  }
  return nearest?{x:nearest.x,y:nearest.y,point:nearest}:p;
 }
 return{Model,read,write,storageKey,overlayScope,whiteScope,render,at,snap,extent,clamp,previewPoint,previewLabel};
})();
