class CoverLayerTeacher{
 constructor(){
  this.open=false;this.tool='rect';this.draft=null;this.models=new Map();
  this.overlay=document.getElementById('coverLayer');
  this.overlay.addEventListener('pointerdown',e=>this.pointerDown(e));
  this.overlay.addEventListener('pointermove',e=>this.pointerMove(e));
  this.overlay.addEventListener('pointerup',e=>this.pointerUp(e));
  this.overlay.addEventListener('pointercancel',()=>this.cancelPending());
  document.getElementById('coverControls').addEventListener('click',e=>{
   const button=e.target.closest('button');if(button?.dataset.coverTool)this.selectTool(button.dataset.coverTool);
  });
  document.addEventListener('keydown',e=>{
   if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)||!this.open)return;
   if(e.key==='Escape'&&this.hasPending()){
    this.cancelPending();e.preventDefault();e.stopImmediatePropagation();return;
   }
   const k=e.key.toLowerCase();
   if((e.ctrlKey||e.metaKey)&&k==='z'){this.undo();e.preventDefault();e.stopImmediatePropagation()}
   else if((e.ctrlKey||e.metaKey)&&k==='y'){this.redo();e.preventDefault();e.stopImmediatePropagation()}
  },true);
  window.addEventListener('resize',()=>this.render());
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.render()).observe(document.getElementById('figureInner'));
  this.render();
 }
 key(){return lesson?CoverLayer.scope(lesson,i):''}
 model(scene=this.key()){
  if(!lesson||!scene)return null;
  const key=CoverLayer.storageKey(currentLessonId,scene);
  if(!this.models.has(key))this.models.set(key,new CoverLayer.Model(currentLessonId,scene));
  return this.models.get(key);
 }
 summary(){if(!lesson)return null;const scene=this.key();return{scope:scene,revision:this.model(scene)?.revision||0}}
 editing(){return this.open&&!!currentImage()}
 hasPending(){return !!this.draft}
 lessonChanged(){this.cancelPending();this.models.clear();this.open=false;this.render()}
 screenChanged(){this.cancelPending();if(!currentImage())this.open=false;this.render()}
 toggle(){
  if(!lesson||!currentImage())return;
  if(this.open){this.close();return}
  boardController?.close();smartController?.close();this.open=true;if(viewMode==='text')viewMode='split';
  render();sync();
 }
 close(){if(!this.open)return;this.cancelPending();this.open=false;this.render();sync()}
 selectTool(tool){if(!['rect','path','erase'].includes(tool))return;this.cancelPending();this.tool=tool;this.updateControls()}
 cancelPending(){if(!this.draft)return;this.draft=null;this.render()}
 updateControls(){
  const box=document.getElementById('coverControls');box.hidden=!this.open;
  const button=document.getElementById('coverOpenBtn');button.disabled=!currentImage();button.classList.toggle('active',this.open);
  box.querySelectorAll('[data-cover-tool]').forEach(b=>b.classList.toggle('active',b.dataset.coverTool===this.tool));
  const m=this.model();document.getElementById('coverUndo').disabled=!m?.undoStack.length;
  document.getElementById('coverRedo').disabled=!m?.redoStack.length;
  document.getElementById('coverClear').disabled=!m?.objects.length;
  document.getElementById('coverStatus').textContent=({rect:'Kéo để tạo ô che',path:'Kéo để tô che tự do',erase:'Click vùng che để khôi phục'})[this.tool];
 }
 render(){
  this.overlay.style.pointerEvents=this.editing()?'auto':'none';
  const objects=lesson&&currentImage()?this.model()?.objects||[]:[];
  CoverLayer.render(this.overlay,this.draft?[...objects,this.draft]:objects,{editable:this.editing()});
  this.updateControls();
 }
 publish(){
  this.render();const m=this.model(),event={type:'coverLayer',lessonId:currentLessonId,scope:this.key(),revision:m.revision};
  send(event);try{if(tvWindow&&!tvWindow.closed)tvWindow.postMessage(event,'*')}catch(_){}sync();
 }
 changed(result){if(result)this.publish();else this.updateControls()}
 undo(){this.cancelPending();this.changed(this.model()?.undo())}
 redo(){this.cancelPending();this.changed(this.model()?.redo())}
 clear(){
  this.cancelPending();
  const m=this.model();if(!m?.objects.length)return;
  if(confirm('Xóa tất cả vùng che trong scene này?'))this.changed(m.clear());
 }
 point(e){return CoverLayer.at(this.overlay,e)}
 pointerDown(e){
  if(!this.editing())return;
  e.stopPropagation();e.preventDefault();
  const p=this.point(e);
  if(e.shiftKey){pointer=p;renderPointer();sync();return}
  if(this.tool==='erase'){
   const id=e.target.closest('[data-cover-id]')?.getAttribute('data-cover-id');
   if(id)this.changed(this.model().remove(id));
   return;
  }
  this.draft=this.tool==='rect'?CoverLayer.rect(p,p):{type:'coverPath',points:[p],size:.034};
  this.draft.id='draft';this.start=p;
  this.overlay.setPointerCapture?.(e.pointerId);this.render();
 }
 pointerMove(e){
  if(!this.editing()||!this.draft)return;
  e.stopPropagation();e.preventDefault();
  const p=this.point(e),box=this.overlay.getBoundingClientRect();
  if(this.tool==='rect'){
   this.draft=CoverLayer.rect(this.start,p);this.draft.id='draft';
  }else if(this.tool==='path'){
   const points=this.draft.points,last=points.at(-1);
   if(points.length<1000&&Math.hypot((p.x-last.x)*box.width,(p.y-last.y)*box.height)>=2)points.push(p);
  }
  this.render();
 }
 pointerUp(e){
  if(!this.editing()||!this.draft)return;
  e.stopPropagation();e.preventDefault();
  const p=this.point(e),box=this.overlay.getBoundingClientRect(),draft=this.draft;
  this.draft=null;
  if(this.tool==='rect'){
   const cover=CoverLayer.rect(this.start,p);
   if(cover.w*box.width>=2&&cover.h*box.height>=2)this.changed(this.model().add(cover));
   else this.render();
  }else if(this.tool==='path'){
   const points=draft.points,last=points.at(-1);
   if(points.length<1000&&Math.hypot((p.x-last.x)*box.width,(p.y-last.y)*box.height)>0)points.push(p);
   this.changed(this.model().add({type:'coverPath',points,size:draft.size}));
  }
 }
 snapshot(scene,source){
  if(!lesson||!scene||scene!==this.key())return;
  const message={type:'coverSnapshot',lessonId:currentLessonId,scope:scene,record:this.model(scene).record()};
  if(source?.postMessage)source.postMessage(message,'*');else send(message);
 }
}
