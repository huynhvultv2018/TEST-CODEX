# Cover Layer — WEB LIVE V0.5.0.3 HOTFIX CANDIDATE

## Phạm vi

Lớp `coverLayer` là SVG runtime nằm giữa ảnh geometry và Draw Board; pointer đỏ nằm trên cùng. Không sửa pixel, không ghi đè file ảnh, không đưa cover vào `lesson.json` hay gói LIVE. Chỉ hoạt động khi màn hiện tại có resolved geometry image.

## Dữ liệu và scene

Mỗi scene có record riêng `{version:1, revision, objects:[]}` trong localStorage tại `coverLayer:<lessonId>:<coverScope>`. `coverScope` lấy cùng ranh giới Geometry Scene như Draw Board overlay: `sceneId`, `sceneStart`, `sceneEnd` và phân tách legacy. Màn tiếp theo cùng scene kế thừa vùng che; scene mới không kế thừa. Board và cover có history riêng (tối đa 80 action mỗi scene).

| Object | Tọa độ | Cách tạo |
| --- | --- | --- |
| `coverRect` | `id,x,y,w,h` normalized | Kéo chuột tạo ô che, kéo ngược hướng cũng được |
| `coverPath` | `id,points:[{x,y}],size` normalized | Rê chuột tạo nét trắng đầu tròn; tối đa 1000 điểm/nét |

Màu mặc định `#fff`, phù hợp hình có nền trắng/trắng ngà. Không tự lấy mẫu màu từ ảnh, không có palette trong hotfix này. Vùng che nằm trên ảnh gốc, nên hình Draw Board và pointer vẫn nhìn thấy phía trên. SVG cùng `figureInner` với ảnh và dùng inverse screen CTM để đổi vị trí chuột sang normalized coordinate ở zoom/pan/resize.

## Công cụ và history

Nút `▧ CHE DỮ LIỆU` mở editor trên hình: `▭ CHE Ô`, `🖌 CHE TỰ DO`, `↺ KHÔI PHỤC CHE`. Eraser chỉ xóa cover object được click, không xóa Draw Board hoặc pointer. `🗑 XÓA TẤT CẢ CHE` có xác nhận và chỉ xóa cover trong scene hiện tại. Tạo, xóa riêng, xóa tất cả đều vào Undo/Redo. Trong pointermove chỉ render draft trên GV; mouseup commit một action và ghi storage một lần. Esc/pointercancel hủy draft; Shift+click đặt pointer đỏ.

Mở Draw Board đóng editor cover; mở cover đóng editor Draw Board. Các object đã lưu luôn hiển thị khi hình hiện ra. Màn GV không thể chuyển sang Text Mode trong lúc editor cover mở.

## TV và đồng bộ

State LIVE mang `{cover:{scope,revision}}`. Khi commit, GV gửi event `coverLayer` gồm `lessonId,scope,revision`; TV đọc record để dựng SVG, không có toolbar và không nhận ảnh qua event. Nếu TV không chia sẻ storage, TV gửi `needCoverLayer` và GV trả `coverSnapshot` gồm record object JSON. Resize/reload TV render lại theo scope và revision. File ảnh và lesson giữ nguyên.

## Giới hạn cần kiểm tra thực tế

Trên hình có nền khác trắng, vùng che trắng có thể nhìn thấy mép. Hotfix chưa có lấy mẫu màu nền, chỉnh màu riêng, di chuyển cover đã tạo hay xuất cover vào ảnh. Cần thử hit target SVG, độ bám hình ở nhiều zoom/pan/resize và độ nhìn trên laptop/TV thật trước Production.
