# Draw Board Basic — WEB LIVE V0.5.0.2 HOTFIX CANDIDATE

## Phạm vi

Bảng vẽ là chú thích runtime, độc lập với `lesson.json`, ảnh hình học và sơ đồ phân tích. Module `draw-board.js` định nghĩa model, scene key, lưu trữ, snap và SVG renderer; `draw-board-teacher.js` điều khiển editor; `draw-board-tv.js` chỉ hiển thị. Không có CDN, Canvas, constraint engine hoặc thay đổi schema gói LIVE.

## Hai chế độ

| Chế độ | GV | TV | Phạm vi lưu |
| --- | --- | --- | --- |
| BẢNG TRẮNG | SVG nền trắng, dựng hình độc lập | SVG nền trắng, không toolbar | Từng màn của bài |
| VẼ TRÊN HÌNH LIVE | SVG nằm trên ảnh trong cùng `figureInner` | SVG cùng transform với geometry image, dưới điểm chỉ | Geometry Scene |

`VẼ TRÊN HÌNH LIVE` chỉ bật khi có resolved geometry image. Cùng `sceneId` dùng chung board; `sceneStart`, `sceneEnd`, chuyển ID hoặc ranh giới legacy mở scope mới. Board cũ vẫn lưu và được nạp khi trở lại. Màn không có scene vẫn có bảng trắng riêng.

## Dữ liệu

Mỗi board lưu một record `{version:1, revision, objects:[]}` tại `drawBoard:<lessonId>:<scope>` trong localStorage. Scope có tiền tố `overlay:` hoặc `white:`. Mỗi object có `id`, `type` và tọa độ normalized 0..1:

- `point`: `x,y`.
- `segment`, `line`: `x1,y1,x2,y2`, thêm `startPointId/endPointId` khi snap. Đường thẳng được kéo đến biên SVG khi render.
- `circle`: `cx,cy,r`, thêm `centerPointId/radiusPointId` khi snap; `r` theo cạnh ngắn hơn của vùng vẽ.
- `label`: `targetId,text,x,y,dx,dy`. `dx,dy` là độ lệch normalized có thể đổi bằng kéo nhãn; nhãn theo điểm qua `targetId`. `x,y` là tọa độ fallback nên xóa điểm không xóa nhãn.
- `marker`: `points:[{x,y},...]`, tối đa 1000 điểm/nét.

Các đường, đường tròn và nhãn không có dependency xóa dây chuyền. Snap vào điểm đã có trong bán kính hiển thị khoảng 16 px. Mỗi action tạo snapshot Undo/Redo; giới hạn 80 action cho từng board. Action mới sau Undo xóa Redo. Xóa toàn bộ có hộp xác nhận và có thể Undo.

## Tọa độ và lớp hiển thị

Overlay SVG và ảnh là con cùng `figureInner`; zoom/pan của WEB LIVE áp dụng cho cả hai bằng một CSS transform. SVG tính `viewBox` theo kích thước hiển thị chưa transform; event đổi sang normalized coordinates bằng inverse screen CTM (có fallback cho scale/translate). Resize/full screen cập nhật viewBox. Thứ tự lớp: ảnh → SVG → điểm chỉ. Bảng trắng dùng SVG riêng.

TV chỉ dựng object, không chứa toolbar, selected/hover, input nhãn hay undo stack. SVG object giữ độ sắc nét khi zoom. Marker được preview trong bộ nhớ khi kéo, chỉ ghi storage lúc thả.

## Đồng bộ và phục hồi

GV ghi record lên localStorage và tăng `revision` khi commit. State LIVE chứa `board: {open,mode,overlayScope,whiteScope,overlayVersion,whiteVersion}`. Một event `drawBoard` nhỏ truyền scope/revision qua BroadcastChannel và postMessage. TV đọc record từ localStorage rồi render; nếu storage không chia sẻ, TV yêu cầu `needDrawBoard` và GV trả `drawBoardSnapshot` chỉ gồm object JSON. Không gửi ảnh nền, screenshot hay PNG theo thao tác. Tải lại TV đọc state và record đang lưu.

## Công cụ và phím

Di chuyển (kéo-thả điểm hoặc chữ nhãn); điểm; đoạn (2 click); đường (2 click); tròn (tâm rồi điểm bán kính); nhãn (chọn điểm, nhập tên); marker (kéo); xóa (click object). Trạng thái công cụ: `idle`, `move`, `point`, `segment_wait_start/end`, `line_wait_start/end`, `circle_wait_center/radius`, `label_select`, `marker`, `eraser`. Esc hủy thao tác dở; nếu không có thao tác dở thì xóa pointer đỏ. X/V/L/R/C/N/M/E chọn công cụ; Ctrl+Z/Ctrl+Y Undo/Redo. Khi focus input/textarea/select thì không bắt phím. Shift + click trên hình khi editor overlay mở để đặt điểm chỉ độc lập.

## Giới hạn

Đây là bản basic. Chỉ kéo-thả point và label; không kéo trực tiếp đoạn/đường/tròn, không có constraint, đo đạc, ký hiệu vuông góc/song song, palette, xuất ảnh hoặc ghi ngược vào gói. Cần xác nhận khả năng đọc, hit target, alignment và offline trên laptop/TV thật trước Production.

## Hotfix V0.5.0.2: point reference và pointer

Đoạn/đường tạo qua snap lưu thêm `startPointId/endPointId`; tròn tạo qua snap lưu `centerPointId/radiusPointId`. Tọa độ x/y ban đầu vẫn là fallback nếu point bị xóa. Nhãn dùng `targetId` và render theo point hiện tại. Point có hit radius 16 px, kích thước nhìn thấy 5 px. Board cũ được nối tham chiếu khi endpoint trùng chính xác point đã lưu.

Tool `✥ DI CHUYỂN` cho phép kéo point ở BẢNG TRẮNG hoặc VẼ TRÊN HÌNH LIVE. SVG lấy tọa độ qua inverse screen CTM và có fallback cho transform scale/translate. Trong pointermove chỉ dựng bản xem trước trong memory và gửi `drawBoardPreview` nhỏ (point ID, normalized x/y, revision gốc) theo khung hình; không ghi localStorage. Mouseup ghi một action và gửi board revision. TV render các hình phụ thuộc từ point đang preview; sự kiện kết thúc/cancel xóa preview.

Pointer đỏ không thuộc board. Shift + click đặt pointer; nút `⌖ XÓA ĐIỂM CHỈ` luôn hiện trên thanh đầu và ESC xóa pointer khi không có thao tác vẽ dở. ESC khi đang kéo hoặc chờ click thứ hai chỉ hủy thao tác ấy.

## Hotfix V0.5.0.2: kéo nhãn điểm

Nhãn có vùng bắt chuột rộng hơn chữ nhìn thấy. Trong công cụ `✥ DI CHUYỂN`, nhấn vào **chữ nhãn** để kéo nhãn, nhấn vào **chấm điểm** để kéo điểm. Dùng độ lệch con trỏ từ lúc nhấn để không giật vị trí; kéo nhãn chỉ cập nhật `dx,dy` theo hệ tọa độ normalized tương đối với điểm và giữ `targetId`. Khi kéo điểm về sau, nhãn vẫn đi theo và giữ độ lệch đã chỉnh. Có thể kéo trên bảng trắng và overlay ở zoom/pan/resize; giới hạn điểm neo của nhãn trong vùng SVG.

Trong lúc kéo, GV dựng preview cục bộ và TV nhận `drawBoardPreview` gồm `labelId,dx,dy,scope,baseRevision`; không gửi ảnh hoặc ghi localStorage. Thả chuột commit một action Undo/Redo và board revision; Esc/pointercancel hủy preview. Dữ liệu nhãn V0.5.0/V0.5.0.1 tiếp tục đọc được, không đổi `lesson.json` hoặc schema gói LIVE.
