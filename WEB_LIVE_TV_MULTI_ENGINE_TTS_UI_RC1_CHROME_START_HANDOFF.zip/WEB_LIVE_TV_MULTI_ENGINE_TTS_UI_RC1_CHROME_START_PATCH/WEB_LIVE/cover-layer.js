// Runtime masks live beside the geometry image; lesson data and image bytes are untouched.
const CoverLayer=(()=>{
 const NS='http://www.w3.org/2000/svg',COLOR='#fff',LIMIT=80;
 const copy=value=>JSON.parse(JSON.stringify(value));
 const clamp=value=>Math.max(0,Math.min(1,Number(value)||0));
 const scope=(lesson,index)=>DrawBoard.overlayScope(lesson,index).replace(/^overlay:/,'cover:');
 const storageKey=(lessonId,scene)=>'coverLayer:'+encodeURIComponent(String(lessonId))+':'+encodeURIComponent(scene);
 function read(lessonId,scene){
  try{
   const data=JSON.parse(localStorage.getItem(storageKey(lessonId,scene))||'null');
   if(data&&Array.isArray(data.objects))return{version:1,revision:Math.max(0,Number(data.revision)||0),
    objects:data.objects.filter(o=>o?.type==='coverRect'||o?.type==='coverPath').slice(0,2000)};
  }catch(_){}
  return{version:1,revision:0,objects:[]};
 }
 function write(lessonId,scene,record){
  try{localStorage.setItem(storageKey(lessonId,scene),JSON.stringify(record));return true}catch(_){return false}
 }
 let sequence=0;
 const uid=()=>globalThis.crypto?.randomUUID?.()||'cover'+Date.now().toString(36)+'_'+(++sequence).toString(36);
 class Model{
  constructor(lessonId,scene){this.lessonId=lessonId;this.scene=scene;this.data=read(lessonId,scene);this.undoStack=[];this.redoStack=[]}
  get objects(){return this.data.objects}
  get revision(){return this.data.revision}
  record(){return copy(this.data)}
  change(next){
   if(JSON.stringify(next)===JSON.stringify(this.objects))return false;
   this.undoStack.push(copy(this.objects));if(this.undoStack.length>LIMIT)this.undoStack.shift();
   this.redoStack=[];this.data.objects=copy(next);this.data.revision++;
   return write(this.lessonId,this.scene,this.data);
  }
  add(object){return this.change([...this.objects,{...object,id:uid()}])}
  remove(id){return this.change(this.objects.filter(o=>o.id!==id))}
  clear(){return this.change([])}
  undo(){if(!this.undoStack.length)return false;this.redoStack.push(copy(this.objects));this.data.objects=this.undoStack.pop();this.data.revision++;return write(this.lessonId,this.scene,this.data)}
  redo(){if(!this.redoStack.length)return false;this.undoStack.push(copy(this.objects));this.data.objects=this.redoStack.pop();this.data.revision++;return write(this.lessonId,this.scene,this.data)}
 }
 function node(tag,attrs={}){const n=document.createElementNS(NS,tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,String(v));return n}
 function dimensions(svg){const r=svg.getBoundingClientRect();return{w:svg.clientWidth||r.width||1000,h:svg.clientHeight||r.height||1000}}
 function rect(a,b){const x=Math.min(clamp(a.x),clamp(b.x)),y=Math.min(clamp(a.y),clamp(b.y));return{type:'coverRect',x,y,w:Math.abs(clamp(a.x)-clamp(b.x)),h:Math.abs(clamp(a.y)-clamp(b.y))}}
 function render(svg,objects,options={}){
  if(!svg)return;
  const {w,h}=dimensions(svg),min=Math.min(w,h);svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('preserveAspectRatio','none');
  const nodes=options.editable?[node('rect',{x:0,y:0,width:w,height:h,fill:'transparent','pointer-events':'all'})]:[];
  for(const o of objects||[]){
   if(!o||typeof o!=='object')continue;
   let n=null,hit=null;
   if(o.type==='coverRect'){
    n=node('rect',{x:clamp(o.x)*w,y:clamp(o.y)*h,width:Math.max(0,Number(o.w)||0)*w,height:Math.max(0,Number(o.h)||0)*h,fill:COLOR});
   }else if(o.type==='coverPath'&&Array.isArray(o.points)&&o.points.length){
    const points=o.points.slice(0,1000),width=Math.max(4,(Number(o.size)||.034)*min);
    if(points.length===1){
     n=node('circle',{cx:clamp(points[0].x)*w,cy:clamp(points[0].y)*h,r:width/2,fill:COLOR});
     if(options.editable)hit=node('circle',{cx:clamp(points[0].x)*w,cy:clamp(points[0].y)*h,r:Math.max(12,width/2+6),fill:'transparent','pointer-events':'all'});
    }else{
     const d=points.map((p,i)=>(i?'L':'M')+clamp(p.x)*w+' '+clamp(p.y)*h).join(' ');
     n=node('path',{d,fill:'none',stroke:COLOR,'stroke-width':width,'stroke-linecap':'round','stroke-linejoin':'round'});
     if(options.editable)hit=node('path',{d,fill:'none',stroke:'transparent','stroke-width':Math.max(22,width+12),'pointer-events':'stroke'});
    }
   }
   if(n){n.setAttribute('data-cover-id',o.id||'');nodes.push(n)}
   if(hit){hit.setAttribute('data-cover-id',o.id||'');nodes.push(hit)}
  }
  svg.replaceChildren(...nodes);
 }
 return{Model,read,write,storageKey,scope,render,rect,at:DrawBoard.at,clamp};
})();
