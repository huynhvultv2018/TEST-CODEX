# Chuẩn gói LIVE Hình học V0.4.5

Giữ nguyên `manifest.json`, `lesson.json`, `images/` và các trường của V0.3/V0.4. Các trường dưới đây **tùy chọn**; gói cũ vẫn nhập được. Hệ thống không sửa nội dung toán học hoặc ghi ngược vào `lesson.json` khi trình chiếu.

## Geometry Scene

Mỗi bài toán/hình liên tục nên có một `sceneId` riêng trên **mọi screen của bài toán**. Hình chỉ khai báo ở màn mở scene và ở màn thay hình. Màn còn lại không cần lặp `image`.

```json
{"id":6,"sceneId":"VD2","sceneStart":true,"type":"Ví dụ 2","image":"images/VD2_H331.png","title":"Đề bài","content":"Chứng minh AHCK là hình bình hành."}
{"id":7,"sceneId":"VD2","imageMode":"inherit","type":"Ví dụ 2","title":"Chọn dấu hiệu","content":"Cần chứng minh hai điều gì về AH và CK?"}
{"id":9,"sceneId":"VD2","imageMode":"inherit","analysisDiagram":"images/VD2_bang_nhau.png","type":"Ví dụ 2","title":"Chứng minh bằng nhau"}
{"id":10,"sceneId":"VD2","sceneEnd":true,"imageMode":"inherit","type":"Ví dụ 2","title":"Kết luận"}
```

- `sceneStart: true`: xóa hình cũ rồi bắt đầu scene, kể cả khi dùng lại một ID.
- `sceneId`: ranh giới chính xác; chuyển ID thì không kế thừa hình cũ.
- `image` mang `visualRole: "geometry"`: hình mới trở thành hình hiện hành trong scene; các màn sau kế thừa hình mới. `image` mang `visualRole: "analysis"` là sơ đồ riêng của màn hiện tại.
- `imageMode: "inherit"`: lấy hình hiện hành; đây cũng là mặc định khi cùng scene.
- `imageMode: "none"`: không hiện hình và xóa hình hiện hành. Trường này có ưu tiên cao hơn `image` nếu cả hai cùng có.
- `sceneEnd: true`: màn hiện tại vẫn có thể hiện hình; màn tiếp theo không kế thừa từ scene đã kết thúc.
- Màn không có `sceneId` không thể kế thừa từ scene có ID. Màn không ảnh ngoài scene dùng Text Mode.

### Gói V0.3/V0.4 chưa có `sceneId`

Fallback chỉ kế thừa qua **các màn liền kề** có `type` cùng nhóm và số: `Ví dụ 2`, `Luyện tập 2/2a/2b`, `Thực hành 2`; hoặc qua nhóm `Vận dụng` liền kề. Đổi nhóm/số, `sceneStart`, `sceneEnd`, `imageMode: "none"` hoặc tiêu đề bắt đầu bằng `Bài` kèm số sẽ cắt kế thừa. Màn ngoài các nhóm này không kế thừa. Nếu có hai bài Vận dụng liền nhau cùng `type`, hãy dùng `sceneId`/`sceneStart` để nêu ranh giới rõ ràng; hệ thống không thể suy ra chắc chắn từ văn bản.

## Văn bản và bước chứng minh

- Lưu câu văn liền mạch. Không chèn `\n` theo chiều rộng dự kiến của TV.
- `steps[]`: mỗi phần tử là **một bước logic**. Có thể dùng `conclusion` riêng; kết luận được hiện cùng lời giải đầy đủ và sau bước cuối.
- Dùng dòng trống, dấu đầu dòng, số thứ tự, `Bước 1`, các dòng công thức độc lập hoặc hai khoảng trắng trước `\n` để đánh dấu xuống dòng có chủ ý. Dòng bắt đầu `⇒`, `⇔`, `∴` được giữ riêng.
- Renderer nối newline giữa một câu văn thành một khoảng trắng và giữ các dòng có ý nghĩa; cùng một hàm áp dụng cho TV và preview GV. CSS tự ngắt khi hết chiều ngang. Nội dung `lesson.json` lưu nguyên bản.
- Các trường được xử lý: `title`, `content` (hoặc `question` khi thiếu content), `hint`, `answer`, từng phần tử `steps[]`, `conclusion`.

Kiểm tra gói bằng cách mở từ `index.html`, sang màn giữa một scene, đổi hình, sang scene tiếp theo, tải lại TV và thử Gợi ý/BƯỚC +/Đáp án khi offline.

## Sơ đồ phân tích trong cùng Geometry Scene

Màn `type: "analysis"`, `"analysisDiagram"`, `"proofAnalysis"` hoặc có tiêu đề chứa “Sơ đồ phân tích”, “Phân tích”, “Hướng chứng minh”, “Tìm hướng giải”, “Chuỗi suy luận”, “Sơ đồ chứng minh” phải mang **cùng `sceneId`** với đề bài khi còn dùng hình đó. Dùng `imageMode: "inherit"`; chỉ khai báo `image` mới khi hình thực sự thay đổi. Không dùng `imageMode: "none"` khi học sinh vẫn cần nhìn hình. Renderer giữ Hình + Chữ ở các màn này khi có resolved image, kể cả metadata cũ đặt `layout: "text"`.

```json
{
  "id": "7A",
  "sceneId": "VD2",
  "type": "analysisDiagram",
  "title": "Sơ đồ phân tích",
  "imageMode": "inherit",
  "content": "Tìm hướng chứng minh AHCK là hình bình hành.",
  "analysisSteps": [
    "Cần chứng minh AH ∥ CK và AH = CK.",
    "AH ⟂ BD, CK ⟂ BD ⇒ AH ∥ CK.",
    "∆AHD ≅ ∆CKB ⇒ AH = CK.",
    "AH ∥ CK và AH = CK ⇒ AHCK là hình bình hành."
  ]
}
```

Mỗi `analysisSteps[]` là một đơn vị suy luận hoàn chỉnh; không chèn newline để khống chế chiều rộng. Ban đầu TV chỉ hiện `content`; mỗi lần bấm **PHÂN TÍCH +** sẽ thêm một bước. Hình và điểm chỉ vẫn hiện; trạng thái truyền giữa GV và TV chỉ chứa số bước, không gửi lại ảnh. Khi đổi screen, số bước và điểm chỉ reset. Các gói cũ không có `analysisSteps[]` vẫn trình chiếu bình thường. Với gói cũ thiếu `sceneId`, màn phân tích liền kề được phép kế thừa scene đang hoạt động; metadata rõ ràng vẫn là cách đáng tin cậy để tách các bài toán.

## Hai vai trò hình trong một scene

`geometry image` là hình điểm/cạnh/góc của bài toán, được kế thừa trong scene. `analysis diagram` là sơ đồ suy luận của **màn hiện tại**, đặt trong cột nội dung bên phải; nó không thay hình học bên trái và không được kế thừa sang màn sau. Không lặp hình gốc trong mọi screen.

Gói mới nên khai báo vai trò rõ ràng:

```json
{"id":6,"sceneId":"VD2","sceneStart":true,"image":"images/VD2_H331.png","visualRole":"geometry","title":"Đề bài"}
{"id":8,"sceneId":"VD2","type":"proofAnalysis","title":"Chứng minh song song","imageMode":"inherit","content":"Vì sao AH ∥ CK?","analysisDiagram":"images/VD2_song_song.png"}
{"id":9,"sceneId":"VD2","type":"proofAnalysis","title":"Chứng minh bằng nhau","imageMode":"inherit","analysisDiagram":"images/VD2_bang_nhau.png"}
```

Có thể dùng `image` với `visualRole:"analysis"` thay cho `analysisDiagram`. Nếu cùng màn cần một hình hình học mới và một sơ đồ, dùng `image` + `visualRole:"geometry"` cho hình gốc, thêm `analysisDiagram` cho sơ đồ. Importer nhúng cả hai đường dẫn khi đọc LIVE.zip. Khi chỉ nhập lesson.json riêng, phải có `imageData`/`analysisDiagramData` hoặc data URI tương ứng.

Nếu có `analysisSteps[]`, renderer ưu tiên các bước chữ rõ nét; ảnh `analysisDiagram` vẫn được giữ trong gói nhưng không trình chiếu cùng lúc. `PHÂN TÍCH +` chỉ tăng số bước; hình gốc, zoom và điểm chỉ không đổi. `PHÓNG HÌNH` tác động lên hình học bên trái; màn phân tích mặc định HÌNH + CHỮ và không cho PHÓNG CHỮ làm ẩn hình.

### Fallback V0.3/V0.4 thiếu vai trò

Ảnh có tên `_H331`, `_H332`, `_Hinh` và mẫu `H` kèm số được ưu tiên là hình học; `_song_song`, `_bang_nhau`, `_so_do`, `_phan_tich`, `_can`, `_duong_cheo`, `_dung`, `_ket_luan` được ưu tiên là sơ đồ. Tên không rõ ràng vẫn dùng hành vi ảnh hình học cũ để tránh crash. Fallback chỉ áp dụng trong ranh giới scene; với tệp tên mơ hồ phải gắn `visualRole` rõ ràng. Không suy đoán nội dung toán học từ ảnh.
