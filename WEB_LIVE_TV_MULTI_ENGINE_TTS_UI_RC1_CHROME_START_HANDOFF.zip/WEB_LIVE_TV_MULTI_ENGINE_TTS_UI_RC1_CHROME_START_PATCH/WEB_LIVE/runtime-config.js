/* Installation credential for this package. Teacher window only. */
const WEB_LIVE_INSTALLATION = Object.freeze({"installationId":"cNeM7fi6mw5s7bYrjoGbjXxl","installationKey":"47d09ea9b6748e4cbef75f3fb18ad3c53f41ca600d0ce455ba29de96529c06c3"});
