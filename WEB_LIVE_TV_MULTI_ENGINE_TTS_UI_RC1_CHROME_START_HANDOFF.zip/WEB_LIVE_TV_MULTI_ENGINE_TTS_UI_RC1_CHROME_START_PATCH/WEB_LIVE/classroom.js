/* V0.6.2 presentation state. Lesson data and image pixels are never changed. */
const Classroom=(()=>{
 const NS='http://www.w3.org/2000/svg';
 const clamp=x=>Math.max(0,Math.min(1,Number(x)||0));
 function parts(value){
  const source=String(value??''),result=[],separator=/(\n+|(?<=[.!?])\s+(?=[A-ZÀ-Ỹ△∠]))/gu;
  let offset=0;
  for(const match of source.matchAll(separator)){
   if(match.index>offset)result.push({type:'block',text:source.slice(offset,match.index)});
   result.push({type:'separator',text:match[0]});offset=match.index+match[0].length;
  }
  if(offset<source.length)result.push({type:'block',text:source.slice(offset)});
  return result;
 }
 function focusText(node,value,region,focus,onPick){
  const source=String(value??'');
  if(!document.createElement||!document.createTextNode||!node.replaceChildren){
   if(typeof renderMathAtomic==='function')renderMathAtomic(node,source);else node.textContent=source;
   return;
  }
  const children=[];let index=0;
  for(const part of parts(source)){
   if(part.type==='separator'){
    const sep=document.createElement('span');sep.className='focusSeparator';sep.textContent=part.text;children.push(sep);continue;
   }
   if(part.text.trim()==='↓'){
    const arrow=document.createElement('span');arrow.className='focusArrow';arrow.textContent=part.text;children.push(arrow);continue;
   }
   const blockIndex=index++;
   const line=document.createElement('span');line.className='focusBlock';line.dataset.focusRegion=region;line.dataset.focusIndex=String(blockIndex);
   if(focus?.region===region&&focus.index===blockIndex)line.classList.add('isFocused');
   if(typeof renderMathAtomic==='function')renderMathAtomic(line,part.text);else line.textContent=part.text;
   if(onPick)line.addEventListener('click',()=>onPick(region,blockIndex));
   children.push(line);
  }
  node.replaceChildren(...children);node.classList.toggle('hasFocus',!!focus&&focus.region===region);
 }
 function step(node,region,index,focus,onPick){
  node.classList.add('focusBlock');node.dataset.focusRegion=region;node.dataset.focusIndex=String(index);
  node.classList.toggle('isFocused',focus?.region===region&&focus.index===index);
  if(onPick)node.addEventListener('click',()=>onPick(region,index));
 }
 function svgNode(tag,attrs){const node=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))node.setAttribute(k,String(v));return node}
 function draw(svg,objects=[],draft=[]){
  const w=svg.clientWidth||svg.parentElement?.clientWidth||1000,h=svg.clientHeight||svg.parentElement?.clientHeight||1000;
  svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('preserveAspectRatio','none');
  const nodes=[];
  const px=p=>({x:clamp(p.x)*w,y:clamp(p.y)*h});
  for(const o of [...objects,...(draft.length?[{type:'draft',points:draft}]:[])]){
   if(o.type==='point'&&o.points?.[0]){const p=px(o.points[0]);nodes.push(svgNode('circle',{cx:p.x,cy:p.y,r:Math.max(14,Math.min(w,h)*.025),class:'highlightPoint'}));}
   if(o.type==='segment'&&o.points?.length===2){const a=px(o.points[0]),b=px(o.points[1]);nodes.push(svgNode('line',{x1:a.x,y1:a.y,x2:b.x,y2:b.y,class:'highlightStroke'}));}
   if(o.type==='triangle'&&o.points?.length===3){const pts=o.points.map(px);nodes.push(svgNode('polygon',{points:pts.map(p=>`${p.x},${p.y}`).join(' '),class:'highlightTriangle'}));}
   if(o.type==='draft')for(const p0 of o.points){const p=px(p0);nodes.push(svgNode('circle',{cx:p.x,cy:p.y,r:Math.max(8,Math.min(w,h)*.012),class:'highlightDraft'}));}
  }
  svg.replaceChildren(...nodes);
 }
 function elapsed(clock,now=Date.now()){
  const base=Math.max(0,Number(clock?.elapsedMs)||0),since=clock?.running?Math.max(0,now-(Number(clock.startedAt)||now)):0;
  return Math.min(99*3600000,base+since);
 }
 function clockText(clock,now=Date.now()){
  if(!clock||clock.mode==='off')return '';
  if(clock.mode==='clock')return new Date(now).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit',hour12:false});
  const format=ms=>{const sec=Math.floor(ms/1000);return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`};
  return format(elapsed(clock,now))+' / '+format((clock.durationMin||45)*60000);
 }
 return{parts,focusText,step,draw,clockText,elapsed};
})();
