// Read the central directory to support ordinary ZIPs and ZIPs with data descriptors.
async function unzipFile(file){
 const b=file instanceof Uint8Array?file:new Uint8Array(await file.arrayBuffer()),v=new DataView(b.buffer,b.byteOffset,b.byteLength),out=Object.create(null);
 const u16=p=>v.getUint16(p,true),u32=p=>v.getUint32(p,true);
 let end=-1;for(let p=b.length-22;p>=Math.max(0,b.length-65557);p--)if(u32(p)===0x06054b50){end=p;break}
 if(end<0)throw Error('Tệp không phải ZIP hợp lệ');
 let count=u16(end+10),p=u32(end+16),total=0;
 if(count===65535||p===0xffffffff)throw Error('ZIP64 chưa được hỗ trợ');
 for(let n=0;n<count;n++){
  if(p+46>b.length||u32(p)!==0x02014b50)throw Error('Thư mục ZIP bị lỗi');
  let flags=u16(p+8),method=u16(p+10),compressed=u32(p+20),size=u32(p+24),nl=u16(p+28),extra=u16(p+30),comment=u16(p+32),local=u32(p+42);
  let name=new TextDecoder('utf-8').decode(b.slice(p+46,p+46+nl));p+=46+nl+extra+comment;
  if(name.endsWith('/'))continue;
  if(name.startsWith('/')||name.includes('\\')||name.split('/').includes('..')||Object.hasOwn(out,name))throw Error('Đường dẫn ZIP không hợp lệ: '+name);
  if(flags&1)throw Error('ZIP có mật khẩu: '+name);
  if(size>30*1024*1024||(total+=size)>70*1024*1024)throw Error('Gói ZIP quá lớn');
  if(local+30>b.length||u32(local)!==0x04034b50)throw Error('Mục ZIP bị lỗi: '+name);
  let start=local+30+u16(local+26)+u16(local+28);
  if(start+compressed>b.length)throw Error('Dữ liệu ZIP bị thiếu: '+name);
  let raw=b.slice(start,start+compressed),data;
  if(method===0)data=raw;
  else if(method===8){if(typeof DecompressionStream==='undefined')throw Error('Trình duyệt không hỗ trợ giải nén ZIP');
   data=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer())}
  else throw Error('Kiểu nén ZIP không hỗ trợ: '+name);
  if(data.length!==size)throw Error('Kích thước ZIP không khớp: '+name);
  out[name]=data;
 }
 return out;
}
function txt(u){return new TextDecoder('utf-8',{fatal:true}).decode(u)}
function getLibrary(){try{return JSON.parse(localStorage.getItem('webLiveLibrary')||'[]')}catch(_){return[]}}
function getLesson(id){try{return JSON.parse(localStorage.getItem('lesson:'+id))}catch(_){return null}}
function fingerprint(bytes){
 let h=0xcbf29ce484222325n;for(const b of bytes)h=BigInt.asUintN(64,(h^BigInt(b))*0x100000001b3n);
 return h.toString(16).padStart(16,'0');
}
function assetPath(value){return typeof value==='string'?value:(value&&typeof value==='object'?(value.path||value.src||value.image||''):'')}
function saveLesson(x,sourceKey){
 const key=sourceKey||'json:'+fingerprint(new TextEncoder().encode(JSON.stringify(x)));
 const original=String(x.id||x.packageId||`${x.subject||'BAI'}_${x.week||0}_${x.period||0}`);
 let id=original,prior=getLesson(id);
 if(prior&&prior._runtimeSourceKey!==key){
  const same=JSON.stringify(prior.screens)===JSON.stringify(x.screens)&&prior.title===x.title&&prior.subject===x.subject;
  if(!same)id=original+'~'+key.replace(/[^a-zA-Z0-9]/g,'').slice(-16);
 }
 x._runtimeSourceKey=key;
 let lib=getLibrary();
 x.id=id;let k=lib.findIndex(v=>v.id===id),meta={id,subject:x.subject||'',week:x.week??'',period:x.period??'',title:x.title||'Bài chưa đặt tên',savedAt:new Date().toISOString()};
 if(k>=0)lib[k]=meta;else lib.unshift(meta);
 localStorage.setItem('lesson:'+id,JSON.stringify(x));localStorage.setItem('webLiveLibrary',JSON.stringify(lib));return id;
}
function deleteLesson(id){localStorage.removeItem('lesson:'+id);localStorage.setItem('webLiveLibrary',JSON.stringify(getLibrary().filter(x=>x.id!==id)))}
function validateLesson(x){if(!x||!Array.isArray(x.screens)||!x.screens.length)throw Error('lesson.json thiếu screens[] hoặc không có màn hình');return x}
async function importZip(file){
 const bytes=new Uint8Array(await file.arrayBuffer()),sourceKey='zip:'+fingerprint(bytes);
 let z=await unzipFile(bytes),keys=Object.keys(z).filter(k=>k==='lesson.json'||k.endsWith('/lesson.json'));
 if(keys.length!==1)throw Error(keys.length?'ZIP có nhiều lesson.json':'Gói LIVE thiếu lesson.json');
 let lk=keys[0],x;try{x=validateLesson(JSON.parse(txt(z[lk])))}catch(e){throw Error('lesson.json không hợp lệ: '+e.message)}
 let base=lk.slice(0,-'lesson.json'.length),missing=[];
 if(z[base+'manifest.json'])try{JSON.parse(txt(z[base+'manifest.json']))}catch(e){throw Error('manifest.json không hợp lệ: '+e.message)}
 for(let s of x.screens)for(const [field,dataField] of [['image','imageData'],['geometryImage','geometryImageData'],['analysisImage','analysisImageData'],['analysisDiagram','analysisDiagramData']]){
  const source=assetPath(s[field]);
  if(!source||s[dataField]||source.startsWith('data:image/')||s[field]?.imageData||s[field]?.data)continue;
  let path=source.replace(/^\.\//,'');
  if(path.startsWith('/')||path.split('/').includes('..')){missing.push(source);continue}
  let key=z[base+path]?base+path:path,bytes=z[key];
  if(!bytes){missing.push(source);continue}
  let ext=key.split('.').pop().toLowerCase(),mime=({svg:'image/svg+xml',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png'})[ext];
  if(!mime){missing.push(source+' (định dạng không hỗ trợ)');continue}
  let bin='';for(let j=0;j<bytes.length;j+=8192)bin+=String.fromCharCode(...bytes.slice(j,j+8192));
  s[dataField]=`data:${mime};base64,${btoa(bin)}`;
 }
 if(missing.length)throw Error('Thiếu/không đọc được ảnh: '+[...new Set(missing)].join(', '));
 saveLesson(x,sourceKey);return x;
}
