class SmartGeometryTeacher{
 constructor(){
  this.open=false;this.tool='select';this.models=new Map();this.selectedId=null;this.message='';
  this.targets=[];this.anchors=[];this.angles=[];
  this.overlay=document.getElementById('smartLayer');
  this.overlay.addEventListener('pointerdown',e=>this.pointerDown(e));
  document.getElementById('smartControls').addEventListener('click',e=>{
   const button=e.target.closest('button');if(button?.dataset.smartTool)this.selectTool(button.dataset.smartTool);
  });
  document.addEventListener('keydown',e=>{
   if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)||!this.open)return;
   if(e.key==='Escape'&&this.hasPending()){
    this.cancelPending();e.preventDefault();e.stopImmediatePropagation();return;
   }
   const k=e.key.toLowerCase();
   if((e.ctrlKey||e.metaKey)&&k==='z'){this.undo();e.preventDefault();e.stopImmediatePropagation()}
   else if((e.ctrlKey||e.metaKey)&&k==='y'){this.redo();e.preventDefault();e.stopImmediatePropagation()}
  },true);
  window.addEventListener('resize',()=>this.render());
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.render()).observe(document.getElementById('figureInner'));
  this.render();
 }
 key(){return lesson?SmartGeometry.scope(lesson,i):''}
 model(scene=this.key()){
  if(!lesson||!scene)return null;
  const key=SmartGeometry.storageKey(currentLessonId,scene);
  if(!this.models.has(key))this.models.set(key,new SmartGeometry.Model(currentLessonId,scene));
  return this.models.get(key);
 }
 boardObjects(){
  if(!lesson||!currentImage())return[];
  const scope=boardController.overlayKey(),objects=boardController.model(scope)?.objects||[],drag=boardController.dragging;
  return drag?.pointId&&drag.scope===scope?DrawBoard.previewPoint(objects,drag.pointId,drag.x,drag.y):objects;
 }
 summary(){if(!lesson)return null;const scene=this.key();return{scope:scene,revision:this.model(scene)?.revision||0}}
 editing(){return this.open&&!!currentImage()}
 hasPending(){return !!(this.targets.length||this.anchors.length||this.angles.length)}
 lessonChanged(){this.cancelPending();this.models.clear();this.selectedId=null;this.open=false;this.render()}
 screenChanged(){this.cancelPending();this.selectedId=null;if(!currentImage())this.open=false;this.render()}
 toggle(){
  if(!lesson||!currentImage())return;
  if(this.open){this.close();return}
  boardController?.close();coverController?.close();this.open=true;
  if(viewMode==='text')viewMode='split';render();sync();
 }
 close(){if(!this.open)return;this.cancelPending();this.open=false;this.selectedId=null;this.render();sync()}
 selectTool(tool){
  if(!['select','erase','parallel','perpendicular','equalSegment','angle','equalAngle','midpoint'].includes(tool))return;
  this.cancelPending();this.selectedId=null;this.tool=tool;this.message='';this.render();
 }
 cancelPending(){
  this.targets=[];this.anchors=[];this.angles=[];this.message='';this.render();
 }
 status(){
  if(this.message)return this.message;
  if(this.tool==='select')return this.selectedId?'Đã chọn ký hiệu. Bấm ⌫ XÓA để bỏ.':'Click một ký hiệu để chọn';
  if(this.tool==='erase')return 'Click ký hiệu để xóa';
  if(this.tool==='angle')return `Chọn A – O – B (${this.anchors.length}/3 điểm)`;
  if(this.tool==='equalAngle')return `Chọn góc 1 rồi góc 2 (${this.angles.length} góc, ${this.anchors.length}/3 điểm)`;
  if(this.tool==='equalSegment')return `Chọn đoạn thứ ${this.targets.length+1}; từ 2 đoạn bấm ✓ GHI NHÓM`;
  if(this.tool==='midpoint')return this.anchors.length?'Chọn đầu đoạn thứ hai':'Click đoạn hoặc chọn hai đầu';
  return `Chọn hai đường/đoạn, hoặc bốn điểm (${this.targets.length}/2 đường, ${this.anchors.length}/2 điểm)`;
 }
 updateControls(){
  const box=document.getElementById('smartControls');box.hidden=!this.open;
  const openBtn=document.getElementById('smartOpenBtn');openBtn.disabled=!currentImage();openBtn.classList.toggle('active',this.open);
  box.querySelectorAll('[data-smart-tool]').forEach(b=>b.classList.toggle('active',b.dataset.smartTool===this.tool));
  const m=this.model();document.getElementById('smartUndo').disabled=!m?.undoStack.length;
  document.getElementById('smartRedo').disabled=!m?.redoStack.length;
  document.getElementById('smartFinish').disabled=this.tool!=='equalSegment'||this.targets.length<2;
  document.getElementById('smartDelete').disabled=!this.selectedId;
  document.getElementById('smartStatus').textContent=this.status();
 }
 render(){
  this.overlay.style.pointerEvents=this.editing()?'auto':'none';
  SmartGeometry.render(this.overlay,lesson&&currentImage()?this.model()?.objects||[]:[],this.boardObjects(),
   {editable:this.editing(),selectedId:this.selectedId,pendingAnchors:this.anchors,pendingLines:this.targets});
  this.updateControls();
 }
 publish(){
  this.render();const m=this.model(),event={type:'smartGeometry',lessonId:currentLessonId,scope:this.key(),revision:m.revision};
  send(event);try{if(tvWindow&&!tvWindow.closed)tvWindow.postMessage(event,'*')}catch(_){}sync();
 }
 changed(result){if(result)this.publish();else this.render()}
 undo(){this.cancelPending();this.selectedId=null;this.changed(this.model()?.undo())}
 redo(){this.cancelPending();this.selectedId=null;this.changed(this.model()?.redo())}
 deleteSelected(){
  if(!this.selectedId)return;
  const id=this.selectedId;this.selectedId=null;this.changed(this.model()?.remove(id));
 }
 fail(message){this.targets=[];this.anchors=[];this.angles=[];this.message=message;this.render()}
 linePicked(ref){
  if(!ref)return;
  if(this.targets.some(t=>JSON.stringify(t)===JSON.stringify(ref))){this.message='Đường này đã được chọn';this.render();return}
  this.message='';this.targets.push(ref);
  if(this.tool==='midpoint'){
   const answer=prompt('Nhãn trung điểm (để trống nếu không cần)','M');
   const label=answer==null?'':String(answer).trim().slice(0,8);
   this.targets=[];this.changed(this.model().add({type:'midpointMark',source:ref,label}));return;
  }
  if(this.tool==='parallel'||this.tool==='perpendicular'){
   if(this.targets.length===2)this.finishPair();else this.render();
  }else this.render();
 }
 finishPair(){
  const {w,h}=SmartGeometry.size(this.overlay),board=this.boardObjects(),lines=this.targets;
  if(this.tool==='perpendicular'){
   if(!SmartGeometry.perpendicular(lines,board,w,h))return this.fail('Không xác định được giao điểm vuông góc trong hình');
   this.targets=[];this.changed(this.model().add({type:'perpendicularMark',lines}));return;
  }
  const a=SmartGeometry.resolveLine(lines[0],board,w,h),b=SmartGeometry.resolveLine(lines[1],board,w,h);
  if(!a||!b)return this.fail('Hãy chọn hai đường hợp lệ');
  const ax=(a.b.x-a.a.x)*w,ay=(a.b.y-a.a.y)*h,bx=(b.b.x-b.a.x)*w,by=(b.b.y-b.a.y)*h;
  if(Math.abs((ax*by-ay*bx)/(Math.hypot(ax,ay)*Math.hypot(bx,by)))>.22)return this.fail('Hai hướng chưa song song; hãy chọn lại');
  const styleIndex=SmartGeometry.nextStyle(this.model().objects,'parallelMark',2);
  this.targets=[];this.changed(this.model().add({type:'parallelMark',lines,styleIndex}));
 }
 finishGroup(){
  if(this.tool!=='equalSegment'||this.targets.length<2)return;
  const targets=this.targets,styleIndex=SmartGeometry.nextStyle(this.model().objects,'equalSegmentMark',3);
  this.targets=[];this.changed(this.model().add({type:'equalSegmentMark',targets,styleIndex}));
 }
 anglePicked(angle){
  this.message='';
  if(this.tool==='angle'){
   this.anchors=[];this.changed(this.model().add({type:'angleMark',angle,styleIndex:1}));return;
  }
  this.angles.push(angle);this.anchors=[];
  if(this.angles.length===2){
   const angles=this.angles,styleIndex=SmartGeometry.nextStyle(this.model().objects,'equalAngleMark',2);
   this.angles=[];this.changed(this.model().add({type:'equalAngleMark',angles,styleIndex}));
  }else this.render();
 }
 validAngle(angle){
  const points=new Map(this.boardObjects().filter(o=>o.type==='point').map(o=>[o.id,o]));
  const a=SmartGeometry.resolveAnchor(angle.p1,points),v=SmartGeometry.resolveAnchor(angle.vertex,points),b=SmartGeometry.resolveAnchor(angle.p2,points),{w,h}=SmartGeometry.size(this.overlay);
  const x1=(a.x-v.x)*w,y1=(a.y-v.y)*h,x2=(b.x-v.x)*w,y2=(b.y-v.y)*h;
  return Math.hypot(x1,y1)>=8&&Math.hypot(x2,y2)>=8&&Math.abs(x1*y2-y1*x2)/(Math.hypot(x1,y1)*Math.hypot(x2,y2))>.05;
 }
 pointerDown(e){
  if(!this.editing())return;
  e.stopPropagation();e.preventDefault();
  const p=SmartGeometry.at(this.overlay,e),id=e.target.closest('[data-smart-id]')?.getAttribute('data-smart-id');
  if(e.shiftKey){pointer={x:p.x,y:p.y};renderPointer();sync();return}
  if(this.tool==='select'){
   this.selectedId=this.model().objects.some(o=>o.id===id)?id:null;this.message='';this.render();return;
  }
  if(this.tool==='erase'){
   if(id){this.selectedId=null;this.changed(this.model().remove(id))}return;
  }
  if(this.tool==='equalAngle'&&id){
   const old=this.model().objects.find(o=>o.id===id&&o.type==='angleMark');
   if(old){this.anglePicked(old.angle);return}
  }
  const board=this.boardObjects();
  if(['parallel','perpendicular','equalSegment','midpoint'].includes(this.tool)){
   const line=!this.anchors.length&&SmartGeometry.hitLine(board,p,this.overlay);
   if(line){this.linePicked(line);return}
  }
  const a=SmartGeometry.anchor(p,board,this.overlay);this.message='';this.anchors.push(a);
  if(this.tool==='angle'||this.tool==='equalAngle'){
   if(this.anchors.length===3){
    const angle={p1:this.anchors[0],vertex:this.anchors[1],p2:this.anchors[2]};
    if(!this.validAngle(angle))return this.fail('Ba điểm chưa tạo thành góc rõ ràng');
    this.anglePicked(angle);
   }else this.render();
   return;
  }
  if(this.anchors.length===2){
   const {w,h}=SmartGeometry.size(this.overlay),[one,two]=this.anchors;
   if(Math.hypot((one.x-two.x)*w,(one.y-two.y)*h)<5)return this.fail('Hai điểm quá gần nhau');
   this.anchors=[];this.linePicked({kind:'anchors',a:one,b:two});
  }else this.render();
 }
 snapshot(scene,source){
  if(!lesson||!scene||scene!==this.key())return;
  const message={type:'smartSnapshot',lessonId:currentLessonId,scope:scene,record:this.model(scene).record()};
  if(source?.postMessage)source.postMessage(message,'*');else send(message);
 }
}
