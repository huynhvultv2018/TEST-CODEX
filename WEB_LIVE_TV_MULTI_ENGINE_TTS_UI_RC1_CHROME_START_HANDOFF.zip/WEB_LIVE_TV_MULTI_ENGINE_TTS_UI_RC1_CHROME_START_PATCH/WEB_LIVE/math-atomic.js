/* Typography only. Keep the normalized source string unchanged; wrap short math relations as DOM text. */
const MATH_OPERATORS='[=<>≥≤≠≈∥⊥⟂≅∼⇔⇒]';
const MATH_CHAIN_OPERATORS='[=<>≥≤≠≈∥⊥⟂≅∼]';
const MATH_OPERAND='(?:[△∠][A-Z][A-Z0-9]{0,5}|[A-Z][A-Z0-9]{0,5}|[0-9]+(?:[.,][0-9]+)?|[a-z])';
const MATH_PAIR=new RegExp(`(^|[^A-Za-z0-9△∠])((?:[⇒⇔][ \\t]+)?${MATH_OPERAND}[ \\t]*${MATH_OPERATORS}[ \\t]*${MATH_OPERAND})(?=$|[^A-Za-z0-9])`,'gmu');
const MATH_CHAIN_BEFORE=new RegExp(`${MATH_CHAIN_OPERATORS}[ \\t]*$`,'u');
const MATH_CHAIN_AFTER=new RegExp(`^[ \\t]*${MATH_CHAIN_OPERATORS}`,'u');
function mathAtomicRanges(value){
 const source=String(value??''),ranges=[];MATH_PAIR.lastIndex=0;
 for(const match of source.matchAll(MATH_PAIR)){
  const start=match.index+match[1].length,end=start+match[2].length;
  if(match[2].length>26||MATH_CHAIN_BEFORE.test(source.slice(Math.max(0,start-30),start))||MATH_CHAIN_AFTER.test(source.slice(end,end+30)))continue;
  ranges.push({start,end,text:match[2]});
 }
 return ranges;
}
function renderMathAtomic(node,value){
 const source=String(value??'');node.textContent=source;
 if(typeof document==='undefined'||typeof document.createElement!=='function'||typeof document.createTextNode!=='function'||typeof node.replaceChildren!=='function')return;
 const ranges=mathAtomicRanges(source);if(!ranges.length)return;
 const pieces=[];let offset=0;
 for(const range of ranges){
  pieces.push(document.createTextNode(source.slice(offset,range.start)));
  const span=document.createElement('span');span.className='math-atomic';span.textContent=range.text;pieces.push(span);
  offset=range.end;
 }
 pieces.push(document.createTextNode(source.slice(offset)));
 node.replaceChildren(...pieces);
}
