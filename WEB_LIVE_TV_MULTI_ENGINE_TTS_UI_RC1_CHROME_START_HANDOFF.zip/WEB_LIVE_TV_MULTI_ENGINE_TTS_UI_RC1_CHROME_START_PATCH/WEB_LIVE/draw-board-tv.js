class DrawBoardTV{
 constructor(){
  this.overlay=document.getElementById('drawOverlay');this.white=document.getElementById('drawWhite');
  this.whitePane=document.getElementById('whiteBoardPane');this.state=null;this.preview=null;
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.fit()).observe(document.getElementById('figureInner'));
  window.addEventListener('resize',()=>this.fit());
 }
 apply(d,hasGeometry){
  if(this.state?.lessonId!==d.lessonId||this.overlayScope!==d.board?.overlayScope||this.whiteScope!==d.board?.whiteScope)this.preview=null;
  this.state=d;const board=d.board||{},white=board.open&&board.mode==='whiteboard';
  this.whitePane.hidden=!white;document.getElementById('screen').hidden=white;
  this.overlayScope=board.overlayScope;this.whiteScope=board.whiteScope;
  this.overlayVersion=board.overlayVersion||0;this.whiteVersion=board.whiteVersion||0;
  this.hasGeometry=hasGeometry;
  this.fit();
 }
 board(scope,expected){
  if(!scope||!this.state)return[];
  const b=DrawBoard.read(this.state.lessonId,scope);
  if(b.revision<expected){
   const ask={type:'needDrawBoard',lessonId:this.state.lessonId,scope};
   send(ask);try{window.opener?.postMessage(ask,'*')}catch(_){}
  }
  return b.objects;
 }
 fit(){
  if(!this.state)return;
  const draw=(svg,scope,expected)=>{
   let objects=this.board(scope,expected);
   if(this.preview?.scope===scope){
    if(DrawBoard.read(this.state.lessonId,scope).revision===this.preview.baseRevision)
     objects=this.preview.labelId?
      DrawBoard.previewLabel(objects,this.preview.labelId,this.preview.dx,this.preview.dy):
      DrawBoard.previewPoint(objects,this.preview.pointId,this.preview.x,this.preview.y);
    else this.preview=null;
   }
   DrawBoard.render(svg,objects);
  };
  if(this.hasGeometry)draw(this.overlay,this.overlayScope,this.overlayVersion);
  else DrawBoard.render(this.overlay,[]);
  if(!this.whitePane.hidden)draw(this.white,this.whiteScope,this.whiteVersion);
 }
 transient(event){
  if(!this.state||event.lessonId!==this.state.lessonId||![this.overlayScope,this.whiteScope].includes(event.scope))return;
  if(DrawBoard.read(event.lessonId,event.scope).revision!==event.baseRevision)return;
  this.preview=event;this.fit();
 }
 endTransient(event){
  if(this.preview?.scope===event.scope&&this.state?.lessonId===event.lessonId){this.preview=null;this.fit()}
 }
 refresh(event){
  if(!this.state||event.lessonId!==this.state.lessonId)return;
  if(event.scope!==this.overlayScope&&event.scope!==this.whiteScope)return;
  if(event.scope===this.overlayScope)this.overlayVersion=Math.max(this.overlayVersion,event.revision||0);
  if(event.scope===this.whiteScope)this.whiteVersion=Math.max(this.whiteVersion,event.revision||0);
  if(this.preview?.scope===event.scope&&event.revision>this.preview.baseRevision)this.preview=null;
  this.fit();
 }
 snapshot(event){
  if(!this.state||event.lessonId!==this.state.lessonId||![this.overlayScope,this.whiteScope].includes(event.scope))return;
  if(!event.record||!Array.isArray(event.record.objects))return;
  DrawBoard.write(event.lessonId,event.scope,event.record);this.refresh({lessonId:event.lessonId,scope:event.scope,revision:event.record.revision});
 }
 storage(event){
  if(!this.state)return;
  const prefix=DrawBoard.storageKey(this.state.lessonId,'');
  if(event.key?.startsWith(prefix))this.fit();
 }
}
