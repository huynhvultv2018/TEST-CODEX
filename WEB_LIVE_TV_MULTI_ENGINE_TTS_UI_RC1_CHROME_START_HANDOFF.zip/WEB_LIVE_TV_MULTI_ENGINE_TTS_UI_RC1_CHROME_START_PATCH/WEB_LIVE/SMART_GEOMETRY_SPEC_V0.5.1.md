# Smart Geometry Marks — WEB LIVE V0.5.1 CANDIDATE

## Layer và nguồn dữ liệu

Thứ tự trên cùng `figureInner`: geometry image → cover SVG → smart SVG → Draw Board SVG → pointer. Smart marks chỉ là runtime objects, lưu localStorage theo cùng ranh giới Geometry Scene của Draw Board; không sửa ảnh, ZIP bài học hoặc `lesson.json`. Không đọc nội dung pixel ảnh để nhận dạng nét.

`smartGeometry:<lessonId>:<smartScope>` lưu `{version:1,revision,objects}`. `smartScope` lấy từ `DrawBoard.overlayScope` và đổi tiền tố sang `smart:`. Model có history riêng tối đa 80 action, mọi thao tác tạo/xóa có Undo/Redo. TV chỉ nhận scope/revision và đọc object JSON; nếu storage không chia sẻ, dùng `needSmartGeometry`/`smartSnapshot`. Không gửi base64 ảnh theo thao tác.

## Tham chiếu hình học

`lineRef` có một trong hai dạng: `{kind:'boardLine',id,fallback:{kind,a,b}}` hoặc `{kind:'anchors',a,b}`. Mỗi anchor là `{x,y,pointId?}` với tọa độ normalized 0..1; khi có point ID thì renderer đọc tọa độ point hiện tại, nếu point bị xóa sẽ dùng tọa độ fallback. Board line dùng endpoint của segment/line và cập nhật theo point tham chiếu. `midpointMark` tính lại tâm từ source mỗi lần render, kể cả preview kéo point trước mouseup; source tĩnh trên ảnh giữ nguyên.

| Object | Nội dung | Cách render |
| --- | --- | --- |
| `parallelMark` | `lines:[lineRef,lineRef],styleIndex` | 1 hoặc 2 vạch xiên gần trung điểm mỗi đường |
| `perpendicularMark` | `lines:[lineRef,lineRef]` | Ô vuông tại giao điểm; text ⊥ nhỏ khi cạnh quá ngắn |
| `equalSegmentMark` | `targets:[lineRef,...],styleIndex` | 1, 2 hoặc 3 vạch cắt trên từng cạnh |
| `angleMark` | `angle:{p1,vertex,p2},styleIndex` | Cung góc nhỏ tại vertex |
| `equalAngleMark` | `angles:[angle,angle],styleIndex` | Hai góc cùng 1 hoặc 2 cung |
| `midpointMark` | `source:lineRef,label` | Chấm midpoint và nhãn tùy chọn |

Style index tự tăng theo nhóm trong scene, song song/góc bằng luân phiên 1–2, cạnh bằng luân phiên 1–3. Đây là ký hiệu GV chủ động đặt, không phải phép chứng minh tự động.

## Tương tác

Tool line chọn hai segment/line Draw Board bằng click gần nét hoặc bốn click xác định hai hướng trên ảnh. `= CẠNH BẰNG` nhận hai hoặc nhiều cạnh rồi bấm `✓ GHI NHÓM CẠNH`. `∠ GÓC` nhận A–O–B; `∠= GÓC BẰNG` nhận hai bộ ba điểm hoặc chọn một góc đã lưu. Midpoint nhận một segment hoặc hai đầu đoạn và có prompt nhãn.

Điểm được snap nhẹ trong phạm vi 16 px screen; giao điểm của các segment/line Draw Board cũng có thể snap khi đủ gần. Không snap pixel từ PNG/JPG. Góc vuông chỉ tạo khi hai hướng gần 90° và giao điểm thuộc viewport cùng phạm vi hai segment hữu hạn (dung sai tối đa 8 px ngoài đầu đoạn do click thủ công trên raster); nếu không đạt thì báo GV và không lưu mark. Cung góc không tạo từ ba điểm quá gần hay thẳng hàng.

`✥ CHỌN` làm nổi mark trên preview GV, `⌫ XÓA` hoặc `⌫ XÓA ĐÃ CHỌN` xóa đúng mark. TV không hiện selection, handles, helper clicks hay toolbar. Esc hủy lựa chọn dở trước khi xóa pointer. Khi chuyển sang Draw Board hoặc Cover, editor smart đóng nhưng marks vẫn hiện. Không yêu cầu kéo riêng mark trong bản này.

## Tọa độ và hiển thị

Tọa độ đối tượng normalized; click đổi bằng inverse SVG screen CTM để chịu zoom 70–200%, pan, fullscreen và resize. Renderer dựng vector SVG theo kích thước figure hiện tại. Draw Board point drag làm smart mark dùng preview point trong bộ nhớ trên GV và TV mà không ghi smart history mỗi mousemove. Khi thả, board revision cập nhật các marks liên quan.

Không đo độ dài/góc, không constraint solver, không tự nhận dạng hình hoặc suy luận định lý. Cần runtime test laptop/TV thật và offline trước Production.
