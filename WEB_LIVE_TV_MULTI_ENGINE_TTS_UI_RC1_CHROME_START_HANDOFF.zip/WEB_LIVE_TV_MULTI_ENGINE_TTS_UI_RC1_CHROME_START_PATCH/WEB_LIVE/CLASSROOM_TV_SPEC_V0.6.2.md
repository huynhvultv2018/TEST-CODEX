# CLASSROOM TV SPEC V0.6.2 — Candidate

## Nền và mục đích

Xuất phát từ `WEB_LIVE_V0.6.1.1_TV_TYPOGRAPHY_HOTFIX.zip`. Chế độ mặc định là Classroom Readability, ưu tiên chữ và hình đọc được từ xa. Các thay đổi là trạng thái trình bày runtime; không sửa `lesson.json`, ảnh, LIVE.zip, `normalizeLiveText`, image resolver, Draw Board, Cover, Smart Geometry hoặc Math Atomic Inline.

## Bố cục và chữ

| Trạng thái | TV | Preview giáo viên |
|---|---|---|
| `60` (mặc định) | 60% hình / 40% chữ | Tỷ lệ tương ứng |
| `70` | 70% hình / 30% chữ | Tỷ lệ tương ứng |
| `full` | Hình gần toàn viewport, giữ mọi overlay | Hình gần toàn vùng Preview |

Double-click lên hình trên Preview hoặc cửa sổ TV đổi `60/70 → full → bố cục trước đó`. Công cụ Draw Board/Cover/Smart Geometry/Highlight hoặc thao tác đang dở khóa thao tác này. Nút PHÓNG CHỮ tăng cỡ chữ có giới hạn; với bố cục mặc định và chữ quá dày, TV ưu tiên nới vùng chữ, giảm khoảng cách rồi mới giảm font đến mức sàn. Preset 70/30 hoặc 60/40 giáo viên chọn được giữ đúng tỷ lệ, cho phép cuộn vùng chữ nếu cần thay vì cắt. Math Atomic vẫn bọc các quan hệ ngắn.

TV ở 1920×1080: content khoảng 52px, proof/reveal khoảng 47px, title khoảng 61px trước khi khớp chiều cao; line-height 1.38. Từ 2560px trở lên có thang font riêng, content tối đa 88px ở 4K. 1366×768 dùng font content khoảng 37px. Đây là giá trị CSS danh nghĩa; trình duyệt/TV thật phải được kiểm tra.

## Focus Line

`Classroom.parts` tách văn bản đã normalize theo xuống dòng và ranh giới câu rõ ràng; list item, paragraph, proof step, conclusion có thể chọn như một block. Các dấu `↓` của sơ đồ không tính là bước. Preview giáo viên click block khi TẬP TRUNG đang bật; TV nhận `{region,index}` trong `state.classroom.focus`. Cụm toán trong từng block vẫn dùng `renderMathAtomic`. Dòng focus giữ sáng, các dòng cùng vùng giảm opacity còn 0.52. Bấm XÓA TẬP TRUNG hoặc Esc (khi không có thao tác đang dở hoặc pointer) để xóa. Đổi màn/bài xóa focus; lesson data không đổi.

## Highlight tạm thời

Giáo viên chọn NHẤN ĐOẠN (2 click), NHẤN TAM GIÁC (3 click), NHẤN ĐIỂM (1 click) tại vị trí trên ảnh. `DrawBoard.at` đổi tọa độ chuột qua SVG CTM thành normalized `[0,1]`; không nhận dạng đối tượng tự động từ PNG/JPG. Mỗi object chỉ gồm `type` và mảng `points` normalized. Cùng Geometry Scene giữ nhiều highlight; đổi scene hoặc bài xóa. XÓA NHẤN MẠNH không ảnh hưởng lớp khác. Không lưu highlights trong lesson/Draw Board/Smart Geometry, không thêm vào undo stack.

Thứ tự hiển thị: geometry image → Cover (`z=1`) → Smart Geometry (`z=2`) → Draw Board (`z=3`) → Classroom Highlight (`z=4`) → Pointer (`z=5`). Highlight là SVG chung `figureInner`, co giãn/pan/zoom cùng ảnh; nét vẽ dùng `vector-effect: non-scaling-stroke`. Ảnh nguồn không đổi.

## TV và đồng hồ

`state.classroom` trong gói sync nhẹ chứa `layout`, `layoutPinned`, `fontBoost`, `focus`, `highlights`, `interactionLocked`, `clock`. TV render local. Không gửi lại base64 ảnh do thao tác focus/highlight. TV không có toolbar mới; icon toàn màn chỉ hiện gần mép khi di chuột và tự ẩn sau 2.5 giây. Số màn và thanh tiến trình ở đáy giữ nhỏ.

Đồng hồ tắt mặc định. Chế độ giờ hiện tại dùng thời gian local trên TV. Timer 45/90 phút dùng `elapsedMs`, `startedAt`, `running`; BẮT ĐẦU/TẠM DỪNG/ĐẶT LẠI nằm trên GV. Timer không reset khi đổi màn, đổi bài, resize/fullscreen. Trạng thái sync đủ để cửa sổ TV nạp lại và tiếp tục hiển thị, không phụ thuộc Internet.

## Kiểm thử/giới hạn

Các ca tự động bao gồm focus + Math Atomic, ba kiểu highlight, xóa, đồng bộ, đổi scene, CTM/resize qua tọa độ normalized, layout/double-click/khóa công cụ, timer và hồi quy các bản trước. Kiểm chứng thực tế tại 1366×768, 1600×900, 1920×1080, 2560×1440, 3840×2160 và các vị trí 3/5/7m trong lớp vẫn phải thực hiện trên laptop + TV thật trước khi xét Production.
