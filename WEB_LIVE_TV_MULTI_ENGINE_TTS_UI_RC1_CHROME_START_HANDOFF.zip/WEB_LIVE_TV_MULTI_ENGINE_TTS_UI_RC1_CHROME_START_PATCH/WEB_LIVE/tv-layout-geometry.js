/* GEOMETRY_ENGINE: figure DOM and overlay order remain owned by RC4. */
const TVGeometryEngine={render(screen,vm,ui){
 const content=ui.node('content');
 if(ui.node('activityBadge').hidden){
  const badge=/^chứng minh/iu.test(vm.title)?'CHỨNG MINH':/^chốt|kết luận/iu.test(vm.title)?'KẾT LUẬN':/^đọc hình/iu.test(vm.title)?'ĐỀ BÀI':'';
  if(badge){ui.node('activityBadge').textContent=badge;ui.node('activityBadge').hidden=false;}
 }
 if(vm.bodyBlocks.some(x=>/giả thiết|kết luận|cần chứng minh|cần có|mục tiêu|dữ kiện/iu.test(x.label))&&!content.hidden){ui.grouped(content,vm,vm.bodyBlocks,'tvGeometryStatement');content.classList.add('tvStatementGrid');}
 if(vm.activityType==='PROOF_DEPENDENCY_TREE'){
  // Build the dependency presentation from disclosed analysis only. No hidden labels enter DOM.
  const analysis=ui.node('analysis');analysis.classList.add('tvDependencyTree');
  analysis.querySelectorAll('.analysisStep').forEach(step=>{
   const source=step.textContent,branches=source.split(/\s+\+\s+/u);
   if(branches.length===2){const row=ui.element('div','tvDependencyBranches');branches.forEach((text,i)=>{if(i)row.appendChild(ui.element('span','tvDependencyPlus','+'));row.appendChild(ui.element('div','tvDependencyNode',text))});step.replaceChildren(row);}
  });
 }
}};
