/* Single speech owner: instantiated only in Teacher. TV never loads this module. */
(()=>{
 const SETTINGS_KEY='WEB_LIVE_TTS_SETTINGS_V1',OWNER_KEY='WEB_LIVE_TTS_OWNER_V1';
 const rates=Object.freeze([.75,.85,.95,1,1.1,1.2]);
 const gender=value=>['male','nam'].includes(String(value).toLowerCase())?'male':['female','nữ','nu'].includes(String(value).toLowerCase())?'female':'unknown';
 const voiceKey=v=>[v.voiceURI||v.name,v.lang].join('|');
 class TTSController{
  constructor(options={}){
   this.synth=options.synth??globalThis.speechSynthesis;this.makeUtterance=options.makeUtterance||((text)=>new globalThis.SpeechSynthesisUtterance(text));
   this.storage=options.storage;try{this.storage??=globalThis.localStorage}catch(_){}
   this.onState=options.onState||(()=>{});this.onHighlight=options.onHighlight||(()=>{});this.getContext=options.getContext||(()=>null);
   this.ownerId=options.ownerId||globalThis.crypto?.randomUUID?.()||'tts-'+Date.now()+'-'+Math.random();
   this.supported=!!this.synth&&typeof this.synth.speak==='function'&&typeof this.synth.cancel==='function';
   this.state='IDLE';this.message='';this.errorCode='';this.generation=0;this.activeBlock=null;this.queue=[];this.lastRequest=null;this.monitor=null;this.heartbeat=null;this.ownsSpeech=false;
   this.settings=this._load();this.voices=[];this.voice=null;
   this.voicesChanged=()=>this.refreshVoices();this.synth?.addEventListener?.('voiceschanged',this.voicesChanged);
   if(this.synth&&!this.synth.addEventListener)this.synth.onvoiceschanged=this.voicesChanged;
   this.ownerChanged=event=>{if(event.key===OWNER_KEY&&this.ownsSpeech){const lease=this._lease();if(lease?.owner!==this.ownerId)this.stop('Đã dừng: quyền đọc chuyển sang cửa sổ GV khác.')}};
   globalThis.addEventListener?.('storage',this.ownerChanged);this.refreshVoices();
  }
  _load(){
   let old={};try{old=JSON.parse(this.storage?.getItem(SETTINGS_KEY)||'{}')||{}}catch(_){}
   const map=Object.create(null);if(old.genderByVoice&&typeof old.genderByVoice==='object')for(const [key,value] of Object.entries(old.genderByVoice))if(gender(value)!=='unknown')map[key]=gender(value);
   return{voice:typeof old.voice==='string'?old.voice:'',preferredGender:['male','female','any'].includes(old.preferredGender)?old.preferredGender:'male',rate:rates.includes(Number(old.rate))?Number(old.rate):.95,highlight:typeof old.highlight==='boolean'?old.highlight:true,volume:Number.isFinite(old.volume)?Math.max(0,Math.min(1,old.volume)):1,genderByVoice:map};
  }
  _save(){try{this.storage?.setItem(SETTINGS_KEY,JSON.stringify(this.settings))}catch(_){}}
  voiceGender(v){return this.settings.genderByVoice[voiceKey(v)]||gender(v.gender)}
  refreshVoices(){
   try{this.voices=this.supported?Array.from(this.synth.getVoices?.()||[]).filter(v=>/^vi(?:-|$)/iu.test(v.lang||'')):[]}catch(_){this.voices=[]}
   this.voices.sort((a,b)=>Number(/^vi-vn$/iu.test(b.lang))-Number(/^vi-vn$/iu.test(a.lang))||Number(!!b.localService)-Number(!!a.localService));
   this.voice=this.voices.find(v=>voiceKey(v)===this.settings.voice)||this.voices.find(v=>this.settings.preferredGender!=='any'&&this.voiceGender(v)===this.settings.preferredGender)||this.voices[0]||null;
   if(!this.supported){this.state='ERROR';this.errorCode='UNSUPPORTED';this.message='Trình duyệt chưa hỗ trợ giọng đọc.'}
   else if(!this.voice){if(this.ownsSpeech)this.stop();this.state='ERROR';this.errorCode='NO_VOICE';this.message='Chưa có giọng tiếng Việt. Cài giọng Việt trên máy GV rồi mở lại trình duyệt.'}
   else if(['NO_VOICE','UNSUPPORTED'].includes(this.errorCode)){this.state='IDLE';this.errorCode='';this.message=''}
   this._emit();
  }
  configure(patch){
   const old=this.settings;
   const next={...old,...patch,genderByVoice:old.genderByVoice};
   if(!rates.includes(Number(next.rate)))next.rate=old.rate;else next.rate=Number(next.rate);
   if(!['male','female','any'].includes(next.preferredGender))next.preferredGender=old.preferredGender;
   if(typeof next.voice!=='string')next.voice=old.voice;
   next.highlight=!!next.highlight;next.volume=Number.isFinite(Number(next.volume))?Math.max(0,Math.min(1,Number(next.volume))):old.volume;
   if(this.ownsSpeech&&(next.voice!==old.voice||next.rate!==old.rate||next.volume!==old.volume))this.stop('Đã dừng để đổi cấu hình đọc.');
   this.settings=next;this._save();this.refreshVoices();this._highlight(this.activeBlock);
  }
  setVoiceGender(value){
   if(!this.voice)return;
   const key=voiceKey(this.voice),g=gender(value);if(g==='unknown')delete this.settings.genderByVoice[key];else this.settings.genderByVoice[key]=g;
   this._save();this.refreshVoices();
  }
  snapshot(){return{state:this.state,message:this.message,errorCode:this.errorCode,supported:this.supported,voice:this.voice,voices:this.voices,settings:this.settings,activeBlock:this.activeBlock,ownerId:this.ownerId}}
  _emit(){try{this.onState(this.snapshot())}catch(_){}}
  _highlight(block){try{this.onHighlight(this.settings.highlight?block:null,this.snapshot())}catch(_){}}
  _state(state,message=''){this.state=state;this.message=message;this._emit()}
  _lease(){try{return JSON.parse(this.storage?.getItem(OWNER_KEY)||'null')}catch(_){return null}}
  _claim(){
   this.claimFailure='OTHER_OWNER';const lease=this._lease();
   if(lease?.owner!==this.ownerId&&lease?.expiresAt>Date.now())return false;
   if(!this.storage){this.claimFailure='OWNER_STORAGE';return false}
   this.ownsSpeech=true;
   const renew=()=>{
    try{this.storage.setItem(OWNER_KEY,JSON.stringify({owner:this.ownerId,expiresAt:Date.now()+20000}))}catch(_){return false}
    this._emit();if(['SPEAKING','PAUSED'].includes(this.state))this._highlight(this.activeBlock);return true;
   };
   if(!renew()||this._lease()?.owner!==this.ownerId){this.ownsSpeech=false;this.claimFailure='OWNER_STORAGE';return false}
   this.heartbeat=setInterval(()=>{if(!renew())this._error('OWNER_STORAGE','Không giữ được quyền đọc. Kiểm tra quyền lưu trữ của trình duyệt.')},4000);return true;
  }
  _release(){clearInterval(this.heartbeat);clearInterval(this.monitor);this.heartbeat=null;this.monitor=null;try{if(this._lease()?.owner===this.ownerId)this.storage?.removeItem(OWNER_KEY)}catch(_){}this.ownsSpeech=false}
  stop(message='Đã dừng đọc.',forget=false){
   ++this.generation;this.queue=[];this.activeBlock=null;
   if(this.ownsSpeech)try{this.synth.cancel()}catch(_){}
   this._release();if(forget)this.lastRequest=null;this._state(!this.supported||!this.voice?'ERROR':'STOPPED',!this.supported?'Trình duyệt chưa hỗ trợ giọng đọc.':!this.voice?'Chưa có giọng tiếng Việt trên máy GV.':message);this._highlight(null);
  }
  _error(code,message){this.stop('',false);this.errorCode=code;this._state('ERROR',message)}
  read(blocks,context=null){
   this.stop('',false);
   if(!this.supported){this._error('UNSUPPORTED','Trình duyệt chưa hỗ trợ giọng đọc.');return false}
   this.refreshVoices();
   if(!this.voice){this._error('NO_VOICE','Chưa có giọng tiếng Việt trên máy GV.');return false}
   const selected=(Array.isArray(blocks)?blocks:[]).filter(b=>b&&typeof b.text==='string'&&b.text.trim());
   if(!selected.length){this._state('IDLE','Không có nội dung đang hiển thị để đọc.');return false}
   if(!this._claim()){this._error(this.claimFailure,this.claimFailure==='OTHER_OWNER'?'Giọng đọc đang ở cửa sổ GV khác. Dừng đọc tại cửa sổ đó trước.':'Không giữ được quyền đọc. Cho phép lưu trữ cục bộ trong trình duyệt.');return false}
   this.errorCode='';this.lastRequest={blocks:selected.map(b=>({...b})),context};
   this.queue=selected.flatMap(block=>{
    const text=globalThis.MathSpeechPreprocessor?.preprocess(block.text)||block.text;
    const chunks=[];let current='';
    for(const sentence of text.split(/(?<=[.!?;])\s+|\n+/u)){
     if(current&&(current.length+sentence.length>240)){chunks.push(current);current=''}
     if(sentence.length>400){if(current){chunks.push(current);current=''}let part='';for(const word of sentence.split(/\s+/u)){if(part.length+word.length>240){chunks.push(part);part=''}part+=(part?' ':'')+word}if(part)chunks.push(part)}
     else current+=(current?' ':'')+sentence;
    }
    if(current)chunks.push(current);
    return chunks.filter(Boolean).map(text=>({block,text}));
   });
   const token=++this.generation;
   try{this.synth.cancel()}catch(_){this._error('ENGINE_ERROR','Không khởi động được giọng đọc.');return false}
   this._next(token);return true;
  }
  _next(token){
   if(token!==this.generation)return;
   const item=this.queue.shift();
   if(!item){this.activeBlock=null;this._release();this._state('IDLE','Đã đọc xong.');this._highlight(null);return}
   this.activeBlock=item.block;this._highlight(null);this._state('STARTING','Đang chuẩn bị đọc…');
   let utterance;try{utterance=this.makeUtterance(item.text)}catch(_){this._error('ENGINE_ERROR','Không tạo được giọng đọc.');return}
   utterance.voice=this.voice;utterance.lang=this.voice.lang||'vi-VN';utterance.rate=this.settings.rate;utterance.volume=this.settings.volume;
   let started=false,finished=false,lastSignal=Date.now();
   const valid=()=>token===this.generation&&!finished;
   const finish=()=>{if(!valid())return;finished=true;clearInterval(this.monitor);this.monitor=null;this._next(token)};
   utterance.onstart=()=>{if(!valid())return;started=true;lastSignal=Date.now();this._state('SPEAKING');this._highlight(item.block)};
   utterance.onpause=()=>{if(valid()){lastSignal=Date.now();this._state('PAUSED');this._highlight(item.block)}};
   utterance.onresume=()=>{if(valid()){lastSignal=Date.now();this._state('SPEAKING');this._highlight(item.block)}};
   utterance.onend=finish;
   utterance.onerror=e=>{if(valid()){finished=true;this._error(e?.error||'ENGINE_ERROR','Giọng đọc bị gián đoạn. Có thể chọn giọng khác hoặc thử lại.')}};
   this.monitor=setInterval(()=>{
    if(!valid())return;
    try{
     if(!started&&Date.now()-lastSignal>5000){finished=true;this._error('START_TIMEOUT','Giọng đọc chưa phản hồi. Hãy thử lại hoặc chọn giọng Việt khác.')}
     else if(started&&this.synth.paused&&this.state==='SPEAKING')this._state('PAUSED');
     else if(started&&!this.synth.paused&&this.synth.speaking&&this.state==='PAUSED')this._state('SPEAKING');
     else if(started&&!this.synth.speaking&&!this.synth.pending&&!this.synth.paused&&Date.now()-lastSignal>700)finish();
    }catch(_){this._error('ENGINE_ERROR','Không kiểm tra được trạng thái giọng đọc.')}
   },250);
   try{this.synth.speak(utterance)}catch(_){finished=true;this._error('ENGINE_ERROR','Không phát được giọng đọc.')}
  }
  pause(){if(this.state!=='SPEAKING')return;try{this.synth.pause();if(this.synth.paused)this._state('PAUSED')}catch(_){this._error('PAUSE_ERROR','Giọng này chưa tạm dừng được.')}}
  resume(){if(this.state!=='PAUSED')return;try{this.synth.resume();if(!this.synth.paused&&this.synth.speaking)this._state('SPEAKING')}catch(_){this._error('RESUME_ERROR','Giọng này chưa tiếp tục được.')}}
  replay(){
   const previous=this.lastRequest,current=this.getContext();
   if(!previous||JSON.stringify(previous.context)!==JSON.stringify(current)){this.stop('Nội dung đã đổi. Chọn phần hiện tại để đọc.',true);return false}
   return this.read(previous.blocks,previous.context);
  }
  destroy(){this.stop('',true);this.synth?.removeEventListener?.('voiceschanged',this.voicesChanged);globalThis.removeEventListener?.('storage',this.ownerChanged)}
 }
 TTSController.rates=rates;TTSController.voiceKey=voiceKey;
 globalThis.TTSController=TTSController;if(typeof module!=='undefined'&&module.exports)module.exports=TTSController;
})();
