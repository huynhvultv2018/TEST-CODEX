/* ALGEBRA_ENGINE: source expressions and visible runtime steps only. */
const TVAlgebraEngine=(()=>{
 function kind(vm){
  const explicit=vm.activityType;
  const supported=['EXPRESSION','EQUATION','SYSTEM','FACTORIZATION','IDENTITY','WORD_PROBLEM','TABLE','GRAPH','STATISTICS','PROBABILITY','PROOF','EXERCISE'];
  if(supported.includes(explicit))return explicit;
  const text=vm.title+'\n'+vm.source;
  if(vm.bodyBlocks.some(x=>/đặt ẩn|điều kiện/iu.test(x.label)))return 'WORD_PROBLEM';
  if(/hệ phương trình/iu.test(text))return 'SYSTEM';
  if(/phương trình/iu.test(text))return 'EQUATION';
  if(/hằng đẳng thức|đẳng thức/iu.test(text))return 'IDENTITY';
  if(/nhân tử/iu.test(text))return 'FACTORIZATION';
  if(/\|.*\|\n\s*\|?\s*:?-{3}/u.test(vm.source)||vm.source.split('\n').filter(x=>x.includes('\t')).length>=2)return 'TABLE';
  if(/đồ thị/iu.test(text)&&vm.resolvedImage)return 'GRAPH';
  return vm.mathBlocks.length?'EXPRESSION':'EXERCISE';
 }
 function table(source){
  const lines=source.split('\n'),rows=[];let start=-1,end=-1;
  for(let i=0;i<lines.length;i++){
   if(lines[i].includes('\t')||/^\s*\|.*\|\s*$/u.test(lines[i])){if(start<0)start=i;end=i;rows.push(lines[i]);}
   else if(start>=0)break;
  }
  if(rows.length<2)return null;
  const cells=rows.filter(x=>!/^\s*\|?[\s:|\-]+\|?\s*$/u.test(x)).map(x=>x.includes('\t')?x.split('\t'):x.trim().replace(/^\||\|$/g,'').split('|').map(v=>v.trim()));
  if(cells.length<2||cells.some(x=>x.length!==cells[0].length))return null;
  return {cells,before:lines.slice(0,start).join('\n'),after:lines.slice(end+1).join('\n')};
 }
 function render(screen,vm,ui){
  const mode=kind(vm),content=ui.node('content');screen.dataset.algebraKind=mode;content.classList.add('tvMathContent');
  if(!content.hidden){
   if(mode==='WORD_PROBLEM'&&vm.bodyBlocks.length){ui.grouped(content,vm,vm.bodyBlocks,'tvWordProblemGrid');content.classList.add('tvWordGrid');}
   else if(['TABLE','STATISTICS','PROBABILITY'].includes(mode)){
    const parsed=table(vm.source);
    if(parsed){const t=ui.element('table','tvDataTable');parsed.cells.forEach((row,i)=>{const tr=document.createElement('tr');row.forEach(value=>tr.appendChild(ui.element(i===0?'th':'td','',value)));t.appendChild(tr)});content.replaceChildren(ui.block(parsed.before,vm),t,ui.block(parsed.after,vm));}
   }else if(mode==='SYSTEM'){
    const lines=vm.source.split('\n'),equations=lines.filter(x=>/[=]/u.test(x));
    // Only group an unambiguous adjacent two-equation source block.
    if(equations.length===2&&lines.indexOf(equations[1])===lines.indexOf(equations[0])+1){
     const at=lines.indexOf(equations[0]);content.replaceChildren(ui.block(lines.slice(0,at).join('\n'),vm),ui.block(equations.join('\n'),vm,'tvSystemBlock'),ui.block(lines.slice(at+2).join('\n'),vm));
    }
   }else{
    const pieces=ui.sections(vm.source,/(?:^|\n)\s*(Bước\s+\d+)\s*[:.)-]?\s*/giu);
    if(pieces.length)ui.grouped(content,vm,pieces,'tvSourceSteps');
    else content.querySelectorAll('.focusBlock').forEach(n=>{if(/[=²³^]/u.test(n.textContent)&&n.textContent.length<160)n.classList.add('tvExpressionBlock')});
   }
  }
  if(['EQUATION','SYSTEM','IDENTITY','FACTORIZATION','EXPRESSION','PROOF'].includes(mode)){
   const answer=ui.node('answer');
   if(vm.state.answerMode==='full'&&vm.proofSteps.length&&typeof renderStepCards==='function')renderStepCards(answer,vm.proofSteps,answer.textContent,'proof',vm.state.classroom?.focus);
   ui.node('answer').classList.add('tvTransformation');ui.node('analysis').classList.add('tvTransformation');
  }
 }
 return {kind,table,render};
})();
