/* Presentation-only model. Never mutates lessons or computes answers. */
function resolveSubjectLayout(screen={},lesson={}){
 const modes=['COMPUTER_SCIENCE','ALGEBRA','GEOMETRY','GENERIC'];
 for(const value of [screen.subjectMode,screen.layoutEngine,screen.presentation?.subjectMode,lesson.subjectMode,lesson.layoutEngine]){
  if(typeof value==='string'&&modes.includes(value.toUpperCase()))return value.toUpperCase();
 }
 const classify=value=>{
  const text=String(value||'').normalize('NFC');
  if(/tin học|computer science|informatics/iu.test(text))return 'COMPUTER_SCIENCE';
  if(/hình học|geometry/iu.test(text))return 'GEOMETRY';
  if(/đại số|algebra|thống kê|xác suất/iu.test(text))return 'ALGEBRA';
  return null;
 };
 for(const value of [screen.subject,lesson.subject,screen.section,lesson.section,lesson.title,screen.title]){
  const mode=classify(value);if(mode)return mode;
 }
 if(screen.geometryImage||screen.geometryImageData||screen.visualRole==='geometry')return 'GEOMETRY';
 const type=String(screen.layoutType||screen.type||'').toUpperCase();
 if(['PROOF_DEPENDENCY_TREE','GEOMETRY_PROOF','GEOMETRY_ANALYSIS'].includes(type))return 'GEOMETRY';
 if(['EXPRESSION','EQUATION','SYSTEM','FACTORIZATION','IDENTITY','WORD_PROBLEM','STATISTICS','PROBABILITY'].includes(type))return 'ALGEBRA';
 if(/(?:rút gọn|giải phương trình|phân tích.*nhân tử|chứng minh đẳng thức)/iu.test(screen.title||'')&&/[=+−²^]/u.test(screen.content||''))return 'ALGEBRA';
 return 'GENERIC';
}
const TVMultiEngine=(()=>{
 const node=id=>document.getElementById(id);
 function options(source){
  const matches=[...source.matchAll(/(?:^|\n|\s)([A-E])[.)]\s+/gu)];
  if(matches.length<2||matches.length>5||matches.some((m,i)=>m[1]!==String.fromCharCode(65+i)))return null;
  const items=matches.map((m,i)=>({label:m[1],text:source.slice(m.index+(m[0].match(/^\s/u)?.[0].length||0),matches[i+1]?.index??source.length).trim()}));
  if(items.some(x=>x.text.length<4))return null;
  return {question:source.slice(0,matches[0].index).trim(),options:items};
 }
 function sections(source,pattern){
  const matches=[...source.matchAll(pattern)];if(!matches.length)return [];
  const out=[];if(source.slice(0,matches[0].index).trim())out.push({label:'',text:source.slice(0,matches[0].index).trim()});
  matches.forEach((m,i)=>out.push({label:m[1],text:source.slice(m.index,matches[i+1]?.index??source.length).trim()}));return out;
 }
 function model(l,s,d,p){
  const source=livePedagogyContent(l,s,d.pedagogy?.knowledgeCloseVisible).replace(/\r\n?/g,'\n');
  let mcq=options(source);
  if(!mcq&&Array.isArray(s.options)&&s.options.length>=2&&s.options.length<=5){
   const explicit=s.options.map((o,i)=>{const text=typeof o==='string'?o:typeof o?.text==='string'?o.text:null;const label=typeof o?.label==='string'?o.label:String.fromCharCode(65+i);return text==null?null:{label,text:/^[A-E][.)]\s/u.test(text)?text:label+'. '+text};});
   if(explicit.every((o,i)=>o&&o.label===String.fromCharCode(65+i)))mcq={question:source||s.question||'',options:explicit};
  }
  const bodyBlocks=sections(source,/(?:^|\n)\s*(Giả thiết|Kết luận|Cần chứng minh|Cần có|Mục tiêu|Dữ kiện|Đặt ẩn|Điều kiện|Biểu diễn|Quan hệ|Phương trình|Sản phẩm(?:\s*\/[^:\n]+)?|Kết quả cần có)\s*[:：]\s*/giu);
  const mathBlocks=source.split('\n').filter(x=>/[=∥⊥≅<>²³^]/u.test(x));
  return {subjectMode:resolveSubjectLayout(s,l),activityType:String(s.layoutType||s.type||'').toUpperCase(),context:TVLayout.infoContext(l,s),source,title:s.title||'',prompt:mcq?.question||source,question:mcq?.question||s.question||'',options:mcq?.options||[],mathBlocks,proofSteps:liveSteps(s).slice(0,d.answerMode==='full'?liveSteps(s).length:d.answerMode==='steps'?d.answerStep||0:0),bodyBlocks,instruction:typeof s.instruction==='string'?s.instruction:'',image:s.image,resolvedImage:p.resource,state:d};
 }
 function element(tag,cls,text){const e=document.createElement(tag);e.className=cls;if(text!=null)renderMathAtomic(e,text);return e;}
 // Keep focus indexes aligned with the baseline's normalized Classroom.parts contract.
 function block(text,model,cls='tvSemanticBlock'){
  const e=element('div',cls),normalized=normalizeLiveText(model.source,'prose');
  Classroom.focusText(e,normalizeLiveText(text,'prose'),'content',null);
  const originals=Classroom.parts(normalized).filter(p=>p.type==='block');
  e.querySelectorAll('.focusBlock').forEach(part=>{
   const index=originals.findIndex(p=>p.text.includes(part.textContent)||part.textContent.includes(p.text));
   if(index>=0){part.dataset.focusIndex=String(index);part.classList.toggle('isFocused',model.state.classroom?.focus?.region==='content'&&model.state.classroom.focus.index===index);}
  });e.classList.toggle('hasFocus',model.state.classroom?.focus?.region==='content');return e;
 }
 function grouped(target,model,blocks,cls){
  const grid=element('div',cls);blocks.forEach(b=>grid.appendChild(block(b.text,model,'tvSemanticBlock tvLabeledBlock')));target.replaceChildren(grid);
 }
 function apply(screen,l,s,d,p){
  const vm=model(l,s,d,p);screen.dataset.subjectMode=vm.subjectMode;screen.dataset.engineActivity=vm.activityType;
  for(const id of ['content','analysis','answer'])node(id).classList.remove('tvOptionContent','tvWordGrid','tvStatementGrid','tvTransformation','tvDependencyTree','tvMathContent','tvApplication');
  node('title').hidden=false;node('content').classList.remove('primaryFocus');
  delete screen.dataset.algebraKind;delete screen.dataset.optionCount;delete screen.dataset.longOptions;
  if(vm.subjectMode==='GENERIC')return;
  screen.dataset.studentUi='multi-engine-rc1';
  node('taskHeader').hidden=true;node('taskLabel').hidden=true;node('situationPane').hidden=true;
  screen.classList.remove('hasSituation');
  // The entire supplied task is retained; semantic engines do not select a guessed question.
  if(!node('content').hidden)Classroom.focusText(node('content'),normalizeLiveText(vm.source,'prose'),'content',d.classroom?.focus);
  const labels={ANALYSISDIAGRAM:'PHÂN TÍCH',PROOFANALYSIS:'PHÂN TÍCH',CONCLUSION:'KẾT LUẬN',STATEMENT:'ĐỀ BÀI',EQUATION:'GIẢI PHƯƠNG TRÌNH',SYSTEM:'HỆ PHƯƠNG TRÌNH',WORD_PROBLEM:'PHÂN TÍCH',IDENTITY:'CHỨNG MINH ĐẲNG THỨC',EXPRESSION:'LUYỆN TẬP',TABLE:'BẢNG SỐ LIỆU',GRAPH:'QUAN SÁT',GEOMETRY_PROOF:'CHỨNG MINH',GEOMETRY_ANALYSIS:'PHÂN TÍCH',ANALYSIS:'PHÂN TÍCH',PROOF:'CHỨNG MINH',PROOF_DEPENDENCY_TREE:'PHÂN TÍCH',OBSERVE:'QUAN SÁT',DISCUSS:'THẢO LUẬN','CHỨNG MINH':'CHỨNG MINH','PHÂN TÍCH':'PHÂN TÍCH','QUAN SÁT':'QUAN SÁT'};
  const badge=labels[vm.activityType]||TVLayout.activityLabel(s);node('activityBadge').textContent=badge;node('activityBadge').hidden=!badge;
  node('title').hidden=!!badge&&String(s.title||'').trim().toLocaleUpperCase('vi')===badge;
  const renderer={COMPUTER_SCIENCE:TVComputerEngine,ALGEBRA:TVAlgebraEngine,GEOMETRY:TVGeometryEngine}[vm.subjectMode];
  renderer.render(screen,vm,{node,element,block,grouped,sections});
  if(vm.subjectMode==='COMPUTER_SCIENCE'&&!vm.options.length)TVLayout.hierarchy(node('content'),s);
  if(vm.subjectMode!=='COMPUTER_SCIENCE'){
   screen.querySelectorAll('.focusBlock').forEach(part=>{if(part.querySelector('.tvDependencyBranches'))return;const text=part.textContent;
    if(text.length<=100&&/[=∥⊥≅<>]/u.test(text)&&/^[\sA-Za-z0-9△∠²³+−\-*/().,=∥⊥≅<>≥≤⇒:]+$/u.test(text)){
     const atomic=element('span','tvAtomicExpression',text);part.replaceChildren(atomic);
    }
   });
  }
 }
 return {model,options,sections,element,block,grouped,apply};
})();
