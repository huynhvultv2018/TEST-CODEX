class ClassroomTeacher{
 constructor(){
  this.layout='60';this.previousLayout='60';this.previousViewMode='split';this.layoutPinned=false;this.fontBoost=false;this.focusMode=false;this.focus=null;
  this.tool=null;this.pending=[];this.highlights=[];this.scope='';
  this.clock={mode:'off',durationMin:45,elapsedMs:0,startedAt:0,running:false};
  this.overlay=document.getElementById('classroomHighlight');
  this.overlay.addEventListener('pointerdown',e=>this.pickGeometry(e));
  document.getElementById('figurePane').addEventListener('dblclick',e=>{if(this.canToggleFigure()){e.preventDefault();this.toggleFigure()}});
  document.addEventListener('keydown',e=>{
   if(e.key!=='Escape'||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
   if(boardController?.hasPending()||coverController?.hasPending()||smartController?.hasPending())return;
   if(this.pending.length){this.pending=[];this.render();e.preventDefault();e.stopImmediatePropagation();return}
   if(pointer)return;
   if(this.focus){this.clearFocus();e.preventDefault();e.stopImmediatePropagation()}
  });
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.fit()).observe(document.getElementById('figureInner'));
  window.addEventListener('resize',()=>this.fit());
  setInterval(()=>this.updateClock(),1000);
  this.render();
 }
 scene(){return lesson&&currentImage()?DrawBoard.overlayScope(lesson,i):''}
 locked(){return !!(boardController?.editingOverlay()||coverController?.editing()||smartController?.editing()||this.tool||this.pending.length||boardController?.hasPending()||coverController?.hasPending()||smartController?.hasPending())}
 state(){return{layout:this.layout,layoutPinned:this.layoutPinned,fontBoost:this.fontBoost,focus:this.focus,highlights:this.highlights,interactionLocked:this.locked(),clock:{...this.clock}}}
 lessonChanged(){this.layout='60';this.previousLayout='60';this.previousViewMode='split';this.layoutPinned=false;this.fontBoost=false;this.focusMode=false;this.focus=null;this.tool=null;this.pending=[];this.highlights=[];this.scope=this.scene();this.render()}
 screenChanged(){const next=this.scene();if(next!==this.scope){this.highlights=[];this.pending=[];this.tool=null}this.scope=next;this.focus=null;this.render()}
 canToggleFigure(){return !!lesson&&!!currentImage()&&!this.locked()}
 setLayout(value){if(!lesson||!currentImage()||!['60','70'].includes(value))return;this.layout=value;this.previousLayout=value;this.layoutPinned=true;viewMode='split';render();sync()}
 toggleFigure(){if(!this.canToggleFigure())return;if(this.layout==='full'){this.layout=this.previousLayout;if(this.previousViewMode==='text')viewMode='text'}else{this.previousLayout=this.layout;this.previousViewMode=viewMode;if(viewMode==='text')viewMode='split';this.layout='full'}render();sync()}
 toggleFont(){if(!lesson)return;this.fontBoost=!this.fontBoost;this.render();sync()}
 toggleFocus(){if(!lesson)return;this.focusMode=!this.focusMode;if(this.focusMode){this.tool=null;this.pending=[]}this.render();sync()}
 clearFocus(){if(!this.focus)return;this.focus=null;this.render();sync()}
 pickFocus(region,index){if(!this.focusMode)return;this.focus={region,index};this.render();sync()}
 setTool(tool){
  if(!lesson||!currentImage()||!['segment','triangle','point'].includes(tool))return;
  const next=this.tool===tool?null:tool;
  this.tool=next;this.pending=[];this.focusMode=false;
  if(next){boardController?.close();coverController?.close();smartController?.close();if(viewMode==='text')viewMode='split'}
  render();sync();
 }
 pickGeometry(e){
  if(!this.tool||!lesson||!currentImage())return;
  e.stopPropagation();e.preventDefault();
  const p=DrawBoard.at(this.overlay,e),count={point:1,segment:2,triangle:3}[this.tool];
  this.pending.push(p);
  if(this.pending.length===count){
   this.highlights.push({type:this.tool,points:this.pending});
   if(this.highlights.length>80)this.highlights.shift();
   this.pending=[];
  }
  this.render();sync();
 }
 clearHighlights(){if(!this.highlights.length&&!this.pending.length)return;this.highlights=[];this.pending=[];this.render();sync()}
 render(){
  const hasImage=!!lesson&&!!currentImage(),screen=$('screen');
  screen.dataset.classroomLayout=this.layout;
  screen.classList.toggle('classroomFigure',hasImage&&this.layout==='full');
  screen.classList.toggle('fontBoost',this.fontBoost);
  screen.classList.toggle('focusEnabled',this.focusMode);
  for(const [id,active] of [['layout70',this.layout==='70'],['layout60',this.layout==='60'],['layoutFull',this.layout==='full'],['fontBoost',this.fontBoost],['focusMode',this.focusMode],['highlightSegment',this.tool==='segment'],['highlightTriangle',this.tool==='triangle'],['highlightPoint',this.tool==='point']])$(id).classList.toggle('active',active);
  for(const id of ['layout70','layout60','layoutFull','highlightSegment','highlightTriangle','highlightPoint'])$(id).disabled=!hasImage;
  const pick=this.focusMode?(region,index)=>this.pickFocus(region,index):null;
  if(lesson){
   for(const [id,region] of [['content','content'],['previewHint','hint'],['previewAnalysis','analysis'],['previewAnswer','answer']]){
    const node=$(id);Classroom.focusText(node,node.textContent,region,this.focus,pick);
   }
  }
  this.overlay.style.pointerEvents=this.tool&&hasImage?'all':'none';
  this.fit();
  $('classroomStatus').textContent=this.tool?`Chọn ${this.tool==='triangle'?'3 đỉnh tam giác':this.tool==='segment'?'2 đầu đoạn':'một vị trí'} trên hình (${this.pending.length}/${this.tool==='triangle'?3:this.tool==='segment'?2:1}).`:this.focusMode?'Click dòng trong Preview để tập trung nội dung.':this.focus?'Đang tập trung một dòng. Bấm XÓA TẬP TRUNG để trở lại.':'Double-click hình để phóng và quay lại.';
  $('clockMode').value=this.clock.mode;$('clockDuration').value=String(this.clock.durationMin);this.updateClock();
  requestAnimationFrame(applyZoom);
 }
 fit(){Classroom.draw(this.overlay,lesson&&currentImage()?this.highlights:[],this.pending)}
 setClockMode(mode){if(!['off','clock','timer'].includes(mode))return;this.clock.mode=mode;this.updateClock();sync()}
 setDuration(min){if(![45,90].includes(min))return;this.clock.durationMin=min;this.updateClock();sync()}
 startTimer(){if(this.clock.running)return;this.clock.mode='timer';this.clock.startedAt=Date.now();this.clock.running=true;this.updateClock();sync()}
 pauseTimer(){if(!this.clock.running)return;this.clock.elapsedMs=Classroom.elapsed(this.clock);this.clock.running=false;this.clock.startedAt=0;this.updateClock();sync()}
 resetTimer(){this.clock.elapsedMs=0;this.clock.startedAt=this.clock.running?Date.now():0;this.updateClock();sync()}
 updateClock(){$('clockPreview').textContent=Classroom.clockText(this.clock)||'—'}
}
classroomController=new ClassroomTeacher();
