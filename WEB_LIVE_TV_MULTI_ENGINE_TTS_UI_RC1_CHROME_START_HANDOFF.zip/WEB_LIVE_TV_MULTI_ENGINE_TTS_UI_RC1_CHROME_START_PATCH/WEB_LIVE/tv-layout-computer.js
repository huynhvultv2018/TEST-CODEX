/* COMPUTER_SCIENCE_ENGINE: Activity Cards, no disclosure changes. */
const TVComputerEngine={render(screen,vm,ui){
 const content=ui.node('content');
 if(vm.options.length&&!content.hidden){
  const grid=ui.element('div','tvOptionGrid');
  vm.options.forEach(option=>grid.appendChild(ui.block(option.text,vm,'tvOptionCard')));
  content.replaceChildren(ui.block(vm.question,vm,'tvQuestion'),grid);content.classList.add('tvOptionContent');
  screen.dataset.optionCount=String(vm.options.length);screen.dataset.longOptions=String(vm.options.some(x=>x.text.length>110));
 }else if(vm.activityType==='APPLICATION'&&!content.hidden&&vm.bodyBlocks.some(x=>/sản phẩm|kết quả/iu.test(x.label))){
  ui.grouped(content,vm,vm.bodyBlocks,'tvApplicationGrid');content.classList.add('tvApplication');
 }
 if(vm.instruction&&!vm.source.includes(vm.instruction)&&!content.hidden)content.appendChild(ui.block(vm.instruction,vm,'tvInstruction'));
}};
