/* TV reads disclosed DOM and paints block highlight only. No speech synthesis here. */
const TTSTVPresentation=(()=>{
 const regions=[['content','content','Câu hỏi / hoạt động'],['hint','hint','Gợi ý'],['analysis','analysis','Phân tích'],['answer','answer','Đáp án']];
 let context=null,targets=[],reading=null,expiry=null;const sequences=new Map();
 function collect(){
  const rows=[];
  for(const [id,region,label] of regions){
   const root=document.getElementById(id);if(!TTSPresentation.visible(root))continue;
   let parts=region==='analysis'?Array.from(root.querySelectorAll('.analysisStep')):region==='answer'?Array.from(root.querySelectorAll('.proofStep')):region==='content'?Array.from(root.querySelectorAll('.tvQuestion,.tvOptionCard,.tvLabeledBlock')):[];
   if(!parts.length)parts=[root];
   parts.filter(TTSPresentation.visible).forEach((element,index)=>{
    const text=TTSPresentation.cleanText(element);if(!text)return;
    rows.push({element,block:{id:region+':'+index,region,index,label:label+(parts.length>1?' '+(index+1):''),text,textKey:TTSPresentation.textKey(text)}});
   });
  }
  return rows;
 }
 function paint(){
  document.querySelectorAll('.tts-reading-block').forEach(n=>n.classList.remove('tts-reading-block'));
  if(!reading||!TTSPresentation.same(reading.context,context)||reading.expiresAt<Date.now()||!reading.block)return;
  const match=targets.find(t=>t.block.id===reading.block.id&&t.block.textKey===reading.block.textKey);
  if(match&&TTSPresentation.visible(match.element))match.element.classList.add('tts-reading-block');
 }
 function refresh(state){
  context={lessonId:state.lessonId,lessonActivation:state.lessonActivation,lessonSourceKey:state.lessonSourceKey||'',index:state.index};
  targets=collect();if(!TTSPresentation.same(reading?.context,context))reading=null;
  paint();
  TTSPresentation.publish({type:'ttsRegistry',context,stateVersion:state.stateVersion||0,blocks:targets.map(t=>t.block)},window.opener);
 }
 TTSPresentation.subscribe(packet=>{
  if(packet.type!=='ttsReading'||!TTSPresentation.same(packet.context,context)||typeof packet.owner!=='string'||!Number.isFinite(packet.sequence)||packet.expiresAt<Date.now())return;
  if(packet.sequence<=(sequences.get(packet.owner)||0))return;
  sequences.set(packet.owner,packet.sequence);reading=packet;clearTimeout(expiry);paint();
  expiry=setTimeout(()=>{reading=null;paint()},Math.min(15000,Math.max(0,packet.expiresAt-Date.now())));
 });
 window.addEventListener('beforeunload',()=>{if(context)TTSPresentation.publish({type:'ttsRegistry',context,blocks:[],closed:true},window.opener)});
 window.addEventListener('pagehide',()=>{if(context)TTSPresentation.publish({type:'ttsRegistry',context,blocks:[],closed:true},window.opener)});
 return{refresh,get blocks(){return targets.map(t=>t.block)}};
})();
