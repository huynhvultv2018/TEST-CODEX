/* Separate presentation packets. The existing lesson schema/state remains untouched. */
const TTSPresentation=(()=>{
 const keys={ttsReading:'WEB_LIVE_TTS_PRESENTATION_V1',ttsRegistry:'WEB_LIVE_TTS_REGISTRY_V1'};
 const contextKey=c=>c?[c.lessonId,c.lessonActivation||'',c.lessonSourceKey||'',c.index].join('|'):'';
 const same=(a,b)=>!!a&&!!b&&contextKey(a)===contextKey(b);
 function visible(el){return !!el&&!el.hidden&&!!el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden'&&getComputedStyle(el).display!=='none'}
 function textKey(text){let hash=2166136261;for(const ch of String(text)){hash^=ch.codePointAt(0);hash=Math.imul(hash,16777619)}return(hash>>>0).toString(16)}
 function cleanText(el){const copy=el.cloneNode(true);copy.querySelectorAll('button,script,style,[hidden],svg,canvas,img').forEach(n=>n.remove());return copy.textContent.trim()}
 function publish(packet,peer){
  if(!keys[packet.type])return;
  const data={...packet,ttsProtocol:1};
  try{send(data)}catch(_){}try{peer?.postMessage(data,location.origin==='null'?'*':location.origin)}catch(_){}
  try{localStorage.setItem(keys[data.type],JSON.stringify(data))}catch(_){}
 }
 function subscribe(handler){
  const accept=data=>{if(data?.ttsProtocol===1&&keys[data.type])try{handler(data)}catch(_){}};
  if(typeof bc!=='undefined')bc?.addEventListener?.('message',e=>accept(e.data));
  window.addEventListener('message',e=>{if(e.origin===location.origin)accept(e.data)});
  window.addEventListener('storage',e=>{if(Object.values(keys).includes(e.key)&&e.newValue)try{accept(JSON.parse(e.newValue))}catch(_){}});
 }
 return{contextKey,same,visible,textKey,cleanText,publish,subscribe};
})();
