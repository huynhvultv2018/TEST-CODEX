/* V1.1.5: current Teacher session; explicit TV demo and return. */
class DemoTeacher{
 constructor(){
  this.token='';this.busy=false;this.ready=false;this.state='offline';this.apps=null;
  this.screenKey='';this.demo=null;this.poller=null;this.pending=null;
  this.active=null;this.demoState='READY';this.monitorCount=0;this.monitorState='NO_TV';
  this.endpoint='http://127.0.0.1:47381';
 }
 el(id){return document.getElementById(id)}
 key(){return String(lessonActivation)+':'+String(i)}
 definition(d){
  if(!d||typeof d!=='object'||Array.isArray(d))return null;
  const appId=d.appId,validApp=appId==='word'||appId==='geogebra';
  const validText=(x,max)=>x===undefined||typeof x==='string'&&x.length<=max;
  const sourceFile=d.file===undefined?'':d.file;
  // Both old demos/<name> and new <name> metadata map to LAUNCHER/demos.
  const file=typeof sourceFile==='string'&&sourceFile.startsWith('demos/')?sourceFile.slice(6):sourceFile;
  const validFile=typeof file==='string'&&typeof sourceFile==='string'&&sourceFile.length<=240&&file.length<=240&&
   !(sourceFile.startsWith('demos/')&&!file)&&(!file||(!file.startsWith('/')&&!file.includes('\\')&&
   file.split('/').every(p=>p&&p!=='.'&&p!=='..'&&!/[<>:"|?*\x00-\x1f]/.test(p)&&!/[. ]$/.test(p))));
  const validExtension=!file||appId==='word'&&/\.docx$/i.test(file)||appId==='geogebra'&&/\.ggb$/i.test(file);
  return{appId,file,title:validText(d.title,120)?d.title||'Demo trực tiếp':'',instruction:validText(d.instruction,500)?d.instruction||'':'',valid:validApp&&validText(d.title,120)&&validText(d.instruction,500)&&validFile&&validExtension};
 }
 message(s){this.el('demoMessage').textContent=s}
 friendly(error){
  if(error?.code==='PACKAGE_MISMATCH')return 'WEB LIVE và Launcher không cùng một gói cài đặt.';
  if(error?.code==='PAIR_DENIED'||error?.code==='INVALID_PAIR')return 'Không ghép được Launcher: khóa cài đặt không hợp lệ.';
  if(error?.code==='INVALID_TOKEN')return 'Phiên Launcher đã đổi; đang ghép lại.';
  if(error?.code==='APP_DENIED')return 'Ứng dụng không nằm trong whitelist.';
  if(error?.code==='APP_NOT_FOUND')return `${this.demo?.appId==='word'?'Word':'GeoGebra'} chưa được cấu hình trên Launcher.`;
  if(error?.code==='FILE_NOT_FOUND')return 'Không tìm thấy tệp demo trong thư mục demos của Launcher.';
  if(error?.code==='COOLDOWN')return 'Demo vừa mở; vui lòng chờ vài giây.';
  if(error?.code==='NO_DEMO')return 'Chưa có ứng dụng demo để chuyển.';
  if(error?.code==='RETURN_FAILED')return 'Chưa thu nhỏ được ứng dụng demo; hãy thử lại.';
  if(error?.code==='INVALID_REQUEST')return 'Yêu cầu điều khiển demo không hợp lệ.';
  if(error?.code==='WEBCRYPTO_UNAVAILABLE')return 'Browser không hỗ trợ xác thực Launcher bằng Web Crypto.';
  return 'Không kết nối được Launcher. Hãy kiểm tra phiên bản gói và thử lại.';
 }
 paint(){
  const names={offline:'○ CHƯA CHẠY',connecting:'◐ ĐANG KẾT NỐI',ready:'● SẴN SÀNG',error:'○ CHƯA KẾT NỐI'};
  this.el('launcherStatus').textContent='Launcher: '+names[this.state];
  this.el('demoRetry').hidden=this.state==='ready'||this.state==='connecting';
  this.el('demoAppStatus').textContent=this.apps?['word','geogebra'].map(id=>`${this.apps[id]?.name||id} ${(this.apps[id]?.configured??this.apps[id]?.available)?'✓':'— CHƯA CẤU HÌNH'}`).join(' · '):
   'Ứng dụng: '+({word:'Microsoft Word',geogebra:'GeoGebra'}[this.demo?.appId]||'—');
  this.el('demoOpenBtn').disabled=this.busy||!this.demo?.valid||!this.token||!this.ready;
  this.el('demoOpenBtn').hidden=!this.demo;
  this.el('demoReturnBtn').hidden=!['PRESENTING','NO_TV','MONITOR_SELECTION_REQUIRED'].includes(this.demoState)||!this.active;
  this.el('demoReturnBtn').disabled=this.busy||!this.ready;
  this.el('demoMoveRetry').hidden=!['WINDOW_NOT_FOUND','PRESENT_FAILED','MONITOR_SELECTION_REQUIRED','NO_TV'].includes(this.demoState)||!this.active;
  this.el('demoMoveRetry').disabled=this.busy||!this.ready;
  this.el('demoHandoffStatus').textContent={OPENING:'ĐANG MỞ ỨNG DỤNG',PRESENTING:'ĐANG DEMO TRÊN TV',
   RETURNED:'ĐÃ TRỞ LẠI WEB LIVE',READY:'SẴN SÀNG',NO_TV:'KHÔNG CÓ TV THỨ HAI',
   MONITOR_SELECTION_REQUIRED:'CẦN CHỌN MÀN TV',WINDOW_NOT_FOUND:'CHƯA TÌM THẤY CỬA SỔ',
   PRESENT_FAILED:'CHƯA CHUYỂN ĐƯỢC SANG TV'}[this.demoState]||'SẴN SÀNG';
 }
 render(screen){
  const current=this.key(),changed=current!==this.screenKey;
  if(changed)this.pending=null;
  this.screenKey=current;this.renderDemoPanel(screen?.demo,changed);
  if(!this.demo&&!this.active){if(this.poller){clearInterval(this.poller);this.poller=null}return}
  if(!this.poller&&typeof setInterval==='function'){
   this.poller=setInterval(()=>{if((this.demo||this.active)&&!this.busy)this.refresh(true)},1500);
  }
  if(changed)this.refresh(); // Only /status and /pair; never /launch.
 }
 renderDemoPanel(metadata,changed=true){
  this.demo=this.definition(metadata);
  this.el('demoSection').hidden=!this.demo&&!this.active;
  if(!this.demo&&!this.active)return;
  const label=this.demo?.title||({word:'Microsoft Word',geogebra:'GeoGebra'}[this.demo?.appId||this.active?.appId]||'Demo trực tiếp');
  this.el('demoTitle').textContent=label;
  this.el('demoInstruction').textContent=this.demo?.instruction||'Ứng dụng demo đang mở; có thể trở lại WEB LIVE.';
  if(changed&&this.demo)this.message(this.demo.valid?'':this.demo.appId!=='word'&&this.demo.appId!=='geogebra'?'Ứng dụng không nằm trong whitelist.':'Thông tin demo hoặc đường dẫn tệp không hợp lệ.');
  this.paint();
 }
 updateHandoff(status){
  const previous=this.demoState;
  this.active=status.demo?.appId&&status.demo.state!=='RETURNED'?status.demo:null;
  this.demoState=status.demo?.state||'READY';
  this.monitorCount=status.monitorCount||0;
  this.monitorState=status.monitorState||'NO_TV';
  if(previous!==this.demoState){
   const notes={OPENING:'Đang mở ứng dụng và tìm cửa sổ demo…',
    PRESENTING:'Đang demo trên TV. Bấm TRỞ LẠI WEB LIVE để thu nhỏ ứng dụng.',
    RETURNED:'Đã trở lại WEB LIVE; ứng dụng demo vẫn mở.',
    NO_TV:'Không phát hiện màn hình TV thứ hai. Ứng dụng sẽ mở trên màn hình hiện tại.',
    MONITOR_SELECTION_REQUIRED:'Có nhiều màn hình phụ; hãy cấu hình tvMonitorIndex trong Launcher.',
    WINDOW_NOT_FOUND:'Ứng dụng đã mở nhưng chưa thể chuyển sang TV. Bấm THỬ CHUYỂN LẠI.',
    PRESENT_FAILED:'Chưa chuyển được cửa sổ sang TV. Bấm THỬ CHUYỂN LẠI.'};
   if(notes[this.demoState])this.message(notes[this.demoState]);
  }
  this.el('demoSection').hidden=!this.demo&&!this.active;
  if(!this.demo&&!this.active&&this.poller){clearInterval(this.poller);this.poller=null}
  this.paint();
 }
 async request(path,{token='',...options}={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),2500);
  try{
   const headers={...options.headers};if(token)headers['X-WebLive-Token']=token;
   const response=await fetch(this.endpoint+path,{...options,mode:'cors',cache:'no-store',signal:controller.signal,headers});
   const body=await response.json();
   if(!response.ok){const error=Error(body.message||'Launcher từ chối yêu cầu.');error.code=body.error;throw error}
   return body;
  }finally{clearTimeout(timer)}
 }
 async proof(challenge,instanceId){
  const config=typeof WEB_LIVE_INSTALLATION==='undefined'?null:WEB_LIVE_INSTALLATION;
  if(!config||!/^[0-9a-f]{64}$/.test(config.installationKey||''))throw Object.assign(Error('Missing installation key'),{code:'PACKAGE_MISMATCH'});
  if(!globalThis.crypto?.subtle)throw Object.assign(Error('Web Crypto unavailable'),{code:'WEBCRYPTO_UNAVAILABLE'});
  const bytes=new Uint8Array(config.installationKey.match(/../g).map(x=>parseInt(x,16)));
  const key=await crypto.subtle.importKey('raw',bytes,{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const data=new TextEncoder().encode(`WEBLIVE-PAIR-V1.1.4\n${instanceId}\n${challenge}`);
  const signature=await crypto.subtle.sign('HMAC',key,data);
  return Array.from(new Uint8Array(signature),x=>x.toString(16).padStart(2,'0')).join('');
 }
 async _refresh(silent){
  if(!this.demo&&!this.active)return false;
  const current=this.screenKey,wasReady=this.ready;
  try{
   const status=await this.request('/status',{token:this.token});
   if((!this.demo&&!this.active)||current!==this.screenKey)return false;
   if(status.status==='PAIR_REQUIRED'){
    this.ready=false;this.token='';this.apps=null;this.state='connecting';this.paint();
    const config=typeof WEB_LIVE_INSTALLATION==='undefined'?null:WEB_LIVE_INSTALLATION;
    if(!config||status.installationId!==config.installationId)throw Object.assign(Error('Different package'),{code:'PACKAGE_MISMATCH'});
    const proof=await this.proof(status.challenge,status.instanceId);
    if((!this.demo&&!this.active)||current!==this.screenKey)return false;
    const paired=await this.request('/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({challenge:status.challenge,proof})});
    if((!this.demo&&!this.active)||current!==this.screenKey)return false;
    if(paired.status!=='READY'||paired.instanceId!==status.instanceId||
       !/^[A-Za-z0-9_-]{43}$/.test(paired.token||''))throw Object.assign(Error('Invalid pair response'),{code:'PAIR_DENIED'});
    if(!paired.demo||typeof paired.monitorCount!=='number')throw Object.assign(Error('Old Launcher'),{code:'PACKAGE_MISMATCH'});
    this.token=paired.token;this.apps=paired.apps||null;this.updateHandoff(paired);
   }else if(status.status==='READY'&&this.token){
    if(!status.demo||typeof status.monitorCount!=='number')throw Object.assign(Error('Old Launcher'),{code:'PACKAGE_MISMATCH'});
    this.apps=status.apps||null;
    this.updateHandoff(status);
   }else throw Object.assign(Error('Incompatible Launcher'),{code:'PACKAGE_MISMATCH'});
   this.ready=true;this.state='ready';
   if((!silent||!wasReady)&&this.demoState==='READY')this.message('Launcher đã sẵn sàng.');
   return true;
  }catch(error){
   if((!this.demo&&!this.active)||current!==this.screenKey)return false;
   this.ready=false;this.apps=null;
   if(error?.name==='TypeError'||error?.name==='AbortError'){
    this.state='offline';this.message('Hãy chạy LAUNCHER/START_LAUNCHER.bat.');
   }else{
    this.state='error';this.message(this.friendly(error));
    if(error?.code==='INVALID_TOKEN')this.token='';
   }
   return false;
  }finally{if((this.demo||this.active)&&current===this.screenKey)this.paint()}
 }
 async refresh(silent=false){
  if(this.pending)return this.pending;
  const job=this._refresh(silent);this.pending=job;
  try{return await job}finally{if(this.pending===job)this.pending=null}
 }
 async launch(){
  if(this.busy||!this.demo?.valid||!this.ready||!this.token)return;
  const key=this.screenKey,demo=this.demo;
  this.busy=true;this.paint();
  try{
   if(!await this.refresh()||this.screenKey!==key)return;
   if(!this.apps?.[demo.appId]?.available){this.message(`${demo.appId==='word'?'Word':'GeoGebra'} chưa được cấu hình trên Launcher.`);return}
   if(!window.confirm(`Mở ${this.apps[demo.appId].name} để demo?`))return;
   if(this.screenKey!==key)return;
   const payload={appId:demo.appId};if(demo.file)payload.file=demo.file;
   const result=await this.request('/launch',{token:this.token,method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
   this.message(['STARTED','REUSED','RETRYING'].includes(result.result)?'Đang mở ứng dụng và chuyển cửa sổ sang TV…':'Launcher chưa xác nhận mở ứng dụng.');
   await this.refresh(true);
  }catch(error){
   if(error?.code==='INVALID_TOKEN'){this.token='';this.ready=false;this.state='error'}
   this.message(this.friendly(error));
  }finally{this.busy=false;this.paint()}
 }
 async retryPresent(){
  if(this.busy||!this.ready||!this.active)return;
  this.busy=true;this.paint();
  try{
   const result=await this.request('/present',{token:this.token,method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
   this.message(result.result==='OPENING'?'Đang tìm lại cửa sổ đã mở…':'Đang chuyển ứng dụng sang TV…');
   await this.refresh(true);
  }catch(error){this.message(this.friendly(error))}
  finally{this.busy=false;this.paint()}
 }
 async returnToWeb(){
  if(this.busy||!this.ready||!this.active)return;
  this.busy=true;this.paint();
  try{
   await this.request('/return',{token:this.token,method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
   await this.refresh(true);
  }catch(error){this.message(this.friendly(error))}
  finally{this.busy=false;this.paint()}
 }
}
const demoController=new DemoTeacher();
if(typeof lesson!=='undefined'&&lesson)demoController.render(lesson.screens[i]);
