/* Speech-only conversion. Never modifies mathematical display or lesson data. */
(()=>{
 const digits=['không','một','hai','ba','bốn','năm','sáu','bảy','tám','chín'];
 function small(n,full=false){
  const h=Math.floor(n/100),t=Math.floor(n%100/10),u=n%10,out=[];
  if(h||full)out.push(digits[h],'trăm');
  if(t>1)out.push(digits[t],'mươi');else if(t===1)out.push('mười');else if((h||full)&&u)out.push('linh');
  if(u)out.push(u===1&&t>1?'mốt':u===5&&t?'lăm':digits[u]);
  return out.join(' ');
 }
 function number(value){
  const raw=String(value);
  if(!/^-?\d{1,12}(?:[.,]\d+)?$/u.test(raw))return raw;
  const negative=raw.startsWith('-'),parts=raw.replace(/^-/u,'').split(/[.,]/u),n=Number(parts[0]);
  let text='';
  if(n===0)text=digits[0];else{
   const groups=[],scales=['','nghìn','triệu','tỷ'];let remaining=n;
   while(remaining){groups.push(remaining%1000);remaining=Math.floor(remaining/1000)}
   const out=[];for(let i=groups.length-1;i>=0;i--)if(groups[i])out.push(small(groups[i],i<groups.length-1&&groups[i]<100),scales[i]);
   text=out.join(' ').trim().replace(/\s+/gu,' ');
  }
  if(parts[1])text+=' phẩy '+parts[1].split('').map(c=>digits[Number(c)]).join(' ');
  return (negative?'âm ':'')+text;
 }
 function parse(source){
  const tokens=source.match(/\d+(?:[.,]\d+)?|[A-Za-z]+|[()+\-−*/×÷^²³√=<>≥≤≠≈∥⊥⟂≅⇒⇔∠△∆°]/gu)||[];
  if(tokens.join('')!==source.replace(/\s+/gu,''))return null;
  let index=0;
  const peek=()=>tokens[index],take=()=>tokens[index++];
  function atom(){
   if(peek()==='('){take();const node=add();if(take()!==')')throw Error('group');return{type:'group',node}}
   if(peek()==='√'){take();return{type:'root',node:power()}}
   if(['∠','△','∆'].includes(peek())){const kind=take(),label=take();if(!/^[A-Z]{1,5}$/u.test(label||''))throw Error('geometry');return{type:'geometry',kind,label}}
   const v=take();if(/^\d+(?:[.,]\d+)?$/u.test(v||''))return{type:'number',value:v};
   if(/^[a-z]$|^[A-Z]{1,5}$/u.test(v||''))return{type:'name',value:v};
   throw Error('operand');
  }
  function power(){
   let node=atom();
   if(peek()==='²'||peek()==='³')node={type:'power',left:node,right:{type:'number',value:take()==='²'?'2':'3'}};
   else if(peek()==='^'){take();node={type:'power',left:node,right:power()}}
   if(peek()==='°'){take();node={type:'degree',node}}
   return node;
  }
  function unary(){if(peek()==='-'||peek()==='−'){take();return{type:'negative',node:unary()}}if(peek()==='+'){take();return unary()}return power()}
  function mul(){
   let left=unary();
   while(index<tokens.length){
    if(['*','×','÷','/'].includes(peek())){const op=take();left={type:op==='/'?'fraction':'binary',op,left,right:unary()}}
    else if(peek()==='('||/^[a-z]$|^[A-Z]{1,5}$/u.test(peek()||'')){left={type:'binary',op:'implicit',left,right:unary()}}
    else break;
   }
   return left;
  }
  function add(){let left=mul();while(['+','-','−'].includes(peek())){const op=take();left={type:'binary',op,left,right:mul()}}return left}
  try{
   let node=add();while(['=','<','>','≥','≤','≠','≈','∥','⊥','⟂','≅','⇒','⇔'].includes(peek())){const op=take();node={type:'binary',op,left:node,right:add()}}
   return index===tokens.length?node:null;
  }catch(_){return null}
 }
 const operators={'+':'cộng','-':'trừ','−':'trừ','*':'nhân','×':'nhân','÷':'chia cho','=':'bằng','<':'nhỏ hơn','>':'lớn hơn','≥':'lớn hơn hoặc bằng','≤':'nhỏ hơn hoặc bằng','≠':'khác','≈':'xấp xỉ','∥':'song song với','⊥':'vuông góc với','⟂':'vuông góc với','≅':'bằng nhau','⇒':'suy ra','⇔':'tương đương','implicit':''};
 function speak(node,unwrap=false){
  switch(node.type){
   case 'number':return number(node.value);
   case 'name':return node.value;
   case 'geometry':return(node.kind==='∠'?'góc ':'tam giác ')+node.label;
   case 'degree':return speak(node.node)+' độ';
   case 'negative':return 'âm '+speak(node.node);
   case 'group':return unwrap?speak(node.node):'mở ngoặc '+speak(node.node)+' đóng ngoặc';
   case 'root':return 'căn bậc hai của '+speak(node.node,true);
   case 'power':return speak(node.left)+(node.right.type==='number'&&node.right.value==='2'?' bình phương':node.right.type==='number'&&node.right.value==='3'?' lập phương':' mũ '+speak(node.right,true));
   case 'fraction':{
    const a=node.left,b=node.right;
    if(a.type==='number'&&b.type==='number')return speak(a)+' phần '+(b.value==='4'?'tư':speak(b));
    return 'phân số có tử số là '+speak(a,true)+', mẫu số là '+speak(b,true);
   }
   case 'binary':return speak(node.left)+' '+operators[node.op]+' '+speak(node.right);
   default:return '';
  }
 }
 const geometryDictionary=Object.freeze({'∠':'góc','△':'tam giác','∆':'tam giác','∥':'song song với','⊥':'vuông góc với','⟂':'vuông góc với','≅':'bằng nhau','°':'độ',point:'điểm',segment:'đoạn thẳng',line:'đường thẳng',ray:'tia',quadrilateral:'tứ giác',circle:'đường tròn',radius:'bán kính',diameter:'đường kính',midpoint:'trung điểm',intersection:'giao điểm'});
 function preprocess(value){
  const original=String(value??'').trim();if(!original)return '';
  if(/^\d{1,2}\/\d{1,2}\/\d{2,4}$/u.test(original))return original;
  const parsed=parse(original);if(parsed)return speak(parsed).replace(/\s+/gu,' ').trim();
  // Preserve URLs, filenames/code and dates. They are not guessed to be fractions.
  const protectedText=[];
  let source=original.replace(/https?:\/\/[^\s]+|[\w.-]+\.(?:docx?|xlsx?|pptx?|zip|html|exe|txt)\b|(?:ngày|tháng)\s+\d{1,2}\/\d{1,2}(?:\/\d{2,4})?|`[^`]+`/giu,m=>{protectedText.push(m);return '§'+String.fromCharCode(0xe000+protectedText.length-1)+'§'});
  source=source.replace(/(\([^()\n]+\)|(?<![\p{L}\p{N}_])\d+(?:[.,]\d+)?|(?<![\p{L}\p{N}_])[a-z])\s*\/\s*(\([^()\n]+\)|\d+(?:[.,]\d+)?|[a-z])(?![\p{L}\p{N}_])/gu,(all,a,b)=>{const p=parse(a+'/'+b);return p?speak(p):all});
  source=source.replace(/√\s*(\d+(?:[.,]\d+)?|\([^()\n]+\))/gu,(all,a)=>{const p=parse('√'+a);return p?speak(p):all});
  source=source.replace(/([a-zA-Z]|\([^()\n]+\))\s*(²|³|\^[23])/gu,(_,a,p)=>a+(p==='²'||p==='^2'?' bình phương':' lập phương'));
  source=source.replace(/(?<![\p{L}\p{N}_])(\d+(?:[.,]\d+)?)(?=[a-z]\b)/gu,(_,n)=>number(n)+' ');
  source=source.replace(/[∠△∆∥⊥⟂≅°]/gu,c=>' '+geometryDictionary[c]+' ');
  source=source.replace(/[=<>≥≤≠≈⇒⇔+−×÷]/gu,c=>' '+operators[c]+' ');
  source=source.replace(/(?<![\p{L}\p{N}_])\d+(?:[.,]\d+)?(?![\p{L}\p{N}_])/gu,n=>number(n));
  source=source.replace(/[₀₁₂₃₄₅₆₇₈₉]/gu,c=>' '+digits['₀₁₂₃₄₅₆₇₈₉'.indexOf(c)]);
  source=source.replace(/§([\ue000-\uf8ff])§/gu,(_,c)=>protectedText[c.charCodeAt(0)-0xe000]);
  return source.replace(/[ \t]+/gu,' ').trim();
 }
 const api=Object.freeze({preprocess,number,parse,geometryDictionary});
 globalThis.MathSpeechPreprocessor=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
