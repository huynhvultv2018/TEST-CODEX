/* RC3 contract mapping. Read fields only; never rewrite lesson content or order. */
function livePedagogyEnabled(l){return l?.preparedContract==='TIN_SGK_PREP_3'||l?.pedagogyLocks?.knowledgeFormation===true}
function livePedagogyText(v){return typeof v==='string'?v:Array.isArray(v)&&v.every(x=>typeof x==='string')?v.join('\n'):''}
function livePedagogyGuidance(s,key){return livePedagogyText(s?.[key]??s?.pedagogyGuidance?.[key])}
function livePedagogyHint(s,level){
 const first=livePedagogyGuidance(s,'hintLevel1')||livePedagogyText(s?.hint),second=livePedagogyGuidance(s,'hintLevel2');
 return level===2?[first,second].filter(Boolean).join('\n'):level===1?first:'';
}
function livePedagogyStage(l,s){return s?.pedagogyStage||Object.entries(l?.pedagogyFlow||{}).find(([,id])=>id===s?.id)?.[0]||''}
function livePedagogyIsClose(l,s){return livePedagogyEnabled(l)&&(livePedagogyStage(l,s)==='STANDARDIZE'||['KNOWLEDGE','CLOSE','KNOWLEDGE_CLOSE'].includes(String(s?.type||'').toUpperCase()))}
function livePedagogyContent(l,s,revealed=false){return livePedagogyIsClose(l,s)&&!revealed?'':livePedagogyText(s?.content||s?.question)}
function livePedagogyCore(s){return typeof s?.coreStatus==='string'?s.coreStatus:typeof s?.CORE_STATUS==='string'?s.CORE_STATUS:''}
function livePedagogyState(l,level,closed){return livePedagogyEnabled(l)?{hintLevel:[1,2].includes(level)?level:0,knowledgeCloseVisible:closed===true}:null}
