/* Presentation state only. Lesson, drawing, cover, scene and TV state remain in their V0.5.1.2 modules. */
function toggleCompactUI(){
  const compact=document.body.classList.toggle('compactUI');
  const button=document.getElementById('compactBtn');
  button.setAttribute('aria-pressed',String(compact));
  button.textContent=compact?'☷ MỞ RỘNG':'☷ THU GỌN';
  requestAnimationFrame(applyZoom);
  setTimeout(applyZoom,180);
}
function toggleTeacherFull(){
  if(document.fullscreenElement)document.exitFullscreen?.();
  else document.documentElement.requestFullscreen?.();
}
const groups=[['drawOpenBtn','drawControls'],['coverOpenBtn','coverControls'],['smartOpenBtn','smartControls']];
function reflectToolPanels(){
  for(const [toggle,body] of groups){
    const button=document.getElementById(toggle),panel=document.getElementById(body);
    button.setAttribute('aria-expanded',String(!panel.hidden));
  }
  const open=groups.some(([_,body])=>!document.getElementById(body).hidden);
  if(open)document.getElementById('pointerGroup').open=false;
}
const panelObserver=new MutationObserver(reflectToolPanels);
for(const [_,body] of groups)panelObserver.observe(document.getElementById(body),{attributes:true,attributeFilter:['hidden']});
reflectToolPanels();
if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>requestAnimationFrame(applyZoom)).observe(document.getElementById('figurePane'));
