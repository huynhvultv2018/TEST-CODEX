/* Teacher integration: read disclosed student blocks, never the notes/menu/sidebar. */
(()=>{
 const roots=[['content','content','Câu hỏi / hoạt động'],['previewHint','hint','Gợi ý'],['previewAnalysis','analysis','Phân tích'],['previewAnswer','answer','Đáp án']];
 const el=id=>document.getElementById(id);
 let controller,registry=null,tvContext=null,available=[],signature='',voiceSignature='',sequence=0,refreshQueued=false;
 const context=()=>lesson?{lessonId:currentLessonId,lessonActivation,lessonSourceKey:lesson._runtimeSourceKey||'',index:i}:null;
 function previewBlocks(){
  const blocks=[];
  for(const [id,region,label] of roots){
   const root=el(id);if(!TTSPresentation.visible(root))continue;
   let parts=['analysis','answer'].includes(region)?Array.from(root.querySelectorAll('.focusBlock')):[root];if(!parts.length)parts=[root];
   parts.filter(TTSPresentation.visible).forEach((node,index)=>{const text=TTSPresentation.cleanText(node);if(text)blocks.push({id:region+':'+index,region,index,label:label+(parts.length>1?' '+(index+1):''),text,textKey:TTSPresentation.textKey(text)})});
  }
  return blocks;
 }
 function paintTeacher(block,state){
  el('screen').querySelectorAll('.tts-reading-block').forEach(n=>n.classList.remove('tts-reading-block'));
  if(!block||!state.settings.highlight||!['SPEAKING','PAUSED'].includes(state.state))return;
  const id=roots.find(r=>r[1]===block.region)?.[0],root=el(id);if(!TTSPresentation.visible(root))return;
  const steps=['analysis','answer'].includes(block.region)?Array.from(root.querySelectorAll('.focusBlock')):[];
  (steps[block.index]||root).classList.add('tts-reading-block');
 }
 function publishHighlight(block,state){
  paintTeacher(block,state);
  const c=controller?.lastRequest?.context||context();if(!c)return;
  TTSPresentation.publish({type:'ttsReading',owner:state.ownerId,sequence:++sequence,context:c,state:state.state,block:block?{id:block.id,textKey:block.textKey}:null,expiresAt:Date.now()+12000},tvWindow);
 }
 function renderState(s){
  const active=['SPEAKING','PAUSED','STARTING'].includes(s.state),ready=!!s.voice&&available.length>0;
  el('ttsMain').textContent=s.state==='SPEAKING'?'⏸ TẠM DỪNG':s.state==='PAUSED'?'▶ TIẾP TỤC':s.state==='STARTING'?'ĐANG CHUẨN BỊ':'🔊 ĐỌC';
  el('ttsMain').disabled=s.state==='STARTING'||(!active&&!ready);
  el('ttsStop').disabled=!active;el('ttsReplay').disabled=!ready;
  el('ttsStatus').dataset.state=s.state;
  let status=s.message||({IDLE:'Sẵn sàng đọc.',SPEAKING:'Đang đọc.',PAUSED:'Đã tạm dừng.',STOPPED:'Đã dừng đọc.'}[s.state]||'');
  if(s.voice&&!active){const g=controller?.voiceGender(s.voice)||'unknown';status+=' '+(g==='unknown'?(s.settings.preferredGender==='any'?'Giọng chưa xác định giới tính.':'Ưu tiên '+(s.settings.preferredGender==='male'?'Nam':'Nữ')+'; giọng được chọn chưa xác định giới tính.'):g==='male'?'Giọng Nam.':'Giọng Nữ.');if(!/^vi-vn$/iu.test(s.voice.lang))status+=' Không có vi-VN; đang dùng giọng Việt '+s.voice.lang+'.'}
  el('ttsStatus').textContent=status;
  const sig=JSON.stringify([s.voices.map(v=>[TTSController.voiceKey(v),v.name,v.lang]),s.voice&&TTSController.voiceKey(s.voice)]);
  if(sig!==voiceSignature){
   voiceSignature=sig;el('ttsVoice').replaceChildren();
   if(!s.voices.length){const option=new Option('Chưa có giọng Việt','');el('ttsVoice').appendChild(option)}
   for(const voice of s.voices)el('ttsVoice').appendChild(new Option(voice.name+' · '+voice.lang+(voice.localService?' · máy GV':' · cần mạng'),TTSController.voiceKey(voice)));
   el('ttsVoice').value=s.voice?TTSController.voiceKey(s.voice):'';
  }
  el('ttsRate').value=String(s.settings.rate);el('ttsGenderPreference').value=s.settings.preferredGender;el('ttsHighlight').checked=s.settings.highlight;el('ttsVolume').value=String(s.settings.volume);
  el('ttsKnownGender').value=s.voice&&controller?controller.voiceGender(s.voice):'unknown';
  el('ttsVoice').disabled=!s.voices.length;el('ttsKnownGender').disabled=!s.voice;
  if(active)el('ttsGroup').open=true;
  paintTeacher(s.activeBlock,s);
 }
 controller=new TTSController({getContext:context,onState:renderState,onHighlight:publishHighlight});
 function readBlocks(blocks){el('ttsGroup').open=true;return controller.read(blocks,context())}
 function readSelected(){refresh();const id=el('ttsBlock').value;return readBlocks(id==='screen'?available:available.filter(b=>b.id===id))}
 function addIcons(){
  for(const [id,region] of roots){
   const root=el(id);if(!TTSPresentation.visible(root))continue;
   let hosts=['analysis','answer'].includes(region)?Array.from(root.querySelectorAll('.focusBlock')):[root];if(!hosts.length)hosts=[root];
   hosts.forEach((host,index)=>{
    host.classList.add('tts-readable');
    let button=Array.from(host.children).find(n=>n.classList.contains('tts-block-button'));
    if(!button){button=document.createElement('button');button.type='button';button.className='tts-block-button';host.appendChild(button)}
    button.setAttribute('aria-label','Đọc '+(region==='content'?'câu hỏi / hoạt động':region==='hint'?'gợi ý':region==='analysis'?'bước phân tích':'đáp án'));button.title=button.getAttribute('aria-label');
    button.disabled=!controller.voice||!available.some(b=>b.region===region&&(!['analysis','answer'].includes(region)||b.index===index));
    button.onclick=e=>{e.stopPropagation();e.preventDefault();readBlocks(available.filter(b=>b.region===region&&(!['analysis','answer'].includes(region)||b.index===index)))};
   });
  }
 }
 function refresh(){
  const c=context();if(tvWindow?.closed){tvContext=null;registry=null}
  const useTV=TTSPresentation.same(registry?.context,c),otherTV=!!tvContext&&!TTSPresentation.same(tvContext,c);
  available=c?(useTV?registry.blocks:otherTV?[]:previewBlocks()):[];
  const sig=JSON.stringify(available.map(b=>[b.id,b.textKey]));
  if(sig!==signature){
   signature=sig;const old=el('ttsBlock').value;el('ttsBlock').replaceChildren(new Option('Màn đang hiển thị','screen'));
   available.forEach(b=>el('ttsBlock').appendChild(new Option(b.label,b.id)));
   el('ttsBlock').value=available.some(b=>b.id===old)?old:'screen';
  }
  el('ttsSource').textContent=useTV?'Nội dung đang hiện trên TV.':otherTV?'TV đang hiển thị màn khác. Đồng bộ TV trước khi đọc.':'Nội dung đang hiện trong preview.';
  if(controller.ownsSpeech){
   const request=controller.lastRequest;
   if(!TTSPresentation.same(request?.context,c)||request.blocks.some(b=>!available.some(a=>a.id===b.id&&a.textKey===b.textKey)))controller.stop('Đã dừng vì nội dung trình chiếu thay đổi.',true);
  }
  addIcons();renderState(controller.snapshot());
 }
 function scheduleRefresh(){if(refreshQueued)return;refreshQueued=true;requestAnimationFrame(()=>{refreshQueued=false;refresh()})}
 TTSPresentation.subscribe(packet=>{
  if(packet.type!=='ttsRegistry'||!packet.context||!Number.isInteger(packet.context.index))return;
  if(packet.closed){if(TTSPresentation.same(packet.context,tvContext)){tvContext=null;registry=null;refresh()}return}
  tvContext=packet.context;
  if(!TTSPresentation.same(packet.context,context())){registry=null;refresh();return}
  if(!Array.isArray(packet.blocks))return;
  if(TTSPresentation.same(registry?.context,packet.context)&&(packet.stateVersion||0)<(registry.stateVersion||0))return;
  registry={...packet,blocks:packet.blocks.filter(b=>['content','hint','analysis','answer'].includes(b.region)&&Number.isInteger(b.index)&&b.id===b.region+':'+b.index&&typeof b.text==='string'&&b.text.length<=20000&&b.textKey===TTSPresentation.textKey(b.text))};refresh();
 });
 function cancelOnPresentation(packet){if(packet?.type==='state'&&controller.ownsSpeech&&!TTSPresentation.same(packet,context()))controller.stop('Đã dừng vì cửa sổ GV khác đổi nội dung TV.',true)}
 if(typeof bc!=='undefined')bc?.addEventListener?.('message',event=>cancelOnPresentation(event.data));
 window.addEventListener('message',event=>{if(event.origin===location.origin)cancelOnPresentation(event.data)});
 window.addEventListener('storage',event=>{if(event.key===STATE_KEY&&event.newValue)try{cancelOnPresentation(JSON.parse(event.newValue))}catch(_){}});
 el('ttsMain').onclick=()=>controller.state==='SPEAKING'?controller.pause():controller.state==='PAUSED'?controller.resume():readSelected();
 el('ttsStop').onclick=()=>controller.stop();el('ttsReplay').onclick=readSelected;
 el('ttsVoice').onchange=e=>controller.configure({voice:e.target.value});
 el('ttsRate').onchange=e=>controller.configure({rate:Number(e.target.value)});
 el('ttsGenderPreference').onchange=e=>controller.configure({preferredGender:e.target.value,voice:''});
 el('ttsKnownGender').onchange=e=>controller.setVoiceGender(e.target.value);
 el('ttsHighlight').onchange=e=>controller.configure({highlight:e.target.checked});
 el('ttsVolume').onchange=e=>controller.configure({volume:Number(e.target.value)});
 new MutationObserver(scheduleRefresh).observe(el('screen'),{childList:true,subtree:true});
 for(const id of ['drawControls','coverControls','smartControls'])new MutationObserver(()=>{if(!el(id).hidden)el('displayToolsGroup').open=true}).observe(el(id),{attributes:true,attributeFilter:['hidden']});
 for(const id of ['zipfile','jsonfile'])el(id).addEventListener('change',()=>controller.stop('Đã dừng để nhập bài.',true),true);
 window.addEventListener('beforeunload',()=>controller.stop('',true));
 window.addEventListener('pagehide',()=>controller.stop('',true));
 globalThis.ttsUI={controller,refresh,cancel:reason=>controller.stop(reason||'Đã dừng khi chuyển màn.',true),get blocks(){return available}};
 refresh();
})();
