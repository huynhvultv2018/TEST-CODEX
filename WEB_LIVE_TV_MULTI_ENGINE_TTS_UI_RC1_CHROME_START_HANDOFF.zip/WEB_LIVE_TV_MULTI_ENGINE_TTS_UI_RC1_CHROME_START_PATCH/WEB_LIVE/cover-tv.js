class CoverLayerTV{
 constructor(){
  this.overlay=document.getElementById('coverLayer');this.state=null;this.scope=null;this.revision=0;
  if(typeof ResizeObserver!=='undefined')new ResizeObserver(()=>this.fit()).observe(document.getElementById('figureInner'));
  window.addEventListener('resize',()=>this.fit());
 }
 apply(state,hasGeometry){
  this.state=state;this.scope=state.cover?.scope||null;this.revision=state.cover?.revision||0;
  this.hasGeometry=hasGeometry;this.fit();
 }
 fit(){
  if(!this.state||!this.hasGeometry){CoverLayer.render(this.overlay,[]);return}
  const record=CoverLayer.read(this.state.lessonId,this.scope);
  if(record.revision<this.revision){
   const ask={type:'needCoverLayer',lessonId:this.state.lessonId,scope:this.scope};
   send(ask);try{window.opener?.postMessage(ask,'*')}catch(_){}
  }
  CoverLayer.render(this.overlay,record.objects);
 }
 refresh(event){
  if(!this.state||event.lessonId!==this.state.lessonId||event.scope!==this.scope)return;
  this.revision=Math.max(this.revision,event.revision||0);this.fit();
 }
 snapshot(event){
  if(!this.state||event.lessonId!==this.state.lessonId||event.scope!==this.scope||!Array.isArray(event.record?.objects))return;
  CoverLayer.write(event.lessonId,event.scope,event.record);
  this.refresh({lessonId:event.lessonId,scope:event.scope,revision:event.record.revision});
 }
 storage(event){
  if(this.state&&event.key===CoverLayer.storageKey(this.state.lessonId,this.scope))this.fit();
 }
}
