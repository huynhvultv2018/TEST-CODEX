"""Exercise real loopback servers and native browser CORS, without Windows app launching."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import ast
import hashlib
import hmac
import http.client
import json
import os
import subprocess
import tempfile
import threading
from http.server import ThreadingHTTPServer

root=Path(os.environ.get('WEB_LIVE_HTTP_PATCH_ROOT', str(Path(__file__).resolve().parent.parent)))
out=root/'LOCAL_HTTP_EVIDENCE';out.mkdir(exist_ok=True)
sys.path.insert(0,str(root/'LAUNCHER'))
import web_live_http as web
import WebLiveLauncher as launcher
import start_web_live as startup


def request(port,path,*,origin=None,method='GET',headers=None,body=None,host=None):
    fields=dict(headers or {})
    if origin is not None:fields['Origin']=origin
    if host is not None:fields['Host']=host
    conn=http.client.HTTPConnection('127.0.0.1',port,timeout=3)
    try:
        conn.request(method,path,body=body,headers=fields)
        r=conn.getresponse();data=r.read();return r.status,dict(r.headers),data
    finally:conn.close()


def main():
    for p in (root/'LAUNCHER').glob('*.py'):ast.parse(p.read_text())
    installation_id,key=launcher.load_installation(root/'LAUNCHER/launcher-config.json')
    service=launcher.LauncherService(root/'LAUNCHER',launcher.load_registry(root/'LAUNCHER/launcher_apps.json'),tv_monitor_index=launcher.load_display_config(root/'LAUNCHER/launcher-display.json'))
    api=ThreadingHTTPServer((launcher.HOST,launcher.PORT),launcher.LauncherHandler);api.daemon_threads=True
    api.service=service;api.pairing=launcher.Pairing(installation_id,key)
    http=web.create_web_server(root)
    threads=[threading.Thread(target=s.serve_forever,daemon=True) for s in (api,http)]
    for t in threads:t.start()
    checks=[];children=[]
    try:
        for origin in sorted(web.ALLOWED_WEB_ORIGINS):
            status,headers,body=request(47381,'/status',origin=origin)
            assert status==200 and headers.get('Access-Control-Allow-Origin')==origin
            challenge=json.loads(body);assert challenge['status']=='PAIR_REQUIRED'
            status,headers,_=request(47381,'/pair',origin=origin,method='OPTIONS',headers={'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type','Access-Control-Request-Private-Network':'true'})
            assert status==204 and headers.get('Access-Control-Allow-Origin')==origin
            assert headers.get('Access-Control-Allow-Private-Network')=='true'
            proof=hmac.new(key,f"WEBLIVE-PAIR-V1.1.4\n{challenge['instanceId']}\n{challenge['challenge']}".encode(),hashlib.sha256).hexdigest()
            status,headers,body=request(47381,'/pair',origin=origin,method='POST',headers={'Content-Type':'application/json'},body=json.dumps({'challenge':challenge['challenge'],'proof':proof}))
            assert status==200
            paired=json.loads(body);assert paired['status']=='READY'
            token=paired['token']
            status,headers,body=request(47381,'/status',origin=origin,headers={'X-WebLive-Token':token})
            assert status==200 and json.loads(body)['status']=='READY'
            status,_,body=request(47381,'/pair',origin=origin,method='POST',headers={'Content-Type':'application/json'},body=json.dumps({'challenge':challenge['challenge'],'proof':proof}))
            assert status==401 and json.loads(body)['error']=='EXPIRED_CHALLENGE'
            status,_,body=request(47381,'/return',origin=origin,method='POST',headers={'Content-Type':'application/json','X-WebLive-Token':'invalid'},body='{}')
            assert status==401 and json.loads(body)['error']=='INVALID_TOKEN'
            checks.append({'check':'Exact origin, preflight/PNA, HMAC pair, authenticated status, one-use challenge, token protection','origin':origin,'result':'PASS'})
        for denied in [None,'null','*','http://127.0.0.1:47383','http://localhost:8765','https://127.0.0.1:47382','http://127.0.0.1:47382.evil.example','https://evil.example']:
            for method,path in [('GET','/status'),('OPTIONS','/pair'),('POST','/pair')]:
                status,headers,_=request(47381,path,origin=denied,method=method,headers={'Access-Control-Request-Method':'POST','Content-Type':'application/json'},body='{}' if method=='POST' else None)
                assert status==403 and 'Access-Control-Allow-Origin' not in headers
            checks.append({'check':'Untrusted origin GET/OPTIONS/POST denied with no ACAO','origin':denied,'result':'PASS'})
        status,_,body=request(47381,'/')
        assert status==403 and json.loads(body)['error']=='ORIGIN_DENIED'
        checks.append({'check':'Direct API address bar/no Origin is not the Teacher site','http':status,'result':'PASS'})
        status,_,_=request(47381,'/status',origin=web.TEACHER_URL.rsplit('/WEB_LIVE/',1)[0],host='evil.example:47381')
        assert status==403
        status,_,_=request(47381,'/pair',origin='http://127.0.0.1:47382',method='OPTIONS',headers={'Access-Control-Request-Method':'DELETE'})
        assert status==403
        checks.append({'check':'Wrong Host and wrong preflight method denied','result':'PASS'})
        for path in ['/LAUNCHER/launcher-config.json','/WEB_LIVE/../LAUNCHER/launcher-config.json','/WEB_LIVE/%2e%2e/LAUNCHER/launcher-config.json','/WEB_LIVE/','/WEB_LIVE/%5c..%5cLAUNCHER/launcher-config.json']:
            status,headers,_=request(47382,path);assert status==404 and 'Access-Control-Allow-Origin' not in headers
        for host in ['127.0.0.1:47382','localhost:47382']:
            status,headers,body=request(47382,'/WEB_LIVE/teacher.html',host=host)
            assert status==200 and body==(root/'WEB_LIVE/teacher.html').read_bytes()
            status,headers,body=request(47382,'/WEB_LIVE/teacher.html',host=host,method='HEAD')
            assert status==200 and not body
        status,headers,_=request(47382,'/');assert status==302 and headers['Location']=='/WEB_LIVE/teacher.html'
        status,_,_=request(47382,'/WEB_LIVE/teacher.html',host='evil.example:47382');assert status==403
        status,_,_=request(47382,'/WEB_LIVE/teacher.html',origin='null');assert status==403
        status,_,_=request(47382,'/WEB_LIVE/teacher.html',headers={'Sec-Fetch-Site':'cross-site'});assert status==403
        status,headers,_=request(47382,'/WEB_LIVE/teacher.html',headers={'Sec-Fetch-Site':'cross-site','Sec-Fetch-Mode':'navigate','Sec-Fetch-Dest':'document'})
        assert status==200 and 'Access-Control-Allow-Origin' not in headers
        checks.append({'check':'Static WEB root/redirect/HEAD and exact Host; no config/directory/traversal/cross-site subresource exposure; ordinary document navigation allowed','result':'PASS'})
        # Running patched services are reused; no new processes or browser are created here.
        assert startup.start_services(root)==[]
        try:
            startup.ensure_service(root/'LAUNCHER/WebLiveLauncher.py','http://127.0.0.1:47381/',lambda _:False,'CONFLICT TEST')
            raise AssertionError('Occupied port must be rejected')
        except startup.StartupError:pass
        checks.append({'check':'Bootstrap readiness and reuse; occupied/legacy endpoint rejected without kill or port fallback','result':'PASS'})
        with tempfile.TemporaryDirectory() as temporary:
            link=root/'WEB_LIVE'/'__http_test_symlink__'
            try:
                hidden=Path(temporary)/'outside.txt';hidden.write_text('outside marker')
                link.symlink_to(hidden)
                assert request(47382,'/WEB_LIVE/__http_test_symlink__')[0]==404
                checks.append({'check':'Symlink outside WEB_LIVE is denied','result':'PASS'})
            finally:link.unlink(missing_ok=True)
        result={'environment':'LINUX CLOUD; actual production HTTP server/LauncherHandler/Pairing/LauncherService, no API mock. Win32 desktop unavailable, no application launch attempted.','web':'http://127.0.0.1:47382/WEB_LIVE/teacher.html','launcher':'http://127.0.0.1:47381','bind':'127.0.0.1 only','allowedOrigins':sorted(web.ALLOWED_WEB_ORIGINS),'checks':checks,'WindowsBatPhysical':'PENDING'}
        # Exercise real process startup of the new static server, with the production API still running.
        http.shutdown();http.server_close();threads[1].join(timeout=3)
        children=startup.start_services(root)
        assert len(children)==1 and children[0].poll() is None
        assert startup.start_services(root)==[]
        checks.append({'check':'Bootstrap starts real web_live_http.py subprocess at fixed port and reuses production API; second invocation reuses both','result':'PASS'})
        (out/'http-api-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        env=dict(os.environ,WEB_LIVE_HTTP_PATCH_ROOT=str(root))
        subprocess.run(['node',str(Path(__file__).with_name('browser.cjs'))],env=env,check=True)
        print(json.dumps({'apiChecks':len(checks),'result':'PASS','browserEvidence':'browser-runtime.json','WindowsBatPhysical':'PENDING'},indent=2))
    finally:
        for child in children:
            if child.poll() is None:child.terminate();child.wait(timeout=5)
        for server in (api,http):server.shutdown();server.server_close()
        for thread in threads:thread.join(timeout=3)


if __name__=='__main__':main()
