# HTTP / origin runtime checks

Kiểm tra bằng Python 3.10+, Node.js, Playwright và Chromium. Không cần các công cụ kiểm thử này để chạy WEB LIVE trên Windows; runtime chính chỉ cần Python 3.10+ như baseline.

Thực thi từ thư mục patch, khi hai port 47381/47382 đang trống:

```sh
python -B LOCAL_HTTP_TESTS/run.py
```

`WEB_LIVE_HTTP_PATCH_ROOT` có thể đổi absolute root. Browser harness trong vòng cloud dùng `/usr/bin/chromium`; môi trường khác cần chỉnh executable trong bản sao kiểm thử. Không dùng việc sửa harness để sửa source sản phẩm.

Harness dùng HTTP server và LauncherHandler/Pairing/LauncherService thật. Chrome fetch/CORS/HMAC thật, không mock API. Trên Linux, desktop Win32 không khả dụng và không launch Word/GeoGebra. Không gọi speak và không kiểm TTS. Các checks gồm hai origin chính xác, preflight/PNA, pair/token, origin bị từ chối, Host, traversal/symlink, static assets, process startup/reuse, Teacher→TV popup/Next/Previous.

Harness ghi lại LOCAL_HTTP_EVIDENCE, nên chạy trên bản sao nếu muốn giữ checksum artifact đã bàn giao. Kiểm thử .bat và chuyển cửa sổ ứng dụng trên Windows thật còn riêng; kết quả cloud không chứng nhận phần đó.
