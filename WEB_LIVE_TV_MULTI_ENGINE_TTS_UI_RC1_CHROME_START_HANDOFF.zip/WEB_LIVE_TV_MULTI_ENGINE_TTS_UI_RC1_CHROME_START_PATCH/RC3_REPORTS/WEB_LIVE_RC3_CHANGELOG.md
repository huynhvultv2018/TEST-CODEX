# RC3_PED1 — CHANGELOG

**Trạng thái candidate: PARTIAL — chưa có runtime acceptance. Không Production.**

Baseline accepted V1.1.5 TV DEMO HANDOFF được giữ read-only. Không gán version release mới.

- Thêm `pedagogy.js`: đọc contract/nested guidance, Hint 1/2, stage/core và gating Knowledge Close.
- Thêm `pedagogy-teacher.js`: panel GV cho flow/policy/probe/response/error/resource/online/offline; điều khiển Hint 2 và chốt; khôi phục task RC3 sau refresh với disclosure ẩn.
- `teacher.js`: disclosure state/reset/render/sync theo RC3; giữ legacy Hint/Answer; restore task/timer hợp lệ theo sourceKey.
- `tv.js`: render đúng Hint được GV chọn; chốt chỉ theo state GV; không đưa panel/private guidance lên TV.
- `teacher.html`, `tv.html`: nạp module; vùng chờ chốt; nút GV và panel Teacher-only. Không thay CSS/layout tổng thể.
- Đính kèm README candidate và 3 LIVE RC3_PED1 nguyên byte để nhập test; không sửa lesson.json hoặc ảnh bên trong.

Không đổi image resolver, Geometry Scene, Math Atomic, Draw/Cover/Smart/Classroom, Focus/Highlight/Pointer/Timer engine, Demo/Launcher, whitelist, auto-pair, confirm hay offline assets. Không sửa producer/Soạn/PPCT/SGK/methodology; không redesign; không Production.

Validation: INPUT LOCK + integrity + syntax PASS; 95 kiểm contract VM PASS; 11 suite regression non-browser PASS; runtime/end-to-end PARTIAL vì gaps đã ghi. Dừng tại WEB_LIVE_PEDAGOGY_RC3_CANDIDATE.zip.

