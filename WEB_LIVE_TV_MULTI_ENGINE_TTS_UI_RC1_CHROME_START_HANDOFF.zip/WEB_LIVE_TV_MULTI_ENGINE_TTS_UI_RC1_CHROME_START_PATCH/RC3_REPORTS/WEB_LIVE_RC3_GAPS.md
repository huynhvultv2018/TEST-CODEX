# RC3_PED1 — GAPS

**Trạng thái candidate: PARTIAL — chưa có runtime acceptance. Không Production.**

| ID | Gap | Bằng chứng | Ảnh hưởng / xử lý tiếp |
|---|---|---|---|
| GAP-01 | Chưa hoàn tất export từ SOẠN_TRƯỚC đã khóa | export_attempt.log; producer giữ validate, thiếu library/tin6/PPCT_TIN_6.docx và SGK_TIN_6.pdf | Chưa chứng nhận chuỗi end-to-end; cung cấp đúng nguồn đã khóa để export lại. Không sửa output |
| GAP-02 | Browser local bị chính sách từ chối trước navigation ở audit trước | browser_block_prior_attempt.json | Không có DOM/screenshot/console runtime candidate; không workaround; acceptance trên laptop + TV |
| GAP-03 | Windows/Word/GeoGebra/monitor handoff chưa chạy thật | Regression API/mock đạt, không có app cài trong môi trường | Giữ Launcher/Demo byte-identical; cần máy Windows kiểm |
| GAP-04 | Readability/fullscreen/overlay/latency/storage browser/offline thực chưa đo | Chỉ VM và asset/hash | Không kết luận CLASSROOM hoặc SYNC thực PASS |

Không có INPUT MISMATCH: INPUT_LOCK PASS, user ĐẠT/acceptance đúng hash. Gaps trên không phải lỗi đã tái hiện của source input và không cho phép sửa SOẠN_TRƯỚC. Không có P0/P1 source FAIL đã xác nhận còn mở; không đủ runtime để tuyên bố không có P0/P1 thực tế. Không tự mở feature/RC mới hoặc Production.

Các nhãn cũ V1.1.4 trong teacher title và V1.1.1 trên importer vẫn còn từ baseline; identity candidate được ghi trong README_RC3_CANDIDATE.md/report. Không đổi nhãn runtime ngoài phạm vi.

