# WEB LIVE RC3 INPUT LOCK REPORT

**INPUT_LOCK = PASS**

**SOAN_TRUOC_RC3 = LOCKED**

**WEB_LIVE_BASELINE = LOCKED**

Input01 được thầy chỉ định lại là RC3_PED1_BAN_GIAO.zip. Chỉ định này thay điều kiện tên PEDAGOGY_PATCH_RC3.zip ở các lượt trước. Không tự thay bằng candidate khác. Gói gốc bổ sung PEDAGOGY_PATCH_RC3.zip cũng khớp hash 52e666… nhưng không là điều kiện chặn cho input01 mới.

| Input | File | Identity/version | SHA-256 | Trạng thái |
|---|---|---|---|---|
| INPUT-01 | RC3_PED1_BAN_GIAO.zip | plugin0.5.0-rc.3; refinementRC3_PED1; core tích hợp và patch PED1 | `18ad3cfe658e6875b9543357c3a418678593e64de2d9f388f0002cb276bfc210` | PASS |
| INPUT-02 JSON | TIN6_W05_SOAN_TRUOC_RC3_PED1.json trong INPUT01 | Tin6 tuần5/tiết5; TIN_SGK_PREP_3; RC3_PED1 | `1b111ac24a17f5192c2989bc74178a0a9a58a1c7bda18bf841c4fd6c8da47e2c` | PASS / LOCKED / userĐẠT |
| INPUT-02 Markdown | TIN6_W05_SOAN_TRUOC_RC3_PED1.md trong INPUT01 | Cùng bản soạn được thầy xác nhận | `1240d3cb608884a6cc4791eb4130427bb0a14d672e314012e5821771bd02afca` | PASS / LOCKED |
| INPUT-03 | WEB_LIVE_V1.1.5_TV_DEMO_HANDOFF_CANDIDATE(1).zip | WEB LIVE V1.1.5 TV DEMO HANDOFF | `eb0647c3ea9a4b6d1188208942fe92a4598b239fc8bfa51a78f893faaf75505b` | PASS / LOCKED / useracceptance |

Dung lượng INPUT01=7347950 byte; INPUT03=1572966 byte; JSON86730byte; Markdown18062byte. CRC ZIP hợp lệ.15/15checksum nội bộ INPUT01 khớp;15/15file patchPED1 trùng core tích hợp. Core chứa pedagogy_flow/policy,prepare_guard/export và outputRC3_PED1; không dựng lại RC3 từ báo cáo. Snapshot producer không cài/không sửa.

Compatibility: đúng Tin6 tuần5/tiết5; contractPREP_3; hai lock=true; PEDAGOGY_FLOW/POLICY/refinement/evidenceLinks; hint1/2/probe/response/commonError trong guidance; CORE_STATUS/timeBudget/resource và online/offline mapping. Trạng thái useracceptance được kế thừa đúng cặp hash đã xác nhận, không hỏi lại.

Baseline51file chỉ đọc; SHA từng file và danh sách tại WEB_LIVE_RC3_TEST_EVIDENCE/INPUT_LOCK.json. Teacher HTML còn nhãnV1.1.4 cũ trong archiveV1.1.5; ghi nhận, không chọn baseline khác. Tạo workingcopy candidate sau thời điểm ghi PASS này. Mọi câu hỏi/đáp án/hint/thứ tự/ảnh/PPCT/SGK của input được giữ nguyên.

Không sửa Production hoặc baseline acceptance. Runtime acceptance candidate là bước sau; INPUT_LOCK PASS không đồng nghĩa runtimePASS.
