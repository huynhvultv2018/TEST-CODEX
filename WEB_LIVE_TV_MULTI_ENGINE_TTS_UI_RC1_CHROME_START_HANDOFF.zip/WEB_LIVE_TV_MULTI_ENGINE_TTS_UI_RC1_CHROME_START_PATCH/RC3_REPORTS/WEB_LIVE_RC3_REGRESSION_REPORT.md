# RC3_PED1 — REGRESSION REPORT

**Trạng thái candidate: PARTIAL — chưa có runtime acceptance. Không Production.**

Ngày kiểm tra: 2026-10-01. Baseline duy nhất: WEB LIVE V1.1.5 TV DEMO HANDOFF, SHA-256 `eb0647c3ea9a4b6d1188208942fe92a4598b239fc8bfa51a78f893faaf75505b`. INPUT-01/02/03 được user xác nhận, khóa trước mọi patch. Không sửa SOẠN_TRƯỚC, SGK/PPCT, ảnh, lesson.json hoặc producer.

| Suite | Kết quả giới hạn |
|---|---|
| `test_math_atomic.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `test_classroom.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `stress_rc.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `ui_test_draw_board_regression.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `ui_test_lesson_switch.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `ui_test_v050_regression.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `test_tv_presentation.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `test_current_session.cjs` | PASS — non-browser, mock DOM/Windows khi có |
| `test_ui_structure.py` | PASS — non-browser, mock DOM/Windows khi có |
| `test_tv_handoff.py` | PASS — non-browser, mock DOM/Windows khi có |
| `test_launcher.py` | PASS — non-browser, mock DOM/Windows khi có |

Test source kế thừa đúng harness baseline V1.1.5; chỉ đổi đường dẫn nguồn candidate và nạp dependency pedagogy.js trước teacher.js/tv.js trong VM. Assertion cũ giữ nguyên. Node VM không phải browser; test Launcher API dùng process Python/API local và Windows handoff dùng mock, không mở Word/GeoGebra thật.

| Bộ dữ liệu | Kết quả |
|---|---|
| Tin6 W4, Tin6 W5, Tin8 W4 RC3_PED1 | 41 + 32 + 29 = 102 screen; mapping contract/metadata PASS |
| 7 fixture producer, baseline accepted và candidate | 198 screen mỗi lượt; importer, source trace, geometry, hidden answer PASS. Tên alias V1_0_0_RC1/V1_1_3 trong script gốc chỉ là label; paths thực dùng V1.1.5 baseline / RC3 candidate |
| 3 LIVE cũ thầy cung cấp | Tin6 W4 RC2 39, Tin6 W5 RC2 27, Tin8 W4 RC2 27; tổng 93 screen import + hidden answer + prose legacy PASS |
| Hình học T04/T07, T04/T08 và text-only | Scene image/analysis tách riêng, đổi bài, TV cache activation/source: PASS trong VM |
| 8 resource ảnh RC3_PED1 | SHA khớp MEDIA_PLAN, PNG giải mã được; không sửa ảnh |

Geometry Scene, image inheritance, analysis diagram, Math Atomic, Draw Board, kéo point/label, Cover, Smart Geometry, Focus/Highlight, Pointer, Timer, layout/zoom, TV nhận state và reload được kiểm trong harness. Các engine và Launcher không đổi byte. Không có assertion FAIL còn mở sau patch; không suy ra browser/Windows regression PASS từ điều đó.

Stress VM baseline harness: 300 navigation, 210 đổi layout, 150 zoom, 50 focus, 31 highlight, 76 thao tác fullscreen giả lập, 60 timer, 12 activation lesson, TV reload. Stress contract mới: thêm 300 navigation, mỗi bước không lộ Hint/Answer. Không đánh giá heap leak, animation frame rate, tọa độ CSS thực, latency màn hình hoặc đọc ở 3/5/7 m.

Offline ở đây: asset cục bộ, không CDN/API Internet mới, harness chạy local. Chưa ngắt Internet trên máy Windows thật. Lesson Tin8 W4 có onlineDependency vẫn chỉ đọc cảnh báo/fallback đã có, không biến nó thành nhiệm vụ offline tự chế.

