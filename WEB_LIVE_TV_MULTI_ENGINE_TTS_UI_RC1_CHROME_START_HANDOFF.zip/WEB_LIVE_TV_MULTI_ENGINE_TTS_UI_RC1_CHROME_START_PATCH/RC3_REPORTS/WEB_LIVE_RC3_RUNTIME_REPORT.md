# RC3_PED1 — RUNTIME REPORT

**Trạng thái candidate: PARTIAL — chưa có runtime acceptance. Không Production.**

**Browser runtime = NOT RUN. Windows / Teacher–TV thật = NOT RUN.** Không có ảnh chụp, DOM browser hoặc console của candidate. Node VM dùng DOM doubles chỉ kiểm logic; mọi PASS VM dưới đây không thay thế runtime acceptance.

## End-to-end Tin6 tuần5

INPUT-02 mới nhất đã ĐẠT được khóa SHA. EXPORT với producer nguyên gốc: BLOCKED do thiếu PPCT/SGK source; không bypass. PACKAGE bàn giao W5 RC3_PED1 → native IMPORT → Teacher/TV renderer trong VM: PASS. RUNTIME browser/học sinh: PENDING. Không dùng output RC2 làm đại diện.

## Flow giữ nguyên

Bảng là đối chiếu source và render VM, không phải quan sát HS thật.

| STT | SOẠN_TRƯỚC | WEB LIVE | TV | HS làm gì | Kết quả |
|---|---|---|---|---|---|
| 1 | `T6W5_OPEN_01` — SETTLE | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Chuẩn bị SGK và một tờ giấy để ghi các dãy kí hiệu. | VM PASS; lớp thật PENDING |
| 2 | `T6W5_OPEN_02` — OLD_LESSON_CHECK | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Theo bài trước, bộ nhớ máy tính dùng để làm gì? | VM PASS; lớp thật PENDING |
| 3 | `T6W5_OPEN_03` — LESSON_TRANSITION | Giữ id/content/thứ tự; CURIOSITY | Content; Hint/Answer ẩn | Bộ nhớ lưu thông tin. Vậy chữ, số, hình ảnh và âm thanh được đưa vào máy tính theo cách nào? Mở Bài 3 và quan sát Hoạt động 1. | VM PASS; lớp thật PENDING |
| 4 | `T6W5_01` — OBSERVE | Giữ id/content/thứ tự; OBSERVE | Content; Hint/Answer ẩn | Quan sát Hình 1.3 và đọc hướng dẫn: số 3 lần lượt nằm ở nửa nào của dãy 0–7? | VM PASS; lớp thật PENDING |
| 5 | `T6W5_THINK` — QUESTION | Giữ id/content/thứ tự; THINK | Content; Hint/Answer ẩn | Khi thu hẹp dãy 0–7 như Hình 1.3, em cần quan sát điều gì ở mỗi lần chia? | VM PASS; lớp thật PENDING |
| 6 | `T6W5_PREDICT` — QUESTION | Giữ id/content/thứ tự; PREDICT | Content; Hint/Answer ẩn | Ghi dự đoán ba lần chọn trái/phải của số 2. Giữ lại để đối chiếu sau khi làm theo Hình 1.3. | VM PASS; lớp thật PENDING |
| 7 | `T6W5_02` — DISCOVER | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Làm tương tự Hình 1.3 với số 2. Ghi ba lần trái/phải và dãy 0–1 tương ứng. | VM PASS; lớp thật PENDING |
| 8 | `T6W5_COMPARE` — QUESTION | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | So sánh dự đoán của em với ba lần chọn vừa làm cho số 2. Nếu khác, em cần sửa lần chọn nào? Vì sao? | VM PASS; lớp thật PENDING |
| 9 | `T6W5_03` — DISCOVER | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Làm tương tự với số 6. Ghi ba lần trái/phải và dãy 0–1 tương ứng. | VM PASS; lớp thật PENDING |
| 10 | `T6W5_04` — DISCOVER | Giữ id/content/thứ tự; DISCUSS | Content; Hint/Answer ẩn | Đặt hai dãy của số 2 và số 6 cạnh nhau. Trao đổi với bạn: chúng khác ở vị trí nào, và vì sao lần chọn ấy khác? | VM PASS; lớp thật PENDING |
| 11 | `T6W5_DISCOVER` — DISCOVER | Giữ id/content/thứ tự; DISCOVER | Content; Hint/Answer ẩn | Từ hai dãy vừa so sánh, vì sao chỉ dùng hai kí hiệu mà vẫn phân biệt được số 2 và số 6? | VM PASS; lớp thật PENDING |
| 12 | `T6W5_05` — QUESTION | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Đối chiếu bảng 0–7 trang 13: số 5 được ghi bằng dãy kí hiệu nào? | VM PASS; lớp thật PENDING |
| 13 | `T6W5_06` — KNOWLEDGE | Giữ id/content/thứ tự; STANDARDIZE | Ẩn chốt; GV bấm CHỐT | Mỗi dãy các kí hiệu 0 và 1 trong bảng được gọi là dãy bit; mỗi kí hiệu trong dãy gọi là một bit. | VM PASS; lớp thật PENDING |
| 14 | `T6W5_07` — QUESTION | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Nếu số lớn hơn các số trong bảng 0–7, SGK nói có thể cần điều gì? | VM PASS; lớp thật PENDING |
| 15 | `T6W5_08` — OBSERVE | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Quan sát Bảng 1.2: kí tự A và B được ghi thành hai dãy bit nào? | VM PASS; lớp thật PENDING |
| 16 | `T6W5_09` — QUESTION | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Đọc sơ đồ CAFE ngay dưới Bảng 1.2: thứ tự các dãy bit ứng với bốn chữ như thế nào? | VM PASS; lớp thật PENDING |
| 17 | `T6W5_10` — KNOWLEDGE | Giữ id/content/thứ tự; — | Ẩn chốt; GV bấm CHỐT | Văn bản được chuyển thành dãy bit bằng cách chuyển từng kí tự một theo bảng mã. | VM PASS; lớp thật PENDING |
| 18 | `T6W5_11` — OBSERVE | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Quan sát Hình 1.4: một ô đen và một ô trắng của chữ A được ghi bằng kí hiệu gì? | VM PASS; lớp thật PENDING |
| 19 | `T6W5_12` — QUESTION | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Đọc hàng đầu tiên của Hình 1.4 từ trái sang phải. Dãy bit của hàng ấy là gì? | VM PASS; lớp thật PENDING |
| 20 | `T6W5_13` — KNOWLEDGE | Giữ id/content/thứ tự; — | Ẩn chốt; GV bấm CHỐT | Hình ảnh số tạo bởi các điểm ảnh (pixel); hình đen trắng có thể mã hoá từng ô bằng 0 hoặc 1. Ảnh màu cần nhiều bit hơn cho một pixel. | VM PASS; lớp thật PENDING |
| 21 | `T6W5_14` — OBSERVE | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Quan sát Hình 1.5: nốt La đi qua giá trị số nào trước khi thành dãy bit? | VM PASS; lớp thật PENDING |
| 22 | `T6W5_15` — KNOWLEDGE | Giữ id/content/thứ tự; — | Ẩn chốt; GV bấm CHỐT | Âm thanh được chuyển thành giá trị số rồi thành dãy bit để máy tính xử lí. | VM PASS; lớp thật PENDING |
| 23 | `T6W5_16` — CLOSE | Giữ id/content/thứ tự; — | Ẩn chốt; GV bấm CHỐT | Đọc đoạn đầu trang 15: trong máy tính, văn bản, hình ảnh, âm thanh đều chuyển thành dãy bit; bit là đơn vị đo thông tin nhỏ nhất. | VM PASS; lớp thật PENDING |
| 24 | `T6W5_17` — OBSERVE | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Quan sát Hình 1.6: lưới trái tim có bao nhiêu hàng và mỗi hàng có bao nhiêu ô? | VM PASS; lớp thật PENDING |
| 25 | `T6W5_18` — DISCOVER | Giữ id/content/thứ tự; TEST | Content; Hint/Answer ẩn | Hoạt động 2, câu 1: Viết dãy 0–1 của hàng đầu tiên (trắng = 0, đen = 1). | VM PASS; lớp thật PENDING |
| 26 | `T6W5_19` — DISCOVER | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Hoạt động 2, câu 1: Làm tiếp từng hàng còn lại, kiểm đủ tám kí hiệu mỗi hàng. | VM PASS; lớp thật PENDING |
| 27 | `T6W5_20` — DISCOVER | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Hoạt động 2, câu 2: Ghép tám dãy theo thứ tự từ hàng trên xuống hàng dưới. | VM PASS; lớp thật PENDING |
| 28 | `T6W5_21` — KNOWLEDGE | Giữ id/content/thứ tự; — | Ẩn chốt; GV bấm CHỐT | Chốt khung đỏ SGK trang 15: thông tin trong máy tính được biểu diễn bằng dãy bit; một bit là 0 hoặc 1; bit là đơn vị đo thông tin nhỏ nhất. | VM PASS; lớp thật PENDING |
| 29 | `T6W5_22` — PRACTICE | Giữ id/content/thứ tự; CHECK_UNDERSTANDING | Content; Hint/Answer ẩn | Câu hỏi 1 trang 15: Dãy bit là gì? Chọn một phương án trong bốn lựa chọn SGK. Nêu một lí do ngắn cho lựa chọn của em. | VM PASS; lớp thật PENDING |
| 30 | `T6W5_23` — PRACTICE | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Câu hỏi 2 trang 15: Máy tính sử dụng dãy bit để làm gì? Chọn một phương án SGK. Nêu một lí do ngắn cho lựa chọn của em. | VM PASS; lớp thật PENDING |
| 31 | `T6W5_APPLY` — APPLICATION | Giữ id/content/thứ tự; APPLICATION | Content; Hint/Answer ẩn | Chọn một hàng của Hình 1.6. Nếu đổi một ô trắng thành đen, kí hiệu ở vị trí đó đổi thế nào? Viết lại hàng và đối chiếu với hình em vừa sửa. | VM PASS; lớp thật PENDING |
| 32 | `T6W5_END` — END | Giữ id/content/thứ tự; — | Content; Hint/Answer ẩn | Hoàn thành tiết học | VM PASS; lớp thật PENDING |

## Các chuỗi kiểm tra

| Chuỗi | Node VM | Browser / Windows |
|---|---|---|
| Next → Back → Next | PASS, reset disclosure | PENDING |
| Hint1 → Back → Next | PASS | PENDING |
| Hint1 → Hint2 → Answer → Back | PASS, reset | PENDING |
| Answer → Next → Back | PASS | PENDING |
| Knowledge Close / ẩn chốt | PASS, bấm thủ công | PENDING |
| Teacher refresh | PASS khởi tạo lại VM, đúng task, disclosure ẩn | PENDING F5 thật |
| TV refresh | PASS đọc state/storage trong VM | PENDING F5 thật |
| Teacher–TV sync | PASS truyền state trực tiếp/storage trong VM | PENDING BroadcastChannel/window thực |
| Fullscreen/layout/zoom | PASS logic trong harness/mocks | PENDING CSS/display thực |
| Đổi bài / stress navigation | PASS 2 lượt 300 thao tác, không tự reveal | PENDING |
| LIVE → Demo → LIVE; Demo fail | Regression mock/API PASS; metadata bài chính không có screen.demo native | PENDING Windows app |

## Acceptance còn phải chạy

Giải nén candidate, chạy START_WEB_LIVE.bat trên Windows, import `RC3_PED1_TEST_PACKAGES/TIN6_W05_LIVE_RC3_PED1.zip`. Mở TV, đi 32 màn theo bảng; không bấm reveal phải không lộ Hint/Answer/Knowledge Close. Tại task có hint1/2: Hint1 → Hint2 → Answer; Back/Next phải reset. Tại KNOWLEDGE/CLOSE: chỉ hiện sau CHỐT KIẾN THỨC. Probe/response/error/cảnh báo offline chi tiết không mặc định chiếu TV.

Kiểm F5 GV đúng task nhưng disclosure ẩn, F5 TV theo state đang chọn; sync, fullscreen, zoom, focus, highlight, overlay, timer. Đổi Tin6 W4 → W5 → Tin8 W4 → W5; kiểm các bài RC2. Ngắt Internet kiểm phần trình chiếu local; task cần Internet giữ cảnh báo/fallback đúng dữ liệu, GV quyết định. Chạy Demo sample baseline: cancel không launch, launcher fail vẫn dạy được, confirm mở đúng app/file; TV không launch.

Chạy lại full exporter khi có đúng nguồn PPCT/SGK đã khóa SHA và kiểm gói mới trước runtime. Chỉ khi mọi tiêu chí runtime/end-to-end/regression cần thiết đạt mới xét PASS; nhiệm vụ hiện tại dừng candidate, không Production.

