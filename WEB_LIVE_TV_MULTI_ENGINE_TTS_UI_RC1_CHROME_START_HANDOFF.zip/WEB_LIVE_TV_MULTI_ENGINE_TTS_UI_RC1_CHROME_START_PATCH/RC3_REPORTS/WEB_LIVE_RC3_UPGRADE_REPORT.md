# WEB LIVE — ADAPT TO RC3_PED1 CONTRACT

**Trạng thái candidate: PARTIAL — chưa có runtime acceptance. Không Production.**

Ngày kiểm tra: 2026-10-01. Baseline duy nhất: WEB LIVE V1.1.5 TV DEMO HANDOFF, SHA-256 `eb0647c3ea9a4b6d1188208942fe92a4598b239fc8bfa51a78f893faaf75505b`. INPUT-01/02/03 được user xác nhận, khóa trước mọi patch. Không sửa SOẠN_TRƯỚC, SGK/PPCT, ảnh, lesson.json hoặc producer.

## Khóa đầu vào

`INPUT_LOCK = PASS`; `SOAN_TRUOC_RC3 = LOCKED`; `WEB_LIVE_BASELINE = LOCKED`. RC3_PED1_BAN_GIAO.zip chứa core tích hợp đúng patch PED1, 15/15 checksum nội bộ và 15/15 patch/core trùng. Không yêu cầu lại PEDAGOGY_PATCH_RC3.zip; bản bổ sung nguyên gốc vẫn đối chiếu đúng SHA. Baseline gốc 51 file chỉ đọc, hash trước/sau khớp. Tên archive có CANDIDATE nhưng chính cặp hash này đã được thầy acceptance; không chọn archive khác.

## Audit và minimal patch

Bằng chứng baseline: importer giữ được metadata RC3 nhưng Teacher/TV dùng `s.hint`, không đọc `pedagogyGuidance.hintLevel1/2`; `render()` và `applyState()` đưa trực tiếp `s.content` lên preview/TV, kể cả KNOWLEDGE/CLOSE. Teacher không có panel resource/policy/probe mới; F5 không khôi phục task RC3. Đây là mismatch source với contract, không kết luận đã tái hiện trên TV thật.

Sửa 4 file: `WEB_LIVE/teacher.html`, `teacher.js`, `tv.html`, `tv.js`. Thêm 2 file: `pedagogy.js`, `pedagogy-teacher.js`. Diff lưu trong evidence. Không sửa `common.js`, `zip.js`, CSS layout, image resolver, geometry, các engine vẽ/cover/smart/classroom, demo client hoặc Launcher. 47/51 file baseline trùng byte trong candidate; 51/51 file baseline gốc vẫn nguyên vẹn. README mới và 3 gói test nguyên byte là tài liệu/fixture kèm, không patch runtime khác.

## Mapping

| Contract | Mapping giữ nguyên | Runtime hỗ trợ |
|---|---|---|
| pedagogyStage | screen.pedagogyStage hoặc pedagogyFlow | Teacher: vị trí hoạt động; không đổi thứ tự |
| pedagogyGuidance | nested guidance và field tương đương | Teacher Probe, phản hồi dự kiến, lỗi; Hint 1/2 khi GV chọn |
| pedagogyFlow | lesson.pedagogyFlow | Teacher: trình tự + task hiện tại; không tự sinh hoạt động |
| pedagogyLocks | knowledgeFormation / engagement | Giữ metadata, bật xử lý RC3; không sửa lock |
| pedagogyPolicy | critical_task_ids, quick_check_task_ids, max_passive_min, time_reserve_min | Thông tin cho GV; không tự skip |
| hintLevel1 / hintLevel2 | screen hoặc nested pedagogyGuidance | Ẩn ban đầu; Hint 2 chỉ sau Hint 1; hiển thị tích lũy |
| teacherProbe / expectedResponse / commonError | screen hoặc nested guidance | Chỉ panel GV; không render TV |
| resourceRequired / Location / Focus | screen metadata + assets gốc | GV biết SGK/WEB_LIVE; ảnh public dùng renderer cũ; Focus/Cover/Highlight do GV chọn |
| onlineDependency / offlineFallback / offlineWarning | screen metadata | Panel GV; không tự tạo fallback/skip task |
| CORE / OPTIONAL / SHORTENABLE | coreStatus hoặc CORE_STATUS | Hiển thị nguyên trạng, không tái phân loại |
| timeBudgetMin | screen.timeBudgetMin | Hiển thị thời lượng; không tự đổi timer |

Metadata giữ nguyên trong bài đã import. Không duplicate schema, không sửa producer và không cài patch vào plugin đang dùng. WEB LIVE là tầng đọc cuối của PPCT → SGK_STRUCTURE_LOCK → KNOWLEDGE_FORMATION_LOCK → ENGAGEMENT_LOCK → SOẠN_TRƯỚC → CONTRACT → RUNTIME; nó không thay đổi tầng trên.

## Quy tắc mở nhiệm vụ

Hint, Answer và Knowledge Close ẩn khi mở/quay lại task. Hint 1 → Hint 2 là thao tác GV; Hint 2 tích lũy Hint 1. Answer/BƯỚC + vẫn dùng cơ chế cũ. KNOWLEDGE, CLOSE, KNOWLEDGE_CLOSE hoặc STANDARDIZE của bài RC3 cần nút CHỐT KIẾN THỨC; GV có thể xem trước trong sidebar. Màn chốt chờ GV thay vì chiếu nội dung mặc định. Bài legacy không mang contract RC3 giữ hành vi cũ.

F5 Teacher RC3 lấy bài/sourceKey/task index đã lưu; mở task với mọi disclosure ẩn. Timer hợp lệ được khôi phục, không resume app hoặc thao tác vẽ dở. TV reload đọc disclosure đang lưu. State chỉ thêm `pedagogy: {hintLevel,knowledgeCloseVisible}`; không đưa probe/response/error vào state. Bài lesson đầy đủ vẫn truyền/cache theo cơ chế baseline, nên Teacher-only là giới hạn hiển thị UI, không phải tuyên bố dữ liệu không bao giờ nằm trong cache TV.

CORE không tự skip. OPTIONAL/SHORTENABLE chỉ báo cho GV. ResourceFocus là chỉ dẫn giữ nguyên, không suy đoán tọa độ/auto crop. Online fallback chỉ thể hiện dữ liệu có sẵn; thiếu fallback không tạo nội dung thay thế. Demo chỉ mở sau thao tác và confirmation hiện có.

## Năm LIVE LOCK

| LIVE LOCK | Kiểm tra đã thực hiện | Kết luận |
|---|---|---|
| LIVE-LOCK-01 — NO EARLY ANSWER | Reset Hint/Answer/Knowledge Close; gating Teacher/TV, Back/Next/F5 trong Node VM | PASS trong mô phỏng; PARTIAL runtime thật |
| LIVE-LOCK-02 — ONE SCREEN ONE TASK | 32 task W5 giữ đúng id, content, answer, thứ tự; không gộp/sinh thêm screen | PASS đối chiếu contract; PARTIAL quan sát runtime |
| LIVE-LOCK-03 — ACTIVE STUDENT | Giữ Question/Think/Predict/Discuss/Check/Application; Teacher Probe + policy; GV chủ động reveal | PASS mapping; PARTIAL hoạt động HS trên lớp |
| LIVE-LOCK-04 — TRACEABILITY | Giữ sourceRef/sgkTrace/teachingTrace/flow/evidence links; asset SHA khớp | PASS audit; chưa chạy lại exporter thiếu nguồn |
| LIVE-LOCK-05 — DEMO FAIL-SAFE | Không đổi demo/launcher; regression late start/re-pair/confirm/return/TV không có quyền launch | PASS mô phỏng và API test; PARTIAL Windows thật |

## Kết quả và giới hạn

95 kiểm tra contract/render/state bằng Node VM đạt; 3 gói RC3_PED1 tổng 102 screen khớp task/answer/guidance/flow/metadata; 8 ảnh khớp SHA và giải mã được. 7 fixture importer/198 screen, 3 package RC2/93 screen và 11 suite hồi quy đạt trong phạm vi non-browser. Không dùng gói LIVE cũ làm test chính W5 RC3_PED1.

Chạy lại exporter nguyên gốc với INPUT-02 bị chặn bởi PPCT_TIN_6.docx và SGK_TIN_6.pdf không có trong snapshot core bàn giao. Không bypass validator, không sửa input, không sinh gói export giả. Gói LIVE W5 RC3_PED1 đã bàn giao được import trực tiếp, đối chiếu mapping byte/nội dung để kiểm phần downstream, chưa chứng nhận toàn chuỗi EXPORT mới → RUNTIME.

Browser trước đó từ chối file: trước navigation. Không vượt bằng server/alternate browser. Chưa có DOM browser/screenshot/console/TV thật; F5/fullscreen/sync/offline/overlay/Word/GeoGebra trên Windows còn phải kiểm acceptance. Candidate không thay baseline acceptance, không nâng version release hoặc Production. Dừng sau đóng gói/checksum.

