# Tin học — Activity Cards

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

PASS cloud: ba gói thật TIN6_W04 (41 màn), TIN6_W05 (32 màn), TIN8_W04 (29 màn). Mỗi màn được kiểm tra câu hỏi và đáp án/phân tích đầy đủ.

MCQ thật TIN6_W04 màn index 14 được tách thành câu hỏi và bốn option card 2×2, không còn đoạn văn chứa cả đáp án lựa chọn. Các option không được đánh dấu đúng/sai. Thêm kiểm tra options[] explicit 2/3/4/5 lựa chọn, parser bất liên tiếp fallback; option dài dùng một cột.

Observe ưu tiên ảnh; knowledge chờ GV chốt vẫn ẩn; review/intro/practice/application dùng hierarchy nguồn và badge chung. Application chỉ tách sản phẩm nếu nguồn cung cấp nhãn chắc chắn. Nguồn không có sản phẩm không được thêm yêu cầu mới. Demo là nhiệm vụ quan sát, không phát lệnh mở ứng dụng.

Ảnh TIN_01–07 dùng gói Tin thật. TIN_08_PRACTICAL và TIN_09_DEMO là fixture trình bày vì các gói Tin hiện có không có hai type này; không xuất chúng thành LIVE.zip. Gói Demo thật được nhập riêng để kiểm tra Teacher/TV và hợp đồng thao tác Demo.

Xem PNG và nguồn từng ảnh trong VISUAL_REPORT. Chưa xác nhận bằng màn TV vật lý.
