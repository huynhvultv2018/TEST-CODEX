# WEB LIVE — LOCAL HTTP PATCH

Đây là bản sao từ TTS UI RC1; không bump version, không sửa WEB_LIVE/TTS/MathSpeech/UI/lesson/engine. Chỉ thêm khởi động HTTP và đổi whitelist origin Launcher.

Trên Windows, lần đầu đóng Launcher cũ bằng Ctrl+C. Giải nén toàn bộ gói riêng, chạy START_WEB_LIVE.bat ở thư mục gốc. Cần Python 3.10+. Script bật hai dịch vụ và mở Teacher:

**http://127.0.0.1:47382/WEB_LIVE/teacher.html**

Nhập bài rồi bấm MỞ TV. API Launcher ở 127.0.0.1:47381; đó không phải trang Teacher. Không mở HTML bằng file://.

Whitelist đúng http://127.0.0.1:47382 và http://localhost:47382; không wildcard/null/tùy ý. HMAC/token và cấu hình app/monitor giữ nguyên. Nếu đã tùy chỉnh app/monitor trên máy, giữ cấu hình đó trong bản chạy mới. Helper không tự đổi port hoặc tắt dịch vụ khác; lỗi conflict báo để GV đóng bản cũ rồi chạy lại.

HTTP/browser/API native cloud: WEB HTTP PASS, Launcher running PASS, Origin allowed PASS, Teacher→Launcher PASS, file://dependency NONE, CORS wildcard NONE. Windows .bat/monitor/native app physical PENDING; không dùng cloud để chứng nhận máy thật. TTS không được xử lý ở vòng này.

Đọc LOCAL_HTTP_LAUNCHER_REPORT.md; xem LOCAL_HTTP_EVIDENCE/index.html và JSON/log. Manifest hiện hành LOCAL_HTTP_SHA256SUMS.txt. SHA256SUMS.txt và các báo cáo cũ được kế thừa như lịch sử TTS/UI baseline.

Chạy `sha256sum -c LOCAL_HTTP_SHA256SUMS.txt` từ thư mục patch để kiểm toàn bộ gói. Không production.
