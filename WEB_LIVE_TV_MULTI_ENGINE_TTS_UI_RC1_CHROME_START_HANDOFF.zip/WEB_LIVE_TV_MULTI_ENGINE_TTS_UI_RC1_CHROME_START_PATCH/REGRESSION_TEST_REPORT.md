# Regression test report

Candidate: `WEB_LIVE_TV_MULTI_ENGINE_TTS_UI_RC1_CANDIDATE`.

Baseline duy nhất theo yêu cầu đã dán: `WEB_LIVE_TV_MULTI_ENGINE_RC1_CANDIDATE.zip`.
SHA-256 baseline: `2f7a231fed483c4bf66e047f033988026977c526d4a24f2793375e87e3cef20c`.
Tệp Motion RC1 được đính kèm cùng lượt yêu cầu không được dùng làm baseline vì văn bản yêu cầu khóa rõ Multi Engine RC1.
Ngày lập báo cáo UTC: 2026-10-02T15:09:19.406387+00:00. Browser kiểm thử: Chromium 151.0.7922.173 trên Linux cloud.

| Hạng mục | Kết luận | Phạm vi |
|---|---|---|
| TTS | **PENDING** | Logic tích hợp đạt kiểm thử có speech mô phỏng; chưa có âm thanh Việt thật. |
| CONTROL PANEL | **PASS** | Runtime Chromium cloud, expanded/compact, fullscreen và TV window. |
| REGRESSION | **PASS** | Các ca cloud đã chạy; giới hạn gói Đại số và Windows nêu bên dưới. |
| WINDOWS PHYSICAL TEST | **PENDING** | Chưa chạy máy GV + Chrome + TV/loa thật. |


## Gate cloud

Harness regression baseline được sao chép vào `TTS_UI_TESTS`, đổi output sang evidence mới; ảnh proof fixture chọn màn có hai bước thật để kiểm disclosure. Không sửa test/report/evidence lịch sử baseline. Chạy lại baseline suite và extra suite trên candidate cuối, cùng runtime30 ca.

Năm gói thật có 171 màn, kiểm 342 trạng thái question/full. Tất cả không tràn dọc/ngang theo kiểm tra suite, 0 pageerrors, 0 external requests. 48 ảnh regression được chụp lại, không dùng ảnh baseline cũ để chứng minh candidate mới.

| Gói thật | Màn | Trạng thái | Kết quả |
|---|---:|---:|---|
| `RC3_PED1_TEST_PACKAGES/TIN6_W04_LIVE_RC3_PED1.zip` | 41 | 82 | PASS |
| `RC3_PED1_TEST_PACKAGES/TIN6_W05_LIVE_RC3_PED1.zip` | 32 | 64 | PASS |
| `RC3_PED1_TEST_PACKAGES/TIN8_W04_LIVE_RC3_PED1.zip` | 29 | 58 | PASS |
| `WEB_LIVE/HINH_HOC_8_T04_T07_LIVE_TEST.zip` | 34 | 68 | PASS |
| `WEB_LIVE/HINH_HOC_8_T04_T07_DUAL_VISUAL_TEST.zip` | 35 | 70 | PASS |

## Các assertion baseline đã chạy

- Real TIN6 MCQ: four option cards.
- Knowledge disclosure retained.
- Geometry scene retained across progressive analysis.
- Proof reveal and previousStep hide.
- Pointer and zoom state received.
- Overlay order unchanged.
- Draw Board, Cover, Smart Geometry, Highlight and Focus render real runtime records.
- Timer sync.
- Whiteboard open/close.
- 70/30 preset and TV double-click Teacher round-trip.
- Algebra future steps absent from DOM.
- Tree branching and future-node disclosure.
- Router explicit priority and ambiguous generic; malformed MCQ fallback.
- Whole equation atomic.
- Offline Teacher→TV navigation after local asset load.

## Extra regression

- Explicit option arrays: 2, 3, 4, 5 cards.
- Application task/product separation.
- Factorization, statistics, probability and proof routing.
- Geometry statement GT/KL.
- All seven requested math atomic expressions.
- Full equation answer also uses transformation cards.
- Switching back to explicit GENERIC.
- Actual demo package import and navigation do not auto-launch.
- Demo explicit launch/return UI contract with mock; lesson position unchanged.
- Demo package TV synchronization.
- Real Tin pedagogy hint toggle synchronized.
- Stale TV state rejected.
- Real geometry all four analysis steps plus answer: all four viewports fit.

13 assertions, 0 pageerrors; Hình học all-analysis + answer vừa layout ở 1920×1080, 1600×900, 1366×768, 1280×720.

Runtime 30 bổ sung click UI thật cho PREV/NEXT, Hint/Answer/Chốt, panel collapse/expand, 70/30, 60/40, Hình toàn màn, Phóng chữ, Focus, Drawing/Label và Timer; browser fullscreen, TVwindow, import và TTS lỗi vẫn dùng bài được. Các gói bài/SOẠN_TRƯỚC input trong baseline được import nguyên trạng; không sửa PPCT/SGK/SBT hay dữ liệu để làm layout đạt.

## Integrity / giới hạn

So sánh trực tiếp 144 entry baseline ZIP: 140 tệp gốc giữ nguyên byte, 4 tệp tích hợp Teacher/TV sửa có kiểm soát, không tệp bị thiếu. Engine Tin/Đại số/Hình, lesson ZIP, Launcher, cấu hình và historical reports/screenshots/checksums đều giữ nguyên. Xem `baseline-integrity.json` và `CHANGED_FILES.md`.

Đại số routing/expression/equation/system/word problem/table/graph/factorization/statistics/probability được thử bằng presentation fixtures; baseline không có gói Đại số thật. Do đó chưa chứng nhận bài Đại số thực tế hay tính đúng nội dung chương trình. Demo package import/navigation/TVsync chạy thật, launch/return protocol dùng mock; Windows Word/GeoGebra/monitor handoff chưa thử. Windows physical, HDMIaudio và DPI/driver thật PENDING.

**REGRESSION PASS cho phạm vi cloud đã chạy.** Không phát hiện regression nghiêm trọng trong các ca này. Kết luận không phải chứng nhận production và không thay các gate vật lý/gói Đại số thật còn thiếu.
