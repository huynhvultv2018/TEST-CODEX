# Regression report

Ngày kiểm tra: 02/10/2026. Baseline duy nhất: WEB_LIVE_TV_LAYOUT_RC4_CANDIDATE.zip. Trạng thái: RC1 CANDIDATE; chưa nâng production.

## Các kiểm tra thực thi

- PASS — Real TIN6 MCQ: four option cards
- PASS — Knowledge disclosure retained
- PASS — Geometry scene retained across progressive analysis
- PASS — Proof reveal and previousStep hide
- PASS — Pointer and zoom state received
- PASS — Overlay order unchanged
- PASS — Draw Board, Cover, Smart Geometry, Highlight and Focus render real runtime records
- PASS — Timer sync
- PASS — Whiteboard open/close
- PASS — 70/30 preset and TV double-click Teacher round-trip
- PASS — Algebra future steps absent from DOM
- PASS — Tree branching and future-node disclosure
- PASS — Router explicit priority and ambiguous generic; malformed MCQ fallback
- PASS — Whole equation atomic
- PASS — Offline Teacher→TV navigation after local asset load
- PASS — Explicit option arrays: 2, 3, 4, 5 cards
- PASS — Application task/product separation
- PASS — Factorization, statistics, probability and proof routing
- PASS — Geometry statement GT/KL
- PASS — All seven requested math atomic expressions
- PASS — Full equation answer also uses transformation cards
- PASS — Switching back to explicit GENERIC
- PASS — Actual demo package import and navigation do not auto-launch
- PASS — Demo explicit launch/return UI contract with mock; lesson position unchanged
- PASS — Demo package TV synchronization
- PASS — Real Tin pedagogy hint toggle synchronized
- PASS — Stale TV state rejected
- PASS — Real geometry all four analysis steps plus answer: all four viewports fit

171 màn, 342 trạng thái từ năm gói thật; không lỗi JS hoặc overflow. Mọi lesson runtime trước/sau vòng kiểm thử vẫn bằng nhau. ZIP lesson/source giữ nguyên checksum. Gói Demo thật được nhập thêm; không tự launch khi đổi màn.

## Source compatibility

Teacher UI/JS/CSS, Launcher Python/config/demo files, common.js scene resolver, pedagogy runtime, zip.js importer, math-atomic.js và module overlay giữ nguyên từng byte so với RC4. Chỉ bốn file TV thay đổi và bốn module trình bày mới được thêm.

## Giới hạn và mục chưa chạy

- Demo /launch và /return: PASS hợp đồng UI/protocol bằng mock và giữ vị trí lesson. **Chưa chạy** handoff Win32, Word/GeoGebra, chọn màn vật lý, Alt+Tab và return thật. Launcher chỉ hỗ trợ Windows; không biến mock thành PASS end-to-end.
- Đại số thật: **chưa chạy**, không có package trong baseline.
- Laptop/TV thật: **chưa chạy**; overscan, scaling Windows, khoảng cách đọc, thao tác pointer và fullscreen cần kiểm tra thực tế.
- Import tích lũy nhiều ảnh: **giới hạn baseline**, browser quota localStorage có thể đầy. Harness dùng storage riêng sạch giữa package để đo từng nguồn; không sửa importer hoặc khóa dependency để né lỗi.
- Các ca nguồn cực dài không có trong test: scrollbar vẫn là last resort; không tuyên bố fit cho mọi dữ liệu tùy ý.

Không tuyên bố production PASS. Candidate chờ runtime test thực tế.
