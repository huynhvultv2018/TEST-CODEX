# WEB LIVE PEDAGOGY RC3_PED1 CANDIDATE

PARTIAL — CHỜ RUNTIME ACCEPTANCE. KHÔNG PRODUCTION.

Baseline accepted: WEB LIVE V1.1.5 TV DEMO HANDOFF, eb0647c3ea9a4b6d1188208942fe92a4598b239fc8bfa51a78f893faaf75505b. Giữ nhãn/version UI cũ của baseline; candidate này không thay baseline acceptance.

Giải nén nguyên thư mục, chạy START_WEB_LIVE.bat trên Windows như baseline. Chưa chứng nhận runtime Windows trong phiên tạo candidate này. Import gói trong RC3_PED1_TEST_PACKAGES; test chính Tin6 W5 mới nhất user ĐẠT. Không tự mở app khi chuyển màn.

RC3: GỢI Ý 1 → GỢI Ý 2 nếu cần; Answer thủ công; tại KNOWLEDGE/CLOSE bấm CHỐT KIẾN THỨC. Back/Next và Teacher refresh mở task với disclosures ẩn. Probe/response/error/resource/policy/cảnh báo dành GV nằm sidebar. Không tự skip CORE hay tạo offline fallback.

Báo cáo tại RC3_REPORTS/. Full exporter còn thiếu nguồn PPCT/SGK trong snapshot bàn giao; downstream import/mapping và regression VM đạt nhưng runtime thật chưa chạy. Không dùng candidate làm bản production trước acceptance.
