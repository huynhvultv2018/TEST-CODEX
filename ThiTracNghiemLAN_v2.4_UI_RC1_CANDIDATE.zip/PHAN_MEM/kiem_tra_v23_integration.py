"""Integration checks using temporary data only; runs before Windows build."""
import tempfile,shutil,sys,json,os
from pathlib import Path
from io import BytesIO
from datetime import datetime,timedelta

def main():
    root=Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='tnlan_test_',ignore_cleanup_errors=True) as tmp:
        p=Path(tmp)
        for file in root.glob('*.py'):
            if file.name!=Path(__file__).name: shutil.copy2(file,p/file.name)
        shutil.copytree(root/'templates',p/'templates')
        os.environ["LOCALAPPDATA"]=str(p/"localappdata")
        sys.path.insert(0,tmp)
        import app as m
        m.init_db(); m.init_db()
        client=m.app.test_client()
        assert client.get('/').status_code==200,'7-day trial access'
        assert client.get('/teacher/login').status_code==200,'Login template'
        # Expire both isolated trial records and verify enforcement without bypasses.
        state_paths=[p/'license_trial.json',p/'localappdata'/'ThiTracNghiemLAN'/(m.machine_id()+'.json')]
        originals=[f.read_text() for f in state_paths]
        for f,text in zip(state_paths,originals):
            state=json.loads(text);state['start']-=8*86400
            f.write_text(json.dumps(state))
        assert client.get('/').status_code==403,'Expired trial gate'
        assert client.get('/teacher/login').status_code==200,'Activation login remains available'
        for f,text in zip(state_paths,originals):f.write_text(text)
        with client.session_transaction() as s:
            s['teacher_logged_in']=True;s['teacher_role']='ADMIN';s['teacher_username']='admin'
        for url in ['/teacher','/teacher/multi','/teacher/multi/new','/teacher/mixed-exam']:
            assert client.get(url).status_code==200,url
        sample=client.get('/teacher/multi/excel?sample=1'); assert sample.status_code==200
        response=client.post('/teacher/multi/import',data={'file':(BytesIO(sample.data),'sample.xlsx')},content_type='multipart/form-data')
        assert response.status_code==302
        c=m.db(); assert c.execute('SELECT COUNT(*) FROM cau_hoi').fetchone()[0]==5;c.close()
        exported=client.get('/teacher/multi/excel'); assert exported.status_code==200
        # Configure through teacher UI, then round-trip all scoring settings through Excel.
        c=m.db(); rows=c.execute('SELECT * FROM cau_hoi').fetchall(); c.close()
        for r in rows:
            k=r['question_type']; d=json.loads(r['payload'])
            items='\n'.join(d['options']); ans=str(d['answer']+1) if k=='SINGLE' else '1,3' if k=='MULTI' else 'D\nS' if k=='TF' else '2\n4' if k=='MATCH' else '2|hai\n3|ba'
            if k=='FILL': items='Một cộng một\nMột cộng hai'
            f=dict(ma_cau=r['ma_cau'],khoi_lop='6',mon='Tin học',chu_de='Ví dụ',muc_do=r['muc_do'],question_type=k,noi_dung=r['noi_dung'],items=items,answers=ans,points='2',scoring_mode='partial',weights='1,3' if k in ('TF','MATCH') else '')
            assert client.post('/teacher/multi/edit/'+str(r['id']),data=f).status_code==302
            assert 'name="points"' in client.get('/teacher/multi/edit/'+str(r['id'])).get_data(as_text=True)
        exported=client.get('/teacher/multi/excel')
        c=m.db(); before=[r[0] for r in c.execute('SELECT payload FROM cau_hoi ORDER BY id')]; c.execute('DELETE FROM cau_hoi');c.commit();c.close()
        client.post('/teacher/multi/import',data={'file':(BytesIO(exported.data),'roundtrip.xlsx')},content_type='multipart/form-data')
        c=m.db(); assert [r[0] for r in c.execute('SELECT payload FROM cau_hoi ORDER BY id')]==before; c.close()
        fields={'ten':'Test 5 kinds','minutes':'15','mon':'Tin học','lop':'6A','hien_diem':'on'}
        for k,lv in [('SINGLE','NB'),('MULTI','TH'),('TF','NB'),('MATCH','TH'),('FILL','NB')]:fields[k+'_'+lv]='1'
        assert client.post('/teacher/mixed-exam',data=fields).status_code==302
        c=m.db();kt=c.execute('SELECT * FROM ky_thi').fetchone();assert kt is not None
        data=m.build_exam(kt);assert len(data)==5
        c.execute("INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES('T1','Học sinh thử','6A')")
        now=datetime.now().strftime('%Y-%m-%d %H:%M:%S');deadline=(datetime.now()+timedelta(minutes=15)).strftime('%Y-%m-%d %H:%M:%S')
        c.execute('INSERT INTO bai_thi(ky_thi_id,ma_hs,ho_ten,lop,started_at,deadline_at,de_json,last_seen_at,client_token) VALUES(?,?,?,?,?,?,?,?,?)',(kt['id'],'T1','Học sinh thử','6A',now,deadline,json.dumps(data),now,'test'))
        aid=c.execute('SELECT id FROM bai_thi').fetchone()[0];c.commit();c.close()
        with client.session_transaction() as s:s['attempt_id']=aid;s['client_token']='test'
        assert client.get('/exam').status_code==200,'Exam rendering'
        form={}
        for i,q in enumerate(data):
            v=q['answer'] if q['type']!='FILL' else [opts[0] for opts in q['answer']]
            if q['type']=='MULTI': v=v[:1]
            elif q['type'] in ('TF','MATCH','FILL'): v=[v[0],None if q['type']=='MATCH' else '']
            assert client.post('/api/save-answer',json={'index':i,'choice':v}).status_code==200
            if q['type']=='SINGLE':form[f'q_{i}']=str(v)
            elif q['type']=='MULTI':form[f'q_{i}']=[str(x) for x in v]
            else:
                for j,x in enumerate(v):form[f'q_{i}_{j}']=str(x)
        assert client.get('/exam').status_code==200,'Saved answers rendering'
        assert client.post('/exam',data=form).status_code==302
        c=m.db();assert c.execute('SELECT diem FROM bai_thi WHERE id=?',(aid,)).fetchone()[0]==5;c.close()
        for url in [f'/teacher/monitor/{kt["id"]}',f'/teacher/api/monitor/{kt["id"]}',f'/teacher/report/{kt["id"]}',f'/teacher/report/{kt["id"]}/export']:
            assert client.get(url).status_code==200,url
        points=client.get(f'/teacher/report/{kt["id"]}/points')
        from openpyxl import load_workbook
        wb=load_workbook(BytesIO(points.data)); values=list(wb.active.values); wb.close()
        assert len(values)==6 and abs(sum(row[6] for row in values[1:])-5)<1e-9
        # A second attempt times out using saved answers and its frozen scoring rules.
        c=m.db(); original=c.execute('SELECT * FROM bai_thi WHERE id=?',(aid,)).fetchone()
        c.execute("INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES('T2','Thử','6A')")
        c.execute('INSERT INTO bai_thi(ky_thi_id,ma_hs,ho_ten,lop,started_at,deadline_at,de_json,last_seen_at,client_token) VALUES(?,?,?,?,?,?,?,?,?)',(kt['id'],'T2','Thử','6A',now,'2000-01-01 00:00:00',json.dumps(data),now,'second'))
        second=c.execute('SELECT MAX(id) FROM bai_thi').fetchone()[0]
        c.execute('INSERT INTO cau_tra_loi(bai_thi_id,vi_tri_cau,cau_hoi_id,lua_chon,dung,saved_at) SELECT ?,vi_tri_cau,cau_hoi_id,lua_chon,dung,saved_at FROM cau_tra_loi WHERE bai_thi_id=?',(second,aid))
        c.execute("UPDATE cau_hoi SET payload='' "); c.commit(); c.close()
        with client.session_transaction() as sess: sess['attempt_id']=second; sess['client_token']='second'
        assert client.get('/exam').status_code==302
        c=m.db(); assert c.execute('SELECT diem FROM bai_thi WHERE id=?',(second,)).fetchone()[0]==5
        assert c.execute('SELECT diem FROM bai_thi WHERE id=?',(aid,)).fetchone()[0]==5; c.close()
        import logging
        logging.shutdown()
        print('PASS v2.3 integration: partial score 5/10, Excel scoring roundtrip, timeout, frozen rules, point report; license gate, templates, Excel, 5 question types, save/reload, submission 5/10, monitoring and reports.')
if __name__=='__main__':main()
