"""Kiểm tra v2.2.2 với dữ liệu tạm, không đụng dữ liệu thật."""
import os
import shutil
import sys
import tempfile
from io import BytesIO
from pathlib import Path

from openpyxl import Workbook,load_workbook


def old_excel_bytes():
    wb=Workbook(); ws=wb.active
    ws.append(['Mã câu','Môn','Chủ đề','Mức độ','Loại','Nội dung câu hỏi','Các mục','Đáp án'])
    ws.append(['OLD7_01','Tên môn trong file','Bài cũ','NB','SINGLE','Câu hỏi mẫu','A\nB','1'])
    out=BytesIO(); wb.save(out); out.seek(0); return out


def main():
    root=Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='tnlan_v222_',ignore_cleanup_errors=True) as tmp:
        p=Path(tmp)
        for file in root.glob('*.py'):
            if file.name!=Path(__file__).name: shutil.copy2(file,p/file.name)
        shutil.copytree(root/'templates',p/'templates')
        shutil.copytree(root/'static',p/'static')
        os.environ['LOCALAPPDATA']=str(p/'localappdata')
        sys.path.insert(0,tmp)
        import app as m

        m.init_db();m.init_db()
        c=m.db()
        columns={r['name'] for r in c.execute('PRAGMA table_info(cau_hoi)')}
        assert 'khoi_lop' in columns
        rows=[]
        for i in range(100): rows.append((f'T8_{i:03d}','8','Toán','Đơn thức','NB',f'Câu Toán {i}','SINGLE','', 'A','B','C','D','A',''))
        for i in range(25): rows.append((f'TIN6_{i:03d}','6','Tin học','Thông tin','TH',f'Câu Tin {i}','SINGLE','', 'A','B','C','D','A',''))
        for i in range(10): rows.append((f'X_{i:03d}','','','Chưa rõ','VD',f'Câu chưa phân loại {i}','SINGLE','', 'A','B','C','D','A',''))
        rows.append(('DS8_LEGACY','','Toán','Đơn thức','NB','Câu cũ cần suy luận','SINGLE','', 'A','B','C','D','A',''))
        c.executemany('''INSERT INTO cau_hoi(ma_cau,khoi_lop,mon,chu_de,muc_do,noi_dung,
                         question_type,payload,a,b,c,d,dap_an_dung,hinh_anh)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',rows)
        c.commit();c.close()
        m.init_db()
        c=m.db();assert c.execute("SELECT khoi_lop FROM cau_hoi WHERE ma_cau='DS8_LEGACY'").fetchone()[0]=='8';c.close()

        client=m.app.test_client()
        with client.session_transaction() as s:
            s['teacher_logged_in']=True;s['teacher_role']='ADMIN';s['teacher_username']='admin'

        page=client.get('/teacher/multi')
        html=page.get_data(as_text=True)
        assert page.status_code==200 and html.count('class="question-row"')==50
        assert 'Khối 8' in html and 'Toán' in html and '101 câu hỏi' in html
        assert 'Chưa phân loại' in html

        filtered=client.get('/teacher/multi?khoi=8&mon=Toán&per_page=25&page=4')
        assert filtered.status_code==200 and filtered.get_data(as_text=True).count('class="question-row"')==25
        last=client.get('/teacher/multi?khoi=8&mon=Toán&per_page=25&page=5').get_data(as_text=True)
        assert last.count('class="question-row"')==1
        searched=client.get('/teacher/multi?khoi=6&mon=Tin+học&q=Tin+24').get_data(as_text=True)
        assert searched.count('class="question-row"')==1 and 'Câu Tin 24' in searched

        sample=client.get('/teacher/multi/excel?sample=1')
        ws=load_workbook(BytesIO(sample.data),read_only=True).active
        assert ws.max_column==12 and ws.cell(1,2).value=='Khối'
        imported=client.post('/teacher/multi/import',data={
            'khoi_lop':'9','mon_folder':'Tin học','file':(BytesIO(sample.data),'new.xlsx')
        },content_type='multipart/form-data')
        assert imported.status_code==302
        old_import=client.post('/teacher/multi/import',data={
            'khoi_lop':'7','mon_folder':'Toán','file':(old_excel_bytes(),'old.xlsx')
        },content_type='multipart/form-data')
        assert old_import.status_code==302
        c=m.db()
        assert c.execute("SELECT COUNT(*) FROM cau_hoi WHERE khoi_lop='9' AND mon='Tin học'").fetchone()[0]==5
        assert c.execute("SELECT COUNT(*) FROM cau_hoi WHERE khoi_lop='7' AND mon='Toán'").fetchone()[0]==1
        c.close()

        exported=client.get('/teacher/multi/excel?khoi=9&mon=Tin+học')
        ws=load_workbook(BytesIO(exported.data),read_only=True).active
        assert ws.max_row==6 and ws.max_column==12
        assert all(ws.cell(i,2).value=='9' and ws.cell(i,3).value=='Tin học' for i in range(2,7))
        print('PASS v2.2.2: migration, folders, inference, paging, filters, new/old Excel import and folder export.')


if __name__=='__main__': main()
