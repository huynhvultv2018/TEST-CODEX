"""Kiểm tra quản lý 1.000 học sinh của v2.2.1 trên dữ liệu tạm."""
import json
import os
import shutil
import sys
import tempfile
from io import BytesIO
from pathlib import Path

from openpyxl import Workbook,load_workbook


def excel_bytes(rows):
    wb=Workbook(); ws=wb.active
    ws.append(["Mã học sinh","Họ tên","Lớp"])
    for row in rows: ws.append(row)
    data=BytesIO(); wb.save(data); data.seek(0); return data


def main():
    root=Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix="tnlan_v221_",ignore_cleanup_errors=True) as tmp:
        p=Path(tmp)
        for file in root.glob("*.py"):
            if file.name!=Path(__file__).name: shutil.copy2(file,p/file.name)
        shutil.copytree(root/"templates",p/"templates")
        os.environ["LOCALAPPDATA"]=str(p/"localappdata")
        sys.path.insert(0,tmp)
        import app as m
        m.init_db()
        c=m.db()
        rows=[(f"HS{i:04d}",f"Học sinh {i:04d}",f"6{chr(65+i%4)}") for i in range(1000)]
        c.executemany("INSERT INTO hoc_sinh(ma_hs,ho_ten,lop) VALUES(?,?,?)",rows)
        c.commit();c.close()
        client=m.app.test_client()
        with client.session_transaction() as s:
            s["teacher_logged_in"]=True;s["teacher_role"]="ADMIN";s["teacher_username"]="admin"

        dashboard=client.get("/teacher")
        assert dashboard.status_code==200 and b"1000" in dashboard.data
        assert "Học sinh 0999" not in dashboard.get_data(as_text=True),"Dashboard must not load full roster"
        page=client.get("/teacher/students")
        assert page.status_code==200
        assert page.get_data(as_text=True).count('class="student-check"')==50
        page25=client.get("/teacher/students?per_page=25&page=40")
        assert page25.get_data(as_text=True).count('class="student-check"')==25
        found=client.get("/teacher/students?q=HS0999")
        assert "Học sinh 0999" in found.get_data(as_text=True)
        filtered=client.get("/teacher/students?lop=6A&per_page=100")
        assert filtered.get_data(as_text=True).count('class="student-check"')==100

        exported=client.get("/teacher/students/export?lop=6A")
        assert exported.status_code==200
        ws=load_workbook(BytesIO(exported.data),read_only=True).active
        assert ws.max_row==251,"250 students plus header"

        upload=excel_bytes([("HS0000","Tên không được đổi","9Z"),("NEW001","Học sinh mới","7A"),("BAD",None,"7A")])
        preview=client.post("/teacher/students/import-preview",data={"file":(upload,"students.xlsx")},content_type="multipart/form-data")
        assert preview.status_code==200 and "2</b> học sinh hợp lệ" in preview.get_data(as_text=True)
        with client.session_transaction() as s: token=s["student_import_token"]
        confirmed=client.post("/teacher/students/import-confirm",data={"token":token,"mode":"skip"},follow_redirects=True)
        assert confirmed.status_code==200
        c=m.db()
        assert c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0]==1001
        assert c.execute("SELECT ho_ten FROM hoc_sinh WHERE ma_hs='HS0000'").fetchone()[0]=="Học sinh 0000"
        new_id=c.execute("SELECT id FROM hoc_sinh WHERE ma_hs='NEW001'").fetchone()[0]
        other_id=c.execute("SELECT id FROM hoc_sinh WHERE ma_hs='HS0001'").fetchone()[0]
        c.close()

        moved=client.post("/teacher/students/bulk",data={"student_ids":[new_id,other_id],"action":"move","new_class":"8A"},follow_redirects=True)
        assert moved.status_code==200
        c=m.db();assert c.execute("SELECT COUNT(*) FROM hoc_sinh WHERE id IN (?,?) AND lop='8A'",(new_id,other_id)).fetchone()[0]==2;c.close()
        before=len(list(m.BACKUP_DIR.glob("before_delete_students_*.db")))
        deleted=client.post("/teacher/students/bulk",data={"student_ids":[new_id,other_id],"action":"delete"},follow_redirects=True)
        assert deleted.status_code==200
        c=m.db();assert c.execute("SELECT COUNT(*) FROM hoc_sinh").fetchone()[0]==999;c.close()
        assert len(list(m.BACKUP_DIR.glob("before_delete_students_*.db")))==before+1
        print("PASS v2.2.1: dashboard summary, 1000 students, paging, search, class filter, export, preview import, skip duplicates, move and backed-up bulk delete.")


if __name__=="__main__": main()
