"""Start the two local services and open Teacher over HTTP; no lesson/TTS changes."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener
import webbrowser

from web_live_http import (BIND_HOST, WEB_PORT, LAUNCHER_PORT, ALLOWED_WEB_ORIGINS,
                           TEACHER_URL, HEALTH_PATH, SERVICE_ID, package_fingerprint)


class StartupError(Exception):
    pass


def probe(url: str):
    # Loopback must remain local even when the machine has an HTTP proxy configured.
    opener = build_opener(ProxyHandler({}))
    request = Request(url, headers={"Origin": f"http://{BIND_HOST}:{WEB_PORT}"})
    try:
        with opener.open(request, timeout=.8) as response:
            data = json.loads(response.read(8192))
            return (response.status, dict(response.headers), data) if isinstance(data, dict) else (0, {}, {})
    except HTTPError as error:
        return error.code, {}, {}
    except URLError:
        return None
    except (ValueError, OSError):
        return 0, {}, {}


def web_ready(result, package_root: Path) -> bool:
    return bool(result and result[0] == 200 and result[2].get("service") == SERVICE_ID
                and result[2].get("webPort") == WEB_PORT
                and result[2].get("packageFingerprint") == package_fingerprint(package_root))


def launcher_ready(result, installation_id: str) -> bool:
    return bool(result and result[0] == 200 and result[2].get("status") == "PAIR_REQUIRED"
                and result[2].get("installationId") == installation_id
                and result[1].get("Access-Control-Allow-Origin") == f"http://{BIND_HOST}:{WEB_PORT}")


def ensure_service(script: Path, url: str, check, label: str):
    initial = probe(url)
    if initial is not None:
        if check(initial):
            return None
        raise StartupError(f"{label} dang co dich vu khac/ban cu tren port nay. "
                           "Dong cua so dich vu cu bang Ctrl+C, roi chay lai START_WEB_LIVE.bat.")
    options = {"cwd": str(script.parent)}
    if sys.platform == "win32":
        options["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    process = subprocess.Popen([sys.executable, "-B", str(script)], **options)
    try:
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            result = probe(url)
            if check(result):
                return process
            if (result is not None and result[0] != 0) or process.poll() is not None:
                raise StartupError(f"{label} khong khoi dong dung ban/port. Kiem tra cua so dich vu.")
            time.sleep(.15)
        raise StartupError(f"{label} chua san sang sau 10 giay. Kiem tra cua so dich vu.")
    except BaseException:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=5)
        raise


def start_services(package_root: Path):
    base = package_root / "LAUNCHER"
    installation_id = json.loads((base / "launcher-config.json").read_text())["installationId"]
    children = []
    try:
        web = ensure_service(base / "web_live_http.py", f"http://{BIND_HOST}:{WEB_PORT}{HEALTH_PATH}",
                             lambda result: web_ready(result, package_root), "WEB SERVER")
        if web:
            children.append(web)
        launcher = ensure_service(base / "WebLiveLauncher.py", f"http://{BIND_HOST}:{LAUNCHER_PORT}/status",
                                  lambda result: launcher_ready(result, installation_id), "LOCAL LAUNCHER")
        if launcher:
            children.append(launcher)
        return children
    except BaseException:
        for child in children:
            if child.poll() is None:
                child.terminate()
                child.wait(timeout=5)
        raise


def main() -> int:
    if sys.platform != "win32":
        print("START_WEB_LIVE.bat/start_web_live.py dung cho Windows.")
        return 2
    if sys.version_info < (3, 10):
        print("Can Python 3.10+ de chay WEB LIVE HTTP va Local Launcher.")
        return 2
    package_root = Path(__file__).resolve().parent.parent
    try:
        start_services(package_root)
    except (OSError, ValueError, KeyError, StartupError) as error:
        print(f"Khong khoi dong duoc WEB LIVE: {error}", flush=True)
        return 1
    print(f"WEB LIVE: {TEACHER_URL}", flush=True)
    print(f"Local Launcher API: http://{BIND_HOST}:{LAUNCHER_PORT}", flush=True)
    print("Allowed origins: " + ", ".join(sorted(ALLOWED_WEB_ORIGINS)), flush=True)
    if not webbrowser.open(TEACHER_URL, new=2):
        print("Chua mo duoc browser tu dong. Mo URL WEB LIVE o tren trong Chrome.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
