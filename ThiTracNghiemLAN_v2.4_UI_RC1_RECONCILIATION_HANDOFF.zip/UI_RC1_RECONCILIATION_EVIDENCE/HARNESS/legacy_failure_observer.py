"""Passive Python exception observation. The original test is executed unchanged."""
import argparse,hashlib,json,logging,os,runpy,shutil,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--script',required=True);a=p.parse_args()
ROOT=Path('/workspace/ui-rc1-reconciliation');source=ROOT/'frozen-source/PHAN_MEM'/a.script;out=ROOT/'evidence/legacy-first-failure';out.mkdir(exist_ok=True)
observed=[]
with tempfile.TemporaryDirectory(prefix='ui_legacy_observer_') as tmp:
 folder=Path(tmp)/'source';shutil.copytree(ROOT/'frozen-source/PHAN_MEM',folder)
 os.environ['LOCALAPPDATA']=str(Path(tmp)/'localappdata');os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
 os.chdir(folder);sys.path.insert(0,str(folder))
 def trace(frame,event,arg):
  if event=='exception' and Path(frame.f_code.co_filename).name==a.script and frame.f_code.co_name=='main' and issubclass(arg[0],AssertionError):
   responses=[]
   for name,v in frame.f_locals.items():
    if hasattr(v,'status_code') and hasattr(v,'get_data') and v.status_code>=400:
     request=getattr(v,'request',None)
     responses.append(dict(variable=name,status=v.status_code,method=getattr(request,'method',None),path=getattr(request,'path',None),location=v.headers.get('Location'),body_excerpt=v.get_data()[:180].decode('utf-8',errors='replace')))
   original_lines=source.read_text().splitlines();observed.append(dict(function='main',line=frame.f_lineno,assertion=original_lines[frame.f_lineno-1],responses=responses))
  return trace
 sys.settrace(trace)
 try:runpy.run_path(str(folder/a.script),run_name='__main__')
 except AssertionError:pass
 finally:sys.settrace(None);logging.shutdown()
 assert observed,'Expected original legacy failure did not reproduce'
record=dict(script=a.script,sha256=hashlib.sha256(source.read_bytes()).hexdigest(),LEGACY_RAW_RESULT='FAIL',product_modified=False,legacy_test_modified=False,observer='Python exception tracing only; no HTTP or middleware injection',failures=observed)
(out/(a.script+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(a.script,[(x['variable'],x['status'],x['path']) for x in observed[0]['responses']])
