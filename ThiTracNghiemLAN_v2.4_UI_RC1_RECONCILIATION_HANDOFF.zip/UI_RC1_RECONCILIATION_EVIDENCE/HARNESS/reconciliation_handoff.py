"""Report contract reconciliation without changing frozen candidate or old outputs."""
import hashlib,json,shutil,zipfile
from pathlib import Path
R=Path('/workspace/ui-rc1-reconciliation');E=R/'evidence';O=R/'artifacts';O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
before=read(E/'candidate-before.json');after=read(E/'candidate-after.json');frozen=Path(before['candidate_path'])
S=before['candidate_sha256'];assert S==sha(frozen)==after['after_sha256']=='d9765ac36c954190a63ac56fa55088a8b4e3eed9c9316a87a4246ff6a705b21f'
canonical=read(E/'canonical-contracts/results.json');native=read(E/'native-final/results.json');r4=read(E/'r4-canonical/results.json');ui=read(E/'ui/results.json');lan=read(E/'lan/results.json')
for suite in [canonical,r4,ui,lan]:assert all(x['status']=='PASS' for x in suite['results'])
assert all(x['status']=='PASS' for x in native if x['mode'].endswith('compatibility'))
assert sum(x['status']=='FAIL' for x in native if x['mode']=='UI_RC1_original')==4
spec=E/'canonical-expectations.json';expected_spec_sha=(E/'canonical-expectations.sha256').read_text().split()[0];assert sha(spec)==expected_spec_sha
old_matrix=[
 dict(id='D001-01',test='kiem_tra_v22.py:main, assert line 36',route='/teacher/multi/import',old='302, five imported types and subsequent score 10',actual='403; no Location; CSRF body',current='Valid session nonce required before multipart import',classification='TEST_HARNESS_INCOMPATIBLE',replacement='Standalone approved nonce-aware v22 + CF011',result='PASS',rationale='302 remains correct for a valid request; missing nonce makes the legacy request invalid.'),
 dict(id='D001-02',test='kiem_tra_v221.py:main, assert line 59',route='/teacher/students/import-preview',old='200 + 2 valid students in preview',actual='403; no Location; CSRF body',current='Multipart preview needs CSRF; operation import token is separate',classification='TEST_HARNESS_INCOMPATIBLE',replacement='Standalone approved nonce-aware v221 + CF011',result='PASS',rationale='Manual teacher session and import-confirm token do not replace submitted CSRF nonce.'),
 dict(id='D001-03',test='kiem_tra_v222.py:main, assert line 70',route='/teacher/multi/import',old='302, all grades/types and legacy Excel import valid',actual='403; no Location; CSRF body',current='Valid session nonce required for each import',classification='TEST_HARNESS_INCOMPATIBLE',replacement='Standalone approved nonce-aware v222 + CF011',result='PASS',rationale='New/legacy workbook transport is valid; nonce setup is missing, not the import behavior.'),
 dict(id='D001-04',test='kiem_tra_v23_integration.py:main, assert line 36',route='/teacher/multi/import',old='302; later partial score 5, scoring roundtrip/timeout/frozen snapshot',actual='403; no Location; CSRF body',current='Header/form nonce required on every unsafe request, current after login rotation',classification='TEST_HARNESS_INCOMPATIBLE',replacement='Standalone approved nonce-aware v23 integration + CF011',result='PASS',rationale='Missing nonce blocks the first POST before subsequent functional assertions can execute.'),
 dict(id='D002-01',test='r3_regression.py:invalid_time(mixed-exam) → invalid_request, assert line 80',route='/teacher/mixed-exam',old='Session _flashes still contains minutes error after response',actual='HTTP 200, minutes error rendered; _flashes consumed; exam DB unchanged',current='F006 requires controlled rejection, visible notice and no new exam; native template consumes flashes',classification='LEGACY_EXPECTATION_OBSOLETE',replacement='CF006 time cases (11)',result='PASS',rationale='Wrong observation layer, not F012. Prior R3 UI observer already observes response notices for non-redirects.'),
 dict(id='D002-02',test='r3_regression.py:invalid_counts(mixed-exam) → invalid_request, assert line 80',route='/teacher/mixed-exam',old='Session _flashes retains quota-field error after response',actual='HTTP 200, field error rendered; _flashes consumed; exam DB unchanged',current='F006 requires rejecting malformed quota and displaying field notice; not retaining consumed flash state',classification='LEGACY_EXPECTATION_OBSOLETE',replacement='CF006 5 types × 4 levels × 7 invalid counts (140)',result='PASS',rationale='Same obsolete observation assumption; no product input-validation failure and no F012 involvement.'),
 dict(id='D002-03',test='r3_regression.py:reports_export, assert line 216',route='/teacher/report/<eid>/export',old='PhanTichCauHoi code starts with marker set in bank AFTER exam; other text cells reflect live bank',actual='R3EXCEL_SINGLE/MULTI/TF/MATCH/FILL, original subject R3EXCEL/topic Safe/NB/text Câu <type>',current='F012 Contract A: metadata/content from submitted attempt snapshot; current bank must not rewrite history',classification='LEGACY_EXPECTATION_OBSOLETE',replacement='CF012 before/after HTML/Excel; marker fixture exists BEFORE snapshot',result='PASS',rationale='Old live-bank expectation contradicts explicit Contract A. New canonical test verifies history freeze and original F008 text/numeric safety separately.')]
(E/'LEGACY_TEST_RECONCILIATION_MATRIX.json').write_text(json.dumps(old_matrix,ensure_ascii=False,indent=2)+'\n')
rows='\n'.join('| '+x['id']+' — `'+x['test']+'` | '+x['old']+' | '+x['current']+' | '+x['classification']+' | '+x['replacement']+' | '+x['result']+' | '+x['rationale']+' |' for x in old_matrix)
sites=[('TC01','v22:35','multi/import','multipart, 302'),('TC02','v22:41','mixed-exam','form, 302'),('TC03','v22:53','api/save-answer','JSON/header, 200; loop five types'),('TC04','v22:59','exam','form, 302'),('TC05','v221:58','students/import-preview','multipart, 200 + preview'),('TC06','v221:61','students/import-confirm','form + operation token; follow redirect 200'),('TC07','v221:70','students/bulk','move; follow redirect 200'),('TC08','v221:74','students/bulk','delete; follow redirect 200'),('TC09','v222:67','multi/import','new format, multipart 302'),('TC10','v222:71','multi/import','legacy format, multipart 302'),('TC11','v23_integration:35','multi/import','multipart, 302'),('TC12','v23_integration:46','multi/edit/<id>','form, 302; loop five types'),('TC13','v23_integration:50','multi/import','roundtrip; DB payload equality retained'),('TC14','v23_integration:54','mixed-exam','form, 302'),('TC15','v23_integration:68','api/save-answer','JSON/header, 200'),('TC16','v23_integration:74','exam','form, 302')]
site_table='\n'.join('| '+' | '.join(x)+' | PASS in standalone compatibility copy |' for x in sites)
matrix=f'''# UI RC1 — Legacy test reconciliation matrix

LEGACY_RAW_RESULT = FAIL (4 native scripts + 3 R3 assertions, preserved)
CANONICAL_CURRENT_CONTRACT_RESULT = PASS

Candidate `{S}` is unchanged. This report replaces no old test/log/report; it records
why current contracts require a distinct canonical path.

## Required matrix

| TEST | OLD CONTRACT | CURRENT CONTRACT | CLASSIFICATION | REPLACEMENT CANONICAL TEST | RESULT | RATIONALE |
|---|---|---|---|---|---|---|
{rows}

## D001 precise observed failures

All four first failures are in `main()`: v22 line 36, v221 line 59, v222 line 70,
v23 integration line 36. Passive exception observation of unchanged scripts records
HTTP 403, Location absent and native CSRF text. Evidence: `legacy-first-failure/*.json`.
The raw standalone executions still fail; observer completion is not counted as a
functional PASS. The first diagnostic observer attempted to decode an XLSX response
as UTF-8 and failed; its source/error record is retained. Corrected observer reads
only failure responses; no request/middleware/source injection occurs.

The expected functional 302/200 is still correct for a VALID request. Therefore D001
is `TEST_HARNESS_INCOMPATIBLE`, not `PRODUCT_DEFECT` and not a reason to change status
or authorize nonce-free requests. Login/auth/attempt/client_token/import operation
token and CSRF are distinct prerequisites. JSON requires X-CSRF-Token, not a JSON
body token. Current nonce must be obtained after rotation; multipart remains multipart.

## All 16 legacy POST call-sites are covered

| Site | Original file:line | Route suffix | Original functional expectation | Canonical path result |
|---|---|---|---|---|
{site_table}

Six native scripts run in build_exe.bat order, each as its own `python script.py`
process in a temporary source copy. The already approved 4-file test-only compatibility
patch adds a local current-session nonce helper and headers, retaining all 76 original
functional assertions and whole-module AST after removing only those additions.
MathJax/v23 tests are byte-identical. No external transport/sitecustomize adapter,
CSRF exemption, middleware monkeypatch, test skip or xpass is used. Original candidate
test files remain byte-identical to the input ZIP; compatibility files are outside it.

## D002 contract distinctions

The two F006 failures are not historical-report/F012 failures. The R3 native
mixed-exam response renders `get_flashed_messages()`, consuming session flash data.
Session persistence is an obsolete harness assumption. Existing R3 observer source
already used HTML notices for a non-redirect response. CF006 checks all 11 bad times
and 140 malformed quota cells: exact field notice visible, 200 controlled response,
0 new/changed exam rows, consumed `_flashes` observed separately. Returning 200 for
the validation form is permitted by the existing R3 status assertion (200/302/400).

The third failure directly conflicts with F012. Old fixture changes bank code/text
after submission then expects those changed values in Excel. Actual raw XLSX contains
the original R3EXCEL metadata; this is correct Contract A. CF012 places the original
Excel marker before snapshot, edits all five bank questions afterwards through the
real editor, and asserts HTML context/Excel values unchanged. Numeric/text cell types
and no formulas are independently asserted; no expected live-bank alias is added.

Current contract sources: HOTFIX_R4_SECURITY_REPORT (F011), HOTFIX_R4_HISTORY_REPORT
(Contract A), HOTFIX_R4_TEST_REPORT (raw failures/fixture timing), prior R3 UI observer,
app.py middleware/history readers and native mixed_exam template. All copied with hashes
in CONTRACT_SOURCES; no PREPROD undefined proposal overrides implemented R4 policy.
'''
(O/'UI_RC1_LEGACY_TEST_MATRIX.md').write_text(matrix)
ui_table='\n'.join('| '+x['id']+' | '+x['status']+' | `'+x['browser_check']+'` |' for x in read(E/'UI01_UI28_TRACEABILITY.json'))
met50=read(E/'lan/metrics-50.json');met60=read(E/'lan/metrics-60.json')
native_table='\n'.join('| '+n+' | '+next(x['status'] for x in native if x['script']==n and x['mode']=='UI_RC1_original')+' | '+next(x['status'] for x in native if x['script']==n and x['mode'].endswith('compatibility'))+' |' for n in ['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_mathjax.py','kiem_tra_v222.py','kiem_tra_v23.py','kiem_tra_v23_integration.py'])
reg=f'''# UI RC1 — Canonical current-contract regression report

CANONICAL_CURRENT_CONTRACT_RESULT = PASS
LEGACY_RAW_RESULT = FAIL (unchanged evidence, not relabeled)
RECONCILIATION = PASS
PRODUCT_DEFECT_FOUND = NO (within executed scope)
PRODUCT_PATCH_REQUIRED = NO
WINDOWS_RUNTIME = NOT_RUN
PHYSICAL_50_PC = NOT_RUN
PRODUCTION = NO

## Fresh executions

| Requested suite | Result | Evidence |
|---|---|---|
| A — R4 canonical functional | 7/7 PASS + 6/6 standalone native compatibility | r4-canonical/results.json; native-final/results.json |
| B — UI01–UI28 | All 28 requirements PASS; 28 browser groups PASS | UI01_UI28_TRACEABILITY.json; ui/results.json; five screenshots |
| C — CSRF F011 canonical | PASS | canonical-contracts/results.json CF011; R4 guard matrix; LAN route matrix |
| D — F012 Contract A | PASS | CF012; 5 marker cases × 5 question types; before/after HTML/XLSX; R4 versions/legacy checks |
| E — 50-client simulation | PASS | 50 primary, mixed, deadline and retry/atomic race |
| F — 60-client headroom | PASS | 60 independent HTTP client sessions |

R4 suite repeats 344 scoring-equivalence cases, malformed scoring/snapshot controlled
rejection, semantic restore/legacy compatibility, all 35 CSRF routes and immutable
historical HTML/Excel including two versions and missing-history legacy snapshots.
It runs against the exact extracted frozen source in disposable runtime copies.

## F011 details and false-positive control

8 route families × missing/wrong/other-session nonce = 24 rejects (403, DB unchanged).
Valid multipart imports five question types; preview has 2 valid students; confirm
imports two actual rows; bulk move updates both. Form-field nonce from a real login
works. Login rotation invalidates the old nonce (403). Import operation nonce is
kept separate. Successful valid workflows show no false reject. Standalone native
compatibility executes all 16 legacy call-sites including JSON saves and submits.
R4/LAN additionally repeat all 35 routes × 5 invalid nonce/origin/referrer variants
(175 rejects per suite); negative clients do not receive automatic valid headers.
No production guard or transport changes.

## F012 / F008 canonical proof

Per case: create 5-type bank, create exam/student through valid POST; start attempt
with rotated student nonce; inspect snapshot history; autosave partial answers;
submit score 4.5; capture report context/HTML and 4-sheet Excel; edit code/subject/
topic/level NB→VD/text/points 4→9 via real bank editor; reopen report/export.
BEFORE == AFTER for metadata/content/levels and every workbook value/cell type.
Stored attempt/answers/de_json/score remain byte-equivalent. Bank actually changes,
so unchanged report is not a no-op test. All five question types are included in
each of five =/+/−/@/normal marker cases; Excel has no formula cells and numeric
cells remain numeric. Actual results do not determine expected contract/oracle.

Canonical expectations were saved before execution and their SHA remains
`{expected_spec_sha}`. Candidate code is never modified or monkeypatched by these tests.

## F006 observation replacement

11 invalid time inputs + 5 types × 4 levels × 7 invalid count inputs = 151 cases.
Each produces its field-specific notice in the rendered response and no exam write.
Remaining session flash list is empty, explaining the two legacy failures. No status
change or validation relaxation is introduced; the response is the original R4 behavior.

## Native raw vs compatibility

| Native script | Raw frozen original | Current-contract test copy |
|---|---|---|
{native_table}

The six original scripts and four previous approved compatibility scripts are not
edited in their existing locations. Tests execute with no PYTHONPATH adapter and
no sitecustomize injection. Test-only patch and assertion AST proof are delivered
as reconciliation artifacts outside the immutable candidate.

## UI evidence

Linux + real Chromium/Playwright. Both 1366x768 and 1920x1080; focused-question
navigation 10/20/30/40/50/60; all five types/MathJax; genuine autosave saved and
offline failure states; submit modal/response; nonce regression; refresh/resume;
50-row monitor/search/filter/keyed updates; tabs; keyboard focus; no normal overflow.
0 browser page errors. Screenshots are genuine fixture runs, not Windows/physical PC.

| Requirement | Result | Fresh browser check |
|---|---|---|
{ui_table}

## HTTP load / limits

50-scope: {met50['request_count']} requests; {met50['failed_count']} unexpected failed;
{met50['HTTP_500_count']} HTTP 500. {met50['planned_timeouts']} planned 0.0005-second
read timeout tests retry and is not hidden as an unexplained failure.
60-scope: {met60['request_count']} requests; {met60['failed_count']} unexpected failed;
{met60['HTTP_500_count']} HTTP 500. Peak 60 concurrent requests. Answer/score comparisons
find no mismatch, cross-student contamination, lost submission or late overwrite.
CPU/RSS samples and raw events included. This is cloud Linux HTTP simulation using
the unmodified native app.py/Waitress entry point in its own data directory; no real
50-PC room, Windows runtime or EXE build is claimed.

## Integrity

BEFORE_SHA256 = AFTER_SHA256 = `{S}`.
The frozen extracted 64-file manifest and original working UI source also match.
No candidate, template, CSS/JS, backend, scoring, CSRF, license, MID, database of
the product or previous report/evidence is edited. Only newly generated disposable
fixture databases receive authorized test workflow writes; no production DB is opened.
'''
(O/'UI_RC1_CANONICAL_REGRESSION_REPORT.md').write_text(reg)
report=f'''# UI RC1 — Blocker reconciliation report

RECONCILIATION = PASS
PRODUCT_DEFECT_FOUND = NO (in scope examined)
PRODUCT_PATCH_REQUIRED = NO
PRODUCTION = NO

## Locked input

Input handoff SHA-256: `{before['handoff_sha256']}`.
Candidate before/after SHA-256: `{S}`.
CANDIDATE_MUTATED = NO. All handoff member checksums and ZIP CRC validated before
extracting. All 64 frozen files and the existing original UI source are unchanged.
The old RC1 reports, candidate ZIP, handoff ZIP, tests and raw evidence remain intact.

## D001 conclusion

D001_CLASSIFICATION = TEST_HARNESS_INCOMPATIBLE (all 4 failures).
D001_CANONICAL_RESULT = PASS.

The first failed request in v22/v222/v23 integration is multipart multi/import;
v221 is student import-preview. Passive observation of each unchanged script measures
403/no redirect/native CSRF body at the exact failed assertion. F011 requires nonce
from the same signed session before every unsafe POST, including import/login.
Legacy auth and operation tokens do not meet this precondition. Expected valid
302/200/DB/scoring behavior remains correct, so it is not obsolete functionality.
The approved test-only compatibility copies negotiate the real current nonce and
retain 76 original functional assertions. All 6 run standalone PASS. Negative
missing/wrong/session-other/stale nonce cases continue to return 403, with no business
mutation; legitimate multipart/form/JSON flows are accepted without false reject.
No product CSRF, status or authorization patch is justified.

## D002 conclusion — do not conflate three root causes

D002_CLASSIFICATION = LEGACY_EXPECTATION_OBSOLETE (3 expectations).
D002_CANONICAL_RESULT = PASS.

- F006 invalid-time and invalid-counts mixed-exam assertions observe session `_flashes`
  after rendering, whereas the native template has already displayed/consumed them.
  This is an obsolete observation assumption in the uncorrected legacy harness,
  not F012 or a new R4 product defect. The prior R3 UI observer documents the corrected
  observation layer. Canonical replacement verifies rendered field notice and unchanged
  exam state for all 151 malformed cases, retaining the functional requirement.
- F008 report-export expects marker metadata edited in the bank AFTER the exam to
  appear in historical Excel. Actual raw XLSX keeps R3EXCEL code/subject/Safe/NB and
  original question text, as Contract A requires. A return to live-bank metadata
  would break F012. Canonical replacement freezes marker before snapshot and then
  genuinely edits bank after submission; all report/Excel and attempt states remain
  unchanged, while Excel text/numeric safety is separately checked.

The precise per-assertion old/current contract, classification, replacement and result
are in UI_RC1_LEGACY_TEST_MATRIX.md and machine-readable evidence. No failed original
test is deleted, changed, skipped, xpassed or silently relabeled.

## Evidence sufficiency / decision

CONTRACT_EVIDENCE_INSUFFICIENT = NO. Current R4 security/history/test reports, middleware,
history readers, prior R3 observer and the explicit GV Contract A instruction agree.
Pre-R4 PREPROD undefined-contract audit is historical context, not the current policy.
Canonical expectations were written before execution; their checksum remains locked.

Fresh runs: R4 7/7; standalone native compatibility 6/6; browser 28/28 groups and all
UI01–UI28; CF011/CF006/CF012 3/3; 50 primary/mixed/deadline/race and 60 headroom PASS.
The new report resolves the current-contract gate only. LEGACY_RAW_RESULT remains
FAIL; the previous UI implementation report is not rewritten to say its old raw
suite passed. The candidate still contains its original legacy scripts: this round
does not claim build_exe.bat raw scripts pass without the separate test-only path.

No new release/candidate version is created, no RC2, no product patch or EXE build.
Windows and physical room acceptance still require GV action; not performed here.

## Final fields

```text
CANDIDATE_BEFORE_SHA256 = {S}
CANDIDATE_AFTER_SHA256 = {S}
CANDIDATE_MUTATED = NO
D001_CLASSIFICATION = TEST_HARNESS_INCOMPATIBLE
D001_CANONICAL_RESULT = PASS
D002_CLASSIFICATION = LEGACY_EXPECTATION_OBSOLETE
D002_CANONICAL_RESULT = PASS
R4_CANONICAL_REGRESSION = PASS
UI01_UI28 = PASS
CSRF_F011 = PASS
HISTORICAL_SNAPSHOT_F012 = PASS
50_CLIENT_SIMULATION = PASS
60_CLIENT_HEADROOM = PASS
PRODUCT_DEFECT_FOUND = NO
PRODUCT_PATCH_REQUIRED = NO
RECONCILIATION = PASS
WINDOWS_RUNTIME = NOT_RUN
PHYSICAL_50_PC = NOT_RUN
PRODUCTION = NO
```

STOP after these reports and artifact handoff; wait for GV decision.
'''
(O/'UI_RC1_BLOCKER_RECONCILIATION_REPORT.md').write_text(report)
share=O/'UI_RC1_RECONCILIATION_EVIDENCE';shutil.copytree(E,share)
h=share/'HARNESS';shutil.copytree(R/'harness',h,ignore=shutil.ignore_patterns('__pycache__'))
approved=h/'APPROVED_TEST_COMPATIBILITY';approved.mkdir()
for n in ['kiem_tra_v22.py','kiem_tra_v221.py','kiem_tra_v222.py','kiem_tra_v23_integration.py']:
 shutil.copy2(Path('/workspace/r4-windows-build-test-patch/candidate/PHAN_MEM')/n,approved/n)
members={'CANDIDATE/'+frozen.name:frozen}
for p in O.glob('*.md'):members['REPORTS/'+p.name]=p
for p in share.rglob('*'):
 if p.is_file():members['UI_RC1_RECONCILIATION_EVIDENCE/'+p.relative_to(share).as_posix()]=p
inner=''.join(sha(p)+'  '+name+'\n' for name,p in sorted(members.items()))
(O/'CHECKSUMS_UI_RC1_RECONCILIATION_CONTENTS.sha256').write_text(inner)
members['CHECKSUMS.sha256']=O/'CHECKSUMS_UI_RC1_RECONCILIATION_CONTENTS.sha256'
name='ThiTracNghiemLAN_v2.4_UI_RC1_RECONCILIATION_HANDOFF.zip'
with zipfile.ZipFile(O/name,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for member,p in sorted(members.items()):z.write(p,member)
with zipfile.ZipFile(O/name) as z:
 assert z.testzip() is None and z.read('CANDIDATE/'+frozen.name)==frozen.read_bytes()
 for member,p in members.items():assert hashlib.sha256(z.read(member)).hexdigest()==sha(p)
assert sha(frozen)==S
(O/'SHA256SUMS_UI_RC1_RECONCILIATION_ARTIFACTS.txt').write_text(S+'  '+frozen.name+'\n'+sha(O/name)+'  '+name+'\n')
proof=dict(candidate_before_sha256=S,candidate_after_sha256=sha(frozen),candidate_mutated=False,reconciliation='PASS',product_patch_required=False,handoff=dict(file=name,bytes=(O/name).stat().st_size,files=len(members),sha256=sha(O/name),ZIP_CRC='PASS',member_checksums='PASS',embedded_candidate_bytes_identical=True),Windows_runtime='NOT_RUN',physical_50_PC='NOT_RUN',production='NO')
(O/'UI_RC1_RECONCILIATION_PACKAGE_VALIDATION.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
