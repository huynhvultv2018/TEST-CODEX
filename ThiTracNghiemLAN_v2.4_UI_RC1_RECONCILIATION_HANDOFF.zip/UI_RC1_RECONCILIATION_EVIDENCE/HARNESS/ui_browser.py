"""Real Chromium + unmodified R4 server, disposable DB/license state, no adapters."""
import json,sys,threading,traceback,time
from pathlib import Path
from datetime import datetime,timedelta
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright
sys.path.insert(0,str(Path(__file__).resolve().parent))
from r4_support import runtime,seed,sql,ValidClient
ROOT=Path('/workspace/ui-rc1-reconciliation');E=ROOT/'evidence/ui';E.mkdir(parents=True,exist_ok=True)
results=[];errors=[];screens=[];types=['SINGLE','MULTI','TF','MATCH','FILL'];levels=['NB','TH','VD','VDC']
def check(name,fn):
  try: detail=fn();results.append(dict(id=name,status='PASS',detail=detail));print(name,'PASS',flush=True)
  except Exception:results.append(dict(id=name,status='FAIL',traceback=traceback.format_exc()));print(name,'FAIL',flush=True)
def dims(p):
  return p.evaluate('''() => ({width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,overflow:document.documentElement.scrollWidth>innerWidth})''')
def save_shot(p,name):
  p.screenshot(path=str(E/name),full_page=False);screens.append(name)
with runtime(ROOT/'frozen-source/PHAN_MEM',E) as (m,teacher,root):
  for kind in types:
    for lv in levels:
      for number in range(3):seed(m,teacher,f'UI_{kind}_{lv}_{number}',kind,subject='Tin học',level=lv,text=f'{kind} — {lv}: tính $2^3$ và $\\frac{{1}}{{2}}$.',weights='1,3' if kind in ['TF','MATCH','FILL'] else '')
  for i in range(1,51):assert teacher.post('/teacher/student/add',data=dict(ma_hs=f'HS{i:03d}',ho_ten=f'Học sinh kiểm thử {i:02d}',lop='8A')).status_code==302
  exam_ids={}
  for n in [10,20,30,40,50,60]:
    remaining=n;fields=dict(ten=f'Kiểm tra Tin học — {n} câu',mon='Tin học',lop='8A',thoi_gian='30',hien_diem='on',chu_de='Chủ đề, có dấu phẩy')
    for k in types:
      for lv in levels:
        count=min(3,remaining);fields[k+'_'+lv]=str(count);remaining-=count
    assert teacher.post('/teacher/create-exam',data=fields).status_code==302
    exam_ids[n]=sql(m,'SELECT MAX(id) FROM ky_thi')[0][0]
  # 40 attempts and 10 not entered: monitor derives status from actual R4 API.
  for i in range(2,41):
    c=ValidClient(m.app.test_client());assert c.post('/',data={'ma_hs':f'HS{i:03d}','ky_thi_id':exam_ids[50]}).location=='/exam'
  server=make_server('127.0.0.1',0,m.app,threaded=True);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}'
  try:
    with sync_playwright() as pw:
      browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
      tc=browser.new_context(viewport={'width':1366,'height':768});tp=tc.new_page();tp.on('pageerror',lambda e:errors.append(dict(page='teacher',error=str(e))))
      def teacher_login():
        tp.goto(url+'/teacher/login');tp.locator('input[name=username]').fill('admin');tp.locator('input[name=password]').fill('123456');tp.locator('form button').click();tp.wait_for_url('**/teacher');assert tp.locator('[data-module=dashboard]').is_visible();return 'Native form login; rotated CSRF nonce.'
      check('LOGIN_TEACHER',teacher_login)
      def sidebar():
        assert tp.locator('.side-nav a').count()==8
        for key in ['exams','bank','students','monitor','reports','system','license','dashboard']:
          tp.locator(f'[data-nav={key}]').click();tp.wait_for_load_state('domcontentloaded');assert tp.locator(f'[data-nav={key}]').get_attribute('aria-current')=='page'
        assert not tp.locator('#createExamForm').is_visible();assert not tp.locator('[data-live-math-form]').is_visible();return 'Eight modules; hidden add/import forms on dashboard.'
      check('UI01_UI02_SIDEBAR_ACTIVE',sidebar)
      def dashboard1366():
        tp.wait_for_function("document.getElementById('server_health').textContent.includes('✓')");tp.wait_for_function("document.querySelector('[data-count=total]').textContent==='50'")
        assert not dims(tp)['overflow'];save_shot(tp,'01_TEACHER_DASHBOARD_1366.png');return dims(tp)
      check('UI03_TEACHER_1366',dashboard1366)
      def teacher1920():
        tp.set_viewport_size({'width':1920,'height':1080});assert not dims(tp)['overflow'];d=dims(tp);tp.set_viewport_size({'width':1366,'height':768});return d
      check('UI04_TEACHER_1920',teacher1920)
      def wizard():
        tp.goto(url+'/teacher?view=exams');tp.locator('input[name=ten]').fill('UI wizard — comma topic');tp.locator('#wizard_next').click();tp.locator('#exam_mon').select_option('Tin học');tp.locator('#createExamForm input[name=chu_de]').check();tp.wait_for_function("document.getElementById('av_FILL_VDC').textContent==='3'");tp.locator('#wizard_next').click()
        assert tp.locator('[data-wizard-step="2"]').is_visible();assert tp.locator('input[name$="_NB"]').count()==5
        tp.locator('#q_SINGLE_NB').fill('99');assert tp.locator('#create_exam_btn').is_disabled();tp.locator('#q_SINGLE_NB').fill('1')
        for k in types[1:]:tp.locator(f'#q_{k}_NB').fill('1')
        tp.locator('#wizard_next').click();assert '5 câu' in tp.locator('#wizard_summary').inner_text();assert not tp.locator('#create_exam_btn').is_disabled();tp.locator('#create_exam_btn').click();tp.wait_for_url('**/teacher')
        eid=sql(m,'SELECT id FROM ky_thi WHERE ten=?',('UI wizard — comma topic',))[0][0];row=sql(m,'SELECT * FROM ky_thi WHERE id=?',(eid,))[0];qs=m.build_exam(row);assert len(qs)==5 and {q['type'] for q in qs}==set(types);return dict(five_types=True,comma_topic_roundtrip=True,availability_blocks_99=True)
      check('WIZARD_MATRIX_COMMA_TOPIC',wizard)
      def monitor():
        tp.goto(url+f'/teacher/monitor/{exam_ids[50]}');tp.wait_for_function("document.querySelectorAll('#monitor_body tr').length===50")
        assert tp.locator('#n_total').inner_text()=='50';assert tp.locator('#n_entered').inner_text()=='39';assert tp.locator('#n_not').inner_text()=='11'
        assert tp.locator('#monitor_body tr').count()==50;assert 'Chưa có dữ liệu' in tp.locator('#monitor_body tr').first.inner_text()
        tp.locator('#monitor_search').fill('HS012');assert tp.locator('#monitor_body tr:visible').count()==1
        tp.locator('#monitor_search').fill('');tp.locator('[data-filter="Chưa vào"]').click();assert tp.locator('#monitor_body tr:visible').count()==11
        tp.locator('[data-filter=""]').click();tp.locator('#monitor_search').focus();tp.evaluate("window.firstMonitorRow=document.querySelector('#monitor_body tr')");tp.wait_for_timeout(3300);assert tp.evaluate("window.firstMonitorRow===document.querySelector('#monitor_body tr')");assert tp.locator('#monitor_search').evaluate('(e)=>document.activeElement===e')
        assert not dims(tp)['overflow'];save_shot(tp,'02_MONITOR_50_1366.png');return dict(rows=50,filter=True,search=True,keyed_update=True,poll_ms=3000,dimensions=dims(tp))
      check('UI23_MONITOR_50_ROWS',monitor)
      sc=browser.new_context(viewport={'width':1366,'height':768});sp=sc.new_page();sp.on('pageerror',lambda e:errors.append(dict(page='student',error=str(e))))
      def student_login(n=50):
        sp.goto(url+'/');sp.locator('input[name=ma_hs]').fill('HS001');sp.locator('select[name=ky_thi_id]').select_option(str(exam_ids[n]));sp.locator('form button').click();sp.wait_for_url('**/exam');sp.wait_for_function("document.querySelectorAll('.question:not([hidden])').length===1")
        return dict(attempt=sql(m,'SELECT id FROM bai_thi WHERE ma_hs=? AND ky_thi_id=?',('HS001',exam_ids[n]))[0][0])
      check('LOGIN_STUDENT',student_login)
      aid=sql(m,'SELECT id FROM bai_thi WHERE ma_hs=? AND ky_thi_id=?',('HS001',exam_ids[50]))[0][0];items=json.loads(sql(m,'SELECT de_json FROM bai_thi WHERE id=?',(aid,))[0][0])
      def navigation():
        assert sp.locator('[data-jump]').count()==50;assert sp.locator('[data-jump="0"]').get_attribute('aria-label').find('Chưa trả lời')>=0
        sp.locator('#question_next').click();assert sp.locator('.question:visible').get_attribute('data-index')=='1';sp.locator('#question_prev').click();assert sp.locator('.question:visible').get_attribute('data-index')=='0'
        sp.locator('[data-jump="49"]').click();assert sp.locator('#question_next').is_disabled();sp.locator('#question_flag').click();assert 'Đánh dấu xem lại' in sp.locator('[data-jump="49"]').get_attribute('aria-label');sp.locator('[data-jump="0"]').click();assert sp.locator('#question_prev').is_disabled();return dict(direct=True,previous_next=True,flag=True,unanswered=True)
      check('UI07_UI09_UI10_UI11_UI12_NAVIGATOR',navigation)
      def answer(i,q):
        sp.locator(f'[data-jump="{i}"]').click();node=sp.locator(f'.question[data-index="{i}"]');v=q['answer']
        if q['type']=='SINGLE':node.locator(f'input[value="{v}"]').check()
        elif q['type']=='MULTI':
          for value in v:node.locator(f'input[value="{value}"]').check()
        elif q['type'] in ['TF','MATCH']:
          for j,value in enumerate(v):node.locator(f'select[name="q_{i}_{j}"]').select_option(str(value))
        else:
          for j,value in enumerate(v):node.locator(f'input[name="q_{i}_{j}"]').fill(value[0]);node.locator(f'input[name="q_{i}_{j}"]').blur()
        sp.wait_for_function(f"document.getElementById('s{i}').textContent==='Đã lưu'")
        # Wait for final queue request as well; no changed autosave cadence.
        sp.evaluate(f'()=>queues[{i}]');assert 'Đã trả lời' in sp.locator(f'[data-jump="{i}"]').get_attribute('aria-label')
      for k in types:
        def test_kind(k=k):
          i=next(i for i,q in enumerate(items) if q['type']==k);answer(i,items[i]);return dict(index=i,autosave_confirmed=True,input_names_preserved=True)
        check({'SINGLE':'UI13','MULTI':'UI14','TF':'UI15','MATCH':'UI16','FILL':'UI17'}[k]+'_'+k,test_kind)
      def math():
        for k in types:
          i=next(i for i,q in enumerate(items) if q['type']==k);sp.locator(f'[data-jump="{i}"]').click();sp.wait_for_function(f"document.querySelector('.question[data-index=\"{i}\"] mjx-container svg')!==null")
        return dict(offline_MathJax=True,all_five_types=True)
      check('UI18_MATHJAX',math)
      def visual_save():
        # R4 shuffles question order. Locate SINGLE by snapshot metadata, never assume index 0.
        i=next(i for i,q in enumerate(items) if q['type']=='SINGLE');sp.locator(f'[data-jump="{i}"]').click();assert sp.locator(f'#s{i}').get_attribute('data-save-state')=='saved'
        sc.set_offline(True)
        try:
          # The chosen option must differ from the checked option; same-value check is a no-op.
          sp.locator('.question:visible input[type=radio]:not(:checked)').first.check();sp.wait_for_function(f"document.getElementById('s{i}').dataset.saveState==='failed'");assert 'Đã lưu' not in sp.locator(f'#s{i}').inner_text()
        finally:sc.set_offline(False)
        answer(i,items[i]);return dict(index=i,confirmed_saved=True,offline_failed_not_faked=True)
      check('UI08_UI19_ANSWERED_AND_AUTOSAVE',visual_save)
      def student1366():
        sp.locator('[data-jump="0"]').click();assert not dims(sp)['overflow'];assert sp.locator('#open_submit').bounding_box()['y']+sp.locator('#open_submit').bounding_box()['height']<=768;save_shot(sp,'03_STUDENT_EXAM_1366.png');return dims(sp)
      check('UI05_STUDENT_1366',student1366)
      def student1920():
        sp.set_viewport_size({'width':1920,'height':1080});assert not dims(sp)['overflow'];save_shot(sp,'05_STUDENT_EXAM_1920.png');d=dims(sp);sp.set_viewport_size({'width':1366,'height':768});return d
      check('UI06_STUDENT_1920',student1920)
      def refresh_resume():
        before=[dict(x) for x in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))];sp.reload();sp.wait_for_function("document.querySelectorAll('.question:not([hidden])').length===1");assert sp.locator('[data-jump="49"]').get_attribute('aria-label').find('Đánh dấu xem lại')>=0
        for k in types:
          i=next(i for i,q in enumerate(items) if q['type']==k);assert 'Đã trả lời' in sp.locator(f'[data-jump="{i}"]').get_attribute('aria-label')
        assert before==[dict(x) for x in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))];return dict(saved_answers_preserved=True,flags_presentation_only=True)
      check('UI28_REFRESH_RESUME',refresh_resume)
      def csrf():
        before=[dict(x) for x in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))]
        for h in [{},{'X-CSRF-Token':'wrong'}]:
          r=sc.request.post(url+'/api/save-answer',data={'index':0,'choice':0},headers=h);assert r.status==403
        assert before==[dict(x) for x in sql(m,'SELECT * FROM cau_tra_loi WHERE bai_thi_id=?',(aid,))];return dict(raw_missing_wrong_rejected=403,positive_UI_nonce=True)
      check('UI27_CSRF_NEW_UI',csrf)
      def modal():
        sp.locator('#open_submit').click();assert sp.locator('#submit_dialog').is_visible();assert '5 / 50' in sp.locator('#submit_summary').inner_text();assert '45 câu chưa trả lời' in sp.locator('#submit_missing').inner_text();assert sp.locator('#submit_dialog input').count()==0;sp.locator('#cancel_submit').click();assert not sp.locator('#submit_dialog').is_visible();return dict(counts_exact=True,missing_question_list=True,return_without_submit=True)
      check('UI20_UI21_SUBMIT_MODAL_WARNING',modal)
      def focus():
        sp.locator('[data-jump="1"]').focus();assert sp.locator('[data-jump="1"]').evaluate('(e)=>document.activeElement===e');style=sp.locator('[data-jump="1"]').evaluate('(e)=>getComputedStyle(e).outlineWidth');assert style=='3px';sp.keyboard.press('Enter');assert sp.locator('.question:visible').get_attribute('data-index')=='1';return dict(keyboard_navigation=True,outline=style)
      check('UI26_KEYBOARD_FOCUS',focus)
      def submit():
        sp.locator('#open_submit').click();sp.locator('#confirm_submit').click();sp.wait_for_url('**/result');assert 'Nộp bài thành công' in sp.locator('.success-heading').inner_text();row=dict(sql(m,'SELECT * FROM bai_thi WHERE id=?',(aid,))[0]);assert row['submitted_at'];return dict(server_confirmed=True,score=row['diem'])
      check('UI22_SUCCESSFUL_SUBMIT',submit)
      def reports():
        tp.goto(url+f'/teacher/report/{exam_ids[50]}');tp.wait_for_function("document.querySelectorAll('[data-report-panel]:not([hidden])').length===1")
        assert tp.locator('[data-report-tab]').count()==5
        for name in ['students','questions','levels','export','overview']:
          tp.locator(f'[data-report-tab={name}]').click();assert tp.locator(f'[data-report-panel={name}]').is_visible();assert tp.locator(f'[data-report-tab={name}]').get_attribute('aria-selected')=='true';assert not dims(tp)['overflow']
        save_shot(tp,'04_REPORT_1366.png');return dict(tabs=5,existing_report_data=True,no_new_classification=True)
      check('UI24_REPORT_TABS',reports)
      def all_sizes():
        for n in [10,20,30,40,60]:
          student_login(n);assert sp.locator('[data-jump]').count()==n;sp.locator(f'[data-jump="{n-1}"]').click();assert sp.locator('.question:visible').get_attribute('data-index')==str(n-1);assert not dims(sp)['overflow']
        return dict(sizes=[10,20,30,40,50,60],no_horizontal_overflow=True)
      check('UI07_UI25_10_TO_60_QUESTIONS',all_sizes)
      def other_teacher_resolutions():
        pages=['/teacher?view=exams',f'/teacher/monitor/{exam_ids[50]}',f'/teacher/report/{exam_ids[50]}','/teacher/mixed-exam']
        observed=[]
        for width,height in [(1366,768),(1920,1080)]:
          tp.set_viewport_size({'width':width,'height':height})
          for path in pages:
            tp.goto(url+path);tp.wait_for_load_state('domcontentloaded');assert not dims(tp)['overflow'];observed.append(dict(path=path,dimensions=dims(tp)))
        tp.set_viewport_size({'width':1366,'height':768});return observed
      check('UI03_UI04_UI25_OTHER_TEACHER_PAGES',other_teacher_resolutions)
      def alternate_wizard():
        tp.goto(url+'/teacher/mixed-exam');tp.locator('input[name=ten]').fill('UI alternate wizard');tp.locator('#simple_next').click();tp.locator('input[name=mon]').fill('Tin học');tp.locator('#simple_next').click();tp.locator('input[name=TF_TH]').fill('1');tp.locator('#simple_next').click();assert tp.locator('[data-simple-step="3"]').is_visible();tp.locator('[data-simple-step="3"] button').click();tp.wait_for_url('**/teacher')
        e=sql(m,'SELECT * FROM ky_thi WHERE ten=?',('UI alternate wizard',))[0];q=m.build_exam(e);assert len(q)==1 and q[0]['type']=='TF';return dict(steps=4,original_field_contract=True,server_validated=True)
      check('ALTERNATE_CREATE_WIZARD',alternate_wizard)
      def machine_identity():
        first=m.machine_id();second=m.machine_id();assert first==second
        # No identifier or activation key is recorded in shareable evidence.
        return dict(same_process_stable=True,algorithm_source_hash_unchanged=True,identifier_changed=False,license_reset=False,Windows_hardware_identity='NOT_RUN')
      check('MACHINE_IDENTITY_LOCK',machine_identity)
      check('JAVASCRIPT_ERRORS',lambda: 'No page errors' if not errors else (_ for _ in ()).throw(AssertionError(errors)))
      browser.close()
  finally:server.shutdown();thread.join(timeout=3)
(E/'results.json').write_text(json.dumps(dict(results=results,screenshots=screens,javascript_errors=errors),ensure_ascii=False,indent=2)+'\n')
raise SystemExit(int(any(r['status']=='FAIL' for r in results)))
