# WINDOWS BUILD FAILURE AUDIT — R4 — NO PATCH

Ngày lập: 03/10/2026 (UTC+07). Phạm vi: audit lỗi tại test gate của `build_exe.bat`; không patch, không build EXE, không nghiệm thu Windows/physical thay thế.

## Kết luận bắt buộc

```text
BASELINE_IDENTITY = PASS (55/55 file PHAN_MEM được cung cấp khớp byte với R4)
FAILED_TEST = kiem_tra_v22.py:36 — assert response.status_code == 302
FAILED_REQUEST = POST /teacher/multi/import, tạo tại kiem_tra_v22.py:35
EXPECTED_STATUS = 302 (assertion gốc giữ nguyên)
ACTUAL_STATUS = 403 (reproduction tối thiểu); raw status Windows chưa được cung cấp
ROOT_CAUSE = Request legacy thiếu csrf_token/X-CSRF-Token dù có session ADMIN
CLASSIFICATION = C — TEST_SETUP_INCOMPLETE
CSRF_RELATED = YES
RUNTIME_DEFECT = NO (đối với failure/request được audit)
LEGACY_TEST_DEFECT = YES (request setup thiếu CSRF, không phải assertion 302 sai)
DATABASE_IMPACT = AUDIT_RAM_ONLY; BUILD_TEST_TEMP_EXPECTED; WINDOWS_ACTUAL_FILES_UNCONFIRMED
NEXT_TEST_COMPATIBILITY_RISK = 16 POST call-sites thiếu CSRF trong 4/6 script build
PATCH_REQUIRED = YES — TEST_ONLY (không thực hiện trong audit)
TECHNICAL_RECOMMENDATION = PATCH_TEST_ONLY
R4_STATUS = PENDING_WINDOWS_VALIDATION
WINDOWS_ACCEPTANCE = NOT_VERIFIED
PHYSICAL_50_PC_LAN = NOT_TESTED
```

**Đúng một khuyến nghị kỹ thuật: PATCH_TEST_ONLY.** Trong một vòng được phép patch sau này, hoàn thiện setup/transport của các request dương tính trong test để nhận nonce thật từ HTML/session của ứng dụng và gửi nonce hiện hành trong form hoặc header, bao gồm JSON/multipart. Giữ assertion/status, kiểm tra dữ liệu, scoring và các negative CSRF tests. Không bỏ test, không hạ gate, không disable/exempt CSRF, không hard-code valid token, không sửa runtime hoặc build script. **Chưa triển khai khuyến nghị này.**

## 1. Input lock và nguồn audit

- R4 candidate có sẵn trong workspace: `/workspace/TEST-CODEX/ThiTracNghiemLAN_v2.3.1_HOTFIX_R4_CANDIDATE.zip`.
- Candidate size: **785.622 byte**; SHA-256 thực tế và expected: `68219167829986f39d025251bf4681d7298e6c652689420d82cfe8a08d130ec2`.
- Upload: `PHAN_MEM.rar`, **679.535 byte**; SHA-256: `c8582ee17f4b1351c11f301478a9cebdb5a4db863dade9207cdab9f589bdab13`.
- Đọc RAR5 bằng libarchive ở chế độ đọc; không giải nén source/runtime ra filesystem.
- So sánh từng byte của **toàn bộ 55 regular files PHAN_MEM** với 55 members tương ứng trong candidate: **55 khớp, 0 missing, 0 changed, 0 extra files**. 61 entries RAR gồm 55 file và 6 directory entries.
- Việc này xác minh source được gửi để audit. Không mở được filesystem Windows ngoài archive nên không suy ra trạng thái những runtime/config/log không được gửi. RAR không có DB, WAL/SHM, backup, license/trial state hoặc log.
- Input và source hash được kiểm lại sau reproduction; 55 file frozen-source trong workspace vẫn khớp candidate. Git tracked files không có thay đổi.

| Source quan trọng | Byte | SHA-256 |
|---|---:|---|
| PHAN_MEM/app.py | 97037 | `44e6e3b5d2cee170f056a80172a7a46ab70ee0a97577165b048adb3130a19edb` |
| PHAN_MEM/multi_routes.py | 18461 | `25d79f309126a33dc77dde6dad7768633592657d677b6766808b86db6beec18f` |
| PHAN_MEM/build_exe.bat | 3333 | `a5bb8b2ebae79389663994fe32b9565e9c335958fd0f5d2f3ee6fe3fdfe41bfd` |
| PHAN_MEM/kiem_tra_v22.py | 4504 | `9a5aff86aecfc44180eb09c4883d47185a03092107a65f592ae7876afa463929` |

## 2. Windows evidence và giới hạn reproduction

Thông tin **người dùng báo**: Windows 10; `python --version` và `py --version` là Python 3.12.6; requirements cài thành công; assertion tại `kiem_tra_v22.py:36` lỗi rồi batch in “DONG GOI KHONG THANH CONG”; có log “Automatic daily backup created: auto_20261003.db”.

Không có raw HTTP status/Location/body hoặc full Windows log trong input. Vì vậy **403 là status đo trong reproduction**, không ghi thành raw Windows response đã quan sát.

Reproduction thực hiện trên **Linux, Python 3.12.14, Flask 3.1.3, Werkzeug 3.1.9, openpyxl 3.1.5**. Không có Windows host được kết nối. Cùng failure được tái hiện từ đúng code R4; không cần Windows-specific path hay Python 3.12.6 để kích hoạt CSRF rejection. Không chạy batch/PyInstaller, toàn bộ suite, application startup, license functions, machine getter hoặc reboot.

## 3. Build gate và thứ tự test

`build_exe.bat` chọn `py -3` nếu launcher tồn tại, nếu không dùng `python`; chạy version check rồi `-m pip install -r requirements.txt`. Bare `py --version` là evidence người dùng cung cấp, không phải một phép xác minh interpreter `py -3` mới trong phiên audit.

| Thứ tự | Lệnh trong batch | Dòng batch | Hành vi lỗi |
|---:|---|---:|---|
| 1 | kiem_tra_v22.py | 45 | line 46: errorlevel → failed |
| 2 | kiem_tra_v221.py | 47 | line 48: errorlevel → failed |
| 3 | kiem_tra_mathjax.py | 49 | line 50: errorlevel → failed |
| 4 | kiem_tra_v222.py | 51 | line 52: errorlevel → failed |
| 5 | kiem_tra_v23.py | 54 | line 55: errorlevel → failed |
| 6 | kiem_tra_v23_integration.py | 56 | line 57: errorlevel → failed |

PyInstaller chỉ được gọi ở batch **line 60–67**, sau khi cả 6 script qua gate. Với assertion failure ở script đầu, batch nhảy đến **line 104–108**, in failure và exit 1. Đây là lỗi test gate trước đóng gói; chưa có bằng chứng PyInstaller chạy rồi thất bại. Các test sau không được batch chạy trong lần dừng này. Không bypass gate hoặc build EXE thủ công để audit.

## 4. Chính xác request tại line 36

Source giữ nguyên:

```python
# kiem_tra_v22.py:30–36
with client.session_transaction() as s:
    s['teacher_logged_in']=True;s['teacher_role']='ADMIN';s['teacher_username']='admin'
for url in ['/teacher','/teacher/multi','/teacher/multi/new','/teacher/mixed-exam']:
    assert client.get(url).status_code==200,url
sample=client.get('/teacher/multi/excel?sample=1'); assert sample.status_code==200
response=client.post('/teacher/multi/import',data={'file':(BytesIO(sample.data),'sample.xlsx')},content_type='multipart/form-data')
assert response.status_code==302
```

- HTTP method: **POST**.
- URL: **/teacher/multi/import**.
- Multipart request: field `file`, filename `sample.xlsx`, workbook từ GET sample của route R4; 5 hàng câu hỏi SINGLE/MULTI/TF/MATCH/FILL.
- Không có `csrf_token` trong form; không có `X-CSRF-Token` header.
- Auth setup: `teacher_logged_in=True`, `teacher_role=ADMIN`, `teacher_username=admin`. Không POST teacher login; không có lỗi login helper tại dòng này.
- Session có thể đã nhận nonce khi GET các template trước đó; **nonce trong session không tự trở thành nonce được gửi lên POST**. Reproduction chứng minh rejection ngay cả khi server-session có nonce thật và cookie đúng.
- Origin/Referer không được legacy test cung cấp. Không cần foreign-origin để gây lỗi: missing submitted nonce đủ để reject.
- Expectation legacy giữ nguyên **302**; actual reproduction **403**, **Location absent**, body text bên dưới.
- Guard R4 tại `app.py:59–78` chạy trước license hook `585–609`, maintenance `611–615` và route handler. Không bắt đầu import/parse/DB insert khi thiếu nonce.

Body đo được:

```text
Yêu cầu không hợp lệ (CSRF). Hãy mở lại trang và gửi từ ứng dụng.
```

## 5. Reproduction tối thiểu và trace

Không import toàn bộ `app.py`: module import đó có thể tạo secret/directory/log files; không gọi `init_db`, license hoặc daily maintenance native. Đọc byte từ archive vào RAM; compile **nguyên function AST** của `csrf_token`, `inject_csrf`, `protect_csrf` và `teacher_required` trong Flask app riêng. Thực thi modules R4 `snapshot_validation/question_types/scoring/multi_routes` nguyên byte trong memory và đăng ký **chính** `multi_excel/multi_import` của `install_multi_routes`.

Setup có cùng các session ADMIN fields như test gốc. Một form HTML của harness gọi context processor và `csrf_token()` R4 nguyên vẹn để nhận nonce thật trong cùng signed session. Nonce không bị hard-code hoặc công khai. Fixtures DB chỉ là SQLite URI `mode=memory&cache=shared`; schema/extra columns được lấy từ source R4. Các startup/license/backup paths không được gọi. Đây là isolated functional reproduction của CSRF/auth/import, **không phải chạy đầy đủ Windows runtime hoặc chứng minh license gate**.

Dùng profiler chỉ quan sát function entry, không thay function/route/CSRF body. Hàm CSRF luôn được đăng ký và chạy trong cả ba case.

| Case | Expected test gốc | Expected contract R4 | Actual | Location | Import handler | Số câu RAM | DB RAM thay đổi |
|---|---:|---:|---:|---|---|---:|---|
| Cùng legacy multipart, thiếu submitted nonce | 302 | 403 | **403** | Không có | Không vào | 0 | Không |
| Nonce sai, cùng authenticated cookie/session | — | 403 | **403** | Không có | Không vào | 0 | Không |
| Nonce thật của cùng session trong form | 302 | 302 | **302** | /teacher/multi?khoi=6&mon=Tin+h%E1%BB%8Dc | Có vào | **5** | Có, chỉ fixture RAM |

Positive case không chỉ nhìn 302: query xác nhận đúng 5 rows VD1…VD5 với SINGLE/MULTI/TF/MATCH/FILL, khối 6, môn Tin học; profiler thấy 5 `insert` calls. Điều này loại khả năng route redirect vì import-error nhưng test vẫn “PASS”.

Negative trace chỉ có `protect_csrf`; không `multi_import`, không `insert`; RAM database digest trước/sau bằng nhau. Positive trace: `protect_csrf → teacher_required.wrapped → multi_import → values/insert`.

Flask logger của ba request trong reproduction: **không có message**. Source guard không gọi logger trước khi trả 403. Log Windows automatic backup người dùng báo không phải log của guard; xem phần database. Không tạo file Flask log giả để bổ sung dữ liệu thiếu.

### Trace đo được đã loại nonce/cookie values

```json
[
  {
    "case": "ORIGINAL_LEGACY_REQUEST_MISSING_CSRF",
    "method": "POST",
    "route": "/teacher/multi/import",
    "request_data": {
      "file_field": "file",
      "filename": "sample.xlsx",
      "workbook_rows": 5,
      "question_types": [
        "SINGLE",
        "MULTI",
        "TF",
        "MATCH",
        "FILL"
      ],
      "csrf_form_field": false,
      "csrf_header": false
    },
    "session": {
      "teacher_logged_in": true,
      "teacher_role": "ADMIN",
      "teacher_username": "admin",
      "server_nonce_present": true,
      "nonce_value": "NOT_DISCLOSED",
      "signed_cookie_present": true
    },
    "original_test_expected_status": 302,
    "current_R4_contract_expected_status": 403,
    "actual_status": 403,
    "Location": null,
    "response_body": "Yêu cầu không hợp lệ (CSRF). Hãy mở lại trang và gửi từ ứng dụng.",
    "handler_entered": false,
    "RAM_database_unchanged": true,
    "RAM_question_count": 0,
    "observed_source_calls": [
      {
        "function": "protect_csrf",
        "line": 59
      }
    ],
    "Flask_log_for_request": ""
  },
  {
    "case": "INVALID_CSRF_NEGATIVE",
    "method": "POST",
    "route": "/teacher/multi/import",
    "request_data": {
      "file_field": "file",
      "filename": "sample.xlsx",
      "workbook_rows": 5,
      "question_types": [
        "SINGLE",
        "MULTI",
        "TF",
        "MATCH",
        "FILL"
      ],
      "csrf_form_field": true,
      "csrf_header": false
    },
    "session": {
      "teacher_logged_in": true,
      "teacher_role": "ADMIN",
      "teacher_username": "admin",
      "server_nonce_present": true,
      "nonce_value": "NOT_DISCLOSED",
      "signed_cookie_present": true
    },
    "original_test_expected_status": null,
    "current_R4_contract_expected_status": 403,
    "actual_status": 403,
    "Location": null,
    "response_body": "Yêu cầu không hợp lệ (CSRF). Hãy mở lại trang và gửi từ ứng dụng.",
    "handler_entered": false,
    "RAM_database_unchanged": true,
    "RAM_question_count": 0,
    "observed_source_calls": [
      {
        "function": "protect_csrf",
        "line": 59
      }
    ],
    "Flask_log_for_request": ""
  },
  {
    "case": "VALID_CSRF_FORM",
    "method": "POST",
    "route": "/teacher/multi/import",
    "request_data": {
      "file_field": "file",
      "filename": "sample.xlsx",
      "workbook_rows": 5,
      "question_types": [
        "SINGLE",
        "MULTI",
        "TF",
        "MATCH",
        "FILL"
      ],
      "csrf_form_field": true,
      "csrf_header": false
    },
    "session": {
      "teacher_logged_in": true,
      "teacher_role": "ADMIN",
      "teacher_username": "admin",
      "server_nonce_present": true,
      "nonce_value": "NOT_DISCLOSED",
      "signed_cookie_present": true
    },
    "original_test_expected_status": null,
    "current_R4_contract_expected_status": 302,
    "actual_status": 302,
    "Location": "/teacher/multi?khoi=6&mon=Tin+h%E1%BB%8Dc",
    "response_body": "<!doctype html>\n<html lang=en>\n<title>Redirecting...</title>\n<h1>Redirecting...</h1>\n<p>You should be redirected automatically to the target URL: <a href=\"/teacher/multi?khoi=6&amp;mon=Tin+h%E1%BB%8Dc\">/teacher/multi?khoi=6&amp;mon=Tin+h%E1%BB%8Dc</a>. If not, click the link.\n",
    "handler_entered": true,
    "RAM_database_unchanged": false,
    "RAM_question_count": 5,
    "observed_source_calls": [
      {
        "function": "protect_csrf",
        "line": 59
      },
      {
        "function": "wrapped",
        "line": 121
      },
      {
        "function": "multi_import",
        "line": 205
      },
      {
        "function": "insert",
        "line": 90
      },
      {
        "function": "insert",
        "line": 90
      },
      {
        "function": "insert",
        "line": 90
      },
      {
        "function": "insert",
        "line": 90
      },
      {
        "function": "insert",
        "line": 90
      }
    ],
    "Flask_log_for_request": ""
  }
]
```

## 6. Contract lịch sử và phân loại

Chức năng v2.2 đang kiểm là **nhập workbook mẫu ngân hàng 5 dạng câu hỏi**, rồi redirect tới danh sách. `multi_routes.py:205–237` giữ contract đó khi request hợp lệ; test tiếp theo line 37 yêu cầu 5 câu trong DB.

Đối chiếu lịch sử ở mức source: sáu script build và `build_exe.bat` byte-identical giữa **R3 pre-F011** và R4. R3 không có `protect_csrf`, R4 có. R3 chỉ được đọc tĩnh làm tham chiếu trước F011, không chạy hoặc dùng làm baseline. Không có full original v2.2 artifact riêng trong input để tuyên bố một audit binary v2.2 độc lập; contract v2.2 ở đây được truy từ test mang tên v22 và route chức năng kế thừa.

| Contract | Kết luận cho request này |
|---|---|
| Chức năng v2.2 import Excel | Hợp lệ: import 5 câu rồi redirect 302 |
| R4 F010 defensive validation | Chưa được gọi ở failing case; valid fixture qua validation/import |
| R4 F011 CSRF | Unsafe request cần nonce hợp lệ của cùng session; thiếu/sai trả 403 trước route |
| R4 F012 historical snapshot contract A | Không có report/attempt/history liên quan tại failing request |

**C — TEST_SETUP_INCOMPLETE** có reproduction âm tính và dương tính. Assertion 302 không lỗi thời với một import hợp lệ; request setup cần điều kiện CSRF mới. Không chọn A vì guard/route đúng contract được kiểm; không chọn B vì expectation 302 vẫn có positive proof; không chọn D vì cùng guard failure được tái hiện trên Linux. Không quy lỗi cho Python 3.12.6, Windows Firewall, license, F010/F012 hoặc XLSX từ một AssertionError không có trace.

Kết luận runtime NO chỉ áp dụng failure cụ thể này; không là tuyên bố toàn bộ R4 không có lỗi.

## 7. TEST_COMPATIBILITY_FINDINGS — audit tĩnh các gate kế tiếp

**16 POST call-sites**, nằm trong 4 script, không có submitted CSRF/form header. Đây là count vị trí source, không là tổng số request thực thi: các loop có thể POST nhiều lần. Chỉ request import v22 được chạy bằng minimal reproduction; các rows dưới là **static findings**, không báo chúng đã thực thi hoặc PASS/FAIL trên Windows.

| Finding | Test / dòng | Request | Expectation gốc hoặc rủi ro tiếp theo |
|---|---|---|---|
| TC01 | kiem_tra_v22.py:35, assert 36 | POST /teacher/multi/import | 302; failure đã tái hiện |
| TC02 | kiem_tra_v22.py:41 | POST /teacher/mixed-exam | 302, thiếu nonce |
| TC03 | kiem_tra_v22.py:53 | POST /api/save-answer | 200, JSON không có X-CSRF-Token; loop 5 dạng |
| TC04 | kiem_tra_v22.py:59 | POST /exam | 302, thiếu nonce |
| TC05 | kiem_tra_v221.py:58 | POST /teacher/students/import-preview | 200 + preview body ở line 59, thiếu nonce |
| TC06 | kiem_tra_v221.py:61 | POST /teacher/students/import-confirm | follow_redirects=True, expects 200; token import khác nonce CSRF |
| TC07 | kiem_tra_v221.py:70 | POST /teacher/students/bulk, move | follow_redirects=True, expects 200; thiếu nonce |
| TC08 | kiem_tra_v221.py:74 | POST /teacher/students/bulk, delete | follow_redirects=True, expects 200; thiếu nonce |
| TC09 | kiem_tra_v222.py:67, assert 70 | POST /teacher/multi/import, new format | 302; thiếu nonce |
| TC10 | kiem_tra_v222.py:71, assert 74 | POST /teacher/multi/import, legacy format | 302; thiếu nonce |
| TC11 | kiem_tra_v23_integration.py:35, assert 36 | POST /teacher/multi/import | 302; cùng failure pattern đầu tiên |
| TC12 | kiem_tra_v23_integration.py:46 | POST /teacher/multi/edit/<id> | 302; loop câu hỏi; thiếu nonce |
| TC13 | kiem_tra_v23_integration.py:50 | POST /teacher/multi/import, roundtrip | Không assert status ngay, line 51 so DB; 403 sẽ chặn refill |
| TC14 | kiem_tra_v23_integration.py:54 | POST /teacher/mixed-exam | 302; thiếu nonce |
| TC15 | kiem_tra_v23_integration.py:68 | POST /api/save-answer | 200; JSON/header không nonce; loop |
| TC16 | kiem_tra_v23_integration.py:74 | POST /exam | 302; thiếu nonce |

`kiem_tra_mathjax.py`: GET-only, manual teacher session; không tìm cùng POST pattern. `kiem_tra_v23.py`: unit scoring, không Flask POST. Không chạy lại các script này và không suy ra chúng hoàn toàn tương thích chỉ từ việc không có POST.

Các manual auth sessions hiện có là fixture auth, không phải CSRF setup. `teacher_logged_in`/ADMIN, `attempt_id`/`client_token`, và `student_import_token` giải quyết các contract khác; không thay thế `_csrf_token` trong session cộng với submitted nonce. JSON request cần header thật hoặc transport hợp lệ; chỉ đưa token vào JSON body không được guard hiện tại đọc. Sau login/rotation phải dùng nonce hiện hành.

**Giới hạn validation trước đã xác minh:** `HOTFIX_R4_TEST_REPORT.md:9` ghi test cũ được chạy với adapter opt-in `transport/sitecustomize.py`; line 53 ghi `TNLAN_R4_VALID_CLIENT=1 PYTHONPATH=.../HOTFIX_R4_EVIDENCE/transport`. `FINAL_REGRESSION_REPORT.md:25` cũng nêu adapter lấy nonce HTML thật, không exemption. Adapter không có trong 55 file candidate và `build_exe.bat` không bật transport ấy. Vì thế PASS trước của suite có adapter **không chứng minh** sáu native build-test commands đóng băng đã tương thích standalone. Audit này ghi rõ khoảng trống đó; không sửa báo cáo cũ hoặc candidate để làm PASS.

## 8. DATABASE_IMPACT — chỉ đọc/static trace

### Vị trí theo source của test đang lỗi

`kiem_tra_v22.py:9–17`:

1. Tạo `tempfile.TemporaryDirectory(prefix='tnlan_test_', ignore_cleanup_errors=True)`.
2. Chỉ copy source `*.py` và templates vào thư mục temp; không copy database runtime gốc.
3. Đặt `LOCALAPPDATA` **trong child test process** thành `<tmp>/localappdata`.
4. Insert temp folder đầu `sys.path`, import app trong process test do batch khởi động mới.
5. Gọi `m.init_db()` hai lần trong temp folder.

App source-run `app.py:20–26` dùng `DATA_DIR = Path(__file__).resolve().parent`; `DB_PATH = DATA_DIR / "thi_trac_nghiem.db"` line 86; `BACKUP_DIR = DATA_DIR / "backups"` line 90. Với flow batch/script gốc và import resolution đó:

```text
TEST DB expected:
<Windows TEMP>\tnlan_test_<generated>\thi_trac_nghiem.db

DAILY BACKUP expected:
<Windows TEMP>\tnlan_test_<generated>\backups\auto_20261003.db

TRIAL fixture expected:
<same tmp>\license_trial.json
<same tmp>\localappdata\ThiTracNghiemLAN\<native-machine-id>.json
```

Các paths có placeholder vì absolute Windows temp path **không được gửi**. Không bịa path thực hoặc xác nhận file vẫn tồn tại.

`app.py:611–615` gọi `auto_backup_daily()` khi GET/POST `/teacher...` được đi qua các hook trước. `auto_backup_daily:290–299` tạo backup từ DB hiện có, log **basename** target. `create_sqlite_backup:163–170` dùng SQLite backup API. GET `/teacher/login` tại test line 20 là một điểm có thể tạo daily backup sau init và trước assertion line 36. Các GET teacher tiếp theo chỉ tạo nếu file theo ngày chưa tồn tại.

POST thiếu nonce bị hook CSRF ở đầu chặn, không chạy maintenance hook hay import insert. Vì vậy message automatic backup ngay trước assertion không chứng minh import đã ghi DB và không phải nguyên nhân của 403.

### Điều đã xác minh và chưa xác minh

- Theo source exact và cách batch launch process mới, các init/backup và trial-expiry fixture của test nhắm **DB/test state trong temp**, không DB production bên cạnh source original. Script không copy hoặc xóa DB original. `LOCALAPPDATA` thay trong child process không đổi environment Windows host hoặc terminal cha.
- Có tạo/đổi DB test qua init trước request; failing POST không insert 5 câu. Reproduction chứng minh latter bằng digest/row count RAM; không mở DB gốc để thử.
- Không có DB, WAL/SHM, backup hoặc Windows logs trong RAR. **Không có phép xác minh trực tiếp actual Windows DB/file timestamps/backup content**, không thể kết luận inventory DB thật, một file khác có bị thay đổi hay actual backup đã cleanup.
- Khi assertion phát sinh, TemporaryDirectory context vẫn cố cleanup. Windows file handle còn mở cùng `ignore_cleanup_errors=True` có thể khiến temp leftovers; chưa đo tại Windows. Không xóa hoặc phục hồi temp/database/backup nào trong audit.
- Auto backup function còn có retention code ở line 301–305; code đó không được audit thực thi. Không dùng log backup để suy ra retention đã xóa file gì.
- Backup `auto_20261003.db`, nếu còn tại Windows, cùng full paths/log/stat timestamps là evidence cần giữ nguyên theo yêu cầu audit; không reset/restore DB/license để điều tra. Chưa được cung cấp nên DATABASE_IMPACT đối với filesystem Windows vẫn **UNCONFIRMED**.
- Reproduction audit tạo schema và 5 rows **chỉ trong SQLite RAM fixture mới**. Không có database file trên disk, không đọc/ghi/xóa/restore database cũ; không import app startup, không gọi license/trial/machine getter.

## 9. Source freeze và stop gate

```text
UPLOADED_RAR_SOURCE_FILES_MATCH_R4 = 55/55
MISSING_SOURCE_FILES = 0
CHANGED_SOURCE_FILES = 0
EXTRA_REGULAR_FILES_IN_RAR = 0
ORIGINAL_RAR_UNCHANGED = YES
ORIGINAL_R4_CANDIDATE_UNCHANGED = YES
WORKSPACE_FROZEN_PHAN_MEM_UNCHANGED = YES
SOURCE_FILES_PATCHED = 0
EXISTING_DATABASE_FILES_OPENED_BY_REPRODUCTION = 0
TRIAL_OR_LICENSE_RESET = NO
MACHINE_ID_OVERRIDE = NO
CSRF_DISABLED_OR_EXEMPTED = NO
BUILD_OR_PYINSTALLER_EXECUTED = NO
AUDIT_CREATED = WINDOWS_BUILD_FAILURE_AUDIT_R4.md (ngoài source/runtime)
R4_STATUS = PENDING_WINDOWS_VALIDATION
```

Dừng audit tại đây. Không triển khai PATCH_TEST_ONLY; chưa nghiệm thu Windows hoặc physical 50-PC và chưa nâng Production.

